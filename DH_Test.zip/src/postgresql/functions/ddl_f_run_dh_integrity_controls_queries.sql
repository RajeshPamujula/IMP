DROP FUNCTION IF EXISTS f_run_dh_integrity_controls_queries();

CREATE OR REPLACE FUNCTION f_run_dh_integrity_controls_queries()
 RETURNS TABLE(quality_class character varying, table_name character varying, domn_nm character varying, description character varying, expected_output character varying, actual_output character varying)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
    queries CURSOR FOR
        SELECT t.query_id,
	       t.quality_class,	
               t.domn_nm,
               t.table_name,
               t.description,
               t.expected_output,
               t.query
        FROM   daas_tm_prepared.dh_monitor_integrity_control_queries t
        WHERE  t.active_status = 'A'
        ORDER  BY t.table_name, t.query_id;
    actual_output varchar(100);
BEGIN
    CREATE TEMP TABLE mytemp(
        id serial,
	query_id int,
	quality_class varchar(64),
	domn_nm varchar(100),
        table_name varchar(64),
        description varchar(100),
        expected_output varchar(100),
        actual_output varchar(100)
    ) on commit drop;
    
    FOR qry IN queries LOOP
        EXECUTE qry.query INTO actual_output;
        insert into mytemp(query_id, quality_class, domn_nm, table_name, description, expected_output, actual_output) 
		values(qry.query_id, qry.quality_class, qry.domn_nm, qry.table_name, qry.description, qry.expected_output, actual_output);
    END LOOP;

    EXECUTE 'insert into daas_tm_prepared.dh_monitor_integrity_control_results SELECT now(), t.query_id, t.quality_class, t.domn_nm, t.table_name, t.description, t.expected_output, t.actual_output FROM mytemp t order by t.id';
    RETURN QUERY SELECT t.quality_class, t.table_name, t.domn_nm, t.description, t.expected_output, t.actual_output FROM mytemp t order by t.id;
END;$function$
;
