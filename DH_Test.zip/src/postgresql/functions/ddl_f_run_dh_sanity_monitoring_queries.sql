CREATE OR REPLACE FUNCTION daas_tm_prepared.f_run_dh_sanity_monitoring_queries()
 RETURNS TABLE(table_name character varying, sor_de_name character varying, description character varying, actual_output character varying)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
    queries CURSOR FOR
        SELECT t.query_id,
               t.table_name,
               t.sor_de_name,
               t.description,
               t.query
        FROM   daas_tm_prepared.dh_sanity_monitoring_queries t
        WHERE  t.active_status = 'A'
        ORDER  BY t.table_name, t.query_id;
    actual_output varchar(100);
BEGIN
    CREATE TEMP TABLE mytemp(
        id serial,
        query_id int,
        table_name varchar(64),
		sor_de_name varchar(500),
        description varchar(100),
        actual_output varchar(100)
    ) on commit drop;
    
    FOR qry IN queries LOOP
        EXECUTE qry.query INTO actual_output;
        insert into mytemp(query_id, table_name, sor_de_name, description, actual_output) 
                             values(qry.query_id, qry.table_name, qry.sor_de_name, qry.description, actual_output);
    END LOOP;

    EXECUTE 'insert into daas_tm_prepared.dh_sanity_monitoring_results SELECT now(), t.query_id, t.table_name, t.sor_de_name, t.description, t.actual_output FROM mytemp t order by t.id';
    RETURN QUERY SELECT t.table_name, t.sor_de_name, t.description, t.actual_output FROM mytemp t order by t.id;
END;$function$
;
