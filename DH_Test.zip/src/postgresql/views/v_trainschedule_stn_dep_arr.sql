DROP VIEW IF EXISTS v_trainschedule_stn_dep_arr;

CREATE OR REPLACE VIEW v_trainschedule_stn_dep_arr AS
SELECT la_asct_obj_type.type_cd AS transaction_type
    , cnvy.id_val AS train_id
    , pec_type.type_cd AS arrival_departure
    , pec.char_val AS arrival_departure_date_time
    , MAX(la_loc_type.type_cd) AS location_type
    , MAX(rs.stn_333) AS stn_333
    , MAX(rs.stn_st) AS stn_st
    , MAX(rs.fsac) AS fsac
    , MAX(rs.scac) AS scac
    , MAX(CASE WHEN lac_type.type_cd = 'Station Sequence Number' THEN lac.char_val ELSE '' END) AS stn_seq_nbr
    , MAX(CASE WHEN lac_type.type_cd = 'Crew Change Indicator' THEN lac.char_val ELSE '' END) AS stn_seq_ts   
    , MAX(CASE WHEN lac_type.type_cd = 'Station Type Code' THEN lac.char_val ELSE '' END) AS stn_type_cd
FROM daas_tm_prepared.dh_cnvy cnvy
JOIN daas_tm_prepared.dh_rte rte ON cnvy.cnvy_key = rte.rte_key
JOIN daas_tm_prepared.dh_loc_asct la ON rte.rte_key = la.asct_obj_key
JOIN daas_tm_prepared.dh_loc_asct_char lac ON lac.asct_key = la.asct_key
JOIN daas_tm_prepared.dh_plan_evt_asct pea ON pea.asct_obj_key = la.asct_key
JOIN daas_tm_prepared.dh_ref_type lac_type ON lac_type.type_key = lac.char_type_key
JOIN daas_tm_prepared.dh_plan_evt pe ON pe.plan_evt_key = pea.plan_evt_key
JOIN daas_tm_prepared.dh_plan_evt_char pec ON pe.plan_evt_key = pec.plan_evt_key
JOIN daas_tm_prepared.dh_ref_type pec_type ON pec_type.type_key = pec.char_type_key
JOIN daas_tm_prepared.dh_rail_station rs ON rs.stn_fsac_key = la.loc_key
JOIN daas_tm_prepared.dh_ref_type la_asct_obj_type ON la_asct_obj_type.type_key = la.asct_obj_type_key
JOIN daas_tm_prepared.dh_ref_type la_loc_type ON la_loc_type.type_key = la.loc_type_key
WHERE la_asct_obj_type.type_cd =  'Train Schedule'
AND la.act_stus_ind = 1
GROUP BY transaction_type, train_id, arrival_departure, arrival_departure_date_time;
