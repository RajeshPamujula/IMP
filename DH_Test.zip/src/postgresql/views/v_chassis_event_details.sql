DROP VIEW IF EXISTS v_chassis_event_details;

CREATE OR REPLACE VIEW v_chassis_event_details
AS
SELECT t1.* 
FROM daas_tm_trusted.v_chassis_event_details_base t1
, (
  SELECT * 
       , ROW_NUMBER() OVER (PARTITION BY chassis_id, chassis_initial ORDER BY event_ts_utc DESC) rk
  FROM daas_tm_trusted.v_chassis_event_details_base t
) t2
WHERE t1.chassis_id = t2.chassis_id
AND t1.chassis_initial = t2.chassis_initial
AND t2.rk = 1;