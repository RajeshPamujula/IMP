DROP VIEW IF EXISTS v_car_condition;

CREATE OR REPLACE VIEW v_car_condition
AS
select rcar.eqp_init || rcar.eqp_nbr as eqp_id,
RCAR.eqp_init,
RCAR.eqp_nbr,
MAX(CASE WHEN cc_char_type.type_cd = 'Bad Order Code' THEN cnvy_cond.char_val ELSE '' END) AS bad_order_code,
Max(case when cc_char_type.type_cd = 'Mechanical Status Codes' then cnvy_cond.char_val else ' ' End) as hold_code
from DAAS_TM_PREPARED.DH_TRSP_EVT TDE
inner join daas_tm_prepared.dh_ref_type TDE_ETYPE on (TDE.TRSP_EVT_TYPE_KEY = TDE_ETYPE.type_key)
inner join daas_tm_prepared.dh_rcar_ref RCAR on (TDE.TRSP_EVT_KEY = rcar.rcar_key)
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond on (tde.trsp_evt_key = cnvy_cond.cnvy_key)
left join daas_tm_prepared.dh_ref_type cc_char_type on (cnvy_cond.char_type_key = cc_char_type.type_key)
where tde_etype.type_cd like 'Railcar Event' --- this is from Car Inventory
and TDE.act_stus_ind = 1
group by 1, 2, 3
;