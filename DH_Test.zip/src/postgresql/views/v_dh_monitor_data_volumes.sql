DROP VIEW IF EXISTS v_dh_monitor_data_volumes;


CREATE OR REPLACE VIEW dh_monitor_data_volumes
AS SELECT * from daas_tm_prepared.dh_monitor_job_details;