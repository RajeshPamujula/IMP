DROP VIEW IF EXISTS v_car_location;

CREATE OR REPLACE VIEW v_car_location
AS
select rcar.eqp_init || rcar.eqp_nbr as eqp_id,
RCAR.eqp_init,
RCAR.eqp_nbr,
Rail_STAT.stn_333,
Rail_STAT.stn_st,
MAX(CASE WHEN char_type.type_cd = 'Track Number' THEN TAC.char_val ELSE '' END) AS track_number,
MAX(CASE WHEN char_type.type_cd = 'Track Sequence Number' THEN TAC.char_val ELSE '' END) AS track_sequence_number,
Max(case when sa_char_type.type_cd = 'Current Assignment' then sa_char.char_val else ' ' End) as train_id,
Max(case when sa_char_type.type_cd = 'First Day of Change' then sa_char.char_val else ' ' End) as last_free_day,
Max(case when sa_char_type.type_cd = 'STCH Status Code' then sa_char.char_val else ' ' End) as stch_stat_cd
from DAAS_TM_PREPARED.DH_TRSP_EVT TDE
inner join daas_tm_prepared.dh_ref_type TDE_ETYPE on (TDE.TRSP_EVT_TYPE_KEY = TDE_ETYPE.type_key)
inner join daas_tm_prepared.dh_rcar_ref RCAR on (TDE.TRSP_EVT_KEY = rcar.rcar_key)
inner join DAAS_TM_PREPARED.dh_trsp_evt_asct TEA on (tde.trsp_evt_key = tea.trsp_evt_key)
inner join daas_tm_prepared.dh_rail_station Rail_STAT on (TEA.asct_obj_key = Rail_STAT.stn_333_key)
inner join daas_tm_prepared.dh_trsp_evt_asct_char TAC on (TEA.asct_key = TAC.asct_key)
inner join daas_tm_prepared.dh_ref_type CHAR_TYPE on (TAC.CHAR_TYPE_KEY = CHAR_TYPE.type_key)
inner join daas_tm_prepared.dh_ship_asct ship_asct on (TDE.trsp_evt_key = ship_asct.asct_obj_key)
inner join daas_tm_prepared.dh_ship_asct_char sa_char on (ship_asct.asct_key = sa_char.asct_key)
inner join daas_tm_prepared.dh_ref_type sa_char_type on (sa_char.char_type_key = sa_char_type.type_key)
where tde_etype.type_cd like 'Railcar Event' --- this is from Car Inventory
and TDE.act_stus_ind = 1
and TDE.sor_crlt_id = TEA.sor_crlt_id
group by 1, 2, 3, 4, 5;