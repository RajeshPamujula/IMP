DROP VIEW IF EXISTS v_car_location_station;

CREATE OR REPLACE VIEW v_car_location_station
AS
select rcar.eqp_init || rcar.eqp_nbr as eqp_id,
RCAR.eqp_init,
RCAR.eqp_nbr,
rail_stat.scac,
rail_stat.fsac,
Rail_STAT.stn_333,
Rail_STAT.stn_st,
case when rail_stat.stn_st in ('PQ', 'ON', 'BC', 'AB', 'NF', 'NB', 'PE', 'NS', 'SK', 'MB') then 'CA' else 'US' end as country_code,
substr(tde.trsp_evt_val,1,2) as event_code,
substr(tde.trsp_evt_val,3,2) as event_status_code,
rail_stat.splc,
rail_stat.stn_nm,
TDE.sor_evt_ts as event_timestamp_utc,
event_tz.tz_lbl as event_tz_label,
event_tz.utc_ofst_val_hr as event_offset_in_hours,
TDE.rpt_sor_proc_ts as process_timestamp_utc,
proc_tz.tz_lbl as process_tz_label,
proc_tz.utc_ofst_val_hr as process_offset_in_hours
from DAAS_TM_PREPARED.DH_TRSP_EVT TDE
inner join daas_tm_prepared.dh_ref_type TDE_ETYPE on (TDE.TRSP_EVT_TYPE_KEY = TDE_ETYPE.type_key)
inner join daas_tm_prepared.dh_rcar_ref RCAR on (TDE.TRSP_EVT_KEY = rcar.rcar_key)
inner join DAAS_TM_PREPARED.dh_trsp_evt_asct TEA on (tde.trsp_evt_key = tea.trsp_evt_key)
inner join daas_tm_prepared.dh_rail_station Rail_STAT on (TEA.asct_obj_key = Rail_STAT.stn_333_key)
inner join daas_tm_prepared.dh_tz_dst_ref event_tz on (TDE.sor_evt_ts_tz_dst_cd = event_tz.tz_dst_cd)
inner join daas_tm_prepared.dh_tz_dst_ref proc_tz on (TDE.sor_proc_ts_tz_dst_cd = proc_tz.tz_dst_cd)
where tde_etype.type_cd like 'Railcar Event' --- this is from Car Inventory
and TDE.act_stus_ind = 1
and TDE.sor_crlt_id = TEA.sor_crlt_id
;