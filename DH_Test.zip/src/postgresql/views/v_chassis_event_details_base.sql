DROP VIEW IF EXISTS v_chassis_event_details_base CASCADE;

CREATE OR REPLACE VIEW v_chassis_event_details_base
AS
SELECT tec.trsp_evt_key
     , tec.char_val AS gate_event_code
     , c.id_val AS chassis_id
     , cc.char_val AS chassis_initial
     , stn.stn_333
     , stn.stn_st
     , tec3.char_val AS cn_tractor_indicator     
     , MAX(te.data_hub_crt_ts) AS data_hub_crt_ts -- one row per trsp_evt_key
     , MAX(te.SOR_evt_TS) AS event_ts_utc
     , MAX(r_tz.utc_ofst_val_hr) AS tz_utc_ofst_val_hr 
     , MAX(r_tz.tz_lbl) AS tz_lbl   
     , MAX(te.act_stus_ind) AS active_gate_event
     , MAX(CASE WHEN cc2_char_type.type_cd = 'Chassis Number' THEN cc2.char_val ELSE '' END) AS chassis_number
     , MAX(CASE WHEN r_cc_cntr_char_type.type_cd = 'Container Initial' THEN cc_cntr.char_val ELSE '' END) AS container_initial
     , MAX(CASE WHEN r_cc_cntr_char_type.type_cd = 'Container Number' THEN cc_cntr.char_val ELSE '' END) AS container_number    
     , MAX(CASE WHEN r_tec2_char_type.type_cd = 'Carter SCAC' THEN tec2.char_val ELSE '' END) AS carter_scac
     , MAX(CASE WHEN r_tec2_char_type.type_cd = 'Carter Customer Number' THEN tec2.char_val ELSE '' END) AS carter_Customer_number
     , MAX(CASE WHEN r_tec2_char_type.type_cd = 'Event Status' THEN tec2.char_val ELSE '' END) AS gate_event_status
     , MAX(CASE WHEN r_tec2_char_type.type_cd = 'Tractor License' THEN tec2.char_val ELSE '' END) AS tractor_license
     , MAX(c_cond.char_val) AS bad_order_status
FROM daas_tm_prepared.dh_trsp_evt_char tec
INNER JOIN daas_tm_prepared.dh_ref_type tec_char_type ON tec.char_type_key = tec_char_type.type_key
INNER JOIN daas_tm_prepared.dh_cnvy_asct ca ON ca.asct_obj_key = tec.trsp_evt_key
INNER JOIN daas_tm_prepared.dh_ref_type r_ca_asct_type ON ca.asct_obj_type_key = r_ca_asct_type.type_key
INNER JOIN daas_tm_prepared.dh_cnvy c ON ca.cnvy_key = c.cnvy_key
INNER JOIN daas_tm_prepared.dh_ref_type cnvy_type ON c.cnvy_type_key = cnvy_type.type_key
INNER JOIN daas_tm_prepared.dh_ref_type cnvy_id_type ON c.id_type_key = cnvy_id_type.type_key
INNER JOIN daas_tm_prepared.dh_cnvy_char cc ON c.cnvy_key = cc.cnvy_key
INNER JOIN daas_tm_prepared.dh_ref_type cc_char_type ON cc.char_type_key = cc_char_type.type_key
INNER JOIN daas_tm_prepared.dh_cnvy_char cc2 ON c.cnvy_key = cc2.cnvy_key
INNER JOIN daas_tm_prepared.dh_ref_type cc2_char_type ON cc2.char_type_key = cc2_char_type.type_key
INNER JOIN daas_tm_prepared.dh_trsp_evt te ON tec.trsp_evt_key = te.trsp_evt_key
INNER JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON te.trsp_evt_key = tea.trsp_evt_key
INNER JOIN daas_tm_prepared.dh_rail_station stn ON tea.asct_obj_key = stn.stn_333_key
INNER JOIN daas_tm_prepared.dh_tz_dst_ref r_tz ON te.sor_evt_ts_tz_dst_cd = r_tz.tz_dst_cd
INNER JOIN daas_tm_prepared.dh_trsp_evt_char tec2 ON tec2.trsp_evt_key = te.trsp_evt_key
INNER JOIN daas_tm_prepared.dh_ref_type r_tec2_char_type ON r_tec2_char_type.type_key = tec2.char_type_key
INNER JOIN daas_tm_prepared.dh_trsp_evt_char tec3 ON tec3.trsp_evt_key = te.trsp_evt_key
INNER JOIN daas_tm_prepared.dh_ref_type r_tec3_char_type ON r_tec3_char_type.type_key = tec3.char_type_key
LEFT JOIN daas_tm_prepared.dh_cnvy_asct ca_cntr ON tea.trsp_evt_key = ca_cntr.asct_obj_key
LEFT JOIN daas_tm_prepared.dh_ref_type r_ca_cntr_cnvy_type ON r_ca_cntr_cnvy_type.type_key = ca_cntr.cnvy_type_key AND r_ca_cntr_cnvy_type.type_cd = 'Container'
LEFT JOIN daas_tm_prepared.dh_cnvy_char cc_cntr ON ca_cntr.cnvy_key = cc_cntr.cnvy_key
LEFT JOIN daas_tm_prepared.dh_ref_type r_cc_cntr_char_type ON cc_cntr.char_type_key = r_cc_cntr_char_type.type_key
LEFT JOIN daas_tm_prepared.dh_cnvy_cond c_cond ON ca.cnvy_key = c_cond.cnvy_key
LEFT JOIN daas_tm_prepared.dh_ref_type r_c_cond_char_type on (c_cond.char_type_key = r_c_cond_char_type.type_key AND r_c_cond_char_type.type_cd = 'Bad Order Code')
WHERE tec_char_type.type_cd = 'Event Code'
AND r_ca_asct_type.type_cd = 'Gate Event'
AND cnvy_type.type_cd = 'Chassis'
AND cnvy_id_type.type_cd = 'Chassis Id'
AND cc_char_type.type_cd = 'Chassis Initial'
AND r_tec3_char_type.type_cd = 'CN Tractor Indicator'
GROUP BY 1,2,3,4,5,6,7;