DROP VIEW IF EXISTS v_intermodal_bad_order;

CREATE OR REPLACE VIEW v_intermodal_bad_order
AS
SELECT rcar.eqp_init AS rcar_init, rcar.eqp_nbr AS rcar_nbr
, ca.cnvy_key::TEXT AS cntr_key, ctnr.eqp_init AS cntr_init, ctnr.eqp_nbr AS ctnr_nbr
, stn.stn_333, stn.stn_st, stn.stn_nm
, MAX(CASE WHEN cc_char_type.type_cd = 'Bad Order Code' THEN cc.char_val ELSE '' END) AS bad_ord_cd
, MAX(CASE WHEN cc_char_type.type_cd = 'Mechanical Status Codes' THEN cc.char_val ELSE '' END) AS mech_stus_cd
, MAX(CASE WHEN cc_char_type.type_cd = 'Car Location Code' THEN cc.char_val ELSE '' END) AS car_loc_cd
, MAX(CASE WHEN r_ship_asct_char_type.type_cd = 'Yard Block' THEN sac.char_val ELSE '' END) AS yd_blk_cd
, MAX(CASE WHEN r_ship_asct_char_type.type_cd = 'Current Assignment' THEN sac.char_val ELSE '' END) AS trn_id
, MAX(rcar.car_kind) AS car_kind, MAX(rcar.osid_lgt_ft) AS osid_lgt_ft
, MAX(CASE WHEN tac_char_type.type_cd = 'Track Number' THEN tac.char_val ELSE '' END) AS trk_nbr
, MAX(CASE WHEN r_cnvy_asct_char_type.type_cd = 'Equipment Sequence Number' THEN cac.char_val ELSE '' END) AS eqp_seq_nbr
, MAX(ctnr.car_kind) AS ctnr_car_kind
, NULL AS load_mpty_ind
FROM daas_tm_prepared.dh_trsp_evt te -- get the transportation event of type Railcar event
INNER JOIN daas_tm_prepared.dh_ref_type r_trsp_evt_type ON (te.trsp_evt_type_key = r_trsp_evt_type.type_key) --- transportation event type key (Railcar Event)
LEFT JOIN daas_tm_prepared.dh_cnvy_cond cc ON (te.trsp_evt_key = cc.cnvy_key) -- This (and the next line) should be changed back to INNER JOIN once the interchange filter is removed for Conveyor Condition
LEFT JOIN daas_tm_prepared.dh_ref_type cc_char_type ON (cc.char_type_key = cc_char_type.type_key)
INNER JOIN daas_tm_prepared.dh_rcar_ref rcar ON (te.trsp_evt_key = rcar.rcar_key)
INNER JOIN daas_tm_prepared.dh_trsp_evt_asct_char TAC ON (te.trsp_evt_key = TAC.prim_obj_key)
INNER JOIN daas_tm_prepared.dh_ref_type tac_char_type ON (TAC.char_type_key = tac_char_type.type_key)
INNER JOIN daas_tm_prepared.dh_trsp_evt_asct ta ON (te.trsp_evt_key = TA.trsp_evt_key)
INNER JOIN daas_tm_prepared.dh_rail_station stn ON (ta.asct_obj_key = stn.stn_333_key)
INNER JOIN daas_tm_prepared.dh_ship_asct sa ON (te.trsp_evt_key = sa.asct_obj_key)
INNER JOIN daas_tm_prepared.dh_ship_asct_char sac on (sa.asct_key = sac.asct_key)
INNER JOIN daas_tm_prepared.dh_cnvy_asct ca ON rcar.rcar_key = ca.prim_obj_key
INNER JOIN daas_tm_prepared.dh_ref_type r_cnvy_type ON r_cnvy_type.type_key = ca.cnvy_type_key
INNER JOIN daas_tm_prepared.dh_ref_type r_asct_obj_type ON r_asct_obj_type.type_key = ca.asct_obj_type_key
INNER JOIN daas_tm_prepared.dh_ref_type r_ship_asct_char_type ON r_ship_asct_char_type.type_key = sac.char_type_key
LEFT JOIN daas_tm_prepared.dh_cnvy_asct_char cac ON cac.asct_key = ca.asct_key
LEFT JOIN daas_tm_prepared.dh_ref_type r_cnvy_asct_char_type ON r_cnvy_asct_char_type.type_key = cac.char_type_key
LEFT JOIN daas_tm_prepared.dh_rcar_ref ctnr ON ctnr.rcar_key = ca.cnvy_key
WHERE r_trsp_evt_type.type_cd LIKE 'Railcar Event' -- this is from Car Inventory
AND SUBSTRING(rcar.car_kind, 1, 1) IN ('P', 'Q')
GROUP BY 1,2,3,4,5,6,7,8;