DROP VIEW IF EXISTS v_dh_monitor_de_runtimes.sql;

CREATE OR REPLACE VIEW v_dh_monitor_de_runtimes
AS SELECT * from daas_tm_prepared.dh_monitor_de_runtimes;