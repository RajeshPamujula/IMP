DROP VIEW IF EXISTS v_ind_reason;

CREATE OR REPLACE VIEW v_ind_reason
AS
   SELECT conv_type.type_cd AS "conveyor_type",
          rcar.eqp_init AS "equipment_initials",
          rcar.eqp_nbr AS "equipment_number",
          pede.rpt_sor_proc_ts AS "processing_ts",
          pede.sor_evt_ts AS "event_ts",
          pede.act_stus_ind AS "active_indicator",
          char_type.type_cd AS "instruction_type",
          pcde.char_val AS "description",
          ca.act_stus_ind AS "association_status",
          asct_type_2.type_cd AS "association_type",
          pede.plan_evt_val AS "planned_event"
   FROM (((((((daas_tm_prepared.dh_plan_evt pede
               JOIN daas_tm_prepared.dh_ref_type pe_type
                  ON ( (pede.plan_evt_type_key = pe_type.type_key)))
              JOIN daas_tm_prepared.dh_plan_evt_char pcde
                 ON ( (pede.plan_evt_key = pcde.plan_evt_key)))
             JOIN daas_tm_prepared.dh_ref_type char_type
                ON ( (pcde.char_type_key = char_type.type_key)))
            JOIN daas_tm_prepared.dh_cnvy_asct ca ON ( (pede.plan_evt_key = ca.asct_obj_key)))
           JOIN daas_tm_prepared.dh_ref_type conv_type
              ON ( (ca.cnvy_type_key = conv_type.type_key)))
          JOIN daas_tm_prepared.dh_ref_type asct_type_2
             ON ( (ca.asct_obj_type_key = asct_type_2.type_key)))
         JOIN daas_tm_prepared.dh_rcar_ref rcar ON ( (ca.cnvy_key = rcar.rcar_key)));