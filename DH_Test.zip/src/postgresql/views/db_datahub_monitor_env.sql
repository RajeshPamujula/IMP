SET search_path TO daas_tm_monitor;
SET ROLE = daas_tm_monitor_admin;