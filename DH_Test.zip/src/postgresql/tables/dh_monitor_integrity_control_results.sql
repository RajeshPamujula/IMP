DROP TABLE IF EXISTS DH_MONITOR_INTEGRITY_CONTROL_RESULTS CASCADE;

CREATE TABLE DH_MONITOR_INTEGRITY_CONTROL_RESULTS (
	query_time timestamp NOT NULL,
	query_id int4 NOT NULL,
	quality_class varchar(64) NULL,
	table_name varchar(64) NULL,
	description varchar(100) NULL,
	expected_output varchar(100) NULL,
	actual_output varchar(100) NULL,
	domn_nm varchar(100) NULL,
	CONSTRAINT DH_MONITOR_DATA_INTEGRITY_CONTROL_RESULTS_pkey PRIMARY KEY (query_time, query_id)
);
