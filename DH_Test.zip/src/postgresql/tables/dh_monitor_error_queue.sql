DROP TABLE IF EXISTS DH_MONITOR_ERROR_QUEUE CASCADE;

CREATE TABLE dh_monitor_error_queue (
	SOR_TPIC_NM text NOT NULL,
	job_name text NOT NULL,
	exec_date timestamp NOT NULL,
	SOURCE_QUEUE text NULL,
	error_count int8 NULL,
	error_to_de text NOT NULL,
	ERROR_DATE date NOT null,
	CONSTRAINT dh_monitor_error_queue_pkey PRIMARY KEY (SOR_TPIC_NM,job_name, error_to_de,ERROR_DATE)
);