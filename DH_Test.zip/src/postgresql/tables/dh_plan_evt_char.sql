DROP TABLE IF EXISTS dh_plan_evt_char CASCADE;

CREATE TABLE dh_plan_evt_char
(
	plan_evt_key         BYTEA NOT NULL,
	char_type_key        BYTEA NOT NULL,
	char_val             TEXT NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	sor_crlt_id          VARCHAR(256) NOT NULL,
	sys_key              BYTEA NOT NULL,
	rpt_clnt_id          VARCHAR(50) NULL,
	rpt_sor_proc_ts      TIMESTAMP NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	rmv_clnt_id          VARCHAR(50) NULL,
	rmv_sor_proc_ts      TIMESTAMP NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	domn_evt_crt_ts      TIMESTAMP NOT NULL,
	domn_evt_read_ts     TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
	domn_evt_meta        TEXT NULL,
	prim_obj_key         BYTEA NULL,
	sor_evt_ts_tz_dst_cd SMALLINT NULL,
	sor_proc_ts_tz_dst_cd SMALLINT NULL,
	PRIMARY KEY (plan_evt_key,char_type_key)
);

CREATE INDEX XIE1PLANNED_EVENT_CHARACTERISTIC ON dh_plan_evt_char
(
	prim_obj_key ASC
);