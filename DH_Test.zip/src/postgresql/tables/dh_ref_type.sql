DROP TABLE IF EXISTS dh_ref_type CASCADE;

CREATE TABLE dh_ref_type
(
	type_key             BYTEA NOT NULL,
	prnt_type_key        BYTEA NOT NULL,
	type_cd              VARCHAR(50) NOT NULL,
	prnt_type_cd         VARCHAR(50) NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	PRIMARY KEY (type_key)
);

CREATE UNIQUE INDEX XAK1REFERENCE_TYPE ON dh_ref_type
(
	prnt_type_key ASC,	type_cd ASC
);

CREATE UNIQUE INDEX XAK2REFERENCE_TYPE ON dh_ref_type
(
	prnt_type_cd ASC,	type_cd ASC
);
