DROP TABLE IF EXISTS dh_rail_station CASCADE;

CREATE TABLE dh_rail_station
(
	stn_333_key          BYTEA NOT NULL,
	stn_333              VARCHAR(9) NOT NULL,
	stn_st               CHAR(2) NOT NULL,
	fsac                 VARCHAR(6) NULL,
	scac                 VARCHAR(4) NULL,
	splc                 VARCHAR(20) NULL,
	stn_abbr             VARCHAR(6) NULL,
	stn_nm               VARCHAR(19) NULL,
	tz_abbr              VARCHAR(4) NULL,
	stn_ctry             VARCHAR(25) NULL,
	yd_scale_cd          CHAR(1) NULL,
	eff_dt               DATE NULL,
	exp_dt               DATE NULL,
	stn_shrt_abbr        CHAR(3) NULL,
	un_locode_nm         VARCHAR(3) NULL,
	un_locode_ctry       VARCHAR(2) NULL,
	stn_fsac_key         BYTEA NULL,
	clnt_id              VARCHAR(50) NULL,
	sor_ingt_crt_ts      TIMESTAMP NULL,
	sor_read_ts          TIMESTAMP NULL,
	ref_evt_crt_ts       TIMESTAMP NULL,
	ref_evt_read_ts      TIMESTAMP NULL,
	data_hub_crt_ts      TIMESTAMP NULL,
	div_cd               CHAR(2) NULL,
	sdiv_cd              CHAR(4) NULL,
	rgn_cd               CHAR(2) NULL,
	srgn_cd              CHAR(2) NULL,
	ramp_cd              CHAR(1) NULL,
	PRIMARY KEY (stn_333_key)
);

CREATE UNIQUE INDEX XAK1RAIL_STATIONS ON dh_rail_station
(
	stn_333 ASC,	stn_st ASC
);

CREATE INDEX XIE1RAIL_STATIONS ON dh_rail_station
(
	stn_fsac_key ASC
);

INSERT INTO DH_RAIL_STATION (STN_333_KEY, STN_333, STN_ST, FSAC, SCAC) VALUES (sha256(('')::text::bytea),'','','','');

