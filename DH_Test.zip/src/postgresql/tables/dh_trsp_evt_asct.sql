DROP TABLE IF EXISTS dh_trsp_evt_asct CASCADE;

CREATE TABLE dh_trsp_evt_asct
(
	asct_key             BYTEA NOT NULL,
	trsp_evt_key         BYTEA NOT NULL,
	asct_obj_key         BYTEA NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	asct_type_key        BYTEA NOT NULL,
	trsp_evt_type_key    BYTEA NOT NULL,
	asct_obj_type_key    BYTEA NOT NULL,
	sor_crlt_id          VARCHAR(256) NOT NULL,
	sys_key              BYTEA NOT NULL,
	asct_clnt_id         VARCHAR(50) NULL,
	asct_sor_proc_ts     TIMESTAMP NULL,
	sor_proc_ts          TIMESTAMP NOT NULL,
	dasc_clnt_id         VARCHAR(50) NULL,
	dasc_sor_proc_ts     TIMESTAMP NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	domn_evt_crt_ts      TIMESTAMP NOT NULL,
	domn_evt_read_ts     TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
	domn_evt_meta        TEXT NULL,
	prim_obj_key         BYTEA NULL,
	sor_evt_ts_tz_dst_cd SMALLINT NULL,
	sor_proc_ts_tz_dst_cd SMALLINT NULL,
	PRIMARY KEY (asct_key)
);

CREATE INDEX XIE1TRANSPORTATION_EVENT_ASSOCIATION ON dh_trsp_evt_asct
(
	asct_obj_key ASC
);

CREATE INDEX XIE2TRANSPORTATION_EVENT_ASSOCIATION ON dh_trsp_evt_asct
(
	prim_obj_key ASC
);

CREATE UNIQUE INDEX XAK1TRANSPORTATION_EVENT_ASSOCIATION ON dh_trsp_evt_asct
(
	trsp_evt_key ASC
);
