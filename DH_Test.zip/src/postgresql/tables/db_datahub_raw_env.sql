SET search_path TO daas_tm_raw;
SET ROLE = daas_tm_raw_admin;