/* *******************************************************************
**********************************************************************
Below functions will apply to all tables
**********************************************************************
******************************************************************* */

-- Add new partitions
--START
CREATE OR REPLACE FUNCTION daas_tm_prepared.add_partitions(
        )
    RETURNS integer
    LANGUAGE 'plpgsql'

    COST 100
    VOLATILE
AS $BODY$
  DECLARE
    partition_date TEXT;
    partition TEXT;
    partition_lower_range TEXT;
    partition_upper_range TEXT;
    schema_name text;
    table_name text;
    i INTEGER;
    row_partition_table  RECORD;
    cur_partition_tables CURSOR
      FOR select schema.nspname as schemaname, class.relname as tablename
          from pg_class class
          inner join pg_partitioned_table part
         on part.partrelid = class.oid
         inner join pg_namespace schema
         on schema.oid = class.relnamespace
         where part.partstrat = 'r'
           and schema.nspname = 'daas_tm_prepared';

  BEGIN
    -- for each partitioned table
    open cur_partition_tables;

    LOOP
      -- fetch row from cursor
      FETCH cur_partition_tables INTO row_partition_table;
      -- exit loop if no more rows
      EXIT WHEN NOT FOUND;
      schema_name := row_partition_table.schemaname;
      table_name := row_partition_table.tablename;

      -- make sure we have 7 days of partitions ahead of today
          FOR i in 0..7 LOOP
            partition_date := to_char(date(current_date + make_interval(days := i)), 'YYYY_MM_DD');
            partition := table_name||'_'||partition_date;
            -- create any missing parttitions
            IF NOT EXISTS(SELECT relname FROM pg_class WHERE relname=partition) THEN
              -- calculate partition ranges start and end
              partition_lower_range := cast(now()::date + make_interval(days := i ) as text);
                  partition_upper_range := cast(now()::date + make_interval(days := i+1 ) as text);
                  EXECUTE 'CREATE TABLE '||schema_name||'.'||table_name||'_'||partition_date||' PARTITION OF '||schema_name||'.'||table_name||' FOR VALUES FROM ('||quote_literal(partition_lower_range)||') TO ('||quote_literal(partition_upper_range)||')';
            END IF;
          END LOOP;  -- for loop
        END LOOP;  -- cursor loop
    RETURN 0;
  END
$BODY$;
--END
 
 
 
-- Remove old partitions
--START
CREATE OR REPLACE FUNCTION daas_tm_prepared.drop_partitions(
        )
    RETURNS integer
    LANGUAGE 'plpgsql'

    COST 100
    VOLATILE
AS $BODY$
  DECLARE
    partition_to_drop TEXT;
    oldest_partition TEXT;
    partition_lower_range TEXT;
    partition_upper_range TEXT;
    days_offset  INTERVAL;
    i INTEGER;
    my_schema_name text;
    my_table_name text;
    row_partition_table  RECORD;

    cur_partition_tables CURSOR
      FOR select schema.nspname as schemaname, class.relname as tablename
         from pg_class class
          inner join pg_partitioned_table part
         on part.partrelid = class.oid
         inner join pg_namespace schema
         on schema.oid = class.relnamespace
         where part.partstrat = 'r'
           and schema.nspname = 'daas_tm_prepared' ;

  BEGIN
    -- for each partitioned table in the daas_tm_prepared schema
    open cur_partition_tables;

    LOOP
      -- fetch row from cursor
      FETCH cur_partition_tables INTO row_partition_table;
      -- exit loop if no more rows
      EXIT WHEN NOT FOUND;
      my_schema_name := row_partition_table.schemaname;
      my_table_name := row_partition_table.tablename;
      -- drop any partitions older than 7 days
          -- calculate name of partition 8 days ago
          oldest_partition := my_table_name||'_'||to_char(current_date + make_interval(days := -8) ,'YYYY_MM_DD');
          FOR partition_to_drop IN
            select table_name
            from information_schema.tables
            where table_name like my_table_name||'_%'
            and table_schema = my_schema_name
            and table_type = 'BASE TABLE'
            and table_name < oldest_partition
          LOOP
            EXECUTE 'DROP TABLE '||my_schema_name||'.'||partition_to_drop;
          END LOOP; -- FOR LOOP
        END LOOP;  -- CURSOR LOOP
  RETURN 0;
END
$BODY$;
--END

CREATE OR REPLACE function daas_tm_prepared.add_init_partitions()
RETURNS integer
AS $$
DECLARE
    queries CURSOR FOR
select 'CREATE TABLE '|| t.schemaname || '.' || t.partname ||' PARTITION OF '|| t.schemaname || '.' || t.tablename || ' FOR VALUES FROM ('||quote_literal('1900-01-01')||') TO ('||quote_literal(upper_date)||')' query_string
from
(
select pt.schemaname, pt.tablename, min(to_date(right(t.tablename,10),'YYYY_MM_DD')) as upper_date, min(pt.tablename || '_' || to_char(to_date(right(t.tablename,10),'YYYY-MM-DD') - 1,'YYYY_MM_DD')) as partname from (
select schema.nspname as schemaname, class.relname as tablename
          from pg_class class
          inner join pg_partitioned_table part
         on part.partrelid = class.oid
         inner join pg_namespace schema
         on schema.oid = class.relnamespace
         where part.partstrat = 'r'
           and schema.nspname = 'daas_tm_prepared') pt inner join pg_tables t on pt.schemaname = t.schemaname and t.tablename like pt.tablename || '%'
where   t.tablename ~ '\d{4}_\d{2}_\d{2}$'
group   by pt.schemaname, pt.tablename
) t
;
BEGIN    
    FOR qry IN queries LOOP
        EXECUTE qry.query_string;
    END LOOP;
RETURN 0;
END;$$ 
LANGUAGE plpgsql; 


/* *******************************************************************
**********************************************************************
END SCRIPT
**********************************************************************
******************************************************************* */    