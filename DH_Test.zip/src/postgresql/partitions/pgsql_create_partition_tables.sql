-- create partition table: dh_aset_asct_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_aset_asct_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,ASCT_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_aset_asct_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               ASCT_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_aset_asct_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_aset_asct_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_aset_asct_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASET_KEY             BYTEA NOT NULL,
               ASET_TYPE_KEY        BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               ASCT_TYPE_KEY        BYTEA NOT NULL,
               ASCT_OBJ_KEY         BYTEA NOT NULL,
               ASCT_OBJ_TYPE_KEY    BYTEA NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_aset_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_aset_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,ASET_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_aset_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               ASET_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASET_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_aset_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_aset_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_aset_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASET_KEY             BYTEA NOT NULL,
               ASET_TYPE_KEY        BYTEA NOT NULL,
               ID_TYPE_KEY          BYTEA NOT NULL,
               ID_VAL               TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_cnvy_asct_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_cnvy_asct_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,ASCT_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_cnvy_asct_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               ASCT_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_cnvy_asct_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_cnvy_asct_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_cnvy_asct_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               CNVY_KEY             BYTEA NOT NULL,
               CNVY_TYPE_KEY        BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               ASCT_TYPE_KEY        BYTEA NOT NULL,
               ASCT_OBJ_KEY         BYTEA NOT NULL,
               ASCT_OBJ_TYPE_KEY    BYTEA NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_cnvy_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_cnvy_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,CNVY_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_cnvy_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               CNVY_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               CNVY_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_cnvy_cond_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_cnvy_cond_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,COND_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_cnvy_cond_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               COND_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               CNVY_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_cnvy_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_cnvy_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_cnvy_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               CNVY_KEY             BYTEA NOT NULL,
               CNVY_TYPE_KEY        BYTEA NOT NULL,
               ID_TYPE_KEY          BYTEA NOT NULL,
               ID_VAL               TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_loc_asct_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_loc_asct_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,ASCT_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_loc_asct_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               ASCT_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_loc_asct_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_loc_asct_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_loc_asct_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               LOC_KEY              BYTEA NOT NULL,
               LOC_TYPE_KEY         BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               ASCT_TYPE_KEY        BYTEA NOT NULL,
               ASCT_OBJ_KEY         BYTEA NOT NULL,
               ASCT_OBJ_TYPE_KEY    BYTEA NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_plan_evt_asct_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_plan_evt_asct_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_plan_evt_asct_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               PLAN_EVT_KEY         BYTEA NOT NULL,
               PLAN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               ASCT_TYPE_KEY        BYTEA NOT NULL,
               ASCT_OBJ_KEY         BYTEA NOT NULL,
               ASCT_OBJ_TYPE_KEY    BYTEA NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_plan_evt_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_plan_evt_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,PLAN_EVT_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_plan_evt_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               PLAN_EVT_CHAR_KEY    BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               PLAN_EVT_KEY         BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_plan_evt_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_plan_evt_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_plan_evt_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               PLAN_EVT_KEY         BYTEA NOT NULL,
               PLAN_EVT_TYPE_KEY    BYTEA NOT NULL,
               PLAN_EVT_VAL         TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_rte_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_rte_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,RTE_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_rte_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               RTE_CHAR_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               RTE_KEY              BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_rte_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_rte_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_rte_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               RTE_KEY              BYTEA NOT NULL,
               RTE_TYPE_KEY         BYTEA NOT NULL,
               ID_TYPE_KEY          BYTEA NOT NULL,
               ID_VAL               TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_ship_asct_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_ship_asct_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,ASCT_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_ship_asct_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               ASCT_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_ship_asct_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_ship_asct_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_ship_asct_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               SHIP_KEY             BYTEA NOT NULL,
               SHIP_TYPE_KEY        BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               ASCT_TYPE_KEY        BYTEA NOT NULL,
               ASCT_OBJ_KEY         BYTEA NOT NULL,
               ASCT_OBJ_TYPE_KEY    BYTEA NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_ship_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_ship_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SHIP_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_ship_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               SHIP_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               SHIP_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_ship_cond_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_ship_cond_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,COND_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_ship_cond_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               COND_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               SHIP_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_ship_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_ship_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_ship_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               SHIP_KEY             BYTEA NOT NULL,
               SHIP_TYPE_KEY        BYTEA NOT NULL,
               ID_TYPE_KEY          BYTEA NOT NULL,
               ID_VAL               TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_trsp_evt_asct_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_trsp_evt_asct_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,ASCT_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_trsp_evt_asct_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               ASCT_CHAR_KEY        BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_trsp_evt_asct_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_trsp_evt_asct_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_trsp_evt_asct_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               TRSP_EVT_KEY         BYTEA NOT NULL,
               TRSP_EVT_TYPE_KEY    BYTEA NOT NULL,
               ASCT_KEY             BYTEA NOT NULL,
               ASCT_TYPE_KEY        BYTEA NOT NULL,
               ASCT_OBJ_KEY         BYTEA NOT NULL,
               ASCT_OBJ_TYPE_KEY    BYTEA NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_trsp_evt_char_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_trsp_evt_char_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,TRSP_EVT_CHAR_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_trsp_evt_char_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               TRSP_EVT_CHAR_KEY    BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               TRSP_EVT_KEY         BYTEA NOT NULL,
               CHAR_TYPE_KEY        BYTEA NOT NULL,
               CHAR_VAL             TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;

-- create partition table: dh_trsp_evt_domn_evt
DO $$
DECLARE
   date_deployment TEXT := to_char(date(current_date + make_interval(days := 0)), 'YYYY_MM_DD');
   date_query TEXT := to_char(date(current_date + make_interval(days := 1)), 'YYYY_MM_DD');
   schema_name TEXT := 'daas_tm_prepared';
   table_name TEXT := 'dh_trsp_evt_domn_evt';
   table_name_first_partition TEXT := table_name||'_'||date_deployment;
   new_key TEXT := '(DOMN_EVT_KEY,SOR_PROC_TS)';
BEGIN 
    -- rename existing table and remove the primary key contraint
    EXECUTE 'alter table '||schema_name||'.'||table_name||' RENAME TO '||table_name_first_partition;
    EXECUTE 'alter table '||schema_name||'.'||table_name_first_partition||' DROP CONSTRAINT IF EXISTS '||table_name||'_pkey';
    -- create partitioned table
    EXECUTE 'CREATE TABLE daas_tm_prepared.dh_trsp_evt_domn_evt
            (  
               DOMN_EVT_KEY         BYTEA NOT NULL,
               DOMN_EVT_TYPE_KEY    BYTEA NOT NULL,
               TRSP_EVT_KEY         BYTEA NOT NULL,
               TRSP_EVT_TYPE_KEY    BYTEA NOT NULL,
               TRSP_EVT_VAL         TEXT NOT NULL,
               SOR_CRLT_ID          VARCHAR(256) NOT NULL,
               SYS_KEY              BYTEA NOT NULL,
               CLNT_ID              VARCHAR(50) NOT NULL,
               SOR_PROC_TS          TIMESTAMP NOT NULL,
               SOR_EVT_TS           TIMESTAMP NOT NULL,
               SOR_INGT_CRT_TS      TIMESTAMP NOT NULL,
               SOR_READ_TS          TIMESTAMP NOT NULL,
               DOMN_EVT_CRT_TS      TIMESTAMP NOT NULL,
               DOMN_EVT_READ_TS     TIMESTAMP NOT NULL,
               DATA_HUB_CRT_TS      TIMESTAMP NOT NULL,
               SOR_TPIC_NM          VARCHAR(80) NOT NULL DEFAULT '''',
               DOMN_EVT_META        TEXT NULL,
               SOR_EVT_TS_TZ_DST_CD SMALLINT NULL,
               SOR_PROC_TS_TZ_DST_CD SMALLINT NULL,
               PRIM_OBJ_KEY         BYTEA NULL    ) PARTITION BY RANGE (sor_proc_ts)';
    -- create unique index based on previous pkey and the partition column
    EXECUTE 'CREATE UNIQUE INDEX '||table_name||'_x01 ON '||schema_name||'.'||table_name||' '||new_key;
    -- add original table as the first parttion
    EXECUTE 'alter table '||schema_name||'.'||table_name||' ATTACH PARTITION '||schema_name||'.'||table_name_first_partition||' FOR VALUES FROM (''0001-01-01 00:00:00'') TO ('||quote_literal(date_query)||')';
END $$;
            
        