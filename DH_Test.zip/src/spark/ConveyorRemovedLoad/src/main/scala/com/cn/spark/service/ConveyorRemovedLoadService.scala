package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.{ col, from_json, lit }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.utils.SparkDataFrameHelper
import java.util.Properties

import org.apache.commons.lang3.exception.ExceptionUtils
import org.apache.hadoop.security.alias.CredentialProviderFactory
import com.cn.spark.commons.references.ConveyorRemovedSchema
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.idFactory.IDGenerationEngine

class ConveyorRemovedLoadService(sourceTopicName:String,ErrorNotificationTopic:String) extends CommonFeed(sourceTopicName:String) {
   import spark.implicits._
   val logger = Logger.getLogger(getClass.getName)
   @transient lazy val conveyorRemovedLoadCheckpointDir = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorRemovedLoadCheckpointDir")
  lazy val targetTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("ConveyorDomTableName")
  lazy val targetUpsertTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("conveyorRemoveUpsertTable")

  //Broadcast any thing thats required
  @transient lazy val jcekFileSystem = applicationConf.getString("jcekFileSystem")
  lazy val dbConfigParam: Properties = CommonsUtil.setPostgreConfig(targetTableName,jcekFileSystem)
  lazy val timeInterval = applicationConf.getInt("timeInterval")

  val domainTypeDF = spark.createDataFrame(Seq(("Unpublished", "Domain Event Type"))).toDF("TYPE_CD", "PRNT_TYPE_CD")
  val domainTypeFinalDF = IDGenerationEngine.createKeyForDF(domainTypeDF, "DOMAIN_EVENT_FLAG", List("TYPE_CD", "PRNT_TYPE_CD"))
  val domainType = domainTypeFinalDF.select($"DOMAIN_EVENT_FLAG").collect().toList.head.getString(0)
  val domainTypeVal = spark.sparkContext.broadcast(domainType)
  
  //Implementation of the trait. using Schema to fetch dataframe from the message.
  @Override
  def applySchema(dataset: Dataset[(String,String)]): DataFrame = {
    logger.info("ConveyorRemovedLoadService Start ::applySchema")
    //applying schema to json message
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA",from_json(CommonsUtil.preprocessJson($"value"), ConveyorRemovedSchema.conveyorRemovedSchema) as "record")
    //adding time stamp while reading
    val auditTimeStampDF = SparkDataFrameHelper.addAuditTimeStamp(rawMsgDF, "DOMN_EVT_READ_TS")
    logger.debug("ConveyorRemovedLoadService End ::applySchema")
    SparkDataFrameHelper.getMessage(auditTimeStampDF)
  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("ConveyorRemovedLoadService Start ::transformAndsinkStream")

    val convDescribedFinalDF = SparkDataFrameHelper.applyTransformation(inputDF)

    convDescribedFinalDF.writeStream.option("checkpointLocation", conveyorRemovedLoadCheckpointDir).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorRemovedLoadForEachWriter(dbConfigParam, ErrorNotificationTopic, "ConveyorRemovedLoad", sourceTopicName,targetUpsertTableName,domainTypeVal.value)).start()

  }
}