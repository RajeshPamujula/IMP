package com.cn.spark.service

import java.sql.Connection
import java.sql.DriverManager
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp

import org.apache.log4j.Logger
import org.apache.spark.SparkException
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.Row
import org.postgresql.util.PSQLException

import com.cn.spark.configFactory.ApplicationConfigEngine
import org.apache.kafka.clients.producer.KafkaProducer
import java.util.Properties
import com.cn.spark.commonsEngine.CommonsUtil

class AssetDescribedLoadForEachWriter(dbConfigParam: Properties, val ErrorNotificationTopic: String, val jobName: String, val sourceTopicName: String, targetUpsertTableName: String, domainTypeVal: String) extends ForeachWriter[Row] with ApplicationConfigEngine with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  lazy val conn: Connection = DriverManager.getConnection(dbConfigParam.getProperty("dbUrl"), dbConfigParam.getProperty("user"), dbConfigParam.getProperty("password"))
  //lazy val conn: Connection = JDBCConnectionFactory.getConnection(dbConfigParam.getProperty("user"), dbConfigParam.getProperty("password"),dbConfigParam.getProperty("dbUrl"))
  @transient lazy val kafkaProperties: Properties = CommonsUtil.getKafkaProperties()
  var producer: KafkaProducer[String, String] = _
  def open(partition_id: Long, epoch_id: Long) = {
    // Open connection. This method is optional in Python.
    logger.debug("AssetDescribedLoadForEachWriter start:: open")
    producer = new KafkaProducer(kafkaProperties)
    conn
    logger.debug("AssetDescribedLoadForEachWriter end:: open")
    true
  }

  //convert to json and write to postgre
  def process(row: Row) = {
    logger.debug("AssetDescribedLoadForEachWriter Start:: process")
    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
      try {
    if (!rowAsMap("DOMN_EVT_TYPE_KEY").equals(domainTypeVal)) {
    CommonsUtil.saveTODB(buildQuery(rowAsMap), conn, true, rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName)
    CommonsUtil.saveTODB(buildUpsertQuery(rowAsMap), conn, true, rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName)
    } else{
      CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, "Unrelated Domain Event Type:Unpublish")
    } 
    } catch {
     case ne: NullPointerException => {
           CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, ne.printStackTrace().toString())
       }
      case se: Exception => {
        CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, se.getMessage)
      }
    }
    logger.debug("AssetDescribedLoadForEachWriter End:: process")
  }

  def close(error: Throwable) = {
    logger.debug("Start close() AssetDescribedLoadForEachWriter")
    conn.close()
    producer.close()
    logger.debug("End close() AssetDescribedLoadForEachWriter")
  }

  def buildQuery(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("AssetDescribedLoadForEachWriter Start :: buildQuery")

    val columns = "DOMN_EVT_KEY,ASET_CHAR_KEY,DOMN_EVT_TYPE_KEY,ASET_KEY,CHAR_TYPE_KEY,CHAR_VAL,SOR_CRLT_ID,SYS_KEY,CLNT_ID,SOR_TPIC_NM,DOMN_EVT_META,SOR_PROC_TS,SOR_EVT_TS,SOR_PROC_TS_TZ_DST_CD,SOR_EVT_TS_TZ_DST_CD,SOR_INGT_CRT_TS,SOR_READ_TS,DOMN_EVT_CRT_TS,DOMN_EVT_READ_TS,DATA_HUB_CRT_TS"
    val insertQuery = "INSERT INTO " + dbConfigParam.getProperty("targetTableName") + " (" + columns + ") VALUES('" +
      rowAsMap("DOMN_EVT_KEY") + "','" +
      rowAsMap("ASET_CHAR_KEY") + "','" +
      rowAsMap("DOMN_EVT_TYPE_KEY") + "','" +
      rowAsMap("ASET_KEY") + "','" +
      rowAsMap("CHAR_TYPE_KEY") + "','" +
      rowAsMap("CHAR_VAL") + "','" +
      rowAsMap("SOR_CRLT_ID") + "','" +
      rowAsMap("SYS_KEY") + "','" +
      rowAsMap("CLNT_ID") + "','" +
      rowAsMap("SOR_TPIC_NM") + "','" +
      rowAsMap("DOMN_EVT_META") + "','" +
      rowAsMap("SOR_PROC_TS") + "','" +
      rowAsMap("SOR_EVT_TS") + "','" +
      rowAsMap("SOR_PROC_TS_TZ_DST_CD") + "','" +
      rowAsMap("SOR_EVT_TS_TZ_DST_CD") + "','" +
      rowAsMap("SOR_INGT_CRT_TS") + "','" +
      rowAsMap("SOR_READ_TS") + "','" +
      rowAsMap("DOMN_EVT_CRT_TS") + "','" +
      rowAsMap("DOMN_EVT_READ_TS") + "',CURRENT_TIMESTAMP)"

    logger.debug("AssetDescribedLoadForEachWriter End :: buildQuery")
    CommonsUtil.replaceNullString(insertQuery)
  }
    def buildUpsertQuery(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("AssetCreatedLoadForEachWriter Start :: buildUpsertQuery")

    val upsertQueryString = "INSERT INTO " + targetUpsertTableName + "(ASET_KEY, CHAR_TYPE_KEY, CHAR_VAL, ACT_STUS_IND, SOR_CRLT_ID, SYS_KEY, RPT_CLNT_ID, RPT_SOR_PROC_TS, SOR_EVT_TS, SOR_INGT_CRT_TS, SOR_READ_TS, DOMN_EVT_CRT_TS, DOMN_EVT_READ_TS, DATA_HUB_CRT_TS, SOR_TPIC_NM, DOMN_EVT_META, SOR_EVT_TS_TZ_DST_CD, SOR_PROC_TS_TZ_DST_CD) VALUES('" +
      rowAsMap("ASET_KEY") + "','" +
      rowAsMap("CHAR_TYPE_KEY") + "','" +
	    rowAsMap("CHAR_VAL") + "','" +
	    1 + "','" +
	    rowAsMap("SOR_CRLT_ID") + "','" +
      rowAsMap("SYS_KEY") + "','" +
      rowAsMap("CLNT_ID") + "','" +
      rowAsMap("SOR_PROC_TS") + "','" +
      rowAsMap("SOR_EVT_TS") + "','" +
      rowAsMap("SOR_INGT_CRT_TS") + "','" +
      rowAsMap("SOR_READ_TS") + "','" +
      rowAsMap("DOMN_EVT_CRT_TS") + "','" +
      rowAsMap("DOMN_EVT_READ_TS") + "',CURRENT_TIMESTAMP,'" +
      rowAsMap("SOR_TPIC_NM") + "','" +
      rowAsMap("DOMN_EVT_META") + "','" +
	    rowAsMap("SOR_EVT_TS_TZ_DST_CD") + "','" +
      rowAsMap("SOR_PROC_TS_TZ_DST_CD") + "') ON CONFLICT(ASET_KEY,CHAR_TYPE_KEY) DO UPDATE SET CHAR_VAL=EXCLUDED.CHAR_VAL, ACT_STUS_IND=EXCLUDED.ACT_STUS_IND, SOR_CRLT_ID=EXCLUDED.SOR_CRLT_ID, SYS_KEY=EXCLUDED.SYS_KEY, RPT_CLNT_ID=EXCLUDED.RPT_CLNT_ID, RPT_SOR_PROC_TS=EXCLUDED.RPT_SOR_PROC_TS, SOR_EVT_TS=EXCLUDED.SOR_EVT_TS, SOR_INGT_CRT_TS=EXCLUDED.SOR_INGT_CRT_TS,SOR_READ_TS=EXCLUDED.SOR_READ_TS, DOMN_EVT_CRT_TS=EXCLUDED.DOMN_EVT_CRT_TS, DOMN_EVT_READ_TS=EXCLUDED.DOMN_EVT_READ_TS, DATA_HUB_CRT_TS=EXCLUDED.DATA_HUB_CRT_TS, SOR_TPIC_NM=EXCLUDED.SOR_TPIC_NM, DOMN_EVT_META=EXCLUDED.DOMN_EVT_META, SOR_EVT_TS_TZ_DST_CD=EXCLUDED.SOR_EVT_TS_TZ_DST_CD, SOR_PROC_TS_TZ_DST_CD=EXCLUDED.SOR_PROC_TS_TZ_DST_CD WHERE " + targetUpsertTableName + ".SOR_EVT_TS<='" + rowAsMap("SOR_EVT_TS") + "'"
     logger.debug("AssetCreatedLoadForEachWriter End :: buildUpsertQuery")
    CommonsUtil.replaceNullString(upsertQueryString)
  }

}