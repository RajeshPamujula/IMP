package com.cn.spark.service

import java.sql.Connection
import java.sql.DriverManager
import org.apache.log4j.Logger
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.Row
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.configFactory.ApplicationConfigEngine
import java.util.Properties
import org.apache.kafka.clients.producer.KafkaProducer

class BusinessPartnerConditionCreatedLoadForEachWriter(dbConfigParam: Properties, val ErrorNotificationTopic: String, val jobName: String, val sourceTopicName: String, val targetUpsertTableName: String, referenceData: Map[String, String]) extends ForeachWriter[Row] with ApplicationConfigEngine with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  lazy val conn: Connection = DriverManager.getConnection(dbConfigParam.getProperty("dbUrl"), dbConfigParam.getProperty("user"), dbConfigParam.getProperty("password"))
  //lazy val conn: Connection = JDBCConnectionFactory.getConnection(dbConfigParam.getProperty("user"), dbConfigParam.getProperty("password"),dbConfigParam.getProperty("dbUrl"))
  @transient lazy val kafkaProperties: Properties = CommonsUtil.getKafkaProperties()
  var producer: KafkaProducer[String, String] = _

  def open(partition_id: Long, epoch_id: Long) = {
    // Open connection.
    logger.debug("BusinessPartnerConditionCreatedLoadForEachWriter Strat:: open")
    producer = new KafkaProducer(kafkaProperties)
    conn
    logger.debug("BusinessPartnerConditionCreatedLoadForEachWriter End :: open ")
    true
  }

  def process(row: Row) = {
    logger.debug("Start process BusinessPartnerConditionCreatedLoadForEachWriter")
    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
    val unpublishedDomainType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val insertQuery = CommonsUtil.replaceNullString(buildQuery(rowAsMap))
    try {
      if (!rowAsMap("DOMN_EVT_TYPE_KEY").equals(unpublishedDomainType)) {
        CommonsUtil.saveTODB(buildQuery(rowAsMap), conn, true, rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName)
      }
      val outputDF = CommonsUtil.saveTODB(buildUpsertQuery(rowAsMap), conn, true, rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName)
    }
    catch {
      case ne: NullPointerException => {
        CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, ne.printStackTrace().toString())
      }
      case se: Exception => {
        CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, se.getMessage)
      }
    }
    logger.debug("End process BusinessPartnerConditionCreatedLoadForEachWriter")
  }

  def close(error: Throwable) = {
    logger.debug("BusinessPartnerConditionCreatedLoadForEachWriter Start ::close")
    conn.close()
    producer.close()
    logger.debug("BusinessPartnerConditionCreatedLoadForEachWriter End :: close")
  }

  def buildQuery(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("BusinessPartnerConditionCreatedLoadForEachWriter Start:: buildQuery")
    val columns = "SOR_INGT_CRT_TS,SOR_READ_TS,DOMN_EVT_CRT_TS,SOR_TPIC_NM,DOMN_EVT_META,DOMN_EVT_TYPE_KEY,COND_CHAR_KEY,DOMN_EVT_KEY,SOR_CRLT_ID,CLNT_ID,SYS_KEY,SOR_PROC_TS,SOR_EVT_TS,SOR_EVT_TS_TZ_DST_CD,SOR_PROC_TS_TZ_DST_CD,BUS_PRTR_KEY,CHAR_TYPE_KEY,CHAR_VAL,DOMN_EVT_READ_TS,DATA_HUB_CRT_TS"
    val insertQuery = "INSERT INTO " + dbConfigParam.getProperty("targetTableName") + " (" + columns + ") VALUES('" +
      rowAsMap("SOR_INGT_CRT_TS") + "','" +
      rowAsMap("SOR_READ_TS") + "','" +
      rowAsMap("DOMN_EVT_CRT_TS") + "','" +
      rowAsMap("SOR_TPIC_NM") + "','" +
      rowAsMap("DOMN_EVT_META") + "','" +
      rowAsMap("DOMN_EVT_TYPE_KEY") + "','" +
      rowAsMap("COND_CHAR_KEY") + "','" +
      rowAsMap("DOMN_EVT_KEY") + "','" +
      rowAsMap("SOR_CRLT_ID") + "','" +
      rowAsMap("CLNT_ID") + "','" +
      rowAsMap("SYS_KEY") + "','" +
      rowAsMap("SOR_PROC_TS") + "','" +
      rowAsMap("SOR_EVT_TS") + "','" +
      rowAsMap("SOR_EVT_TS_TZ_DST_CD") + "','" +
      rowAsMap("SOR_PROC_TS_TZ_DST_CD") + "','" +
      rowAsMap("BUS_PRTR_KEY") + "','" +
      rowAsMap("CHAR_TYPE_KEY") + "','" +
      rowAsMap("CHAR_VAL") + "','" +
      rowAsMap("DOMN_EVT_READ_TS") + "',CURRENT_TIMESTAMP)"
    logger.debug("BusinessPartnerConditionCreatedLoadForEachWriter End:: buildQuery")
    CommonsUtil.replaceNullString(insertQuery)
  }

   def buildUpsertQuery(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("BusinessPartnerConditionCreatedLoadForEachWriter Start :: buildUpsertQuery")
     var domainEventTypeKey = rowAsMap("DOMN_EVT_TYPE_KEY").toString()
     var queryString = ""
     val BusPrtrCondCrtDomainType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
     val UnpublishedDomainType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")

     domainEventTypeKey match {
       case BusPrtrCondCrtDomainType => queryString = "INSERT INTO " + targetUpsertTableName + "(BUS_PRTR_KEY, CHAR_TYPE_KEY, CHAR_VAL, ACT_STUS_IND, SOR_CRLT_ID, SYS_KEY, RPT_CLNT_ID, RPT_SOR_PROC_TS, SOR_EVT_TS, SOR_INGT_CRT_TS, SOR_READ_TS, DOMN_EVT_CRT_TS,DOMN_EVT_READ_TS,DATA_HUB_CRT_TS,SOR_TPIC_NM,DOMN_EVT_META,SOR_EVT_TS_TZ_DST_CD,SOR_PROC_TS_TZ_DST_CD) VALUES('" +
      rowAsMap("BUS_PRTR_KEY") + "','" +
      rowAsMap("CHAR_TYPE_KEY") + "','" +
      rowAsMap("CHAR_VAL") + "'," +
      1 + ",'" +
      rowAsMap("SOR_CRLT_ID") + "','" +
      rowAsMap("SYS_KEY") + "','" +
      rowAsMap("CLNT_ID") + "','" +
      rowAsMap("SOR_PROC_TS") + "','" +
      rowAsMap("SOR_EVT_TS") + "','" +
      rowAsMap("SOR_INGT_CRT_TS") + "','" +
      rowAsMap("SOR_READ_TS") + "','" +
      rowAsMap("DOMN_EVT_CRT_TS") + "','" +
      rowAsMap("DOMN_EVT_READ_TS") + "',CURRENT_TIMESTAMP,'" +
      rowAsMap("SOR_TPIC_NM") + "','" +
      rowAsMap("DOMN_EVT_META") + "','" +
      rowAsMap("SOR_EVT_TS_TZ_DST_CD") + "','" +
      rowAsMap("SOR_PROC_TS_TZ_DST_CD") + "') ON CONFLICT(BUS_PRTR_KEY,CHAR_TYPE_KEY) DO UPDATE SET CHAR_VAL=EXCLUDED.CHAR_VAL,ACT_STUS_IND=EXCLUDED.ACT_STUS_IND, SOR_CRLT_ID=EXCLUDED.SOR_CRLT_ID, SYS_KEY=EXCLUDED.SYS_KEY,RPT_CLNT_ID=EXCLUDED.RPT_CLNT_ID,RPT_SOR_PROC_TS=EXCLUDED.RPT_SOR_PROC_TS,RMV_CLNT_ID=EXCLUDED.RMV_CLNT_ID,RMV_SOR_PROC_TS=EXCLUDED.RMV_SOR_PROC_TS,SOR_EVT_TS=EXCLUDED.SOR_EVT_TS,SOR_INGT_CRT_TS=EXCLUDED.SOR_INGT_CRT_TS,SOR_READ_TS=EXCLUDED.SOR_READ_TS,DOMN_EVT_CRT_TS=EXCLUDED.DOMN_EVT_CRT_TS,DOMN_EVT_READ_TS=EXCLUDED.DOMN_EVT_READ_TS,DATA_HUB_CRT_TS=EXCLUDED.DATA_HUB_CRT_TS,SOR_TPIC_NM=EXCLUDED.SOR_TPIC_NM,DOMN_EVT_META=EXCLUDED.DOMN_EVT_META,SOR_EVT_TS_TZ_DST_CD=EXCLUDED.SOR_EVT_TS_TZ_DST_CD,SOR_PROC_TS_TZ_DST_CD=EXCLUDED.SOR_PROC_TS_TZ_DST_CD WHERE " + targetUpsertTableName + ".SOR_EVT_TS<='" + rowAsMap("SOR_EVT_TS") + "'"

       case UnpublishedDomainType => queryString = "UPDATE " + targetUpsertTableName + " SET SOR_CRLT_ID='" + rowAsMap("SOR_CRLT_ID") + "',ACT_STUS_IND=" + '0' + ",SYS_KEY='" + rowAsMap("SYS_KEY") + "',RMV_CLNT_ID= '" + rowAsMap("CLNT_ID") +  "',RMV_SOR_PROC_TS='" + rowAsMap("SOR_PROC_TS") + "',SOR_EVT_TS='" + rowAsMap("SOR_EVT_TS") + "',SOR_EVT_TS_TZ_DST_CD='" + rowAsMap("SOR_EVT_TS_TZ_DST_CD") + "',SOR_PROC_TS_TZ_DST_CD='" + rowAsMap("SOR_PROC_TS_TZ_DST_CD") + "' WHERE " + targetUpsertTableName + ".BUS_PRTR_KEY='" + rowAsMap("BUS_PRTR_KEY") + "' AND " + targetUpsertTableName + ".SOR_EVT_TS <'" + rowAsMap("SOR_EVT_TS") + "'"
       case _ => CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, "Unrelated Domain Event Type")
     }
     logger.debug("BusinessPartnerConditionCreatedLoadForEachWriter End :: buildUpsertQuery")
     CommonsUtil.replaceNullString(queryString)
   }
}