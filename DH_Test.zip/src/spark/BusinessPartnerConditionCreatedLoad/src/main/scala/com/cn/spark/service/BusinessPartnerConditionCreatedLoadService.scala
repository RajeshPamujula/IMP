package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, from_json, lit, concat }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.references.Schema

import java.util.Properties
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.idFactory.IDGenerationEngine

class BusinessPartnerConditionCreatedLoadService(sourceTopicName:String,ErrorNotificationTopic:String) extends CommonFeed(sourceTopicName:String) {

  import spark.implicits._

  val logger = Logger.getLogger(getClass.getName)
  logger.info("Start BusinessPartnerConditionCreatedLoadService transfromData")
  @transient lazy val businessPartnerCondCreatedLoadCheckpointDir = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("businessPartnerCondCreatedLoadCheckpointDir")
  @transient lazy val targetTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("businessPartnerCondCreatedTable")
  @transient lazy val targetUpsertTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("businessPartnerCondUpsertTable")

  //Broadcast any thing thats required
  @transient lazy val jcekFileSystem = applicationConf.getString("jcekFileSystem")
  lazy val dbConfigParam: Properties = CommonsUtil.setPostgreConfig(targetTableName,jcekFileSystem)
  @transient lazy val timeInterval = applicationConf.getInt("timeInterval")

  val domainTypeDF = spark.createDataFrame(Seq(("Unpublished", "Domain Event Type"),("Created", "Domain Event Type"))).toDF("TYPE_CD", "PRNT_TYPE_CD")
  val domainTypeFinalDF = IDGenerationEngine.createKeyForDF(domainTypeDF, "DOMAIN_EVENT_FLAG", List("TYPE_CD", "PRNT_TYPE_CD"))
  val domainType = domainTypeFinalDF.select(concat($"PRNT_TYPE_CD",lit("|"),$"TYPE_CD"),$"DOMAIN_EVENT_FLAG").as[(String, String)].collect.toMap
  val domainTypeVal = spark.sparkContext.broadcast(domainType)
  
  /*using  schema to fetch dataframe from the message.
  *@throws(classOf[Exception])
  *Input -  json message from Kafka
  *output - Dataframe
  */
  @Override
  def applySchema(dataset: Dataset[(String,String)]): DataFrame = {
    logger.debug("BusinessPartnerConditionCreatedLoadService Start::")

    val messageDF = dataset.select(col("value") as "JSON_DATA",from_json(CommonsUtil.preprocessJson($"value"), Schema.businessPartnerConditionCreatedSchema) as "record")   
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(messageDF, "DOMN_EVT_READ_TS")
    logger.debug("BusinessPartnerConditionCreatedLoadService End ::applySchema")

    SparkDataFrameHelper.getMsgData(auditTimeStampDF)

  }

  /*Transformations will be applied for each batch and saved transformed data into respective sink.
   * Input -  message dataframe
   * output - Streaming query
   */
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("Start BusinessPartnerConditionCreatedLoadService::transformAndsinkStream")
    logger.info("Start BusinessPartnerConditionCreatedLoadService::transformAndsinkStream")
    val finalDF = SparkDataFrameHelper.applyTransformation(inputDF)
    finalDF.writeStream.option("checkpointLocation", businessPartnerCondCreatedLoadCheckpointDir).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new BusinessPartnerConditionCreatedLoadForEachWriter(dbConfigParam, ErrorNotificationTopic, "BusinessPartnerConditionCreatedLoad", sourceTopicName,targetUpsertTableName,domainTypeVal.value)).start()

  }

}
