package com.cn.spark.commons.references

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import scala.collection.Seq

object CarInventoryDomainSchema {

  val carInventoryDomain = StructType(Seq(
    StructField("INGT_CRT_TS", StringType,false),
    StructField("EVT_CD", StringType, false),
    StructField("EVST_CD", StringType, false),
    StructField("PROC_DTTM", StringType, false),
    StructField("EVT_DT", StringType, false),        
    StructField("EVT_TM", StringType,false),
    StructField("CAR_INIT", StringType, false),
    StructField("CAR_NUMB", StringType, false),
    StructField("OP_RAJP", StringType, false),
    StructField("WB_NUMB",StringType,false),
    StructField("WB_DT",StringType,false),
    StructField("OP_CITY_333",StringType,false),
    StructField("OP_ORIG_333",StringType,false),
    StructField("ARR_333",StringType,false),
    StructField("ARR_ST",StringType,false),
    StructField("TRK_SEQ_NUMB",StringType,false),
    StructField("CURR_SPOT",StringType,false),
    StructField("OP_ORIG_ST",StringType,false),
    StructField("OP_ST",StringType,false),
    StructField("OP_ZTS",StringType,false),
    StructField("CAR_LOC_CD",StringType,false),
    StructField("CUST_SWTCH_CD",StringType,false),
    StructField("TRN_BLK",StringType,false),
    StructField("YD_BLK",StringType,false),
    StructField("STN_333", StringType, false),
    StructField("TRK_NUMB", StringType,false),
    StructField("STN_ST", StringType, false),
    StructField("INGT_UUID", StringType, false),
    StructField("USER_ID", StringType, false),
    StructField("SFE_POOL_ID",StringType,false),
    StructField("BO_CD",StringType,false),
    StructField("MECH_STAT_CD1",StringType,false),
    StructField("MECH_STAT_CD2",StringType,false),
    StructField("MECH_STAT_CD3",StringType,false),
    StructField("TRN_TYPE",StringType,false),
    StructField("TRN_SYM",StringType,false),
    StructField("TRN_SECT",StringType,false),
    StructField("TRN_DAY",StringType,false),
    StructField("WB_ID",StringType,false),
    StructField("ASGN_TRN_TYPE",StringType,false),
    StructField("ASGN_TRN_SYM",StringType,false),
    StructField("ASGN_TRN_SECT",StringType,false),
    StructField("ASGN_TRN_DAY",StringType,false),
    StructField("BO_ETR_HRS",StringType,false),
    StructField("IBMSNAP_OPERATION",StringType,false)))
    
     val referenceDataSchema = StructType(Seq(
    StructField("type_cd", StringType, false),
    StructField("prnt_type_cd", StringType, false)))
}