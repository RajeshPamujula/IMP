package com.cn.spark.service

import org.apache.spark.sql.ForeachWriter
import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.commonsEngine.CommonsUtil
import org.apache.kafka.clients.producer.KafkaProducer
import java.util.Properties
import org.apache.spark.sql.Row
import org.apache.log4j.Logger
import org.apache.kafka.clients.producer.ProducerRecord

class ShipmentAssociatedDescribedForEachWriter() extends ForeachWriter[Row] with ApplicationConfigEngine with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  @transient lazy val kafkaProperties: Properties = CommonsUtil.getKafkaProperties()  

  var producer: KafkaProducer[String, String] = _
  def open(partition_id: Long, epoch_id: Long) = {
    // Open connection. This method is optional in Python.
    logger.debug("ShipmentAssociatedDescribedForEachWriter start:: open")
    producer = new KafkaProducer(kafkaProperties)
    logger.debug("ShipmentAssociatedDescribedForEachWriter end:: open")
    true
  }

  //convert to json and write to kafka
  def process(row: Row) = {
    logger.debug("Start process() function ShipmentAssociatedDescribedForEachWriter")
    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
   producer.send(new ProducerRecord(environmentValues.get("TRANSPORTATION_SHP_ASSOC_DESC_PREPARED"), buildJson(rowAsMap)))
    logger.debug("End process() function ShipmentAssociatedDescribedForEachWriter")
  }

  def close(error: Throwable) = {
    logger.debug("Start close() ShipmentAssociatedDescribedForEachWriter")
    producer.close()
    logger.debug("End close() ShipmentAssociatedDescribedForEachWriter")
  }

    def buildJson(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("ShipmentAssociatedDescribedForEachWriter Start :: buildJson")
    val currentTimeInUTC = CommonsUtil.getUTCTimeStamp
    val msgHeaderJson = "{" + "\"DomainEventHeader\"" + ":" + "{" + "\"SOR_INGT_CRT_TS\"" + ":" + "\"" + rowAsMap("SOR_INGT_CRT_TS") + "\"" + "," + "\"SOR_READ_TS\"" + ":" + "\"" + rowAsMap("SOR_READ_TS") + "\"" + "," + "\"DE_CRT_TS\"" + ":" + "\"" + currentTimeInUTC + "\"" + "," + "\"SOR_TPIC_NM\"" + ":" + "\"" + rowAsMap("SOR_TPIC_NM") + "\"" + "," + "\"DE_META\"" + ":" + "\"" + rowAsMap("DE_META") + "\"" + "},"

    val msgBodyJson1 =  "\"ShipmentAssociationDescribed\"" + ":" + "{" + "\"Primary_Object_Key\"" + ":" + "\"" + rowAsMap("Primary_Object_Key") + "\"" + "," + "\"Domain_Event_Type_Key\"" + ":" + "\"" + rowAsMap("Domain_Event_Type_Key") + "\"" + "," + "\"Association_Key\"" + ":" + "\"" + rowAsMap("Association_Key") + "\""

    val msgBodyJson2 = "{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key1") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key1") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value1") + "\"" + "}"

    val msgBodyJson3 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key2") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key2") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value2") + "\"" + "}"

    val msgBodyJson4 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key3") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key3") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value3") + "\"" + "}"

    val msgBodyJson5 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key4") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key4") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value4") + "\"" + "}"

    val msgBodyJson6 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key5") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key5") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value5") + "\"" + "}"

    val msgBodyJson7 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key6") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key6") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value6") + "\"" + "}"

    val msgBodyJson8 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key7") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key7") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value7") + "\"" + "}"

    val msgBodyJson9 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key8") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key8") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value8") + "\"" + "}"

    val msgBodyJson10 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key9") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key9") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value9") + "\"" + "}"

    val msgBodyJson11 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key10") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key10") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value10") + "\"" + "}"

    val msgBodyJson12 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key11") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key11") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value11") + "\"" + "}"

    val msgBodyJson13 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key12") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key12") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value12") + "\"" + "}"
	
	val msgBodyJson14 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key13") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key13") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value13") + "\"" + "}"
	
	val msgBodyJson15 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key14") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key14") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value14") + "\"" + "}"
	
	val msgBodyJson16 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key15") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key15") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value15") + "\"" + "}"

	val msgBodyJson17 = ",{" + "\"Association_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Association_Characteristic_Key16") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key16") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value16") + "\"" + "}"

    val msgBodyJson18 = "," + "\"AssociationCharacteristics\":[" + msgBodyJson2 + msgBodyJson3 + msgBodyJson4 + msgBodyJson5 + msgBodyJson6 + msgBodyJson7 + msgBodyJson8 + msgBodyJson9 + msgBodyJson10 + msgBodyJson11 + msgBodyJson12 + msgBodyJson13 + msgBodyJson14 + msgBodyJson15 + msgBodyJson16 + msgBodyJson17 +"]"

    val msgBodyJson19 = "," + "\"Domain_Event_Key\"" + ":" + "\"" + rowAsMap("Domain_Event_Key") + "\"" + "," + "\"Correlation_Id\"" + ":" + "\"" + rowAsMap("Correlation_Id") + "\"" + "," + "\"Client_Identification\"" + ":" + "\"" + rowAsMap("Client_Identification") + "\"" + "," + "\"System_Key\"" + ":" + "\"" + rowAsMap("System_Key") + "\"" + "," + "\"Proc_Ts\"" + ":" + "\"" + rowAsMap("Proc_Ts") + "\"" + "," + "\"Proc_Ts_Tz_Dst_Cd\"" + ":" + "\"" + rowAsMap("Proc_Ts_Tz_Dst_Cd") + "\"" + "," + "\"Event_Ts\"" + ":" + "\"" + rowAsMap("Event_Ts") + "\"" + "," + "\"Event_Ts_Tz_Dst_Cd\"" + ":" + "\"" + rowAsMap("Event_Ts_Tz_Dst_Cd") + "\"" + "}}"

    val shipAssociatedDescFinalJson =  msgHeaderJson + msgBodyJson1 + msgBodyJson18 + msgBodyJson19   
    logger.debug("ShipmentAssociatedDescribedForEachWriter End :: buildJson")
    shipAssociatedDescFinalJson
  }
}