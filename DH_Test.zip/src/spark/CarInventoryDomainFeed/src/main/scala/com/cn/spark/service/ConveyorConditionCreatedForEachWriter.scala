package com.cn.spark.service

import java.util.Calendar
import java.util.Properties

import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.log4j.Logger
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.Row

import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.commonsEngine.CommonsUtil
class ConveyorConditionCreatedForEachWriter() extends ForeachWriter[Row] with ApplicationConfigEngine with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  @transient lazy val kafkaProperties: Properties = CommonsUtil.getKafkaProperties()

  var producer: KafkaProducer[String, String] = _
  def open(partition_id: Long, epoch_id: Long) = {
    // Open connection. This method is optional in Python.
    logger.debug("ConveyorConditionCreatedForEachWriter start:: open")
    producer = new KafkaProducer(kafkaProperties)
    logger.debug("ConveyorConditionCreatedForEachWriter end:: open")
    true
  }

  //convert to json and write to kafka
  def process(row: Row) = {
    logger.debug("Start process() function ConveyorConditionCreatedForEachWriter")
    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
    producer.send(new ProducerRecord(environmentValues.get("TRANSPORTATION_CNVY_COND_CRT_PREPARED"), buildJson(rowAsMap)))
    logger.debug("End process() function ConveyorConditionCreatedForEachWriter")
  }

  def close(error: Throwable) = {
    logger.debug("Start close() ConveyorConditionCreatedForEachWriter")
    producer.close()
    logger.debug("End close() ConveyorConditionCreatedForEachWriter")
  }

  // build json message for Route Conveyor Matched
  def buildJson(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("ConveyorConditionCreatedForEachWriter Start :: buildJson")
    val currentTimeInUTC = CommonsUtil.getUTCTimeStamp
    val msgHeaderJson = "{" + "\"DomainEventHeader\"" + ":" + "{" + "\"SOR_INGT_CRT_TS\"" + ":" + "\"" + rowAsMap("SOR_INGT_CRT_TS") + "\"" + "," + "\"SOR_READ_TS\"" + ":" + "\"" + rowAsMap("SOR_READ_TS") + "\"" + "," + "\"DE_CRT_TS\"" + ":" + "\"" + currentTimeInUTC + "\"" + "," + "\"SOR_TPIC_NM\"" + ":" + "\"" + rowAsMap("SOR_TPIC_NM") + "\"" + "," + "\"DE_META\"" + ":" + "\"" + rowAsMap("DE_META") + "\"" + "},"
    val msgBodyJson0 = "\"ConveyorConditionCreated\"" + ":" + "{" + "\"Domain_Event_Type_Key\"" + ":" + "\"" + rowAsMap("Domain_Event_Type_Key") + "\"" + "," + "\"Conveyor_Key\"" + ":" + "\"" + rowAsMap("Conveyor_Key") + "\"" + "," + "\"ConditionCharacteristics\"" + ":[{" + "\"Condition_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Condition_Characteristic_Key1") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key1") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value1") + "\"" + "},{" + "\"Condition_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Condition_Characteristic_Key2") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key2") + "\"" + "," + "\"Characteristic_Value\"" + ":"
    val msgBodyJson1 = "\"" + rowAsMap("Characteristic_Value2") + "\""
    val msgBodyJson2 = "},{" + "\"Condition_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Condition_Characteristic_Key3") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key3") + "\"" + "," + "\"Characteristic_Value\"" + ":"
    val msgBodyJson3 = "\"" + rowAsMap("Characteristic_Value3") + "\""
    val msgBodyJson4 = "},{" + "\"Condition_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Condition_Characteristic_Key4") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key4") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value4") + "\""
    val msgBodyJson5 = "}]," + "\"Domain_Event_Key\"" + ":" + "\"" + rowAsMap("Domain_Event_Key") + "\"" + "," + "\"Correlation_Id\"" + ":" + "\"" + rowAsMap("Correlation_Id") + "\"" + "," + "\"Client_Identification\"" + ":" + "\"" + rowAsMap("Client_Identification") + "\"" + "," + "\"System_Key\"" + ":" + "\"" + rowAsMap("System_Key") + "\"" + "," + "\"Proc_Ts\"" + ":" + "\"" + rowAsMap("Proc_Ts") + "\"" + "," + "\"Proc_Ts_Tz_Dst_Cd\"" + ":" + "\"" + rowAsMap("Proc_Ts_Tz_Dst_Cd") + "\"" + "," + "\"Event_Ts\"" + ":" + "\"" + rowAsMap("Event_Ts") + "\"" + "," + "\"Event_Ts_Tz_Dst_Cd\"" + ":" + "\"" + rowAsMap("Event_Ts_Tz_Dst_Cd") + "\"" + "}}"

    val conveyorConditionCreatedFinalJson = msgHeaderJson + msgBodyJson0 + msgBodyJson1 + msgBodyJson2 + msgBodyJson3 + msgBodyJson4 + msgBodyJson5
    logger.debug("ConveyorConditionCreatedForEachWriter End :: buildJson")
    conveyorConditionCreatedFinalJson
  }
}