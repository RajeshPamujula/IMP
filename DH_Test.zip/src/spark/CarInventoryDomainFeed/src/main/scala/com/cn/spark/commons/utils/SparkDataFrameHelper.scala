package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{ col, concat, lit, regexp_replace, to_utc_timestamp, trim, when, to_date, year, date_format, substring }
import com.cn.spark.idFactory.IDGenerationEngine
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.timezoneConversionFactory.TimeZoneConversionEngine
import org.apache.spark.sql.types.{ StringType, StructField }

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def filterOutMessages(inputDF: DataFrame, tzDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::filterOutMessages::Start")

    val selectedDF = inputDF
      .filter(trim(col("record.IBMSNAP_OPERATION")) =!= "D")
      .select(
        col("record.PROC_DTTM").alias("PROC_DTTM"),
        trim(col("record.STN_333")).alias("STN_333"),
        trim(col("record.STN_ST")).alias("STN_ST"),
        trim(col("record.EVT_DT")).alias("EVT_DT"),
        trim(col("record.EVT_TM")).alias("EVT_TM"),
        col("record").alias("record"),
        col("SOR_READ_TS").alias("SOR_READ_TS"),
        col("JSON_DATA").alias("JSON_DATA"),
        col("topic").alias("SOR_TPIC_NM"))

    //LOCAL_TIME, LOCAL_YEAR, DST, (STN_SCAC & FSAC) OR (STN_333 & STN_PRST)
    val transformPrepProcTsTimeZoneDF = selectedDF
      .withColumn("LOCAL_TIME", regexp_replace(col("PROC_DTTM"), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2}).(\\d{3})", "$1-$2-$3 $4:$5:$6.$7"))
      .withColumn("LOCAL_YEAR", substring(col("PROC_DTTM"), 1, 4))
      //Using STN_SCAC & FSAC for Time Zone Conversion
      .withColumn("STN_SCAC", lit("CN"))
      .withColumn("FSAC", lit("33273"))

    val transformWithProcTsTimeZoneDF = TimeZoneConversionEngine.toUTCConversion(transformPrepProcTsTimeZoneDF, tzDF, "SCAC")

    val finalWithProcTsTimeZoneDF = transformWithProcTsTimeZoneDF
      .withColumn("Proc_Ts", trim(col("UTC_TIME_FORMATTED")))
      .withColumn("Proc_Ts_Tz_Dst_Cd", trim(col("TZ_DST_CD")))
      .drop("LOCAL_TIME")
      .drop("LOCAL_YEAR")
      .drop("DST")
      .drop("STN_PRST")
      .drop("UTC_TIME_FORMATTED")
      .drop("TZ_DST_CD")

    //LOCAL_TIME, LOCAL_YEAR, DST, (STN_SCAC & FSAC) OR (STN_333 & STN_PRST)
    val transformPrepEventTsTimeZoneDF = finalWithProcTsTimeZoneDF
      .withColumn("LOCAL_TIME", regexp_replace(concat(col("EVT_DT"), lit("-"), col("EVT_TM")), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2})", "$1-$2-$3 $4:$5:$6.000"))
      .withColumn("LOCAL_YEAR", date_format(col("EVT_DT"), "yyyy"))
      //column STN_PRST is mandatory to compute Time Zone Conversion
      .withColumn("STN_PRST", when(col("STN_ST") === "PQ", lit("QC")).otherwise(col("STN_ST")))
      .withColumn("Station_Key", when(col("record.STN_333").isNull || col("record.STN_333") === "", lit("SCAC")).otherwise(lit("333")))

    val transformWithEventTsTimeZoneDF1 = TimeZoneConversionEngine.toUTCConversion(transformPrepEventTsTimeZoneDF.filter(trim(col("Station_Key")) === "333"), tzDF, "333")
    val transformWithEventTsTimeZoneDF2 = TimeZoneConversionEngine.toUTCConversion(transformPrepEventTsTimeZoneDF.filter(trim(col("Station_Key")) === "SCAC"), tzDF, "SCAC")

    val transformWithEventTsTimeZoneDF3 = transformWithEventTsTimeZoneDF1
      .withColumn("Event_Ts", trim(col("UTC_TIME_FORMATTED")))
      .withColumn("Event_Ts_Tz_Dst_Cd", trim(col("TZ_DST_CD")))
      .drop("LOCAL_TIME")
      .drop("LOCAL_YEAR")
      .drop("STN_PRST")
      .drop("STN_SCAC")
      .drop("FSAC")
      .drop("DST")
      .drop("UTC_TIME_FORMATTED")
      .drop("TZ_DST_CD")
      .drop("Station_Key")
      .drop("STN_333")

    val transformWithEventTsTimeZoneDF4 = transformWithEventTsTimeZoneDF2
      .withColumn("Event_Ts", trim(col("UTC_TIME_FORMATTED")))
      .withColumn("Event_Ts_Tz_Dst_Cd", trim(col("TZ_DST_CD")))
      .drop("LOCAL_TIME")
      .drop("LOCAL_YEAR")
      .drop("STN_PRST")
      .drop("STN_SCAC")
      .drop("FSAC")
      .drop("DST")
      .drop("UTC_TIME_FORMATTED")
      .drop("TZ_DST_CD")
      .drop("Station_Key")
      .drop("STN_333")

    val finalWithEventTsTimeZoneDF = transformWithEventTsTimeZoneDF3.union(transformWithEventTsTimeZoneDF4)

    logger.debug("SparkDataFrameHelper::filterOutMessages::End")

    finalWithEventTsTimeZoneDF
  }

  def applyCommonTransformations(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransformation::Start")

    //GetHash Key (PRNT_TYPE_CD='System', TYPE_CD='SRS-YIT') from reference data
    val systemKey = CommonsUtil.getRefData(referenceData, "System", "SRS-YIT")

    //trim the columns and convert timestamp
    val transformDF = inputDF
      .withColumn("Client_Identification", when(col("USER_ID").isNull, lit("SRS-YIT)")).otherwise(trim(col("USER_ID"))))
      .withColumn("System_Key", lit(systemKey))

    logger.debug("SparkDataFrameHelper::applyTransformation::End")
    transformDF
  }

  /*An interchange receive event is when the EVT_CD is 'RR'.
    A release event is when either is indicated:
    the EVT_CD is 'RI' and the EVST_CD is 'RL'
    the EVT_CD is 'RI' and the EVST_CD is 'RE'*/
  /*  def applyInterchangeFilter(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyInterchangeFilter::Start")
    val finalDF = inputDF.filter((col("EVT_CD") === "RR") || ((col("EVT_CD") === "RI" && col("EVST_CD") === "RL") || (col("EVT_CD") === "RI" && col("EVST_CD") === "RE")))
    logger.debug("SparkDataFrameHelper::applyInterchangeFilter::End")
    finalDF
  }*/

  def applyTransEventReportTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransEventReportTransformation::Start")

    //Domain Event Type from Reference data
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")

    //Transportation Event Type from Reference Data
    val transpEvtTypeKey = CommonsUtil.getRefData(referenceData, "Transportation Event", "Railcar Event")

    //Adding Transportation Event column using hash key of EVT_C,EVST_CD, PROC_DTTM, EVT_DT, EVT_TM, CAR_INIT, CAR_NUMB
    // val transpEventKeyDF = IDGenerationEngine.createKeyForDF(inputDF, "Transportation_Event_Key", List("EVT_CD","EVST_CD","EVT_DT", "EVT_TM", "CAR_INIT", "CAR_NUMB"))
    val transpEventKeyDF = IDGenerationEngine.createKeyForDF(inputDF, "Transportation_Event_Key", List("CAR_INIT", "CAR_NUMB"))

    //Adding Domain Event Type Key and Transportation Event Type columns to dataframe
    val transEvtTypeKeytDF = transpEventKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Transportation_Event_Type_Key", lit(transpEvtTypeKey))

    //Adding Transportation_Event_Value column - Concatenate EVT_CD & EVST_CD
    val transpEvtValueDF = transEvtTypeKeytDF.withColumn("Transportation_Event_Value", concat(transEvtTypeKeytDF.col("EVT_CD"), transEvtTypeKeytDF.col("EVST_CD")))

    //Adding Primary_Object_Key column - Concatenate CAR_INIT & CAR_NUMB
    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(transpEvtValueDF, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))

    //Adding Domain Event Key column with hash key of "Domain_Event_Type_Key", "Transportation_Event_Key", "Client_Identification", "System_Key"
    val transEvtReportFinalDF = IDGenerationEngine.createKeyForDF(primaryObjKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Transportation_Event_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))

    logger.debug("SparkDataFrameHelper::applyTransEventReportTransformation::End")
    transEvtReportFinalDF

  }
  //Publish Domain Event TRANSPORTATION EVENT DESCRIBED to Kafka topic: <env>.tm.prepared.trspEvtDsc.v1 (TDH-875)
  def applyTrnspEventDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTrnspEventDescribedTransformation::Start")
    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(inputDF, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
    val domainEventTypeKey = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")

    //add Domain_Event_Type_Key column with hash value
    val domainEventTypeDF = primaryObjKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventTypeKey))

    //val transpEventKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeDF, "Transportation_Event_Key", List("EVT_CD","EVST_CD","EVT_DT", "EVT_TM", "CAR_INIT", "CAR_NUMB"))
    val transpEventKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeDF, "Transportation_Event_Key", List("CAR_INIT", "CAR_NUMB"))
    // FOR ITERATION ONE
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Event')
    val charTypeRefKey = CommonsUtil.getRefData(referenceData, "Characteristic", "Event")

    //add Characteristic_Type_Key column with hash value
    val charTypeKeyDF = transpEventKeyDF.withColumn("Characteristic_Type_Key", lit(charTypeRefKey))

    //Hash of : Conveyor_Key and Characteristic_Type_Key
    val trnspEvtCharKeyDF = IDGenerationEngine.createKeyForDF(charTypeKeyDF, "Transportation_Event_Characteristic_Key", List("Transportation_Event_Key", "Characteristic_Type_Key"))

    //Characteristic_Value - Car Init, Car Numb map from the message
    val charValueDF = trnspEvtCharKeyDF.withColumn("Characteristic_Value", concat(col("EVT_CD"), col("EVST_CD")))

    // Hash of target fields:Domain_Event_Type_Key,Conveyor_Key,Client_Identification,System_Key,PROC_DTTM
    val eventDescFinalDF = IDGenerationEngine.createKeyForDF(charValueDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Transportation_Event_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))

    logger.debug("SparkDataFrameHelper::applyTrnspEventDescribedTransformation::End")
    eventDescFinalDF

  }

  def applyConveyorDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTransformation::Start")
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
    val domainEventTypeKey = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    //add Domain_Event_Type_Key column with hash value
    val domainEventTypeDF = inputDF.withColumn("Domain_Event_Type_Key", lit(domainEventTypeKey))
    //Generated by a Hash key using the Car Init/Numb
    val convKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeDF, "Conveyor_Key", List("CAR_INIT", "CAR_NUMB"))
    // FOR ITERATION one
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Pool Id')
    val charTypeRefKey = CommonsUtil.getRefData(referenceData, "Characteristic", "Pool Id")

    //add Characteristic_Type_Key1 for Iteration2 column with hash value
    val charTypeKeyDF = convKeyDF.withColumn("Characteristic_Type_Key", lit(charTypeRefKey))
    //Hash of : Conveyor_Key and Characteristic_Type_Key
    val convCharKeyDF = IDGenerationEngine.createKeyForDF(charTypeKeyDF, "Conveyor_Characteristic_Key", List("Conveyor_Key", "Characteristic_Type_Key"))
    //Characteristic_Value - SFE_POOL_ID
    val charValuDF = convCharKeyDF.withColumn("Characteristic_Value", col("SFE_POOL_ID"))
    // Hash of target fields:Domain_Event_Type_Key,Conveyor_Key,Client_Identification,System_Key,PROC_DTTM
    val convDescFinalDF = IDGenerationEngine.createKeyForDF(charValuDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTransformation::End")
    convDescFinalDF
  }

  def applyEventAssociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyEventAssociatedTransformation::Start")

    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(inputDF, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Associated')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    val domainEventTypeDF = primaryObjKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))

    //GetHash Key (PRNT_TYPE_CD='Association', TYPE_CD='Inter-BCD Event-Location')
    val assocTypeKey = CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Event-Location")
    val assocTypeKeyDF = domainEventTypeDF.withColumn("Association_Type_Key", lit(assocTypeKey))

    //Adding Transportation Event column using hash key of EVT_C,EVST_CD, PROC_DTTM, EVT_DT, EVT_TM, CAR_INIT, CAR_NUMB
    //val transpEventKeyDF = IDGenerationEngine.createKeyForDF(assocTypeKeyDF, "Transportation_Event_Key", List("EVT_CD", "EVST_CD", "EVT_DT", "EVT_TM", "CAR_INIT", "CAR_NUMB"))
    //Adding Transportation Event column using hash key of CAR_INIT, CAR_NUMB
    val transpEventKeyDF = IDGenerationEngine.createKeyForDF(assocTypeKeyDF, "Transportation_Event_Key", List("CAR_INIT", "CAR_NUMB"))

    //GetHash Key (PRNT_TYPE_CD='Transportation Event', TYPE_CD='Railcar Event')
    val transpEventTypeKey = CommonsUtil.getRefData(referenceData, "Transportation Event", "Railcar Event")
    val transpEventTypeKeyDF = transpEventKeyDF.withColumn("Transportation_Event_Type_Key", lit(transpEventTypeKey))

    //Hash of SOR fields:STN_333,STN_ST
    val assocObjKeyDF = IDGenerationEngine.createKeyForDF(transpEventTypeKeyDF, "Associated_Object_Key", List("STN_333", "STN_ST"))
    //Hash of Transportation_Event_Key and Associated_Object_Key
    //val assocKeyDF = IDGenerationEngine.createKeyForDF(assocObjKeyDF, "Association_Key", List("Transportation_Event_Key", "Associated_Object_Key"))
    //Hash of: Trim CAR_NUMB, Concatenate CAR_INIT, CAR_NUMB, STN_333, STN_ST
    val ConcaKeysDF = assocObjKeyDF.withColumn("Concat_CarInit_CarNumb", concat(col("CAR_INIT"), col("CAR_NUMB")))
    val assocKeyDF = IDGenerationEngine.createKeyForDF(ConcaKeysDF, "Association_Key", List("Concat_CarInit_CarNumb", "STN_333", "STN_ST"))
    //GetHash Key (PRNT_TYPE_CD='Location', TYPE_CD='Station')
    val assocObjTypeKey = CommonsUtil.getRefData(referenceData, "Location", "Station")
    val assocObjTypeKeyDF = assocKeyDF.withColumn("Associated_Object_Type_Key", lit(assocObjTypeKey))
    //Hash of target fields:Domain_Event_Type_Key,Conveyor_Key,Transportation_Event_Key,Client_Identification,System_Key,PROC_DTTM
    val eventAssociatedFinalDF = IDGenerationEngine.createKeyForDF(assocObjTypeKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Transportation_Event_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))
      .drop("Concat_CarInit_CarNumb")
    logger.debug("SparkDataFrameHelper::applyEventAssociatedTransformation::End")
    eventAssociatedFinalDF
  }

  //TRANSPORTATION EVENT ASSOCIATION DESCRIBED
  def applyTransEvtAssocDescTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransEvtAssocDescTransformation::Start")
    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(inputDF, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))

    // GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val domainEventTypeDF = primaryObjKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))

    //Adding Transportation Event column using hash key of EVT_C,EVST_CD, PROC_DTTM, EVT_DT, EVT_TM, CAR_INIT, CAR_NUMB
    // val transpEventKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeDF, "Transportation_Event_Key", List("CAR_INIT", "CAR_NUMB"))

    //GetHash Key (PRNT_TYPE_CD='Transportation Event', TYPE_CD='Railcar Event')
    /*   val transpEventTypeKeyRefDF = referenceDF.filter(col("prnt_type_cd") === "Transportation Event" && col("type_cd") === "Railcar Event")
    val transpEventTypeKey = transpEventTypeKeyRefDF.collect().toList.head.getString(2)
    val transpEventTypeKeyDF =transpEventKeyDF.withColumn("Transportation_Event_Type_Key", lit(transpEventTypeKey))*/

    //Hash of SOR fields:STN_333,STN_ST
    // val assocObjKeyDF = IDGenerationEngine.createKeyForDF(transpEventTypeKeyDF, "Associated_Object_Key", List("STN_333","STN_ST"))

    //Hash of target fields:Associated_Object_Key,Transportation_Event_Key
    //val assocKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeDF, "Association_Key", List("Transportation_Event_Key", "Associated_Object_Key"))
    //Hash of: Trim CAR_NUMB, Concatenate CAR_INIT, CAR_NUMB, STN_333, STN_ST
    val ConcaKeysDF = domainEventTypeDF.withColumn("Concat_CarInit_CarNumb", concat(col("CAR_INIT"), col("CAR_NUMB")))
    val assocKeyDF = IDGenerationEngine.createKeyForDF(ConcaKeysDF, "Association_Key", List("Concat_CarInit_CarNumb", "STN_333", "STN_ST"))
    // val assocKeyDF = domainEventTypeDF.withColumn("Association_Key",col("Domain_Event_Key"))
    //ITERATION 1
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Track Number')
    val charTypeKey = CommonsUtil.getRefData(referenceData, "Characteristic", "Track Number")
    val charTypeKeyDF = assocKeyDF.withColumn("Characteristic_Type_Key1", lit(charTypeKey))

    //Hash of:Association_Key,Characteristic_Type_Key1
    val associationCharKeyDF = IDGenerationEngine.createKeyForDF(charTypeKeyDF, "Association_Characteristic_Key1", List("Association_Key", "Characteristic_Type_Key1"))

    //TRK_NUMB
    val charValDF = associationCharKeyDF.withColumn("Characteristic_Value1", when(col("TRK_NUMB").isNull, lit("")).otherwise(col("TRK_NUMB")))

    //ITERATION 2
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Track Sequence Number')
    val charTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Track Sequence Number")
    val charTypeKeyDF1 = charValDF.withColumn("Characteristic_Type_Key2", lit(charTypeKey1))

    //Hash of:Association_Key,Characteristic_Type_Key2
    val associationCharKeyDF1 = IDGenerationEngine.createKeyForDF(charTypeKeyDF1, "Association_Characteristic_Key2", List("Association_Key", "Characteristic_Type_Key2"))

    //TRK_SEQ_NUMB
    val charValDF1 = associationCharKeyDF1.withColumn("Characteristic_Value2", when(col("TRK_SEQ_NUMB").isNull, lit("")).otherwise(col("TRK_SEQ_NUMB")))

    //ITERATION 3
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Current Spot'')
    val charTypeKey2 = CommonsUtil.getRefData(referenceData, "Characteristic", "Current Spot")
    val charTypeKeyDF2 = charValDF1.withColumn("Characteristic_Type_Key3", lit(charTypeKey2))

    //Hash of:Association_Key,Characteristic_Type_Key1
    val associationCharKeyDF2 = IDGenerationEngine.createKeyForDF(charTypeKeyDF2, "Association_Characteristic_Key3", List("Association_Key", "Characteristic_Type_Key3"))

    //CURR_SPOT
    val charValDF2 = associationCharKeyDF2.withColumn("Characteristic_Value3", when(col("CURR_SPOT").isNull, lit("")).otherwise(col("CURR_SPOT")))

    //Hash of target fields:Domain_Event_Type_Key,Associated_Object_Key,Transportation_Event_Key,Client_Identification,System_Key,PROC_DTTM
    val eventAssocDescFinalDF = IDGenerationEngine.createKeyForDF(charValDF2, "Domain_Event_Key", List("Domain_Event_Type_Key", "Transportation_Event_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))
      .drop("Concat_CarInit_CarNumb")
    logger.debug("SparkDataFrameHelper::applyTransEvtAssocDescTransformation::End")
    eventAssocDescFinalDF
  }

  //CONVEYOR CONDITION CREATED
  def applyConveyorConditionCreatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorConditionCreatedTransformation::Start")
    //GetHash Key (PRNT_TYPE_CD='Association', TYPE_CD='Inter-BCD Conveyor-Event')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val domainEventTypeDF = inputDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
    //Generated by a Hash key using the Car Init/Numb
    val convKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeDF, "Conveyor_Key", List("CAR_INIT", "CAR_NUMB"))
    //ITERATION 1: CAR_LOC_CD
    //GetHash Key (PRNT_TYPE_CD='Characteristic',TYPE_CD='Car Location Code')
    val charTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Car Location Code")
    val charTypeKeyDF1 = convKeyDF.withColumn("Characteristic_Type_Key1", lit(charTypeKey1))
    //Hash of : Conveyor_Key and Characteristic_Type_Key
    val condCharTypeKeyDF1 = IDGenerationEngine.createKeyForDF(charTypeKeyDF1, "Condition_Characteristic_Key1", List("Conveyor_Key", "Characteristic_Type_Key1"))
    //Copy CAR_LOC_CD
    val charValueDF1 = condCharTypeKeyDF1.withColumn("Characteristic_Value1", col("CAR_LOC_CD"))
    //ITERATION 2: BO_CD
    //GetHash Key (PRNT_TYPE_CD='Characteristic',TYPE_CD='Bad Order Code')
    val charTypeKey2 = CommonsUtil.getRefData(referenceData, "Characteristic", "Bad Order Code")
    val charTypeKeyDF2 = charValueDF1.withColumn("Characteristic_Type_Key2", lit(charTypeKey2))
    //Hash of : Conveyor_Key and Characteristic_Type_Key
    val condCharTypeKeyDF2 = IDGenerationEngine.createKeyForDF(charTypeKeyDF2, "Condition_Characteristic_Key2", List("Conveyor_Key", "Characteristic_Type_Key2"))
    //Copy BO_CD
    val charValueDF2 = condCharTypeKeyDF2.withColumn("Characteristic_Value2", when(col("BO_CD").isNull, lit("")).otherwise((col("BO_CD"))))
    //ITERATION 3: MECH_STAT_CD
    //GetHash Key (PRNT_TYPE_CD='Characteristic',TYPE_CD='Mechanical Status Codes')
    val charTypeKey3 = CommonsUtil.getRefData(referenceData, "Characteristic", "Mechanical Status Codes")
    val charTypeKeyDF3 = charValueDF2.withColumn("Characteristic_Type_Key3", lit(charTypeKey3))
    //Hash of : Conveyor_Key and Characteristic_Type_Key
    val condCharTypeKeyDF3 = IDGenerationEngine.createKeyForDF(charTypeKeyDF3, "Condition_Characteristic_Key3", List("Conveyor_Key", "Characteristic_Type_Key3"))
    //Copy BO_CD
    val charValueDF3 = condCharTypeKeyDF3.withColumn("Characteristic_Value3", when(concat(condCharTypeKeyDF3.col("MECH_STAT_CD1"), condCharTypeKeyDF3.col("MECH_STAT_CD2"), condCharTypeKeyDF3.col("MECH_STAT_CD3")).isNull, lit(""))
      .otherwise(concat(condCharTypeKeyDF3.col("MECH_STAT_CD1"), condCharTypeKeyDF3.col("MECH_STAT_CD2"), condCharTypeKeyDF3.col("MECH_STAT_CD3"))))

    //ITERATION 4: BO_ETR_HRS
    //GetHash Key (PRNT_TYPE_CD='Characteristic',TYPE_CD='Bad Order Code')
    val charTypeKey4 = CommonsUtil.getRefData(referenceData, "Characteristic", "Bad Order Estimated Time to Repair Hours")
    val charTypeKeyDF4 = charValueDF3.withColumn("Characteristic_Type_Key4", lit(charTypeKey4))
    //Hash of : Conveyor_Key and Characteristic_Type_Key
    val condCharTypeKeyDF4 = IDGenerationEngine.createKeyForDF(charTypeKeyDF4, "Condition_Characteristic_Key4", List("Conveyor_Key", "Characteristic_Type_Key4"))
    //Copy BO_ETR_HRS
    val charValueDF4 = condCharTypeKeyDF4.withColumn("Characteristic_Value4", when(col("BO_ETR_HRS").isNull, lit("")).otherwise((col("BO_ETR_HRS"))))
    //Hash of target fields:Domain_Event_Type_Key,Trip_Key,Client_Identification,Client_Identification,System_Key and PROC_DTTM
    val convCreatedFinalDF = IDGenerationEngine.createKeyForDF(charValueDF4, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorConditionCreatedTransformation::End")
    convCreatedFinalDF
  }

  def applyShipmentAssociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyShipmentAssociatedTransformation::Start")
    val transformDF = inputDF.withColumn("Con_carInit_carNumb", concat(col("CAR_INIT"), col("CAR_NUMB")))
    val transformDF1 = transformDF.withColumn("WB_NUMB_1", when((trim(col("WB_NUMB")) === "" || trim(col("WB_NUMB")).isNull), lit("      ")).otherwise(trim(col("WB_NUMB"))))

    //    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(transformDF1, "Primary_Object_Key", List("Con_carInit_carNumb", "WB_NUMB_1", "WB_DT"))
    val ConcatKeysDF = transformDF1.withColumn("Conca_WBID_SRS", concat(col("WB_ID"), lit("SRSWB")))
    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(ConcatKeysDF, "Primary_Object_Key", List("Con_carInit_carNumb"))
    val domainEventTypeKey = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    val domainEventTypeKeyDF = primaryObjKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventTypeKey))
    val associationKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeKeyDF, "Association_Key", List("Conca_WBID_SRS", "Con_carInit_carNumb"))

    val associationTypeKey = CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Shipment-Conveyor")
    val associationTypeKeyDF = associationKeyDF.withColumn("Association_Type_Key", lit(associationTypeKey))
    val shipmentKeyDF = IDGenerationEngine.createKeyForDF(associationTypeKeyDF, "Shipment_Key", List("Conca_WBID_SRS"))
    val shipmentTypeKey = CommonsUtil.getRefData(referenceData, "Shipment", "Waybill")
    val shipmentTypeKeyDF = shipmentKeyDF.withColumn("Shipment_Type_Key", lit(shipmentTypeKey))
    val associatedObjKey = IDGenerationEngine.createKeyForDF(shipmentTypeKeyDF, "Associated_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    val associatedObjTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Railcar")
    val associatedObjTypeKeyDF = associatedObjKey.withColumn("Associated_Object_Type_Key", lit(associatedObjTypeKey))
    val shipmAssociatedFinalDF = IDGenerationEngine.createKeyForDF(associatedObjTypeKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Shipment_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))
      .drop("WB_NUMB")
      .drop("CAR_INIT")
      .drop("Con_carInit_carNumb")
      .drop("WB_NUMB_1")
      .drop("CAR_NUMB")
      .drop("WB_DT")
      .drop("Conca_WBID_SRS")
      .drop("WB_ID")
    logger.debug("SparkDataFrameHelper::applyShipmentAssociatedTransformation::End")
    shipmAssociatedFinalDF
  }
  def applyShipmentAssociatedDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyShipmentAssociatedDescribedTransformation::Start")
    val domainEventTypeKey = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val domainEventTypeKeyDF = inputDF.withColumn("Domain_Event_Type_Key", lit(domainEventTypeKey))
    //val associationKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeKeyDF, "Association_Key", List("Shipment_Key", "Associated_Object_Key"))
    // start of iteration.
    val characteristicTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Train Block")
    val characteristicTypeKey2 = CommonsUtil.getRefData(referenceData, "Characteristic", "Yard Block")
    val characteristicTypeKey3 = CommonsUtil.getRefData(referenceData, "Characteristic", "Op ZTS")
    val characteristicTypeKey4 = CommonsUtil.getRefData(referenceData, "Characteristic", "Customer Switch Code")
    val characteristicTypeKey5 = CommonsUtil.getRefData(referenceData, "Characteristic", "Next Assignment Train Type")
    val characteristicTypeKey6 = CommonsUtil.getRefData(referenceData, "Characteristic", "Next Assignment Train Symbol")
    val characteristicTypeKey7 = CommonsUtil.getRefData(referenceData, "Characteristic", "Next Assignment Train Section")
    val characteristicTypeKey8 = CommonsUtil.getRefData(referenceData, "Characteristic", "Next Assignment Train Day")
    val characteristicTypeKey9 = CommonsUtil.getRefData(referenceData, "Characteristic", "Operating Origin 333")
    val characteristicTypeKey10 = CommonsUtil.getRefData(referenceData, "Characteristic", "Operating Origin 333 Province State Code")
    val characteristicTypeKey11 = CommonsUtil.getRefData(referenceData, "Characteristic", "Operating Station 333")
    val characteristicTypeKey12 = CommonsUtil.getRefData(referenceData, "Characteristic", "Operating Station 333 Province State Code")
    val characteristicTypeKey13 = CommonsUtil.getRefData(referenceData, "Characteristic", "Setout Station 333")
    val characteristicTypeKey14 = CommonsUtil.getRefData(referenceData, "Characteristic", "Setout Station 333 Province State Code")
    val characteristicTypeKey15 = CommonsUtil.getRefData(referenceData, "Characteristic", "Current Assignment")
    val characteristicTypeKey16 = CommonsUtil.getRefData(referenceData, "Characteristic", "Operating Railroad At Junction Point")
    val outputDF1 = domainEventTypeKeyDF.withColumn("Characteristic_Type_Key1", lit(characteristicTypeKey1))
      .withColumn("Characteristic_Type_Key2", lit(characteristicTypeKey2))
      .withColumn("Characteristic_Type_Key3", lit(characteristicTypeKey3))
      .withColumn("Characteristic_Type_Key4", lit(characteristicTypeKey4))
      .withColumn("Characteristic_Type_Key5", lit(characteristicTypeKey5))
      .withColumn("Characteristic_Type_Key6", lit(characteristicTypeKey6))
      .withColumn("Characteristic_Type_Key7", lit(characteristicTypeKey7))
      .withColumn("Characteristic_Type_Key8", lit(characteristicTypeKey8))
      .withColumn("Characteristic_Type_Key9", lit(characteristicTypeKey9))
      .withColumn("Characteristic_Type_Key10", lit(characteristicTypeKey10))
      .withColumn("Characteristic_Type_Key11", lit(characteristicTypeKey11))
      .withColumn("Characteristic_Type_Key12", lit(characteristicTypeKey12))
      .withColumn("Characteristic_Type_Key13", lit(characteristicTypeKey13))
      .withColumn("Characteristic_Type_Key14", lit(characteristicTypeKey14))
      .withColumn("Characteristic_Type_Key15", lit(characteristicTypeKey15))
      .withColumn("Characteristic_Type_Key16", lit(characteristicTypeKey16))
      .withColumn("Characteristic_Value1", when(col("TRN_BLK").isNull, lit("")).otherwise(col("TRN_BLK")))
      .withColumn("Characteristic_Value2", when(col("YD_BLK").isNull, lit("")).otherwise(col("YD_BLK")))
      .withColumn("Characteristic_Value3", when(col("OP_ZTS").isNull, lit("")).otherwise(col("OP_ZTS")))
      .withColumn("Characteristic_Value4", when(col("CUST_SWTCH_CD").isNull, lit("")).otherwise(col("CUST_SWTCH_CD")))
      .withColumn("Characteristic_Value5", when(col("ASGN_TRN_TYPE").isNull, lit("")).otherwise(col("ASGN_TRN_TYPE")))
      .withColumn("Characteristic_Value6", when(col("ASGN_TRN_SYM").isNull, lit("")).otherwise(col("ASGN_TRN_SYM")))
      .withColumn("Characteristic_Value7", when(col("ASGN_TRN_SECT").isNull, lit("")).otherwise(col("ASGN_TRN_SECT")))
      .withColumn("Characteristic_Value8", when(col("ASGN_TRN_DAY").isNull, lit("")).otherwise(col("ASGN_TRN_DAY")))
      .withColumn("Characteristic_Value9", trim(col("OP_ORIG_333")))
      .withColumn("Characteristic_Value10", trim(col("OP_ORIG_ST")))
      .withColumn("Characteristic_Value11", trim(col("OP_CITY_333")))
      .withColumn("Characteristic_Value12", trim(col("OP_ST")))
      .withColumn("Characteristic_Value13", trim(col("ARR_333")))
      .withColumn("Characteristic_Value14", trim(col("ARR_ST")))
      .withColumn("Characteristic_Value15", when(col("CAR_LOC_CD") === "T", concat(col("TRN_TYPE"), col("TRN_SYM"), col("TRN_SECT"), col("TRN_DAY"))).otherwise(lit("")))
      .withColumn("Characteristic_Value16", when(col("OP_RAJP").isNull, lit("")).otherwise(col("OP_RAJP")))
      .drop("TRN_BLK")
      .drop("YD_BLK")
      .drop("OP_ZTS")
      .drop("CUST_SWTCH_CD")
      .drop("ASGN_TRN_TYPE")
      .drop("ASGN_TRN_SYM")
      .drop("ASGN_TRN_SECT")
      .drop("ASGN_TRN_DAY")
      .drop("OP_ORIG_333")
      .drop("OP_ORIG_ST")
      .drop("OP_CITY_333")
      .drop("OP_ST")
      .drop("ARR_333")
      .drop("ARR_ST")
      .drop("CAR_LOC_CD")
      .drop("TRN_TYPE")
      .drop("TRN_SYM")
      .drop("TRN_SECT")
      .drop("USER_ID")
      .drop("TRN_DAY")
      .drop("OP_RAJP")

    val outputDF2 = IDGenerationEngine.createKeyForDF(outputDF1, "Association_Characteristic_Key1", List("Association_Key", "Characteristic_Type_Key1"))
    val outputDF3 = IDGenerationEngine.createKeyForDF(outputDF2, "Association_Characteristic_Key2", List("Association_Key", "Characteristic_Type_Key2"))
    val outputDF4 = IDGenerationEngine.createKeyForDF(outputDF3, "Association_Characteristic_Key3", List("Association_Key", "Characteristic_Type_Key3"))
    val outputDF5 = IDGenerationEngine.createKeyForDF(outputDF4, "Association_Characteristic_Key4", List("Association_Key", "Characteristic_Type_Key4"))
    val outputDF6 = IDGenerationEngine.createKeyForDF(outputDF5, "Association_Characteristic_Key5", List("Association_Key", "Characteristic_Type_Key5"))
    val outputDF7 = IDGenerationEngine.createKeyForDF(outputDF6, "Association_Characteristic_Key6", List("Association_Key", "Characteristic_Type_Key6"))
    val outputDF8 = IDGenerationEngine.createKeyForDF(outputDF7, "Association_Characteristic_Key7", List("Association_Key", "Characteristic_Type_Key7"))
    val outputDF9 = IDGenerationEngine.createKeyForDF(outputDF8, "Association_Characteristic_Key8", List("Association_Key", "Characteristic_Type_Key8"))
    val outputDF10 = IDGenerationEngine.createKeyForDF(outputDF9, "Association_Characteristic_Key9", List("Association_Key", "Characteristic_Type_Key9"))
    val outputDF11 = IDGenerationEngine.createKeyForDF(outputDF10, "Association_Characteristic_Key10", List("Association_Key", "Characteristic_Type_Key10"))
    val outputDF12 = IDGenerationEngine.createKeyForDF(outputDF11, "Association_Characteristic_Key11", List("Association_Key", "Characteristic_Type_Key11"))
    val outputDF13 = IDGenerationEngine.createKeyForDF(outputDF12, "Association_Characteristic_Key12", List("Association_Key", "Characteristic_Type_Key12"))
    val outputDF14 = IDGenerationEngine.createKeyForDF(outputDF13, "Association_Characteristic_Key13", List("Association_Key", "Characteristic_Type_Key13"))
    val outputDF15 = IDGenerationEngine.createKeyForDF(outputDF14, "Association_Characteristic_Key14", List("Association_Key", "Characteristic_Type_Key14"))
    val outputDF16 = IDGenerationEngine.createKeyForDF(outputDF15, "Association_Characteristic_Key15", List("Association_Key", "Characteristic_Type_Key15"))
    val outputDF17 = IDGenerationEngine.createKeyForDF(outputDF16, "Association_Characteristic_Key16", List("Association_Key", "Characteristic_Type_Key16"))

    val shipmAssoDescFinalDF = IDGenerationEngine.createKeyForDF(outputDF17, "Domain_Event_Key", List("Domain_Event_Type_Key", "Shipment_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))
    // End of iteration.
    logger.debug("SparkDataFrameHelper::applyShipmentAssociatedDescribedTransformation::End")
    shipmAssoDescFinalDF
  }

  def getCommonTransformationDataFrame(inputDF: DataFrame): DataFrame = {
    val commonDF = inputDF
      .select(
        trim(col("record.INGT_CRT_TS")).alias("SOR_INGT_CRT_TS"),
        col("PROC_DTTM").alias("PROC_DTTM"),
        col("Proc_Ts").alias("Proc_Ts"),
        col("Proc_Ts_Tz_Dst_Cd").alias("Proc_Ts_Tz_Dst_Cd"),
        col("Event_Ts").alias("Event_Ts"),
        col("Event_Ts_Tz_Dst_Cd").alias("Event_Ts_Tz_Dst_Cd"),
        col("SOR_READ_TS").alias("SOR_READ_TS"),
        col("SOR_TPIC_NM").alias("SOR_TPIC_NM"),
        trim(col("record.USER_ID")).alias("USER_ID"),
        col("DE_META").alias("DE_META"),
        trim(col("record.INGT_UUID")).alias("Correlation_Id"),
        col("record").alias("record"))
    commonDF

  }

  def getConveyorConditionCreatedTransformation(inputDF: DataFrame): DataFrame = {
    val outputDF = inputDF
      .select(
        col("*"),
        trim(col("record.EVT_CD")).alias("EVT_CD"),
        trim(col("record.EVST_CD")).alias("EVST_CD"),
        trim(col("record.CAR_INIT")).alias("CAR_INIT"),
        trim(col("record.CAR_NUMB")).alias("CAR_NUMB"),
        col("record.CAR_LOC_CD").alias("CAR_LOC_CD"),
        col("record.BO_CD").alias("BO_CD"),
        col("record.MECH_STAT_CD1").alias("MECH_STAT_CD1"),
        col("record.MECH_STAT_CD2").alias("MECH_STAT_CD2"),
        col("record.MECH_STAT_CD3").alias("MECH_STAT_CD3"),
        col("record.BO_ETR_HRS").alias("BO_ETR_HRS"))
      .drop("record")
    outputDF
  }

  def getConveyorDescribedTransformation(inputDF: DataFrame): DataFrame = {
    val outputDF = inputDF
      .select(
        col("*"),
        trim(col("record.EVT_CD")).alias("EVT_CD"),
        trim(col("record.EVST_CD")).alias("EVST_CD"),
        trim(col("record.CAR_INIT")).alias("CAR_INIT"),
        trim(col("record.CAR_NUMB")).alias("CAR_NUMB"),
        trim(col("record.SFE_POOL_ID")).alias("SFE_POOL_ID"))
      .drop("record")
    outputDF
  }

  def getTransEventReportTransformation(inputDF: DataFrame): DataFrame = {
    val outputDF = inputDF
      .select(
        col("*"),
        trim(col("record.EVT_CD")).alias("EVT_CD"),
        trim(col("record.EVST_CD")).alias("EVST_CD"),
        trim(col("record.CAR_INIT")).alias("CAR_INIT"),
        trim(col("record.CAR_NUMB")).alias("CAR_NUMB"))
      .drop("record")
    outputDF
  }

  def getEventAssociatedTransformation(inputDF: DataFrame): DataFrame = {
    val outputDF = inputDF
      .select(
        col("*"),
        trim(col("record.STN_333")).alias("STN_333"),
        trim(col("record.STN_ST")).alias("STN_ST"),
        trim(col("record.CAR_INIT")).alias("CAR_INIT"),
        trim(col("record.CAR_NUMB")).alias("CAR_NUMB"),
        trim(col("record.TRK_NUMB")).alias("TRK_NUMB"),
        col("record.TRK_SEQ_NUMB").alias("TRK_SEQ_NUMB"),
        col("record.WB_ID").alias("WB_ID"),
        col("record.CURR_SPOT").alias("CURR_SPOT"))
      .drop("record")
    outputDF
  }

  def getShipmentAssociatedTransformation(inputDF: DataFrame): DataFrame = {
    val outputDF = inputDF
      .select(
        col("*"),
        trim(col("record.CAR_INIT")).alias("CAR_INIT"),
        trim(col("record.CAR_NUMB")).alias("CAR_NUMB"),
        col("record.WB_NUMB").alias("WB_NUMB"),
        col("record.WB_DT").alias("WB_DT"),
        col("record.TRN_BLK").alias("TRN_BLK"),
        col("record.YD_BLK").alias("YD_BLK"),
        col("record.OP_ZTS").alias("OP_ZTS"),
        col("record.CUST_SWTCH_CD").alias("CUST_SWTCH_CD"),
        col("record.ASGN_TRN_TYPE").alias("ASGN_TRN_TYPE"),
        col("record.ASGN_TRN_SYM").alias("ASGN_TRN_SYM"),
        col("record.ASGN_TRN_SECT").alias("ASGN_TRN_SECT"),
        col("record.ASGN_TRN_DAY").alias("ASGN_TRN_DAY"),
        col("record.OP_ORIG_333").alias("OP_ORIG_333"),
        col("record.WB_ID").alias("WB_ID"),
        trim(col("record.OP_RAJP")).alias("OP_RAJP"),
        trim(col("record.OP_ORIG_ST")).alias("OP_ORIG_ST"),
        trim(col("record.OP_CITY_333")).alias("OP_CITY_333"),
        trim(col("record.OP_ST")).alias("OP_ST"),
        trim(col("record.ARR_333")).alias("ARR_333"),
        trim(col("record.ARR_ST")).alias("ARR_ST"),
        col("record.CAR_LOC_CD").alias("CAR_LOC_CD"),
        col("record.TRN_TYPE").alias("TRN_TYPE"),
        col("record.TRN_SYM").alias("TRN_SYM"),
        col("record.TRN_SECT").alias("TRN_SECT"),
        col("record.TRN_DAY").alias("TRN_DAY"))
      .drop("record")
    outputDF
  }

  def applyShipmentAssociatedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyShipmentAssociatedUnpublishedTransformation::Start")
    val transformDF = inputDF.withColumn("Con_carInit_carNumb", concat(col("CAR_INIT"), col("CAR_NUMB")))
    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(transformDF, "Primary_Object_Key", List("Con_carInit_carNumb"))
    val domainEventTypeKey = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val domainEventTypeKeyDF = primaryObjKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventTypeKey))
      .withColumn("Shipment_Key", lit("Not Applicable"))
      .withColumn("Shipment_Type_Key", lit("Not Applicable"))
      .withColumn("Associated_Object_Key", lit("Not Applicable"))
      .withColumn("Associated_Object_Type_Key", lit("Not Applicable"))
      .withColumn("Association_Key", lit("Not Applicable"))
      .withColumn("Association_Type_Key", lit("Not Applicable"))

    val shipmAssociatedUnpubFinalDF = IDGenerationEngine.createKeyForDF(domainEventTypeKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyShipmentAssociatedUnpublishedTransformation::End")
    shipmAssociatedUnpubFinalDF
  }
  
  def applyShipmentAssociatedDescribedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyShipmentAssociatedDescribedUnpublishedTransformation::Start")
    val transformDF = inputDF.withColumn("Con_carInit_carNumb", concat(col("CAR_INIT"), col("CAR_NUMB")))
    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(transformDF, "Primary_Object_Key", List("Con_carInit_carNumb"))
    val domainEventTypeKey = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val domainEventTypeKeyDF = primaryObjKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventTypeKey))
      .withColumn("Association_Key", lit(""))      
    val shipmAssociatedDescUnpubFinalDF = IDGenerationEngine.createKeyForDF(domainEventTypeKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyShipmentAssociatedDescribedUnpublishedTransformation::End")
    shipmAssociatedDescUnpubFinalDF
  }
}