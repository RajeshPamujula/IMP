package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, expr, from_json, lit, trim, concat }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.references.CarInventoryDomainSchema
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.idFactory.IDGenerationEngine
import com.cn.spark.idFactory.ReferenceDataGenerationEngine
import com.cn.spark.notificationFactory.ErrorNotificationEngine
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.timezoneConversionFactory.TimeZoneConversionEngine

class CarInventoryDomainFeedService(sourceTopic: String, errTopic: String) extends CommonFeed(sourceTopic: String) {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)

  //Broadcast any thing thats required
  val refTranDF = CommonsUtil.readReferenceDataFile(spark)

  val refKeyValueDF = refTranDF.withColumn("KEY_CD", concat(col("prnt_type_cd"), lit("|"), col("type_cd"))).drop(col("type_cd")).drop(col("prnt_type_cd"))
  val referenceData = refKeyValueDF.select($"KEY_CD", $"TYPE_KEY").as[(String, String)].collect.toMap
  //println(referenceData)
  val refMapData = spark.sparkContext.broadcast(referenceData)

  //Time Zone Conversion Data
  val timeZoneConversionDataFileDF = TimeZoneConversionEngine.readTimeZoneReferenceFiles(environmentValues.get("SPARK_REFERENCE_DATA_DIR")).cache()
  val tzDataDF = spark.sparkContext.broadcast(timeZoneConversionDataFileDF)

  @transient lazy val timeInterval = applicationConf.getInt("timeInterval")
  @transient lazy val bootstrapServers = environmentValues.get("KAFKA_BROKER_HOST")
  @transient lazy val securityProtocol = applicationConf.getString("security.protocol")
  @transient lazy val transpEventReportCheckPoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpEventReportCheckPointDir")
  @transient lazy val transpEventDescCheckPoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpEventDescCheckPointDir")
  @transient lazy val conveyorDescribedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpConveyorDescribedCheckpointDir")
  @transient lazy val eventAssociatedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpEventAssociatedCheckpointDir")
  @transient lazy val transpConvCondCreatedCheckPoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpConvCondCreatedCheckPointDir")
  @transient lazy val eventAssocDescCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpEventAssocDescCheckpointDir")
  @transient lazy val shipmentAssociatedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpShipmentAssociatedCheckpointDir")
  @transient lazy val shipmentAssociatedDescCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpShipmentAssociatedDescCheckpointDir")
  @transient lazy val errorNotificationCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("errNotifyCarInventoryCheckpointDir")
  @transient lazy val shipmentAssociatedUnpubCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpShipmentAssociatedUnpubCheckpointDir")
  @transient lazy val shipmentAssociatedDescUnpubCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transpShipmentAssociatedDescUnpubCheckpointDir")
  //Implementation of the trait. using Schema to fetch dataframe from the message.

  @Override
  def applySchema(dataset: Dataset[(String, String)]): DataFrame = {
    logger.info("CarInventoryDomainFeedService Start ::applySchema")
    //applying schema to json message
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA", from_json($"value", CarInventoryDomainSchema.carInventoryDomain) as "record", col("topic"))

    //adding time stamp while reading
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(rawMsgDF, "SOR_READ_TS")
    logger.debug("CarInventoryDomainFeedService End ::applySchema")

    /*
     Filter out when IBMSNAP_OPERATION ("IBMSNAP_OPERATION") = 'D'
      */
    val filterDF = SparkDataFrameHelper.filterOutMessages(auditTimeStampDF, tzDataDF.value)
    CommonsUtil.addDeMetaColumn(filterDF, "DE_META")
  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("CarInventoryDomainFeedService Start ::transformAndsinkStream")
    /*
   Check if required fields are null post the filter then redirect to error kafka and remove from the filtered DF. Header to  be updated with Source Kafka queue name
    fields "EVT_CD", "EVST_CD", "PROC_DTTM", "EVT_DT", "EVT_TM", "CAR_INIT", "CAR_NUMB", "STN_ST", "CAR_LOC_CD", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_DAY", "ARR_ST", "ARR_333", "OP_ST", "OP_CITY_333", "OP_ORIG_ST", "OP_ORIG_333", "SOR_INGT_CRT_TS", "USER_ID"
   */
    val mainDF = ErrorNotificationEngine.addErrorColumnForDF(inputDF, List("record.WB_ID", "record.EVT_CD", "record.EVST_CD", "record.PROC_DTTM", "record.EVT_DT", "record.EVT_TM", "record.CAR_INIT", "record.CAR_NUMB", "record.STN_ST", "record.CAR_LOC_CD", "record.TRN_TYPE", "record.TRN_SYM", "record.TRN_SECT", "record.TRN_DAY", "record.ARR_ST", "record.ARR_333", "record.OP_ST", "record.OP_CITY_333", "record.OP_ORIG_ST", "record.OP_ORIG_333", "record.INGT_CRT_TS", "record.USER_ID","record.INGT_UUID"))
    //Adding timezone columns

    //Filter Error message
    val errorDF = ErrorNotificationEngine.filterErrorMessage(mainDF)
    errorDF.writeStream.option("checkpointLocation", errorNotificationCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ErrorNotificationForEachWriter(errTopic, "CarInventoryDomainFeed", sourceTopic)).start()
    //Filter correct message
    val tempDF1 = ErrorNotificationEngine.dropColumn(mainDF, "JSON_DATA")    
    val tempDF2 = ErrorNotificationEngine.filterCorrectMessage(tempDF1)
    val correctDF = ErrorNotificationEngine.dropColumn(tempDF2, "ERROR_KEY")
    //correctDF.printSchema()

    //getCommonTransformationDataFrame
    val commonTransformedDF = SparkDataFrameHelper.getCommonTransformationDataFrame(correctDF)
    val transformedDF = SparkDataFrameHelper.applyCommonTransformations(commonTransformedDF, refMapData.value)

    //TRANSPORTATION EVENT REPORTED - done
    val transpEventReportDF = SparkDataFrameHelper.getTransEventReportTransformation(transformedDF)
    val transpEventReportFinalDF = SparkDataFrameHelper.applyTransEventReportTransformation(transpEventReportDF, refMapData.value)

    //TRANSPORTATION EVENT DESCRIBED - done   
    val trnspEvtDescFinalDF = SparkDataFrameHelper.applyTrnspEventDescribedTransformation(transpEventReportDF, refMapData.value)

    //CONVEYOR CONDITION CREATED    - Done
    val convConditionCreatedDF = SparkDataFrameHelper.getConveyorConditionCreatedTransformation(transformedDF)
   // val convConditionCreatedFilterDF = SparkDataFrameHelper.applyInterchangeFilter(convConditionCreatedDF)    
    val convConditionCreatedFinalDF = SparkDataFrameHelper.applyConveyorConditionCreatedTransformation(convConditionCreatedDF, refMapData.value)

    //CONVEYOR DESCRIBED - done
    val convDescribedDF = SparkDataFrameHelper.getConveyorDescribedTransformation(transformedDF)
   // val convDescribedFilterDF = SparkDataFrameHelper.applyInterchangeFilter(convDescribedDF)
    val convDescribedFinalDF = SparkDataFrameHelper.applyConveyorDescribedTransformation(convDescribedDF, refMapData.value)

    //Event ASSOCIATED - done
    val eventAssociatedDF = SparkDataFrameHelper.getEventAssociatedTransformation(transformedDF)
    val eventAssociatedFinalDF = SparkDataFrameHelper.applyEventAssociatedTransformation(eventAssociatedDF, refMapData.value)
    //TRANSPORTATION EVENT ASSOCIATION DESCRIBED - done
    val transpEventAssocDescFinalDF = SparkDataFrameHelper.applyTransEvtAssocDescTransformation(eventAssociatedFinalDF, refMapData.value)

    // Shipment Associated -done
    val shipmentAssociatedDF = SparkDataFrameHelper.getShipmentAssociatedTransformation(transformedDF)
    val shipmentAssociatedFinalDF = SparkDataFrameHelper.applyShipmentAssociatedTransformation(shipmentAssociatedDF, refMapData.value)
    // Shipment Associated Described - done
    val shipmentAssociatedDescFinalDF = SparkDataFrameHelper.applyShipmentAssociatedDescribedTransformation(shipmentAssociatedFinalDF, refMapData.value)
    // Shipment Associated -unpublished
    val shipmentAssociatedUnpubFinalDF = SparkDataFrameHelper.applyShipmentAssociatedUnpublishedTransformation(shipmentAssociatedDF, refMapData.value)
     // Shipment Associated Described -unpublished
    val shipmentAssociatedDescUnpubFinalDF = SparkDataFrameHelper.applyShipmentAssociatedDescribedUnpublishedTransformation(shipmentAssociatedDF, refMapData.value)

    trnspEvtDescFinalDF.writeStream.option("checkpointLocation", transpEventDescCheckPoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new TranspEventDescribedForEachWriter()).start()
    convConditionCreatedFinalDF.writeStream.option("checkpointLocation", transpConvCondCreatedCheckPoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorConditionCreatedForEachWriter()).start()
    transpEventAssocDescFinalDF.writeStream.option("checkpointLocation", eventAssocDescCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new EventAssociationDescribedForEachWriter()).start()
    eventAssociatedFinalDF.writeStream.option("checkpointLocation", eventAssociatedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new EventAssociatedForEachWriter()).start()
    convDescribedFinalDF.writeStream.option("checkpointLocation", conveyorDescribedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDescribedForEachWriter()).start()
    transpEventReportFinalDF.writeStream.option("checkpointLocation", transpEventReportCheckPoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new TranspEventReportedForeachWriter()).start()
    shipmentAssociatedFinalDF.writeStream.option("checkpointLocation", shipmentAssociatedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ShipmentAssociatedForEachWriter()).start()
    shipmentAssociatedDescFinalDF.writeStream.option("checkpointLocation", shipmentAssociatedDescCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ShipmentAssociatedDescribedForEachWriter()).start()
     shipmentAssociatedUnpubFinalDF.writeStream.option("checkpointLocation", shipmentAssociatedUnpubCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ShipmentAssociatedUnpublishedForEachWriter()).start()
      shipmentAssociatedDescUnpubFinalDF.writeStream.option("checkpointLocation", shipmentAssociatedDescUnpubCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ShipmentAssociatedDescribedUnpublishedForEachWriter()).start()
  }

}