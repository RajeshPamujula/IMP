package com.cn.spark.commons.references

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import scala.collection.Seq

object Schema {
  val trSchema = StructType(Seq(
   StructField("IngestionHeader", StructType(Seq(
     StructField("ING_CRT_TS", StringType, false),
     StructField("UUID", StringType, false))), false),
   StructField("WMBGATEV20", StructType(Seq(
     StructField("MSG_HEADER", StructType(Seq(
       StructField("HDR_MSG_SUBTYPE", StringType, false),
       StructField("HDR_ACTION_CD", StringType, false))), false),
     StructField("CARTER_SECTION", StructType(Seq(
       StructField("CRTR_CUSTOMER", StructType(Seq(
         StructField("CRTR_CUST_NBR", StringType, false),
         StructField("CRTR_CUST_633", StringType, false),
         StructField("CRTR_CUST_NAME", StringType, false))), false),
      StructField("CURRENT_TERMINAL", StructType(Seq(
         StructField("LOCN_333", StringType, false),
         StructField("LOCN_PRST", StringType, false))), false),
       StructField("CRTR_CODE",StringType,false),
       StructField("BOBTAIL_IND",StringType,false),
       StructField("CN_TRACTOR_IND",StringType,false),
       StructField("TRCTR_LIC",StringType,false),
       StructField("GATE_EVT_CD",StringType,false),
       StructField("GATE_EVT_STUS",StringType,false),
       StructField("RPTG_DATE",StringType,false),
       StructField("RPTG_TIME",StringType,false),
       StructField("RPTG_TIME_ZN",StringType,false),
       StructField("RPTG_DST_FLAG",StringType,false),
       StructField("REPORTING_SECTION_CNT",StringType,false))),false),
     StructField("REPORTING_SECTION", StructType(Seq(
        StructField("UNIT_EQUIPMENT", StructType(Seq(
         StructField("EQP_INIT", StringType, false),
         StructField("EQP_NUMB", StringType, false))), false),
         StructField("CHASSIS_EQUIPMENT", StructType(Seq(
         StructField("CHAS_INIT", StringType, false),
         StructField("CHAS_NUMB", StringType, false),
         StructField("CHAS_CAR_KIND", StringType, false),
         StructField("CHAS_CN_EQP_IND", StringType, false))),false))),false),
     StructField("MSG_FOOTER", StructType(Seq(
         StructField("FTR_AUDT_TS", StringType, false),
         StructField("FTR_AUDT_USER_ID", StringType, false))),false)
   )))))

val referenceDataSchema = StructType(Seq(
    StructField("type_cd", StringType, false),
    StructField("prnt_type_cd", StringType, false)))
   
}