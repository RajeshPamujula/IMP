package com.cn.spark.service

import java.util.Properties

import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.log4j.Logger
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.Row

import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.configFactory.ApplicationConfigEngine

class ConveyorDescribedTractorForEachWriter extends ForeachWriter[Row] with ApplicationConfigEngine with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  @transient lazy val kafkaProperties: Properties = CommonsUtil.getKafkaProperties()

  var producer: KafkaProducer[String, String] = _
  def open(partition_id: Long, epoch_id: Long) = {
    // Open connection. This method is optional in Python.
    logger.debug("ConveyorDescribedTractorForEachWriter start:: open")
    producer = new KafkaProducer(kafkaProperties)
    logger.debug("ConveyorDescribedTractorForEachWriter end:: open")
    true
  }

  //convert to json and write to kafka
  def process(row: Row) = {
    logger.debug("Start process() function ConveyorDescribedTractorForEachWriter")
    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
    producer.send(new ProducerRecord(environmentValues.get("TRANSPORTATION_CNVY_DSC_PREPARED"), buildJson(rowAsMap)))
    logger.debug("End process() function ConveyorDescribedTractorForEachWriter")
  }

  def close(error: Throwable) = {
    logger.debug("Start close() ConveyorDescribedTractorForEachWriter")
    producer.close()
    logger.debug("End close() ConveyorDescribedTractorForEachWriter")
  }

  // build json message for Conveyor Described
  def buildJson(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("ConveyorDescribedTractorForEachWriter Start :: buildConveyorDescribedJson")
    val currentTimeInUTC = CommonsUtil.getUTCTimeStamp
    val msgHeaderJson = "{" + "\"DomainEventHeader\"" + ":" + "{" + "\"SOR_INGT_CRT_TS\"" + ":" + "\"" + rowAsMap("SOR_INGT_CRT_TS") + "\"" + "," + "\"SOR_READ_TS\"" + ":" + "\"" + rowAsMap("SOR_READ_TS") + "\"" + "," + "\"DE_CRT_TS\"" + ":" + "\"" + currentTimeInUTC + "\"" + "," + "\"SOR_TPIC_NM\"" + ":" + "\"" + rowAsMap("SOR_TPIC_NM") + "\"" + "," + "\"DE_META\"" + ":" + "\"" + rowAsMap("DE_META") + "\"" + "},"
    val msgBodyJson = "\"ConveyorDescribed\"" + ":" + "{" + "\"Domain_Event_Type_Key\"" + ":" + "\"" + rowAsMap("Domain_Event_Type_Key") + "\"" + "," + "\"Conveyor_Key\"" + ":" + "\"" + rowAsMap("Conveyor_Key") + "\"" + "," + "\"ConveyorCharacteristics\"" + ":" + "[{" + "\"Conveyor_Characteristic_Key\"" + ":" + "\"" + rowAsMap("Conveyor_Characteristic_key1") + "\"" + "," + "\"Characteristic_Type_Key\"" + ":" + "\"" + rowAsMap("Characteristic_Type_Key1") + "\"" + "," + "\"Characteristic_Value\"" + ":" + "\"" + rowAsMap("Characteristic_Value1") + "\"" + "}]" + ","
    val msgBodyJson1 = "\"Domain_Event_Key\"" + ":" + "\"" + rowAsMap("Domain_Event_Key") + "\"" + "," + "\"Correlation_Id\"" + ":" + "\"" + rowAsMap("Correlation_Id") + "\"" + "," + "\"Client_Identification\"" + ":" + "\"" + rowAsMap("Client_Identification") + "\"" + "," + "\"System_Key\"" + ":" + "\"" + rowAsMap("System_Key") + "\"" + "," + "\"Proc_Ts\"" + ":" + "\"" + rowAsMap("Proc_Ts") + "\"" + "," + "\"Proc_Ts_Tz_Dst_Cd\"" + ":" + "\"" + rowAsMap("Proc_Ts_Tz_Dst_Cd") + "\"" + "," + "\"Event_Ts\"" + ":" + "\"" + rowAsMap("Event_Ts") + "\"" + "," + "\"Event_Ts_Tz_Dst_Cd\"" + ":" + "\"" + rowAsMap("Event_Ts_Tz_Dst_Cd") + "\"" + "}}"
    val conveyorDescribedfinalJson = msgHeaderJson + msgBodyJson + msgBodyJson1
    logger.debug("ConveyorDescribedTractorForEachWriter End :: buildConveyorDescribedJson")
    conveyorDescribedfinalJson
  }

}