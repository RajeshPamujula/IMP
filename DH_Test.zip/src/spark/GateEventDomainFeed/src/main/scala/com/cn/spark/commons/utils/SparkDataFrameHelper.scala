package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.concat
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.regexp_replace
import com.cn.spark.idFactory.IDGenerationEngine
import com.cn.spark.commonsEngine.CommonsUtil
import org.apache.spark.sql.functions.{ col, lit }
import com.cn.spark.commonsEngine.Constants
import com.cn.spark.timezoneConversionFactory.TimeZoneConversionEngine
import org.apache.spark.sql.functions.date_format

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def getSchemaAppliedDataFrame(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::filterOutMessages::Start")
    val selectedDF = inputDF
      .select(
        col("record.IngestionHeader.ING_CRT_TS").alias("SOR_INGT_CRT_TS"),
        col("record.IngestionHeader.UUID").alias("Correlation_Id"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.GATE_EVT_CD")).alias("GATE_EVT_CD"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.GATE_EVT_STUS")).alias("GATE_EVT_STUS"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.RPTG_DATE")).alias("RPTG_DATE"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.RPTG_TIME")).alias("RPTG_TIME"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.TRCTR_LIC")).alias("TRCTR_LIC"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.RPTG_TIME_ZN")).alias("TIME_ZONE"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.RPTG_DST_FLAG")).alias("RPTG_DST_FLAG"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.REPORTING_SECTION_CNT")).alias("REPORTING_SECTION_CNT"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.CRTR_CODE")).alias("CRTR_CODE"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.CN_TRACTOR_IND")).alias("CN_TRACTOR_IND"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.BOBTAIL_IND")).alias("BOBTAIL_IND"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.CRTR_CUSTOMER.CRTR_CUST_NBR")).alias("CRTR_CUST_NBR"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.CRTR_CUSTOMER.CRTR_CUST_633")).alias("CRTR_CUST_633"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.CRTR_CUSTOMER.CRTR_CUST_NAME")).alias("CRTR_CUST_NAME"),
        trim(col("record.WMBGATEV20.MSG_FOOTER.FTR_AUDT_TS")).alias("FTR_AUDT_TS"),
        trim(col("record.WMBGATEV20.MSG_FOOTER.FTR_AUDT_USER_ID")).alias("FTR_AUDT_USER_ID"),
        trim(col("record.WMBGATEV20.MSG_HEADER.HDR_MSG_SUBTYPE")).alias("HDR_MSG_SUBTYPE"),
        trim(col("record.WMBGATEV20.MSG_HEADER.HDR_ACTION_CD")).alias("HDR_ACTION_CD"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.CURRENT_TERMINAL.LOCN_333")).alias("LOCN_333"),
        trim(col("record.WMBGATEV20.CARTER_SECTION.CURRENT_TERMINAL.LOCN_PRST")).alias("LOCN_PRST"),
        trim(col("record.WMBGATEV20.REPORTING_SECTION.UNIT_EQUIPMENT.EQP_INIT")).alias("EQP_INIT"),
        trim(col("record.WMBGATEV20.REPORTING_SECTION.UNIT_EQUIPMENT.EQP_NUMB")).alias("EQP_NUMB"),
        trim(col("record.WMBGATEV20.REPORTING_SECTION.CHASSIS_EQUIPMENT.CHAS_INIT")).alias("CHAS_INIT"),
        trim(col("record.WMBGATEV20.REPORTING_SECTION.CHASSIS_EQUIPMENT.CHAS_NUMB")).alias("CHAS_NUMB"),
        trim(col("record.WMBGATEV20.REPORTING_SECTION.CHASSIS_EQUIPMENT.CHAS_CAR_KIND")).alias("CHAS_CAR_KIND"),
        trim(col("record.WMBGATEV20.REPORTING_SECTION.CHASSIS_EQUIPMENT.CHAS_CN_EQP_IND")).alias("CHAS_CN_EQP_IND"),
        col("SOR_READ_TS").alias("SOR_READ_TS"),
        col("JSON_DATA").alias("JSON_DATA"),
        col("record").alias("record"),
        col("topic").alias("SOR_TPIC_NM"))
    logger.debug("SparkDataFrameHelper::filterOutMessages::End")
    selectedDF
  }
  
  def applyCommonTransformations(inputDF: DataFrame, referenceData: Map[String, String], tzDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransformation::Start")

  //  val systemDF = referenceDF.filter(col("prnt_type_cd") === "System" && col("type_cd") === "SRS-IM")
    val systemKey= CommonsUtil.getRefData(referenceData, "System", "SRS-IM")
    val transformDF = inputDF
      .withColumn("Client_Identification", when((col("FTR_AUDT_USER_ID").isNull || col("FTR_AUDT_USER_ID") === ""), lit("SRS-IM")).otherwise(col("FTR_AUDT_USER_ID")))
      .withColumn("System_Key", lit(systemKey))
      .withColumn("Proc_Ts", regexp_replace(col("FTR_AUDT_TS"), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2}).(\\d{6})", "$1-$2-$3 $4:$5:$6.$7"))
      .withColumn("Proc_Ts_Tz_Dst_Cd", lit(Constants.DST_CD_UTC_DST_NO))

    val transformPrepEventTimeZoneDF = transformDF
      .withColumn("LOCAL_TIME", regexp_replace(concat(col("RPTG_DATE"), lit("-"), col("RPTG_TIME")), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2})", "$1-$2-$3 $4:$5:$6.000"))
      .withColumn("LOCAL_YEAR", date_format(col("RPTG_DATE"), "yyyy"))
      .withColumn("DST", col("RPTG_DST_FLAG"))

    val transformEventTimeZoneDF = TimeZoneConversionEngine.toUTCConversion(transformPrepEventTimeZoneDF, tzDF, "")
      .withColumn("Event_Ts", trim(col("UTC_TIME_FORMATTED")))
      .withColumn("Event_Ts_Tz_Dst_Cd", trim(col("TZ_DST_CD")))
      .drop("LOCAL_TIME")
      .drop("LOCAL_YEAR")
      .drop("DST")
      .drop("UTC_TIME_FORMATTED")
      .drop("TZ_DST_CD")

    val outputDF = IDGenerationEngine.createKeyForDF(transformEventTimeZoneDF, "Primary_Object_Key", List("TRCTR_LIC"))
    logger.debug("SparkDataFrameHelper::applyTransformation::End")
    outputDF
  }
  //Step 150. Remove Transportation Event
  //TRANSPORTATION EVENT REPORTED to Kafka topic: <env>.tm.prepared.trspEvtRmv.v1
  def applyTransportationEventRemovedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransportationEventRemovedTransformation::Start")
 /* val domainEventTypeDF = referenceDF.filter(col("prnt_type_cd") === "Domain Event Type" && col("type_cd") === "Removed")
    val domainEventType = domainEventTypeDF.collect().toList.head.getString(2)
    val transportationeventTypeDF = referenceDF.filter(col("prnt_type_cd") === "Transportation Event" && col("type_cd") === "Gate Event")
    val transportationeventType = transportationeventTypeDF.collect().toList.head.getString(2)
    */
    val domainEventType=CommonsUtil.getRefData(referenceData, "Domain Event Type", "Removed")
    val transportationeventType=CommonsUtil.getRefData(referenceData, "Transportation Event", "Gate Event")
    val tranRemovedDF = inputDF
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Transportation_Event_Type_Key", lit(transportationeventType))
      .withColumn("Transportation_Event_Value", col("HDR_MSG_SUBTYPE"))

    //val traneventRemovedDF = IDGenerationEngine.createKeyForDF(Primary_Object_Key_DF, "Transportation_Event_Key", List("GATE_EVT_CD", "GATE_EVT_STUS", "RPTG_DATE", "RPTG_TIME", "TRCTR_LIC","CRTR_CUST_NBR"))
    val tranRemovedFinalDF = IDGenerationEngine.createKeyForDF(tranRemovedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyTransportationEventRemovedTransformation::End")
    tranRemovedFinalDF
  }
  //Step 30. Create Transportation Event
  //TRANSPORTATION EVENT REPORTED to Kafka topic: <env>.tm.prepared.trspEvtRpt.v1
  def applyTransportationEventReportedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransportationEventReportedTransformation::Start")
 
    val Domain_Event_Type_Key = CommonsUtil.getRefData(referenceData,"Domain Event Type", "Created")
    val Transportation_Event_Type_Key = CommonsUtil.getRefData(referenceData,"Transportation Event", "Gate Event")
    val transformDF = inputDF
      .withColumn("Domain_Event_Type_Key", lit(Domain_Event_Type_Key))
      .withColumn("Transportation_Event_Type_Key", lit(Transportation_Event_Type_Key))
      .withColumn("Transportation_Event_Value", col("HDR_MSG_SUBTYPE"))  

    val outputDF = IDGenerationEngine.createKeyForDF(transformDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyTransportationEventReportedTransformation::End")
    outputDF
  }
  //Publish Domain Event TRANSPORTATION EVENT DESCRIBED to Kafka topic <env>.tm.prepared.trspEvtDsc.v1
  def applyTransportationEventDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransportationEventDescribedTransformation::Start")
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
/*    val Domain_Event_Type_KeyDF = referenceDF.filter(col("prnt_type_cd") === "Domain Event Type" && col("type_cd") === "Created")
    val Domain_Event_Type_Key = Domain_Event_Type_KeyDF.collect().toList.head.getString(2)*/
    val Domain_Event_Type_Key = CommonsUtil.getRefData(referenceData,"Domain Event Type", "Created")
    val transformDF = inputDF.withColumn("Domain_Event_Type_Key", lit(Domain_Event_Type_Key))

    //Start Iteration 1
    //GetHash Key (PRNT_TYPE_CD='Characteristic',TYPE_CD='Event Code')
/*    val Characteristic_Type_KeyDF = referenceDF.filter(col("prnt_type_cd") === "Characteristic" && col("type_cd") === "Event Code")
    val Characteristic_Type_Key = Characteristic_Type_KeyDF.collect().toList.head.getString(2)
*/
    val Characteristic_Type_Key = CommonsUtil.getRefData(referenceData,"Characteristic", "Event Code")
    val charTypeDF = transformDF
      .withColumn("Characteristic_Type_Key1", lit(Characteristic_Type_Key))
      .withColumn("Characteristic_Value1", col("GATE_EVT_CD"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF = IDGenerationEngine.createKeyForDF(charTypeDF, "Transportation_Event_Characteristic_Key1", List("Primary_Object_Key", "Characteristic_Type_Key1"))
    //End Iteration1
    //Start Iteration 2
    //GetHash Key (PRNT_TYPE_CD='Characteristic',TYPE_CD='Event Status')
/*    val Characteristic_Type_KeyDF1 = referenceDF.filter(col("prnt_type_cd") === "Characteristic" && col("type_cd") === "Event Status")
    val Characteristic_Type_Key1 = Characteristic_Type_KeyDF1.collect().toList.head.getString(2)*/
    
    val Characteristic_Type_Key1 = CommonsUtil.getRefData(referenceData,"Characteristic", "Event Status")
    val charTypeDF1 = Transportation_Event_Characteristic_KeyDF
      .withColumn("Characteristic_Type_Key2", lit(Characteristic_Type_Key1))
      .withColumn("Characteristic_Value2", col("GATE_EVT_STUS"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF1 = IDGenerationEngine.createKeyForDF(charTypeDF1, "Transportation_Event_Characteristic_Key2", List("Primary_Object_Key", "Characteristic_Type_Key2"))
    //End Iteration2
    //Start Iteration 3
    //GetHash Key (PRNT_TYPE_CD='Characteristic',TYPE_CD='Carter Customer Number')
/*    val Characteristic_Type_KeyDF2 = referenceDF.filter(col("prnt_type_cd") === "Characteristic" && col("type_cd") === "Carter Customer Number")
    val Characteristic_Type_Key2 = Characteristic_Type_KeyDF2.collect().toList.head.getString(2)*/
    val Characteristic_Type_Key2 = CommonsUtil.getRefData(referenceData,"Characteristic", "Carter Customer Number")
    val charTypeDF2 = Transportation_Event_Characteristic_KeyDF1
      .withColumn("Characteristic_Type_Key3", lit(Characteristic_Type_Key2))
      .withColumn("Characteristic_Value3", col("CRTR_CUST_NBR"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF2 = IDGenerationEngine.createKeyForDF(charTypeDF2, "Transportation_Event_Characteristic_Key3", List("Primary_Object_Key", "Characteristic_Type_Key3"))
    //End Iteration3
    //Start Iteration 4
    //GetHash Key (PRNT_TYPE_CD='Characterisitc',TYPE_CD='Tractor License')
/*    val Characteristic_Type_KeyDF3 = referenceDF.filter(col("prnt_type_cd") === "Characteristic" && col("type_cd") === "Tractor License")
    val Characteristic_Type_Key3 = Characteristic_Type_KeyDF3.collect().toList.head.getString(2)*/
    val Characteristic_Type_Key3 = CommonsUtil.getRefData(referenceData,"Characteristic", "Tractor License")
    val charTypeDF3 = Transportation_Event_Characteristic_KeyDF2
      .withColumn("Characteristic_Type_Key4", lit(Characteristic_Type_Key3))
      .withColumn("Characteristic_Value4", col("TRCTR_LIC"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF3 = IDGenerationEngine.createKeyForDF(charTypeDF3, "Transportation_Event_Characteristic_Key4", List("Primary_Object_Key", "Characteristic_Type_Key4"))
    //End Iteration4
    
    //Start Iteration 5
    //GetHash Key (PRNT_TYPE_CD='Characterisitc',TYPE_CD='Carter SCAC')

    val Characteristic_Type_Key4 = CommonsUtil.getRefData(referenceData,"Characteristic", "Carter SCAC")
    val charTypeDF4 = Transportation_Event_Characteristic_KeyDF3
      .withColumn("Characteristic_Type_Key5", lit(Characteristic_Type_Key4))
      .withColumn("Characteristic_Value5", col("CRTR_CODE"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF4 = IDGenerationEngine.createKeyForDF(charTypeDF4, "Transportation_Event_Characteristic_Key5", List("Primary_Object_Key", "Characteristic_Type_Key5"))
    //End Iteration5
    
    //Start Iteration 6
    //GetHash Key (PRNT_TYPE_CD='Characterisitc',TYPE_CD='Carter Customer Name')

    val Characteristic_Type_Key5 = CommonsUtil.getRefData(referenceData,"Characteristic", "Carter Customer Name")
    val charTypeDF5 = Transportation_Event_Characteristic_KeyDF4
      .withColumn("Characteristic_Type_Key6", lit(Characteristic_Type_Key5))
      .withColumn("Characteristic_Value6", col("CRTR_CUST_NAME"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF5 = IDGenerationEngine.createKeyForDF(charTypeDF5, "Transportation_Event_Characteristic_Key6", List("Primary_Object_Key", "Characteristic_Type_Key6"))
    //End Iteration6
    
     //Start Iteration 7
    //GetHash Key (PRNT_TYPE_CD='Characterisitc',TYPE_CD='Carter Customer 633')

    val Characteristic_Type_Key6 = CommonsUtil.getRefData(referenceData,"Characteristic", "Carter Customer 633")
    val charTypeDF6 = Transportation_Event_Characteristic_KeyDF5
      .withColumn("Characteristic_Type_Key7", lit(Characteristic_Type_Key6))
      .withColumn("Characteristic_Value7", col("CRTR_CUST_633"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF6 = IDGenerationEngine.createKeyForDF(charTypeDF6, "Transportation_Event_Characteristic_Key7", List("Primary_Object_Key", "Characteristic_Type_Key7"))
    //End Iteration7
    
     //Start Iteration 8
    //GetHash Key (PRNT_TYPE_CD='Characterisitc',TYPE_CD='CN Tractor Indicator')

    val Characteristic_Type_Key7 = CommonsUtil.getRefData(referenceData,"Characteristic", "CN Tractor Indicator")
    val charTypeDF7 = Transportation_Event_Characteristic_KeyDF6
      .withColumn("Characteristic_Type_Key8", lit(Characteristic_Type_Key7))
      .withColumn("Characteristic_Value8", col("CN_TRACTOR_IND"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF7 = IDGenerationEngine.createKeyForDF(charTypeDF7, "Transportation_Event_Characteristic_Key8", List("Primary_Object_Key", "Characteristic_Type_Key8"))
    //End Iteration8
    
      //Start Iteration 9
    //GetHash Key (PRNT_TYPE_CD='Characterisitc',TYPE_CD='Bob Tail indicator')

    val Characteristic_Type_Key8 = CommonsUtil.getRefData(referenceData,"Characteristic", "Bob Tail indicator")
    val charTypeDF8 = Transportation_Event_Characteristic_KeyDF7
      .withColumn("Characteristic_Type_Key9", lit(Characteristic_Type_Key8))
      .withColumn("Characteristic_Value9", col("BOBTAIL_IND"))
      //End Iteration9
      
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Transportation_Event_Characteristic_KeyDF8 = IDGenerationEngine.createKeyForDF(charTypeDF8, "Transportation_Event_Characteristic_Key9", List("Primary_Object_Key", "Characteristic_Type_Key9"))
    //End Iteration9

    

    //Domain_Event_Key - Hash of target fields: Domain_Event_Type_Key,Transportation_Event_Key,Client_Identification,System_Key,Proc_Ts
    val outputDF = IDGenerationEngine.createKeyForDF(Transportation_Event_Characteristic_KeyDF8, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyTransportationEventDescribedTransformation::End")
    outputDF
  }
  //Step 40.  Associate the Transportation Event (Gate Event) with the Location (Terminal)
  // Domain event TRANSPORTATION EVENT ASSOCIATED to Kafka topic: <env>.tm.prepared.trspEvtAsct.v1
  def applyTransportationEventAssociatedLocationTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransportationEventAssociatedLocationTransformation::Start")
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Associated')
/*    val Domain_Event_Type_KeyDF = referenceDF.filter(col("prnt_type_cd") === "Domain Event Type" && col("type_cd") === "Associated")
    val Domain_Event_Type_Key = Domain_Event_Type_KeyDF.collect().toList.head.getString(2)*/
    val Domain_Event_Type_Key = CommonsUtil.getRefData(referenceData,"Domain Event Type", "Associated")
    //GetHash Key (PRNT_TYPE_CD='Location', TYPE_CD='Terminal')
/*    val Associated_Object_Type_KeyDF = referenceDF.filter(col("prnt_type_cd") === "Location" && col("type_cd") === "Terminal")
    val Associated_Object_Type_Key = Associated_Object_Type_KeyDF.collect().toList.head.getString(2)*/
    val Associated_Object_Type_Key = CommonsUtil.getRefData(referenceData,"Location", "Terminal")
    //Hsh Key - (PRNT_TYPE_CD='Transportation Event', TYPE_CD='Gate Event')
/*    val Transportation_Event_Type_KeyDF = referenceDF.filter(col("prnt_type_cd") === "Transportation Event" && col("type_cd") === "Gate Event")
    val Transportation_Event_Type_Key = Transportation_Event_Type_KeyDF.collect().toList.head.getString(2)
*/ 
    val Transportation_Event_Type_Key = CommonsUtil.getRefData(referenceData, "Transportation Event", "Gate Event")
    val transformDF = inputDF
      .withColumn("Domain_Event_Type_Key", lit(Domain_Event_Type_Key))
      .withColumn("Associated_Object_Type_Key", lit(Associated_Object_Type_Key))
      .withColumn("Transportation_Event_Type_Key", lit(Transportation_Event_Type_Key))
    val transformDF2 = IDGenerationEngine.createKeyForDF(transformDF, "Associated_Object_Key", List("LOCN_333", "LOCN_PRST"))
    //GetHash Key(PRNT_TYPE_CD = 'Association',TYPE_CD='Inter-BCD Event-Location')
/*    val Association_Type_KeyRefDF = referenceDF.filter(col("prnt_type_cd") === "Association" && col("type_cd") === "Inter-BCD Event-Location")
    val Association_Type_Key = Association_Type_KeyRefDF.collect().toList.head.getString(2)
*/
    val Association_Type_Key = CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Event-Location")
    val Association_Type_KeyDF = transformDF2.withColumn("Association_Type_Key", lit(Association_Type_Key))
    //Hash of target field:Transportation_Event_Key,Associated_Object_Key
    val Association_KeyDF = IDGenerationEngine.createKeyForDF(Association_Type_KeyDF, "Association_Key", List("TRCTR_LIC", "LOCN_333", "LOCN_PRST"))

    val outputDF = IDGenerationEngine.createKeyForDF(Association_KeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Association_Key", "Client_Identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyTransportationEventAssociatedLocationTransformation::End")
    outputDF
  }
  def applyConveyorCreatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorCreatedTransformation::Start")
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
/*    val domainEventTypeDF = referenceDF.filter(col("prnt_type_cd") === "Domain Event Type" && col("type_cd") === "Created")
    val domainEventType = domainEventTypeDF.collect().toList.head.getString(2)*/
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    //GetHash Key (PRNT_TYPE_CD='Conveyor', TYPE_CD='Container')
/*    val conveyorTypeDF = referenceDF.filter(col("prnt_type_cd") === "Conveyor" && col("type_cd") === "Container")
    val conveyorType = conveyorTypeDF.collect().toList.head.getString(2)
*/ 
    val conveyorType=CommonsUtil.getRefData(referenceData, "Conveyor", "Container")
    // GetHash (PRNT_TYPE_CD='Identification Type', TYPE_CD='Container Id')
/*    val charTypeKeyDF = referenceDF.filter(col("prnt_type_cd") === "Identification Type" && col("type_cd") === "Container Id")
    val charTypeKey = charTypeKeyDF.collect().toList.head.getString(2)
*/   val charTypeKey=CommonsUtil.getRefData(referenceData, "Identification Type", "Container Id") 
    val convCreatedDF = inputDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Conveyor_Type_Key", lit(conveyorType))
      .withColumn("Identification_Type_Key", lit(charTypeKey))
      .withColumn("Identification_Value", concat(col("EQP_INIT"), col("EQP_NUMB")))
    val Conveyor_Key_DF = IDGenerationEngine.createKeyForDF(convCreatedDF, "Conveyor_Key", List("EQP_INIT", "EQP_NUMB"))
    val outputDF = IDGenerationEngine.createKeyForDF(Conveyor_Key_DF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorCreatedTransformation::End")
    outputDF

  }

  def applyConveyorDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTransformation::Start")
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
    //Domain_Event_Type_Key and Conveyor_Key will be copied from ConveyorCreate
/*    val domainEventTypeDF = referenceDF.filter(col("prnt_type_cd") === "Domain Event Type" && col("type_cd") === "Created")
    val domainEventType = domainEventTypeDF.collect().toList.head.getString(2)*/
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val Conveyor_Key_DF = IDGenerationEngine.createKeyForDF(inputDF, "Conveyor_Key", List("EQP_INIT", "EQP_NUMB"))
    val Domain_Event_Type_KeyDF = Conveyor_Key_DF.withColumn("Domain_Event_Type_Key", lit(domainEventType))

    //Iteration1
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Container Id')
/*    val charTypeKeyDF1 = referenceDF.filter(col("prnt_type_cd") === "Characteristic" && col("type_cd") === "Container Id")
    val charTypeKey1 = charTypeKeyDF1.collect().toList.head.getString(2)*/
    val charTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Container Id")
    val convDescribedDF1 = Domain_Event_Type_KeyDF.withColumn("Characteristic_Type_Key1", lit(charTypeKey1))
      .withColumn("Characteristic_Value1", concat(col("EQP_INIT"), col("EQP_NUMB")))
    val convCharKeyDF1 = IDGenerationEngine.createKeyForDF(convDescribedDF1, "Conveyor_Characteristic_key1", List("Conveyor_Key", "Characteristic_Type_Key1"))
    //End Iteration1

    //Iteration2
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Container Initial')
/*    val charTypeKeyDF2 = referenceDF.filter(col("prnt_type_cd") === "Characteristic" && col("type_cd") === "Container Initial")
    val charTypeKey2 = charTypeKeyDF2.collect().toList.head.getString(2)*/
    val charTypeKey2 = CommonsUtil.getRefData(referenceData, "Characteristic", "Container Initial")
    val convDescribedDF2 = convCharKeyDF1.withColumn("Characteristic_Type_Key2", lit(charTypeKey2))
      .withColumn("Characteristic_Value2", col("EQP_INIT"))
    val convCharKeyDF2 = IDGenerationEngine.createKeyForDF(convDescribedDF2, "Conveyor_Characteristic_key2", List("Conveyor_Key", "Characteristic_Type_Key2"))
    //End Iteration2

    //Iteration3
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Container Number')
/*    val charTypeKeyDF3 = referenceDF.filter(col("prnt_type_cd") === "Characteristic" && col("type_cd") === "Container Number")
    val charTypeKey3 = charTypeKeyDF3.collect().toList.head.getString(2)*/
    val charTypeKey3=CommonsUtil.getRefData(referenceData, "Characteristic", "Container Number")
    val convDescribedDF3 = convCharKeyDF2.withColumn("Characteristic_Type_Key3", lit(charTypeKey3))
      .withColumn("Characteristic_Value3", col("EQP_NUMB"))
    val convCharKeyDF3 = IDGenerationEngine.createKeyForDF(convDescribedDF3, "Conveyor_Characteristic_key3", List("Conveyor_Key", "Characteristic_Type_Key3"))
    //End Iteration3

    val convDescribedFinalDF = IDGenerationEngine.createKeyForDF(convCharKeyDF3, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTransformation::End")
    convDescribedFinalDF
  }
  //Step 80. Associate the Container with the Transportation Event
  //When a Container was reported, publsh a Domain event CONVEYOR ASSOCIATED to Kafka topic: <env>.tm.prepared.cnvyAsct.v1
  def applyConveyorAssociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyRouteConveyorMatchedTransformation::Start")
    //GetHash Key (PRNT_TYPE_CD=’Domain Event Type’, TYPE_CD=’Associated’)
/*    val domainEventTypeDF = referenceDF.filter(col("prnt_type_cd") === "Domain Event Type" && col("type_cd") === "Associated")
    val domainEventType = domainEventTypeDF.collect().toList.head.getString(2)*/
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    //GetHash Key (PRNT_TYPE_CD='Conveyor', TYPE_CD='Container')
/*    val conveyorTypeDF = referenceDF.filter(col("prnt_type_cd") === "Conveyor" && col("type_cd") === "Container")
    val conveyorType = conveyorTypeDF.collect().toList.head.getString(2)*/
    val conveyorType = CommonsUtil.getRefData(referenceData, "Conveyor", "Container")
    //GetHash Key (PRNT_TYPE_CD='Transportation Event', TYPE_CD='Gate Event')'
/*    val routeTypeDF = referenceDF.filter(col("prnt_type_cd") === "Transportation Event" && col("type_cd") === "Gate Event")
    val routeType = routeTypeDF.collect().toList.head.getString(2)
*/
     val routeType = CommonsUtil.getRefData(referenceData, "Transportation Event", "Gate Event")
    //GetHash Key (PRNT_TYPE_CD=’Association’, TYPE_CD=’Inter-BCD Conveyor-Event’)
/*    val associationTypeDF = referenceDF.filter(col("prnt_type_cd") === "Association" && col("type_cd") === "Inter-BCD Conveyor-Event")
    val associationType = associationTypeDF.collect().toList.head.getString(2)*/
     val associationType=CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Conveyor-Event")
    val convAssociatedDF = inputDF
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Association_Type_Key", lit(associationType))
      .withColumn("Conveyor_Type_Key", lit(conveyorType))
      .withColumn("Associated_Object_Key", col("Primary_Object_Key"))
      .withColumn("Associated_Object_Type_Key", lit(routeType))
    val Conveyor_Key_DF = IDGenerationEngine.createKeyForDF(convAssociatedDF, "Conveyor_Key", List("EQP_INIT", "EQP_NUMB"))
    val convAssociatedKeyDF = IDGenerationEngine.createKeyForDF(Conveyor_Key_DF, "Association_Key", List("EQP_INIT", "EQP_NUMB", "TRCTR_LIC"))
    val convAssociatedFinalDF = IDGenerationEngine.createKeyForDF(convAssociatedKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Association_Key", "Client_identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyRouteConveyorMatchedTransformation::End")
    convAssociatedFinalDF
  }

    def applyTransportationEventDescribedUnpublishTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransportationEventDescribedUnpublishTransformation::Start")
    //Get Hash Key (PRNT_TYPE_CD='Domain Event Type',TYPE_CD='Unpublished')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val domainEventTypeDF = inputDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
    .withColumn("Transportation_Event_Key", lit(""))
    // Hash of: TRCTR_LIC, CRTR_CUST_NBR
    // Hash of target fields: Domain_Event_Type_Key, Primary_Object_Key, Client_Identification, System_Key, FTR_AUDT_TS
    val transpEvtDescFinalDF = IDGenerationEngine.createKeyForDF(domainEventTypeDF, "Domain_Event_Key", List("Domain_Event_Type_Key","Primary_Object_Key","Client_Identification","System_Key","Correlation_Id","FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyTransportationEventDescribedUnpublishTransformation::End")
    transpEvtDescFinalDF
  }
    
    def applyTransportationEventAssociatedUnpublishTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransportationEventAssociatedUnpublishTransformation::Start")
    // Get Hash Key (PRNT_TYPE_CD='Domain Event Type',TYPE_CD='Unpublished')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val domainEventTypeDF = inputDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
    // Hash of: TRCTR_LIC, CRTR_CUST_NBR
    val associationKeyDF = domainEventTypeDF.withColumn("Association_Key", lit("Not Applicable"))
    .withColumn("Association_Type_Key", lit("Not Applicable"))
    .withColumn("Transportation_Event_Key", lit("Not Applicable"))
    .withColumn("Transportation_Event_Type_Key", lit("Not Applicable"))
    .withColumn("Associated_Object_Key", lit("Not Applicable"))
    .withColumn("Associated_Object_Type_Key", lit("Not Applicable"))
    // Hash of target fields: Domain_Event_Type_Key, Primary_Object_Key, Client_Identification, System_Key, FTR_AUDT_TS
    val transpEvtAssocFinalDF = IDGenerationEngine.createKeyForDF(associationKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key","Primary_Object_Key","Client_Identification","System_Key","Correlation_Id","FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyTransportationEventAssociatedUnpublishTransformation::End")
    transpEvtAssocFinalDF
  }

    def applyConveyorAssociatedUnpublishTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedUnpublishTransformation::Start")
    // Get Hash Key (PRNT_TYPE_CD='Domain Event Type',TYPE_CD='Unpublished')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val domainEventTypeDF = inputDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
    // Hash of: TRCTR_LIC, CRTR_CUST_NBR
    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(domainEventTypeDF, "Primary_Object_Key", List("TRCTR_LIC"))
    val associationKeyDF = primaryObjKeyDF.withColumn("Association_Key", lit("Not Applicable"))
    .withColumn("Association_Type_Key", lit("Not Applicable"))
    .withColumn("Conveyor_Key", lit("Not Applicable"))
    .withColumn("Conveyor_Type_Key", lit("Not Applicable"))
    .withColumn("Associated_Object_Key", lit("Not Applicable"))
    .withColumn("Associated_Object_Type_Key", lit("Not Applicable"))
    // Hash of target fields: Domain_Event_Type_Key, Primary_Object_Key, Client_Identification, System_Key, FTR_AUDT_TS
    val conveyorAssocFinalDF = IDGenerationEngine.createKeyForDF(associationKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key","Primary_Object_Key","Client_Identification","System_Key","Correlation_Id","FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedUnpublishTransformation::End")
    conveyorAssocFinalDF
  }
    
        // When a Chassis was reported
    def applyConveyorCreatedChassisTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorCreatedChassisTransformation::Start")
    // GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    // GetHash Key(PRNT_TYPE_CD='Conveyor',TYPE_CD='Chassis')
    val conveyorTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Chassis")
    // GetHash (PRNT_TYPE_CD='Identification Type', TYPE_CD='Chassis Id')
    val identificaTypeKey = CommonsUtil.getRefData(referenceData, "Identification Type", "Chassis Id")
    val outputDF = inputDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
    .withColumn("Conveyor_Type_Key", lit(conveyorTypeKey))
    .withColumn("Identification_Type_Key", lit(identificaTypeKey))
    .withColumn("Identification_Value", concat(col("CHAS_INIT"),col("CHAS_NUMB")))
    val conveyorKeyDF = IDGenerationEngine.createKeyForDF(outputDF, "Conveyor_Key", List("CHAS_INIT","CHAS_NUMB"))
    val conveyorCreateFinalDF = IDGenerationEngine.createKeyForDF(conveyorKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key","Conveyor_Key","Client_Identification","System_Key","Correlation_Id","FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorCreatedChassisTransformation::End")
    conveyorCreateFinalDF
    }
    
     def applyConveyorDescribedChassisTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedChassisTransformation::Start")
    // GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val conveyorKeyDF = IDGenerationEngine.createKeyForDF(inputDF, "Conveyor_Key", List("CHAS_INIT","CHAS_NUMB"))
    val Domain_Event_Type_KeyDF = conveyorKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))

    //Iteration1
    //GetHash Key(PRNT_TYPE_CD='Characteristic',TYPE_CD='Chassis Id') 
    val characterTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Chassis Id")
    val convDescribedDF1 = Domain_Event_Type_KeyDF.withColumn("Characteristic_Type_Key1", lit(characterTypeKey1))
      .withColumn("Characteristic_Value1", concat(col("CHAS_INIT"),col("CHAS_NUMB")))
    val convCharKeyDF1 = IDGenerationEngine.createKeyForDF(convDescribedDF1, "Conveyor_Characteristic_key1", List("Conveyor_Key", "Characteristic_Type_Key1"))
    //End Iteration1

    //Iteration2
    //GetHash Key(PRNT_TYPE_CD='Characteristic',TYPE_CD='Chassis Initial')
    val charTypeKey2 = CommonsUtil.getRefData(referenceData, "Characteristic", "Chassis Initial")
    val convDescribedDF2 = convCharKeyDF1.withColumn("Characteristic_Type_Key2", lit(charTypeKey2))
      .withColumn("Characteristic_Value2", col("CHAS_INIT"))
    val convCharKeyDF2 = IDGenerationEngine.createKeyForDF(convDescribedDF2, "Conveyor_Characteristic_key2", List("Conveyor_Key", "Characteristic_Type_Key2"))
    //End Iteration2

    //Iteration3
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Chassis Number')
    val charTypeKey3=CommonsUtil.getRefData(referenceData, "Characteristic", "Chassis Number")
    val convDescribedDF3 = convCharKeyDF2.withColumn("Characteristic_Type_Key3", lit(charTypeKey3))
      .withColumn("Characteristic_Value3", col("CHAS_NUMB"))
    val convCharKeyDF3 = IDGenerationEngine.createKeyForDF(convDescribedDF3, "Conveyor_Characteristic_key3", List("Conveyor_Key", "Characteristic_Type_Key3"))
    //End Iteration3
    
    //Iteration4
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='Chassis Car Kind')
    val charTypeKey4=CommonsUtil.getRefData(referenceData, "Characteristic", "Chassis Car Kind")
    val convDescribedDF4 = convCharKeyDF3.withColumn("Characteristic_Type_Key4", lit(charTypeKey4))
      .withColumn("Characteristic_Value4", when((col("CHAS_CAR_KIND").isNull || col("CHAS_CAR_KIND") === ""), lit("U")).otherwise(col("CHAS_CAR_KIND")))
    val convCharKeyDF4 = IDGenerationEngine.createKeyForDF(convDescribedDF4, "Conveyor_Characteristic_key4", List("Conveyor_Key", "Characteristic_Type_Key4"))
    //End Iteration4

    val convDescribedFinalDF = IDGenerationEngine.createKeyForDF(convCharKeyDF4, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_identification", "System_Key","Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTransformation::End")

    convDescribedFinalDF  
    }
    
     def applyConveyorAssociatedChassisTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedChassisTransformation::Start") 
    // GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Associated')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    //Association_Type_Key= GetHash Key(PRNT_TYPE_CD='Association', TYPE_CD='Inter-BCD Conveyor-Event')
    val assocTypeKey = CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Conveyor-Event")
    // Conveyor_Type_Key= GetHash Key (PRNT_TYPE_CD='Conveyor',TYPE_CD='Chassis')
    val conveyorTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Chassis")
    // Associated_Object_Type_Key GetHash Key (PRNT_TYPE_CD='Transportation Event', TYPE_CD='Gate Event')
     val assocObjTypeKey = CommonsUtil.getRefData(referenceData, "Transportation Event", "Gate Event")
    val outputDF = inputDF
    .withColumn("Domain_Event_Type_Key", lit(domainEventType))
    .withColumn("Association_Type_Key", lit(assocTypeKey))
    .withColumn("Conveyor_Type_Key", lit(conveyorTypeKey))
    .withColumn("Associated_Object_Type_Key", lit(assocObjTypeKey))
    .withColumn("Associated_Object_Key", col("Primary_Object_Key"))
    //val associatedObjKeyDF= IDGenerationEngine.createKeyForDF(outputDF, "Associated_Object_Key", List("HDR_MSG_SUBTYPE","RPTG_DATE","RPTG_TIME","TRCTR_LIC","CRTR_CUST_NBR"))
    val conveyorKey = IDGenerationEngine.createKeyForDF(outputDF, "Conveyor_Key", List("CHAS_INIT","CHAS_NUMB"))
    val associationKey = IDGenerationEngine.createKeyForDF(conveyorKey, "Association_Key", List("CHAS_INIT","CHAS_NUMB","TRCTR_LIC"))
    val conveAssocFinalDF = IDGenerationEngine.createKeyForDF(associationKey, "Domain_Event_Key", List("Domain_Event_Type_Key","Association_Key","Client_Identification","System_Key","Correlation_Id","FTR_AUDT_TS"))

    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedChassisTransformation::End")
    conveAssocFinalDF
     }
     
     def applyConveyorCreatedTractor(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorCreatedTractor::Start")
 
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val conveyorType=CommonsUtil.getRefData(referenceData, "Conveyor", "Tractor")
    val charTypeKey=CommonsUtil.getRefData(referenceData, "Identification Type", "Tractor License") 

    val convCreatedDF = inputDF
      .withColumn("Conveyor_Key", col("Primary_Object_Key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Conveyor_Type_Key", lit(conveyorType))
      .withColumn("Identification_Type_Key", lit(charTypeKey))
      .withColumn("Identification_Value", col("TRCTR_LIC"))
    val outputDF = IDGenerationEngine.createKeyForDF(convCreatedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorCreatedTractor::End")

    outputDF
  }

  def applyConveyorDescribedTractor(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTractor::Start")
    //GetHash Key (PRNT_TYPE_CD='Domain Event Type', TYPE_CD='Created')
    //Domain_Event_Type_Key and Conveyor_Key will be copied from ConveyorCreate
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val Domain_Event_Type_KeyDF = inputDF
    .withColumn("Conveyor_Key", col("Primary_Object_Key"))
    .withColumn("Domain_Event_Type_Key", lit(domainEventType))

    //Iteration1
    val charTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Tractor License")
    val convDescribedDF1 = Domain_Event_Type_KeyDF.withColumn("Characteristic_Type_Key1", lit(charTypeKey1))
      .withColumn("Characteristic_Value1", col("TRCTR_LIC"))
    val convCharKeyDF1 = IDGenerationEngine.createKeyForDF(convDescribedDF1, "Conveyor_Characteristic_key1", List("Conveyor_Key", "Characteristic_Type_Key1"))
    //End Iteration1
    val convDescTractorFinalDF = IDGenerationEngine.createKeyForDF(convCharKeyDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_identification", "System_Key", "Correlation_Id", "FTR_AUDT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTractor::End")

    convDescTractorFinalDF
  }


/*  def applyActionCodeFilter(inputDF: DataFrame, filterValue1: String, filterValue2: String): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyActionCodeFilter::Start")
    val finalDF = inputDF.filter(col("HDR_ACTION_CD") === filterValue1 || col("HDR_ACTION_CD") === filterValue2)
    logger.debug("SparkDataFrameHelper::applyActionCodeFilter::End")
    finalDF
  }*/

  def applyActionCodeFilter(inputDF: DataFrame, filterList: List[String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyActionCodeFilter::Start")
    val finalDF = inputDF.filter(col("record.WMBGATEV20.MSG_HEADER.HDR_ACTION_CD").isin(filterList: _*))
    logger.debug("SparkDataFrameHelper::applyActionCodeFilter::End")
    finalDF
  }

  def applyInGateFilter(inputDF: DataFrame, filterValue: String): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyInGateFilter::Start")
    val finalDF = inputDF.filter(col("record.WMBGATEV20.MSG_HEADER.HDR_MSG_SUBTYPE") === filterValue)
    logger.debug("SparkDataFrameHelper::applyInGateFilter::End")
    finalDF
  }

  def applyReportedFilter(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyReportedFilter::Start")
    val finalDF = inputDF.filter(col("record.WMBGATEV20.CARTER_SECTION.REPORTING_SECTION_CNT") === "1" && (col("record.WMBGATEV20.REPORTING_SECTION.UNIT_EQUIPMENT.EQP_INIT").isNotNull && col("record.WMBGATEV20.REPORTING_SECTION.UNIT_EQUIPMENT.EQP_NUMB").isNotNull))
    logger.debug("SparkDataFrameHelper::applyReportedFilter::End")
    finalDF
  }
  
    def applyChassisReportedFilter(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyChassisReportedFilter::Start")
    val finalDF = inputDF.filter(col("record.WMBGATEV20.CARTER_SECTION.REPORTING_SECTION_CNT") === "1" && col("record.WMBGATEV20.REPORTING_SECTION.CHASSIS_EQUIPMENT.CHAS_CN_EQP_IND") === "N" && (col("record.WMBGATEV20.REPORTING_SECTION.CHASSIS_EQUIPMENT.CHAS_INIT").isNotNull && col("record.WMBGATEV20.REPORTING_SECTION.CHASSIS_EQUIPMENT.CHAS_NUMB").isNotNull))
    logger.debug("SparkDataFrameHelper::applyChassisReportedFilter::End")
    finalDF
  }


  def applyRemoveCodeFilter(inputDF: DataFrame, filterValue: String): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyremoveCodeFilter::Start")
    val finalDF = inputDF.filter(col("record.WMBGATEV20.MSG_HEADER.HDR_ACTION_CD") === filterValue)
    logger.debug("SparkDataFrameHelper::applyremoveCodeFilter::End")
    finalDF
  }
}