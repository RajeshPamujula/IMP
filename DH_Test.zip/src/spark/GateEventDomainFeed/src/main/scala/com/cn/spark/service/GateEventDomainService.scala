package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, from_json, lit, expr, trim, concat, when,rtrim }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.references.Schema
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.idFactory.ReferenceDataGenerationEngine
import com.cn.spark.notificationFactory.ErrorNotificationEngine
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.timezoneConversionFactory.TimeZoneConversionEngine

class GateEventDomainService(sourceTopic: String, errTopic: String) extends CommonFeed(sourceTopic: String) {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)
  
  //Broadcast any thing thats required
  lazy val referenceDataDir = environmentValues.get("SPARK_REFERENCE_DATA_DIR") + "/" + applicationConf.getString("referenceDataDir")
  val referenceDataDF = CommonsUtil.readReferenceDataFile(spark)
  val refKeyValueDF = referenceDataDF.withColumn("KEY_CD", concat(col("prnt_type_cd"), lit("|"), col("type_cd"))).drop(col("type_cd")).drop(col("prnt_type_cd"))
  val referenceData = refKeyValueDF.select($"KEY_CD", $"TYPE_KEY").as[(String, String)].collect.toMap
  val refMapData = spark.sparkContext.broadcast(referenceData)
  //Time Zone Conversion Data
  val timeZoneConversionDataFileDF = TimeZoneConversionEngine.readTimeZoneReferenceFiles(environmentValues.get("SPARK_REFERENCE_DATA_DIR"))
  val tzDataDF = spark.sparkContext.broadcast(timeZoneConversionDataFileDF)

  @transient lazy val timeInterval = applicationConf.getInt("timeInterval")
  @transient lazy val transportationEventReportedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transportationEventReportedCheckpointDir")
  @transient lazy val transportationEventRemovedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transportationEventRemovedCheckpointDir")
  @transient lazy val transportationEventDescribedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transportationEventDescribedCheckpointDir")
  @transient lazy val transportationEventAssociatedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transportationEventAssociatedCheckpointDir")
  @transient lazy val conveyorCreatedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorCreatedCheckpointDir")
  @transient lazy val conveyorDescribedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorDescribedCheckpointDir")
  @transient lazy val routePlannedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("routePlannedCheckpointDir")
  @transient lazy val routeConveyorMatchedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("routeConveyorMatchedCheckpointDir")
  @transient lazy val errorNotificationCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("errorNotificationCheckpointDir")
  @transient lazy val conveyorAsctUnpublishCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorAsctUnpublishCheckpointDir")
  @transient lazy val transportationEventAsctUnpublishCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transportationEventAsctUnpublishCheckpointDir")
  @transient lazy val transportationEventDescUnpublishCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transportationEventDescUnpublishCheckpointDir")
  @transient lazy val conveyorCreatedChassisCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorCreatedChassisCheckpointDir")
  @transient lazy val conveyorDescChassisCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorDescChassisCheckpointDir")
  @transient lazy val conveyorAssocChassisCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorAssocChassisCheckpointDir")
  @transient lazy val conveyorCreatedTractorCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorCreatedTractorCheckpointDir")
  @transient lazy val conveyorDescTractorCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorDescTractorCheckpointDir")

  //Implementation of the trait. using Schema to fetch dataframe from the message.
  @Override
  def applySchema(dataset: Dataset[(String, String)]): DataFrame = {
    logger.info("GateEventDomainService Start ::applySchema")
    //applying schema to json message
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA", from_json($"value", Schema.trSchema) as "record", col("topic"))
    //adding time stamp while reading
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(rawMsgDF, "SOR_READ_TS")
    logger.debug("GateEventDomainService End ::applySchema")
    val inputDF = SparkDataFrameHelper.getSchemaAppliedDataFrame(auditTimeStampDF)
    CommonsUtil.addDeMetaColumn(inputDF, "DE_META")
  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("GateEventDomainService Start ::transformAndsinkStream")
    /*
   Check if required fields are null post the filter then redirect to error kafka and remove from the filtered DF. Header to  be updated with Source Kafka queue name
   */
     val mainDF = ErrorNotificationEngine.addErrorColumnForDF(inputDF, List("record.WMBGATEV20.CARTER_SECTION.GATE_EVT_CD", "record.WMBGATEV20.CARTER_SECTION.RPTG_DATE", "record.WMBGATEV20.CARTER_SECTION.RPTG_TIME", "record.WMBGATEV20.CARTER_SECTION.TRCTR_LIC", "record.WMBGATEV20.CARTER_SECTION.CRTR_CUSTOMER.CRTR_CUST_NBR", "record.WMBGATEV20.MSG_FOOTER.FTR_AUDT_TS", "record.WMBGATEV20.MSG_HEADER.HDR_MSG_SUBTYPE", "record.WMBGATEV20.CARTER_SECTION.CURRENT_TERMINAL.LOCN_PRST", "record.WMBGATEV20.CARTER_SECTION.CURRENT_TERMINAL.LOCN_333", "record.WMBGATEV20.CARTER_SECTION.BOBTAIL_IND", "Correlation_Id", "TIME_ZONE", "RPTG_DST_FLAG"))

    //Filter Error message
    val errorDF = ErrorNotificationEngine.filterErrorMessage(mainDF)
    //Filter correct message
    val tempDF1 = ErrorNotificationEngine.dropColumn(mainDF, "JSON_DATA")
    val tempDF2 = ErrorNotificationEngine.filterCorrectMessage(tempDF1)
    val filterDF = ErrorNotificationEngine.dropColumn(tempDF2, "ERROR_KEY")

    val filterList = List("A", "M")
    val correctDF = SparkDataFrameHelper.applyActionCodeFilter(filterDF, filterList)
    val correctDF1 = SparkDataFrameHelper.applyRemoveCodeFilter(filterDF, "D")
    //common transformations

    val commonTransformedDF = SparkDataFrameHelper.applyCommonTransformations(correctDF, refMapData.value, tzDataDF.value)
    val transformedDF = SparkDataFrameHelper.applyCommonTransformations(correctDF1, refMapData.value, tzDataDF.value)
    //TransportationEventReportedTransformation
    val transportationEventReportedFinalDF = SparkDataFrameHelper.applyTransportationEventReportedTransformation(commonTransformedDF, refMapData.value)
    //TransportationEventRemovedTransformation
    val transportationEventRemovedFinalDF = SparkDataFrameHelper.applyTransportationEventRemovedTransformation(transformedDF, refMapData.value)
    //TransportationEventDescriedTransformation
    val transportationEventDescFinalDF = SparkDataFrameHelper.applyTransportationEventDescribedTransformation(commonTransformedDF, refMapData.value)
    //TransportationEventAssociatedLocationTransformation
    val transportationEventAssociatedLocFinalDF = SparkDataFrameHelper.applyTransportationEventAssociatedLocationTransformation(commonTransformedDF, refMapData.value)
    //Check for Ingate and Container Reported
    val inGateDF = SparkDataFrameHelper.applyInGateFilter(commonTransformedDF, "Ingate")
    val cntrReportedDF = SparkDataFrameHelper.applyReportedFilter(inGateDF)
    val chassisReportedDF = SparkDataFrameHelper.applyChassisReportedFilter(inGateDF)

    val cntrReportedAssoDF = SparkDataFrameHelper.applyReportedFilter(commonTransformedDF)
    val chassisReportedAssoDF = SparkDataFrameHelper.applyChassisReportedFilter(commonTransformedDF)

    //ConveyorCreated
    val convCreatedFinalDF = SparkDataFrameHelper.applyConveyorCreatedTransformation(cntrReportedDF, refMapData.value)
    //ConveyprDescribed
    val convDescribedFinalDF = SparkDataFrameHelper.applyConveyorDescribedTransformation(cntrReportedDF, refMapData.value)
    //ConveyorAssociated
    val convAssociatedFinalDF = SparkDataFrameHelper.applyConveyorAssociatedTransformation(cntrReportedAssoDF, refMapData.value)
    // TransportationEventDescribed (Unpublish)
    val TransportationEventDescUnpublDF = SparkDataFrameHelper.applyTransportationEventDescribedUnpublishTransformation(transformedDF, refMapData.value)
    // TransportationEventAssociated (Unpublish)
    val TransportationEventAsctUnpublDF = SparkDataFrameHelper.applyTransportationEventAssociatedUnpublishTransformation(transformedDF, refMapData.value)
    // Conveyor Associated (Unpublish)
    val ConveyorAsctUnpublishedDF = SparkDataFrameHelper.applyConveyorAssociatedUnpublishTransformation(transformedDF, refMapData.value)
    // Conveyor Created(Chassis)
    val convCreatedChassisFinalDF = SparkDataFrameHelper.applyConveyorCreatedChassisTransformation(chassisReportedDF, refMapData.value)
    // Conveyor Described(Chassis)
    val convDescribedChassisFinalDF = SparkDataFrameHelper.applyConveyorDescribedChassisTransformation(chassisReportedDF, refMapData.value)
    // Conveyor Associated(Chassis)
    val convAssociatedChassisFinalDF = SparkDataFrameHelper.applyConveyorAssociatedChassisTransformation(chassisReportedAssoDF, refMapData.value)
    // Conveyor Created(Tractor)
    val convCreatedTractorFinalDF = SparkDataFrameHelper.applyConveyorCreatedTractor(inGateDF, refMapData.value)
    // Conveyor Described(Tractor)
    val convDescribedTractorFinalDF = SparkDataFrameHelper.applyConveyorDescribedTractor(inGateDF, refMapData.value)
    //kafka error reporting.
    errorDF.writeStream.option("checkpointLocation", errorNotificationCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ErrorNotificationForEachWriter(errTopic, "GateEventDomainFeed", sourceTopic)).start()
    transportationEventReportedFinalDF.writeStream.option("checkpointLocation", transportationEventReportedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new TransportationEventReportedForEachWriter).start()
    transportationEventRemovedFinalDF.writeStream.option("checkpointLocation", transportationEventRemovedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new TransportationEventRemovedForEachWriter).start()
    transportationEventDescFinalDF.writeStream.option("checkpointLocation", transportationEventDescribedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new TransportationEventDescribedForEachWriter).start()
    transportationEventAssociatedLocFinalDF.writeStream.option("checkpointLocation", transportationEventAssociatedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new TransportationEventAssociatedForEachWriter).start()
    convCreatedFinalDF.writeStream.option("checkpointLocation", conveyorCreatedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorCreatedForEachWriter).start()
    convDescribedFinalDF.writeStream.option("checkpointLocation", conveyorDescribedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDescribedForEachWriter).start()
    convAssociatedFinalDF.writeStream.option("checkpointLocation", routeConveyorMatchedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociatedForEachWriter).start()
    ConveyorAsctUnpublishedDF.writeStream.option("checkpointLocation", conveyorAsctUnpublishCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociatedUnpublishForEachWriter).start()
    TransportationEventDescUnpublDF.writeStream.option("checkpointLocation", transportationEventDescUnpublishCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new TransportationEventDescribedUnpublishForEachWriter).start()
    TransportationEventAsctUnpublDF.writeStream.option("checkpointLocation", transportationEventAsctUnpublishCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new TransportationEventAssociatedUnpublishForEachWriter).start()
    convCreatedChassisFinalDF.writeStream.option("checkpointLocation", conveyorCreatedChassisCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorCreatedChassisForEachWriter).start()
    convDescribedChassisFinalDF.writeStream.option("checkpointLocation", conveyorDescChassisCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDescribedChassisForEachWriter).start()
    convAssociatedChassisFinalDF.writeStream.option("checkpointLocation", conveyorAssocChassisCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociatedChassisForEachWriter).start()
    convCreatedTractorFinalDF.writeStream.option("checkpointLocation", conveyorCreatedTractorCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorCreatedTractorForEachWriter).start()
    convDescribedTractorFinalDF.writeStream.option("checkpointLocation", conveyorDescTractorCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDescribedTractorForEachWriter).start()

    //logger.debug("GateEventDomainService End ::transformAndsinkStream")
  }

}