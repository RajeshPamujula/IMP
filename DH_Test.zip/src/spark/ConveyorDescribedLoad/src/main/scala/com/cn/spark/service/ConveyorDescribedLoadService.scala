package com.cn.spark.service

import java.util.Properties

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, from_json, lit,concat }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger

import com.cn.spark.commons.references.ConveyorDescribedSchema
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.commonsEngine.CommonFeed
import java.util.Properties
import com.cn.spark.idFactory.IDGenerationEngine
import com.cn.spark.commonsEngine.CommonsUtil

class ConveyorDescribedLoadService(sourceTopicName:String,ErrorNotificationTopic:String) extends CommonFeed(sourceTopicName:String) {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)
  @transient lazy val conveyorDescribedLoadCheckpointDir = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorDescribedLoadCheckpointDir")
  lazy val targetTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("conveyorDescTable")
  //Broadcast any thing thats required
  @transient lazy val jcekFileSystem = applicationConf.getString("jcekFileSystem")
  lazy val dbConfigParam: Properties = CommonsUtil.setPostgreConfig(targetTableName,jcekFileSystem)
  lazy val timeInterval = applicationConf.getInt("timeInterval")

    lazy val targetUpsertTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("conveyorDescUpsertTable")
  val domainTypeDF = spark.createDataFrame(Seq(("Unpublished", "Domain Event Type"),("Created", "Domain Event Type"))).toDF("TYPE_CD", "PRNT_TYPE_CD")
  val domainTypeFinalDF = IDGenerationEngine.createKeyForDF(domainTypeDF, "DOMAIN_EVENT_FLAG", List("TYPE_CD", "PRNT_TYPE_CD"))
  val domainType = domainTypeFinalDF.select(concat($"PRNT_TYPE_CD",lit("|"),$"TYPE_CD"),$"DOMAIN_EVENT_FLAG").as[(String, String)].collect.toMap
  val domainTypeVal = spark.sparkContext.broadcast(domainType)
  //Implementation of the trait. using Schema to fetch dataframe from the message.
  @Override
  def applySchema(dataset: Dataset[(String,String)]): DataFrame = {
    logger.info("ConveyorDescribedLoadService Start ::applySchema")
    //applying schema to json message
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA",from_json(CommonsUtil.preprocessJson($"value"), ConveyorDescribedSchema.conveyorDescribedSchema) as "record")
    //adding time stamp while reading
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(rawMsgDF, "DOMN_EVT_READ_TS")
    logger.debug("ConveyorDescribedLoadService End ::applySchema")

    SparkDataFrameHelper.getMessage(auditTimeStampDF)
  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("ConveyorDescribedLoadService Start ::transformAndsinkStream")

    val convDescribedFinalDF = SparkDataFrameHelper.applyTransformation(inputDF)

    convDescribedFinalDF.writeStream.option("checkpointLocation", conveyorDescribedLoadCheckpointDir).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDescribedLoadForEachWriter(dbConfigParam, ErrorNotificationTopic, "ConveyorDescribedLoad", sourceTopicName,targetUpsertTableName,domainTypeVal.value)).start()

  }

}