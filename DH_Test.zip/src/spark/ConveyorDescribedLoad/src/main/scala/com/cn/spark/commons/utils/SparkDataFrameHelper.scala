package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.explode
import org.apache.spark.sql.functions.to_timestamp
import org.apache.spark.sql.functions.regexp_replace

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def getMessage(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::getMessage::Start")

    val selectedDF = inputDF
      .select(
        col("record.DomainEventHeader.SOR_INGT_CRT_TS").alias("SOR_INGT_CRT_TS"),
        col("record.DomainEventHeader.SOR_READ_TS").alias("SOR_READ_TS"),
        col("record.DomainEventHeader.DE_CRT_TS").alias("DOMN_EVT_CRT_TS"),
        col("record.DomainEventHeader.SOR_TPIC_NM").alias("SOR_TPIC_NM"),
        col("record.DomainEventHeader.DE_META").alias("DOMN_EVT_META"),        
        col("record.ConveyorDescribed.Domain_Event_Type_Key").alias("DOMN_EVT_TYPE_KEY"),
        col("record.ConveyorDescribed.Conveyor_Key").alias("CNVY_KEY"),
        col("record.ConveyorDescribed.Domain_Event_Key").alias("DOMN_EVT_KEY"),
        col("record.ConveyorDescribed.Correlation_Id").alias("SOR_CRLT_ID"),
        col("record.ConveyorDescribed.Client_Identification").alias("CLNT_ID"),
        col("record.ConveyorDescribed.System_Key").alias("SYS_KEY"),
        col("record.ConveyorDescribed.Proc_Ts").alias("SOR_PROC_TS"),
        col("record.ConveyorDescribed.Event_Ts").alias("SOR_EVT_TS"),
        col("record.ConveyorDescribed.Event_Ts_Tz_Dst_Cd").alias("SOR_EVT_TS_TZ_DST_CD"),
        col("record.ConveyorDescribed.Proc_Ts_Tz_Dst_Cd").alias("SOR_PROC_TS_TZ_DST_CD"),
        col("DOMN_EVT_READ_TS").alias("DOMN_EVT_READ_TS"),
        explode(col("record.ConveyorDescribed.ConveyorCharacteristics")),
        col("JSON_DATA").alias("JSON_DATA"))
      .select(
        col("SOR_INGT_CRT_TS"),
        col("SOR_READ_TS"),
        col("DOMN_EVT_CRT_TS"),
        col("SOR_TPIC_NM"),
        col("DOMN_EVT_META"),        
        col("DOMN_EVT_TYPE_KEY"),
        col("CNVY_KEY"),
        col("DOMN_EVT_KEY"),
        col("SOR_CRLT_ID"),
        col("CLNT_ID"),
        col("SYS_KEY"),
        col("SOR_PROC_TS"),
        col("SOR_EVT_TS"),
        col("SOR_EVT_TS_TZ_DST_CD"),
        col("SOR_PROC_TS_TZ_DST_CD"),
        col("DOMN_EVT_READ_TS"),
        col("col.Conveyor_Characteristic_Key").alias("CNVY_CHAR_KEY"),
        col("col.Characteristic_Type_Key").alias("CHAR_TYPE_KEY"),
        col("col.Characteristic_Value").alias("CHAR_VAL"),
        col("JSON_DATA").alias("JSON_DATA"))//.withColumn("CLNT_ID", regexp_replace(col("CLNT_ID"),"'","''"))

    logger.debug("SparkDataFrameHelper::getMessage::End")

    selectedDF
  }

  def applyTransformation(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransformation::Start")
    val transformDF = inputDF
      .withColumn("SOR_INGT_CRT_TS", to_timestamp(col("SOR_INGT_CRT_TS")))
      .withColumn("SOR_READ_TS", to_timestamp(col("SOR_READ_TS")))
      .withColumn("DOMN_EVT_CRT_TS", to_timestamp(col("DOMN_EVT_CRT_TS")))
      .withColumn("SOR_PROC_TS", to_timestamp(col("SOR_PROC_TS")))
      .withColumn("SOR_EVT_TS", to_timestamp(col("SOR_EVT_TS")))
    /*  .withColumn("DOMN_EVT_KEY", col("DOMN_EVT_KEY").cast(BinaryType))
      .withColumn("CNVY_KEY", col("CNVY_KEY").cast(BinaryType))
      .withColumn("DOMN_EVT_TYPE_KEY", col("DOMN_EVT_TYPE_KEY").cast(BinaryType))
      .withColumn("CNVY_CHAR_KEY", col("CNVY_CHAR_KEY").cast(BinaryType))
      .withColumn("CHAR_TYPE_KEY", col("CHAR_TYPE_KEY").cast(BinaryType))
      .withColumn("SYS_KEY", col("SYS_KEY").cast(BinaryType))*/
    logger.debug("SparkDataFrameHelper::applyTransformation::End")
    transformDF
  }

}