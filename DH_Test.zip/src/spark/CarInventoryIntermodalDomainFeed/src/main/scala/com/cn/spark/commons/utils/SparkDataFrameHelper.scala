package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{ col, current_timestamp, date_format, lit, trim, rtrim, when, concat, expr, regexp_replace, to_utc_timestamp, explode, substring, array }
import com.cn.spark.idFactory.IDGenerationEngine
import com.cn.spark.commonsEngine
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.Constants
import com.cn.spark.timezoneConversionFactory.TimeZoneConversionEngine

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def filterOutMessages(inputDF: DataFrame, tzDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::filterOutMessages::Start")

    val selectedDF = inputDF
      .filter(trim(col("record.CarInventoryIntermodal.IBMSNAP_OPERATION")) === "I" || trim(col("record.CarInventoryIntermodal.IBMSNAP_OPERATION")) === "U" || trim(col("record.CarInventoryIntermodal.IBMSNAP_OPERATION")) === "D")
      .select(
        col("SOR_READ_TS").alias("SOR_READ_TS"),
        trim(col("record.CarInventoryIntermodal.IBMSNAP_LOGMARKER")).alias("IBMSNAP_LOGMARKER"),
        col("record").alias("record"),
        col("JSON_DATA").alias("JSON_DATA"),
        col("topic").alias("SOR_TPIC_NM"))

    val transformDF = selectedDF
      .withColumn("IBMSNAP_LOGMARKER_formatted", regexp_replace(col("IBMSNAP_LOGMARKER"), "(\\d{4})-(\\d{2})-(\\d{2}) (\\d{2}):(\\d{2}):(\\d{2}).(\\d{6})", "$1-$2-$3 $4:$5:$6.$7"))

    //LOCAL_TIME, LOCAL_YEAR, DST, (STN_SCAC & FSAC) OR (STN_333 & STN_PRST)
    val transformPrepEventTsTimeZoneDF = transformDF
      .withColumn("LOCAL_TIME", col("IBMSNAP_LOGMARKER_formatted"))
      .withColumn("LOCAL_YEAR", substring(col("IBMSNAP_LOGMARKER_formatted"), 1, 4))
      //Using STN_SCAC & FSAC for Time Zone Conversion
      .withColumn("STN_SCAC", lit("CN"))
      .withColumn("FSAC", lit("33273"))

    val transformWithProcTsTimeZoneDF = TimeZoneConversionEngine.toUTCConversion(transformPrepEventTsTimeZoneDF, tzDF, "SCAC")

    val finalWithProcTsTimeZoneDF = transformWithProcTsTimeZoneDF
      .withColumn("Event_Ts", trim(col("UTC_TIME_FORMATTED")))
      .withColumn("Event_Ts_Tz_Dst_Cd", trim(col("TZ_DST_CD")))
      .drop("LOCAL_TIME")
      .drop("LOCAL_YEAR")
      .drop("STN_SCAC")
      .drop("FSAC")
      .drop("DST")
      .drop("STN_333")
      .drop("STN_PRST")
      .drop("UTC_TIME_FORMATTED")
      .drop("TZ_DST_CD")

    val finalDF = finalWithProcTsTimeZoneDF
      .select(
        trim(col("record.IngestionHeader.ING_CRT_TS")).alias("SOR_INGT_CRT_TS"),
        trim(col("record.IngestionHeader.UUID")).alias("Correlation_Id"),
        col("SOR_READ_TS").alias("SOR_READ_TS"),
        trim(col("record.CarInventoryIntermodal.CAR_NUMB")).alias("CAR_NUMB"),
        col("record.CarInventoryIntermodal.CAR_INIT").alias("CAR_INIT"),
        trim(col("record.CarInventoryIntermodal.EQP_NUMB")).alias("EQP_NUMB"),
        trim(col("record.CarInventoryIntermodal.EQP_INIT")).alias("EQP_INIT"),
        trim(col("record.CarInventoryIntermodal.EQP_SEQ_NUMB")).alias("EQP_SEQ_NUMB"),
        trim(col("record.CarInventoryIntermodal.EQP_RMP_STAT")).alias("EQP_RMP_STAT"),
        trim(col("record.CarInventoryIntermodal.ATCH_DT")).alias("ATCH_DT"),
        trim(col("record.CarInventoryIntermodal.ATCH_TM")).alias("ATCH_TM"),
        trim(col("record.CarInventoryIntermodal.TIME_ZONE")).alias("TIME_ZONE"),
        trim(col("record.CarInventoryIntermodal.IBMSNAP_OPERATION")).alias("IBMSNAP_OPERATION"),
        col("IBMSNAP_LOGMARKER_formatted").alias("IBMSNAP_LOGMARKER_formatted"),
        col("Event_Ts").alias("Event_Ts"),
        col("Event_Ts_Tz_Dst_Cd").alias("Event_Ts_Tz_Dst_Cd"),
        col("JSON_DATA").alias("JSON_DATA"),
        col("SOR_TPIC_NM").alias("SOR_TPIC_NM"))
      .drop("record")

    logger.debug("SparkDataFrameHelper::filterOutMessages::End")

    finalDF
  }

  def applyCommonTransformations(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyCommonTransformations::Start")
    val systemKey = CommonsUtil.getRefData(referenceData, "System", "SRS-IM")
    val transformDF = inputDF
      .withColumn("CAR_NUMB", trim(col("CAR_NUMB")))
      .withColumn("EQP_NUMB", trim(col("EQP_NUMB")))
      .withColumn("Client_Identification", lit("SRS-IM"))
      .withColumn("System_Key", lit(systemKey))
      .withColumn("Proc_Ts", col("SOR_INGT_CRT_TS"))
      .withColumn("Proc_Ts_Tz_Dst_Cd", lit(Constants.DST_CD_UTC_DST_NO))

    logger.debug("SparkDataFrameHelper::applyCommonTransformations::End")
    transformDF
  }

  def applyConveyorAssociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedTransformation::Start")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    val associationTypeKey = CommonsUtil.getRefData(referenceData, "Association", "Intra-BCD Container-Railcar")
    val conveyorTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Container")
    val associatedObjectTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Railcar")

    val transformDF = inputDF.filter(col("IBMSNAP_OPERATION") =!= "D")

    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(transformDF, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    val conveyorAssociatedDF = primaryObjKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Association_Type_Key", lit(associationTypeKey))
      .withColumn("Conveyor_Type_Key", lit(conveyorTypeKey))
      .withColumn("Associated_Object_Type_Key", lit(associatedObjectTypeKey))

    val conveyorAssociatedDF1 = IDGenerationEngine.createKeyForDF(conveyorAssociatedDF, "Associated_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    val conveyorAssociatedDF2 = IDGenerationEngine.createKeyForDF(conveyorAssociatedDF1, "Conveyor_Key", List("EQP_INIT", "EQP_NUMB"))
    val conveyorAssociatedDF3 = IDGenerationEngine.createKeyForDF(conveyorAssociatedDF2, "Association_Key", List("Conveyor_Key", "Associated_Object_Key"))
    val outputDF = IDGenerationEngine.createKeyForDF(conveyorAssociatedDF3, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedTransformation::End")
    outputDF
  }

  def applyConveyorAssociationDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorAssociationDescribedTransformation::Start")

    val Domain_Event_Type_Key = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val Characteristic_Type_Key1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Equipment Sequence Number")
    val Characteristic_Type_Key2 = CommonsUtil.getRefData(referenceData, "Characteristic", "Equipment Ramp Status")
    val Characteristic_Type_Key3 = CommonsUtil.getRefData(referenceData, "Characteristic", "Attach Date Time")
    val Characteristic_Type_Key4 = CommonsUtil.getRefData(referenceData, "Characteristic", "Attach Date Time Time Zone")

    val filterDF = inputDF.filter(col("IBMSNAP_OPERATION") =!= "D")

    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(filterDF, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    val transformDF = primaryObjKeyDF
      .withColumn("Domain_Event_Type_Key", lit(Domain_Event_Type_Key))
      .withColumn("Characteristic_Type_Key1", lit(Characteristic_Type_Key1))
      .withColumn("Characteristic_Value1", when(col("EQP_SEQ_NUMB").isNull, lit("")).otherwise(col("EQP_SEQ_NUMB")))
      .withColumn("Characteristic_Type_Key2", lit(Characteristic_Type_Key2))
      .withColumn("Characteristic_Value2", when(col("EQP_RMP_STAT").isNull, lit("")).otherwise(col("EQP_RMP_STAT")))
      .withColumn("Characteristic_Type_Key3", lit(Characteristic_Type_Key3))
      .withColumn("Characteristic_Value3", when((col("ATCH_DT").isNull || col("ATCH_TM").isNull || col("ATCH_DT") === "" || col("ATCH_TM") === ""), lit("")).otherwise(regexp_replace(concat(col("ATCH_DT"), lit("-"), col("ATCH_TM")), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}):(\\d{2}):(\\d{2})", "$1-$2-$3 $4:$5:$6")))
      .withColumn("Characteristic_Type_Key4", lit(Characteristic_Type_Key4))
      .withColumn("Characteristic_Value4", when(col("TIME_ZONE").isNull, lit("")).otherwise(col("TIME_ZONE")))

    val transformDF1 = IDGenerationEngine.createKeyForDF(transformDF, "Conveyor_Key", List("EQP_INIT", "EQP_NUMB"))
    val transformDF2 = IDGenerationEngine.createKeyForDF(transformDF1, "Associated_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    val transformDF3 = IDGenerationEngine.createKeyForDF(transformDF2, "Association_Key", List("Conveyor_Key", "Associated_Object_Key"))
    val transformDF4 = IDGenerationEngine.createKeyForDF(transformDF3, "Association_Characteristic_Key1", List("Association_Key", "Characteristic_Type_Key1"))
    val transformDF5 = IDGenerationEngine.createKeyForDF(transformDF4, "Association_Characteristic_Key2", List("Association_Key", "Characteristic_Type_Key2"))
    val transformDF6 = IDGenerationEngine.createKeyForDF(transformDF5, "Association_Characteristic_Key3", List("Association_Key", "Characteristic_Type_Key3"))
    val transformDF7 = IDGenerationEngine.createKeyForDF(transformDF6, "Association_Characteristic_Key4", List("Association_Key", "Characteristic_Type_Key4"))
    val outputDF = IDGenerationEngine.createKeyForDF(transformDF7, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "Proc_Ts"))

    logger.debug("SparkDataFrameHelper::applyConveyorAssociationDescribedTransformation::End")
    outputDF
  }
  
  def applyConveyorAssociationDescribedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorAssociationDescribedUnpublishedTransformation::Start")

    val Domain_Event_Type_Key = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    
    val filterDF = inputDF.filter(col("IBMSNAP_OPERATION") === "D")

    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(filterDF, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    val transformDF = primaryObjKeyDF
      .withColumn("Domain_Event_Type_Key", lit(Domain_Event_Type_Key))
      .withColumn("Association_Key", lit(""))
      				
    val outputDF = IDGenerationEngine.createKeyForDF(transformDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "Proc_Ts"))

    logger.debug("SparkDataFrameHelper::applyConveyorAssociationDescribedUnpublishedTransformation::End")
    outputDF
  }


  def applyConveyorDisassociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorDisassociatedTransformation::Start")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Disassociated")
    val associationTypeKey = CommonsUtil.getRefData(referenceData, "Association", "Intra-BCD Container-Railcar")
    val conveyorTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Container")
    val associatedObjectTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Railcar")

    val transformDF = inputDF.filter(col("IBMSNAP_OPERATION") === "D")

    val primaryObjKeyDF = IDGenerationEngine.createKeyForDF(transformDF, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    val conveyorDisassociatedDF = primaryObjKeyDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Association_Type_Key", lit(associationTypeKey))
      .withColumn("Conveyor_Type_Key", lit(conveyorTypeKey))
      .withColumn("Associated_Object_Type_Key", lit(associatedObjectTypeKey))

    val conveyorDisassociatedDF1 = IDGenerationEngine.createKeyForDF(conveyorDisassociatedDF, "Associated_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    val conveyorDisassociatedDF2 = IDGenerationEngine.createKeyForDF(conveyorDisassociatedDF1, "Conveyor_Key", List("EQP_INIT", "EQP_NUMB"))
    val conveyorDisassociatedDF3 = IDGenerationEngine.createKeyForDF(conveyorDisassociatedDF2, "Association_Key", List("Conveyor_Key", "Associated_Object_Key"))
    val outputDF = IDGenerationEngine.createKeyForDF(conveyorDisassociatedDF3, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorDisassociatedTransformation::End")
    outputDF

  }
}