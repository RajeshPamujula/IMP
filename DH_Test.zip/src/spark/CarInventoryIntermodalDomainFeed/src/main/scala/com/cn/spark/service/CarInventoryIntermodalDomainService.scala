package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, from_json, lit, trim, concat }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.references.Schema
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.idFactory.IDGenerationEngine
import com.cn.spark.idFactory.ReferenceDataGenerationEngine
import com.cn.spark.notificationFactory.ErrorNotificationEngine
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.timezoneConversionFactory.TimeZoneConversionEngine

class CarInventoryIntermodalDomainService(sourceTopic:String,errTopic:String) extends CommonFeed(sourceTopic:String) {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)

  //Broadcast any thing thats required
  val referenceDataDF= CommonsUtil.readReferenceDataFile(spark)
  
  val refKeyValueDF = referenceDataDF.withColumn("KEY_CD",concat(col("prnt_type_cd"),lit("|"),col("type_cd"))).drop(col("type_cd")).drop(col("prnt_type_cd"))
  val referenceData = refKeyValueDF.select($"KEY_CD", $"TYPE_KEY").as[(String, String)].collect.toMap
  val refMapData = spark.sparkContext.broadcast(referenceData)  
  
  
  //Time Zone Conversion Data
  val timeZoneConversionDataFileDF = TimeZoneConversionEngine.readTimeZoneReferenceFiles(environmentValues.get("SPARK_REFERENCE_DATA_DIR"))
  val tzDataDF = spark.sparkContext.broadcast(timeZoneConversionDataFileDF)

  
  @transient lazy val timeInterval = applicationConf.getInt("timeInterval")
  @transient lazy val conveyorAssociatedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorAssociatedCheckpointDir")
  @transient lazy val conveyorAsctDescribedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorAsctDescribedCheckpointDir")
  @transient lazy val conveyorDisassociatedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorDisassociatedCheckpointDir")
  @transient lazy val conveyorAsctDescribedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorAsctDescribedUnpublishedCheckpointDir")
  @transient lazy val errorNotificationCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("errorNotificationCheckpointDir")
  //Implementation of the trait. using Schema to fetch dataframe from the message.

  @Override
  def applySchema(dataset: Dataset[(String,String)]): DataFrame = {
    logger.info("CarInventoryIntermodalDomainService Start ::applySchema")
    //applying schema to json message
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA", from_json($"value", Schema.carInvImdlSchema) as "record",col("topic"))

    //adding time stamp while reading
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(rawMsgDF, "SOR_READ_TS")
    logger.debug("CarInventoryIntermodalDomainService End ::applySchema")

    /*
     Filter out when action code ("IBMSNAP_OPERATION") = 'I','U', 'D'
      */
    val filterDF = SparkDataFrameHelper.filterOutMessages(auditTimeStampDF, tzDataDF.value)
    CommonsUtil.addDeMetaColumn(filterDF, "DE_META")

  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("CarInventoryIntermodalDomainService Start ::transformAndsinkStream")

    /*
   Check if required fields are null post the filter then redirect to error kafka and remove from the filtered DF.
   */
    val mainDF = ErrorNotificationEngine.addErrorColumnForDF(inputDF, List("SOR_INGT_CRT_TS","Correlation_Id","CAR_NUMB","CAR_INIT","EQP_NUMB","EQP_INIT","IBMSNAP_LOGMARKER_formatted"))

    //Filter Error message
    val errorDF = ErrorNotificationEngine.filterErrorMessage(mainDF)

    //Filter correct message
    val tempDF1 = ErrorNotificationEngine.dropColumn(mainDF, "JSON_DATA")
    val tempDF2 = ErrorNotificationEngine.filterCorrectMessage(tempDF1)
    val correctDF = ErrorNotificationEngine.dropColumn(tempDF2, "ERROR_KEY")

    val transformedDF = SparkDataFrameHelper.applyCommonTransformations(correctDF, refMapData.value)
    
    //CONVEYOR ASSOCIATED
    val conveyorAssociatedFinalDF = SparkDataFrameHelper.applyConveyorAssociatedTransformation(transformedDF, refMapData.value)
    
    //CONVEYOR ASSOCIATION DESCRIBED
    val conveyorAssociationDescribedFinalDF = SparkDataFrameHelper.applyConveyorAssociationDescribedTransformation(transformedDF, refMapData.value)
    val conveyorAssociationDescribedUnpublishedFinalDF = SparkDataFrameHelper.applyConveyorAssociationDescribedUnpublishedTransformation(transformedDF, refMapData.value)
    
    
    //CONVEYOR DISASSOCIATED
    val conveyorDisassociatedFinalDF = SparkDataFrameHelper.applyConveyorDisassociatedTransformation(transformedDF, refMapData.value)

    //send error messages to kafka Que
    errorDF.writeStream.option("checkpointLocation", errorNotificationCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ErrorNotificationForEachWriter(errTopic, "CarInventoryIntermodalDomainFeed", sourceTopic)).start()

    conveyorAssociatedFinalDF.writeStream.option("checkpointLocation", conveyorAssociatedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociatedForEachWriter).start()
    
    conveyorAssociationDescribedFinalDF.writeStream.option("checkpointLocation", conveyorAsctDescribedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociationDescribedForEachWriter).start()

    conveyorDisassociatedFinalDF.writeStream.option("checkpointLocation", conveyorDisassociatedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDisassociatedForEachWriter).start()
  
    conveyorAssociationDescribedUnpublishedFinalDF.writeStream.option("checkpointLocation", conveyorAsctDescribedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociationDescribedUnpublishedForEachWriter).start()
  
  
  }

}