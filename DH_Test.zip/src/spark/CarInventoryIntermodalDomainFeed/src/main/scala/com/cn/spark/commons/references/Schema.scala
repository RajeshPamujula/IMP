package com.cn.spark.commons.references

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import scala.collection.Seq

object Schema {

  val carInvImdlSchema = StructType(Seq(
    StructField("IngestionHeader", StructType(Seq(
      StructField("ING_CRT_TS", StringType, false),
      StructField("UUID", StringType, false))), false),
      StructField("CarInventoryIntermodal", StructType(Seq(
        StructField("CAR_INIT", StringType, false),
        StructField("CAR_NUMB", StringType, false),
        StructField("EQP_INIT", StringType, false),
        StructField("EQP_NUMB", StringType, false),
        StructField("EQP_SEQ_NUMB", StringType, true),
        StructField("EQP_RMP_STAT", StringType, true),
        StructField("ATCH_DT", StringType, true),
        StructField("ATCH_TM", StringType, true),
        StructField("TIME_ZONE", StringType, true),
        StructField("IBMSNAP_OPERATION", StringType, false),
        StructField("IBMSNAP_LOGMARKER", StringType, false))), false)))

  val referenceDataSchema = StructType(Seq(
    StructField("type_cd", StringType, false),
    StructField("prnt_type_cd", StringType, false)))
}