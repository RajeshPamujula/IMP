
import org.apache.commons.lang3.exception.ExceptionUtils
import org.apache.log4j.Logger

import com.cn.spark.commonsEngine.CommonsUtil.isEmpty
import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.service.BusinessPartnerDescribedLoadService

object BusinessPartnerDescribedLoad extends App with ApplicationConfigEngine {

  val logger = Logger.getLogger(getClass.getName)
  //System.setProperty("hadoop.home.dir", "U:\\winutils")
  
  val sourceTopic = environmentValues.get(applicationConf.getString("KAFKA_SRC_TOPIC"))
  val errorTopic = environmentValues.get(applicationConf.getString("KAFKA_ERR_TOPIC"))
  if(!isEmpty(sourceTopic)){
    if(!isEmpty(errorTopic)){ 
      val businessPartnerDescribedLoadService = new BusinessPartnerDescribedLoadService(sourceTopic,errorTopic)
  try {
    businessPartnerDescribedLoadService.Start()
  } catch {
    case se: Exception => {
      val updateException: Throwable = ExceptionUtils.getRootCause(se)
      logger.error("Error While Starting BusinessPartnerDescribedLoad" + se.printStackTrace())
    }

  }
  }else{
    logger.error("ErrorTopic name is null. Please pass it and run the job again!")
    throw new Exception("ErrorTopic name is null. Please pass it and run the job again!")
  }
   }else{
    logger.error("Source topic name is null. Please pass it and run the job again!")
    throw new Exception("Source topic name is null. Please pass it and run the job again!")
  }
}