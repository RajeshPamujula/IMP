package com.cn.spark.commons.references

import scala.collection.Seq

import org.apache.log4j.Logger
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType

object Schema extends Serializable {
  val logger = Logger.getLogger(getClass.getName)

  val businessPartnerDescribedSchema = StructType(Seq(
    StructField("DomainEventHeader", StructType(Seq(
      StructField("SOR_INGT_CRT_TS", StringType, false),
      StructField("SOR_READ_TS", StringType, false),
      StructField("DE_CRT_TS", StringType, false),
      StructField("SOR_TPIC_NM", StringType, false),
      StructField("DE_META", StringType, false))), false),
    StructField("BusinessPartnerDescribed", StructType(Seq(
      StructField("Domain_Event_Key", StringType, false),
      StructField("Domain_Event_Type_Key", StringType, false),
      StructField("Business_Partner_Key", StringType, false),
      StructField("Correlation_Id", StringType, false),
      StructField("System_Key", StringType, false),
      StructField("Client_Identification", StringType, false),
      StructField("Proc_Ts", StringType, false),
      StructField("Event_Ts", StringType, false),
      StructField("Event_Ts_Tz_Dst_Cd", StringType, false),
      StructField("Proc_Ts_Tz_Dst_Cd", StringType, false),
      StructField("BusinessPartnerCharacteristics", ArrayType(StructType(Seq(
        StructField("Business_Partner_Characteristic_Key", StringType, false),
        StructField("Characteristic_Type_Key", StringType, false),
        StructField("Characteristic_Value", StringType, false)))), false))), false)))
}

