package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, from_json, lit, concat, regexp_replace }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.references.Schema
import com.cn.spark.commons.utils.SparkDataFrameHelper
import java.util.Properties

import org.apache.commons.lang3.exception.ExceptionUtils
import org.apache.hadoop.security.alias.CredentialProviderFactory
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonsUtil.preprocessJson
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.idFactory.IDGenerationEngine

class ConveyorDisassociatedLoadService(sourceTopicName:String,ErrorNotificationTopic:String) extends CommonFeed(sourceTopicName:String) {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)
  @transient lazy val conveyorDisassociatedLoadCheckpointDir = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorDisassociatedLoadCheckpointDir")
  lazy val targetTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("conveyorDisassociatedTable")
  lazy val targetUpsertTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("conveyorDisassociateUpsertTable")
  //Broadcast any thing thats required
  @transient lazy val jcekFileSystem = applicationConf.getString("jcekFileSystem")
  lazy val dbConfigParam: Properties = CommonsUtil.setPostgreConfig(targetTableName,jcekFileSystem)
  lazy val timeInterval = applicationConf.getInt("timeInterval")

  val domainTypeDF = spark.createDataFrame(Seq(("Unpublished", "Domain Event Type"))).toDF("TYPE_CD", "PRNT_TYPE_CD")
  val domainTypeFinalDF = IDGenerationEngine.createKeyForDF(domainTypeDF, "DOMAIN_EVENT_FLAG", List("TYPE_CD", "PRNT_TYPE_CD"))
  val domainType = domainTypeFinalDF.select($"DOMAIN_EVENT_FLAG").collect().toList.head.getString(0)
  val domainTypeVal = spark.sparkContext.broadcast(domainType)


  //Implementation of the trait. using Schema to fetch dataframe from the message.
  @Override
  def applySchema(dataset: Dataset[(String,String)]): DataFrame = {
    logger.info("ConveyorDisassociatedLoadService Start ::applySchema")
    //applying schema to json message
    //val rawMsgDF = dataset.select(col("value") as "JSON_DATA", from_json($"value", Schema.conveyorDisassociatedSchema) as "record")
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA", from_json(preprocessJson($"value"), Schema.conveyorDisassociatedSchema) as "record")
    //adding time stamp while reading
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(rawMsgDF, "DOMN_EVT_READ_TS")
    logger.debug("ConveyorDisassociatedLoadService End ::applySchema")
   
   SparkDataFrameHelper.getMessage(auditTimeStampDF)   
  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("ConveyorDisassociatedLoadService Start ::transformAndsinkStream")

    val conveyorDisassociatedFinalDF = SparkDataFrameHelper.applyTransformation(inputDF)

    conveyorDisassociatedFinalDF.writeStream.option("checkpointLocation", conveyorDisassociatedLoadCheckpointDir).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDisassociatedLoadForEachWriter(dbConfigParam, ErrorNotificationTopic, "ConveyorDisassociatedLoad", sourceTopicName,targetUpsertTableName,domainTypeVal.value)).start()

  }

}