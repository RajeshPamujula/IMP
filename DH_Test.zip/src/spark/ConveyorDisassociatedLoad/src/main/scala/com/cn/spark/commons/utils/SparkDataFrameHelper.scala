package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.functions.date_format
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.functions.when
import com.cn.spark.idFactory.IDGenerationEngine
import org.apache.spark.sql.functions.to_timestamp
import org.apache.spark.sql.functions.explode
import org.apache.spark.sql.types.BinaryType

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def getMessage(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::getMessage::Start")

    val selectedDF = inputDF
      .select(
        col("record.DomainEventHeader.SOR_INGT_CRT_TS").alias("SOR_INGT_CRT_TS"),
        col("record.DomainEventHeader.SOR_READ_TS").alias("SOR_READ_TS"),
        col("record.DomainEventHeader.DE_CRT_TS").alias("DOMN_EVT_CRT_TS"),
        col("record.DomainEventHeader.SOR_TPIC_NM").alias("SOR_TPIC_NM"),
        col("record.DomainEventHeader.DE_META").alias("DOMN_EVT_META"),        
        col("record.ConveyorDisassociated.Domain_Event_Key").alias("DOMN_EVT_KEY"),
        col("record.ConveyorDisassociated.Domain_Event_Type_Key").alias("DOMN_EVT_TYPE_KEY"),
        col("record.ConveyorDisassociated.Conveyor_Key").alias("CNVY_KEY"),
        col("record.ConveyorDisassociated.Conveyor_Type_Key").alias("CNVY_TYPE_KEY"),
        col("record.ConveyorDisassociated.Association_Key").alias("ASCT_KEY"),
        col("record.ConveyorDisassociated.Association_Type_Key").alias("ASCT_TYPE_KEY"),
        col("record.ConveyorDisassociated.Associated_Object_Key").alias("ASCT_OBJ_KEY"),
        col("record.ConveyorDisassociated.Associated_Object_Type_Key").alias("ASCT_OBJ_TYPE_KEY"),
        col("record.ConveyorDisassociated.Correlation_Id").alias("SOR_CRLT_ID"),
        col("record.ConveyorDisassociated.System_Key").alias("SYS_KEY"),
        col("record.ConveyorDisassociated.Client_Identification").alias("CLNT_ID"),
        col("record.ConveyorDisassociated.Proc_Ts").alias("SOR_PROC_TS"),
        col("record.ConveyorDisassociated.Primary_Object_Key").alias("PRIM_OBJ_KEY"),
        col("record.ConveyorDisassociated.Event_Ts").alias("SOR_EVT_TS"),
        col("record.ConveyorDisassociated.Event_Ts_Tz_Dst_Cd").alias("SOR_EVT_TS_TZ_DST_CD"),
        col("record.ConveyorDisassociated.Proc_Ts_Tz_Dst_Cd").alias("SOR_PROC_TS_TZ_DST_CD"),
        col("DOMN_EVT_READ_TS").alias("DOMN_EVT_READ_TS"),
        col("JSON_DATA").alias("JSON_DATA"))

    logger.debug("SparkDataFrameHelper::getMessage::End")

    selectedDF
  }

  def applyTransformation(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransformation::Start")
    val transformDF = inputDF
      .withColumn("SOR_INGT_CRT_TS", to_timestamp(col("SOR_INGT_CRT_TS")))
      .withColumn("SOR_READ_TS", to_timestamp(col("SOR_READ_TS")))
      .withColumn("DOMN_EVT_CRT_TS", to_timestamp(col("DOMN_EVT_CRT_TS")))
      .withColumn("SOR_PROC_TS", to_timestamp(col("SOR_PROC_TS")))
      .withColumn("SOR_EVT_TS", to_timestamp(col("SOR_EVT_TS")))
    logger.debug("SparkDataFrameHelper::applyTransformation::End")
    transformDF
  }

}