package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, from_json, lit, concat}
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.references.Schema
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.idFactory.IDGenerationEngine
import com.cn.spark.idFactory.ReferenceDataGenerationEngine
import com.cn.spark.notificationFactory.ErrorNotificationEngine
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonFeed
import org.apache.spark.sql.functions.trim

class ETAETDDomainService(sourceTopic:String,errTopic:String) extends CommonFeed(sourceTopic:String) {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)

  //Broadcast any thing thats required
  val referenceDataDF= CommonsUtil.readReferenceDataFile(spark)
  
  val refKeyValueDF = referenceDataDF.withColumn("KEY_CD",concat(col("prnt_type_cd"),lit("|"),col("type_cd"))).drop(col("type_cd")).drop(col("prnt_type_cd"))
  val referenceData = refKeyValueDF.select($"KEY_CD", $"TYPE_KEY").as[(String, String)].collect.toMap
  val refMapData = spark.sparkContext.broadcast(referenceData) 
  
  @transient lazy val timeInterval = applicationConf.getInt("timeInterval")
  @transient lazy val errorNotificationCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("errorNotificationCheckpointDir")
  
  @transient lazy val etaEtdArrivalCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("etaEtdArrivalCheckpointDir")
  @transient lazy val etaEtdTopcArrivalCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("etaEtdTopcArrivalCheckpointDir")
  @transient lazy val etaEtdDepartureCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("etaEtdDepartureCheckpointDir")
  @transient lazy val etaEtdTopcDepartureCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("etaEtdTopcDepartureCheckpointDir")
  //Implementation of the trait. using Schema to fetch dataframe from the message.

  @Override
  def applySchema(dataset: Dataset[(String,String)]): DataFrame = {
    logger.info("ETAETDDomainService Start ::applySchema")
    //applying schema to json message
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA", from_json($"value", Schema.etaEtdSchema) as "record",col("topic"))
    //adding time stamp while reading
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(rawMsgDF, "SOR_READ_TS")
    logger.debug("ETAETDDomainService End ::applySchema")
    

    val filterDF = SparkDataFrameHelper.filterOutMessages(auditTimeStampDF)
    CommonsUtil.addDeMetaColumn(filterDF, "DE_META")

  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("ETAETDDomainService Start ::transformAndsinkStream")

    /*   
   Check if required fields are null post the filter then redirect to error kafka and remove from the filtered DF. Header to  be updated with Source Kafka queue name
   only 5 fields TRN_SYM, TRN_TYPE, TRN_SECT, TRN_SCH_DPT_DT, USER_ID
   */    
    
    val commonDF = SparkDataFrameHelper.applyCommonTransformation(inputDF, refMapData.value)
    val ETAETDCommonDF = SparkDataFrameHelper.getETAETDCommonTransformation(commonDF)
    //ETAETDCommonDF.printSchema()
    
    val mainDF = ErrorNotificationEngine.addErrorColumnForDF(ETAETDCommonDF, List("EST_ARR_DT", "EST_ARR_TM", "TIME_ZONE", "TOPC_EST_ARR_DT","TOPC_EST_ARR_TM","TMS_HDR_TMS","Correlation_Id","EST_DPT_DT","EST_DPT_TM","TOPC_EST_DEP_DT","TOPC_EST_DEP_TM","TRN_TYPE","TRN_SYM","TRN_SECT","TRN_SCH_DPT_DT","STN_SEQ_TS"))

    //Filter Error message
    val errorDF = ErrorNotificationEngine.filterErrorMessage(mainDF)    

    //Filter correct message
    val tempDF1 = ErrorNotificationEngine.dropColumn(mainDF,"JSON_DATA")
    val tempDF2 = ErrorNotificationEngine.filterCorrectMessage(tempDF1)    
    val correctDF = ErrorNotificationEngine.dropColumn(tempDF2,"ERROR_KEY")
    
//    val etaEtdArrivalDF = SparkDataFrameHelper.applyETAETDTransformationForArrival(correctDF, refMapData.value)
//    val etaEtdDepartureDF = SparkDataFrameHelper.applyETAETDTransformationForDeparture(correctDF, refMapData.value)
    val etaEtdTOPCArrivalDF = SparkDataFrameHelper.applyETAETDTransformationForTOPCArrival(correctDF, refMapData.value)
    val etaEtdTOPCDepartureDF = SparkDataFrameHelper.applyETAETDTransformationForTOPCDeparture(correctDF, refMapData.value)
    
    
    //send error messages to kafka Que
    errorDF.writeStream.option("checkpointLocation", errorNotificationCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ErrorNotificationForEachWriter(errTopic, "ETAETDDomainFeed", sourceTopic)).start()
//    etaEtdArrivalDF.writeStream.option("checkpointLocation", etaEtdArrivalCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ETAETDArrivalForEachWriter(bootstrapServers, securityProtocol)).start()
//    etaEtdDepartureDF.writeStream.option("checkpointLocation", etaEtdDepartureCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ETAETDDepartureForEachWriter(bootstrapServers, securityProtocol)).start()
    etaEtdTOPCArrivalDF.writeStream.option("checkpointLocation", etaEtdTopcArrivalCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ETAETDTOPCArrivalForEachWriter).start()
    etaEtdTOPCDepartureDF.writeStream.option("checkpointLocation", etaEtdTopcDepartureCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ETAETDTOPCDepartureForEachWriter).start()
   
  }

}