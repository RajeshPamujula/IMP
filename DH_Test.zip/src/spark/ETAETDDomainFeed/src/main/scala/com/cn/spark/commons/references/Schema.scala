package com.cn.spark.commons.references



import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types._

object Schema {
   
val etaEtdSchema = StructType(Seq(
    StructField("IngestionHeader", StructType(Seq(
      StructField("ING_CRT_TS", StringType, false),
      StructField("UUID", StringType, false))), false),
    StructField("ETAETD", StructType(Seq(
      StructField("HEADER", StructType(Seq(
        StructField("TMS_ACTION_CODE", StringType, false),
        StructField("TMS_HDR_TMS", StringType, false))), false),
      StructField("TRN_ID", StructType(Seq(
        StructField("BASE_IND", StringType, false),
		StructField("TRN_TYPE", StringType, false),
		StructField("TRN_SECT", StringType, false),
		StructField("TRN_SYM", StringType, false),
		StructField("TRN_SCH_DPT_DT", StringType, false))), false),
      StructField("STN_SEC", ArrayType(StructType(Seq(
          StructField("STN_SEQ_TS", StringType, false),
          StructField("EST_ARR_DT", StringType, false),
          StructField("EST_ARR_DST_FLAG", StringType, false),
          StructField("STN_TIME_ZONE", StringType, false),
          StructField("EST_ARR_TM", StringType, false),
          StructField("TOPC_EST_ARR_DT", StringType, false),
          StructField("TOPC_EST_ARR_TM", StringType, false),
          StructField("TOPC_EST_ARR_DST_FLAG", StringType, false),
          StructField("EST_DPT_DT", StringType, false),
          StructField("EST_DPT_TM", StringType, false),
          StructField("EST_DPT_DST_FLAG", StringType, false),
          StructField("TOPC_EST_DEP_DT", StringType, false),
          StructField("TOPC_EST_DEP_TM", StringType, false),
          StructField("TOPC_EST_DEP_DST_FLAG", StringType, false))))))))))



  val referenceDataSchema = StructType(Seq(
    StructField("type_cd", StringType, false),
    StructField("prnt_type_cd", StringType, false)))
}