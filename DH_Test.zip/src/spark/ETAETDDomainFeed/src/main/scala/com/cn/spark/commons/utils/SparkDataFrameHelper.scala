package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.functions.date_format
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.functions.rtrim
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.regexp_replace
import org.apache.spark.sql.functions.to_utc_timestamp
import org.apache.spark.sql.functions.explode
import org.apache.spark.sql.functions.expr
import com.cn.spark.idFactory.IDGenerationEngine
import org.apache.spark.sql.functions.concat
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine
import com.cn.spark.commonsEngine.Constants

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def filterOutMessages(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::filterOutMessages::Start")

    //inputDF.printSchema()

    val selectedDF = inputDF
      .filter(trim(col("record.ETAETD.TRN_ID.BASE_IND")) === "A" && (trim(col("record.ETAETD.HEADER.TMS_ACTION_CODE")) === "R" || trim(col("record.ETAETD.HEADER.TMS_ACTION_CODE")) === "Y" || trim(col("record.ETAETD.HEADER.TMS_ACTION_CODE")) === "Z" || trim(col("record.ETAETD.HEADER.TMS_ACTION_CODE")) === "S" || trim(col("record.ETAETD.HEADER.TMS_ACTION_CODE")) === "T"))
      .select(
        col("record.IngestionHeader.ING_CRT_TS").alias("SOR_INGT_CRT_TS"),
        col("record.IngestionHeader.UUID").alias("Correlation_Id"),
        col("record.ETAETD.HEADER.TMS_HDR_TMS").alias("TMS_HDR_TMS"),
        col("SOR_READ_TS").alias("SOR_READ_TS"),
        col("record").alias("record"),
        col("topic").alias("SOR_TPIC_NM"),        
        col("JSON_DATA").alias("JSON_DATA"))
    logger.debug("SparkDataFrameHelper::filterOutMessages::End")

    //selectedDF.printSchema()

    selectedDF
  }

  def applyCommonTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {

    val domainEventTypeKey = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Changed")

    val systemKey = CommonsUtil.getRefData(referenceData, "System", "SRS-YIT") 

    val transformDF1 = inputDF
      .withColumn("Domain_Event_Type_Key", lit(domainEventTypeKey))
      .withColumn("System_Key", lit(systemKey))
      .withColumn("Client_Identification", lit("SRS-YIT"))
      .withColumn("Proc_Ts", regexp_replace(col("TMS_HDR_TMS"), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2}).(\\d{6})", "$1-$2-$3 $4:$5:$6.$7"))
      .withColumn("Event_Ts", regexp_replace(col("TMS_HDR_TMS"), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2}).(\\d{6})", "$1-$2-$3 $4:$5:$6.$7"))
      .withColumn("Proc_Ts_Tz_Dst_Cd", lit(Constants.DST_CD_UTC_DST_NO))
      .withColumn("Event_Ts_Tz_Dst_Cd", lit(Constants.DST_CD_UTC_DST_NO))

    transformDF1

  }

  def getETAETDCommonTransformation(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::getETAETDCommonTransformation::Start")
    val selectedDF = inputDF.select(
      col("*"),
      explode(col("record.ETAETD.STN_SEC")))
      .select(
        col("SOR_INGT_CRT_TS"),
        col("SOR_READ_TS"),
        col("Correlation_Id"),
        col("TMS_HDR_TMS"),
        col("SOR_TPIC_NM"),
        col("DE_META"),
        col("JSON_DATA"),
        col("Domain_Event_Type_Key"),
        col("System_Key"),
        col("Client_Identification"),
        col("Proc_Ts"),
        col("Proc_Ts_Tz_Dst_Cd"),
        col("Event_Ts").alias("Event_Ts"),
        col("Event_Ts_Tz_Dst_Cd"),
        col("record.ETAETD.TRN_ID.TRN_TYPE").alias("TRN_TYPE"),
        col("record.ETAETD.HEADER.TMS_ACTION_CODE").alias("TMS_ACTION_CODE"),
        col("record.ETAETD.TRN_ID.BASE_IND").alias("BASE_IND"),
        col("record.ETAETD.TRN_ID.TRN_SECT").alias("TRN_SECT"),
        col("record.ETAETD.TRN_ID.TRN_SYM").alias("TRN_SYM"),
        col("record.ETAETD.TRN_ID.TRN_SCH_DPT_DT").alias("TRN_SCH_DPT_DT"),
        col("col.STN_SEQ_TS").alias("STN_SEQ_TS"),
        col("col.EST_ARR_DT").alias("EST_ARR_DT"),
        trim(col("col.STN_TIME_ZONE")).alias("TIME_ZONE"),
        col("col.EST_ARR_TM").alias("EST_ARR_TM"),
        col("col.TOPC_EST_ARR_DT").alias("TOPC_EST_ARR_DT"),
        col("col.TOPC_EST_ARR_TM").alias("TOPC_EST_ARR_TM"),
        col("col.EST_DPT_DT").alias("EST_DPT_DT"),
        col("col.EST_DPT_TM").alias("EST_DPT_TM"),
        col("col.TOPC_EST_DEP_DT").alias("TOPC_EST_DEP_DT"),
        col("col.TOPC_EST_DEP_TM").alias("TOPC_EST_DEP_TM"))
      .drop("record")   
    selectedDF
  }

  def applyETAETDTransformationForArrival(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyETAETDTransformationForArrival::Start")

    val input = inputDF.filter(col("EST_ARR_DT") =!= "0001-01-01" && col("EST_ARR_DT").isNotNull)     
    val dfWithTimezone = CommonsUtil.getTimeZoneNameByCode(input, "tz")
    val characteristicTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Estimated Arrival UTC")
    val inputDF2 = dfWithTimezone
      .withColumn("temp1", lit("Arrival"))
      .withColumn("TRN_SCH_DPT_DT_formatted", when(col("TRN_SCH_DPT_DT").isNull, "").otherwise(date_format(col("TRN_SCH_DPT_DT"), "yyyyMMdd")))
    val imDF1 = IDGenerationEngine.createKeyForDF(inputDF2, "Planned_Event_Key", List("temp1", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS"))

    val transformDF1 = imDF1
      .withColumn("charTypeKeyOne", lit(characteristicTypeKey1))

    val tDF2 = IDGenerationEngine.createKeyForDF(transformDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))

    val tDF3 = IDGenerationEngine.createKeyForDF(tDF2, "Planned_Event_Characteristic_Key_one", List("Planned_Event_Key", "charTypeKeyOne"))

    val tDF4 = tDF3
      .withColumn("charValueOne_Ts_localTime", concat(col("EST_ARR_DT"), lit(" "), regexp_replace(col("EST_ARR_TM"), "(\\d{2}).(\\d{2}).(\\d{2})", "$1:$2:$3")))

      .withColumn("charValueOne", expr("to_utc_timestamp(charValueOne_Ts_localTime, tz)"))

    val tDF5 = IDGenerationEngine.createKeyForDF(tDF4, "Primary_Object_Key", List("TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted"))

    logger.debug("SparkDataFrameHelper::applyETAETDTransformationForArrival::End")

    tDF5

  }

  def applyETAETDTransformationForDeparture(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyETAETDTransformationForDeparture::Start")

    val input = inputDF.filter(col("EST_DPT_DT") =!= "0001-01-01" && col("EST_DPT_DT").isNotNull)
    // val inputFilter = input.filter((col("TOPC_EST_DEP_DT") === "0001-01-01") || (col("TOPC_EST_DEP_DT") === null))
    val dfWithTimezone = CommonsUtil.getTimeZoneNameByCode(input, "tz")
    val characteristicTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Estimated Departure UTC")

    val inputDF2 = dfWithTimezone
      .withColumn("temp1", lit("Departure"))
      .withColumn("TRN_SCH_DPT_DT_formatted", when(col("TRN_SCH_DPT_DT").isNull, "").otherwise(date_format(col("TRN_SCH_DPT_DT"), "yyyyMMdd")))

    val imDF1 = IDGenerationEngine.createKeyForDF(inputDF2, "Planned_Event_Key", List("temp1", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS"))

    val transformDF1 = imDF1

      .withColumn("charTypeKeyOne", lit(characteristicTypeKey1))

    val tDF2 = IDGenerationEngine.createKeyForDF(transformDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))

    val tDF3 = IDGenerationEngine.createKeyForDF(tDF2, "Planned_Event_Characteristic_Key_one", List("Planned_Event_Key", "charTypeKeyOne"))

    val tDF4 = tDF3.withColumn("charValueOne_Ts_localTime", concat(col("EST_DPT_DT"), lit(" "), regexp_replace(col("EST_DPT_TM"), "(\\d{2}).(\\d{2}).(\\d{2})", "$1:$2:$3")))

      .withColumn("charValueOne", expr("to_utc_timestamp(charValueOne_Ts_localTime, tz)"))

    val tDF5 = IDGenerationEngine.createKeyForDF(tDF4, "Primary_Object_Key", List("TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted"))

    logger.debug("SparkDataFrameHelper::applyETAETDTransformationForDeparture::End")

    tDF5

  }

  def applyETAETDTransformationForTOPCArrival(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyETAETDTransformationForTOPCArrival::Start")

    val input = inputDF.filter(col("EST_ARR_DT") =!= "0001-01-01" && col("EST_ARR_DT").isNotNull)
    val dfWithTimezone = CommonsUtil.getTimeZoneNameByCode(input, "tz")   

    val characteristicTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Estimated Arrival UTC")

    val characteristicTypeKey2 = CommonsUtil.getRefData(referenceData, "Characteristic", "TOPC Estimated Arrival UTC")

    val inputDF2 = dfWithTimezone
      .withColumn("temp1", lit("Arrival"))
      .withColumn("TRN_SCH_DPT_DT_formatted", when(col("TRN_SCH_DPT_DT").isNull, "").otherwise(date_format(col("TRN_SCH_DPT_DT"), "yyyyMMdd")))

    val imDF1 = IDGenerationEngine.createKeyForDF(inputDF2, "Planned_Event_Key", List("temp1", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS"))

    val transformDF1 = imDF1
      .withColumn("charTypeKeyOne", lit(characteristicTypeKey1))
      .withColumn("charTypeKeyTwo", lit(characteristicTypeKey2))

    val tDF2 = IDGenerationEngine.createKeyForDF(transformDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))

    val tDF3 = IDGenerationEngine.createKeyForDF(tDF2, "Planned_Event_Characteristic_Key_one", List("Planned_Event_Key", "charTypeKeyOne"))

    val tDF4 = tDF3
      .withColumn("charValueOne_Ts_localTime", concat(col("EST_ARR_DT"), lit(" "), regexp_replace(col("EST_ARR_TM"), "(\\d{2}).(\\d{2}).(\\d{2})", "$1:$2:$3")))

      .withColumn("charValueOne", expr("to_utc_timestamp(charValueOne_Ts_localTime, tz)"))
      .withColumn("charValueTwo_Ts_localTime", concat(col("TOPC_EST_ARR_DT"), lit(" "), regexp_replace(col("TOPC_EST_ARR_TM"), "(\\d{2}).(\\d{2}).(\\d{2})", "$1:$2:$3")))
      .withColumn("charValueTwo", expr("to_utc_timestamp(charValueTwo_Ts_localTime, tz)"))

    val tDF5 = IDGenerationEngine.createKeyForDF(tDF4, "Planned_Event_Characteristic_Key_two", List("Planned_Event_Key", "charTypeKeyTwo"))

    val tDF6 = IDGenerationEngine.createKeyForDF(tDF5, "Primary_Object_Key", List("TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted"))

    logger.debug("SparkDataFrameHelper::applyETAETDTransformationForTOPCArrival::End")

    tDF6

  }

  def applyETAETDTransformationForTOPCDeparture(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyETAETDTransformationForTOPCDeparture::Start")

    val input = inputDF.filter(col("EST_DPT_DT") =!= "0001-01-01" && col("EST_DPT_DT").isNotNull)
    // val inputFilter = input.filter((col("TOPC_EST_DEP_DT") =!= "0001-01-01") || (col("TOPC_EST_DEP_DT") =!= null))

    val dfWithTimezone = CommonsUtil.getTimeZoneNameByCode(input, "tz")

    val characteristicTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Estimated Departure UTC")

    val characteristicTypeKey2 = CommonsUtil.getRefData(referenceData, "Characteristic", "TOPC Estimated Departure UTC")

    val inputDF2 = dfWithTimezone
      .withColumn("temp1", lit("Departure"))
      .withColumn("TRN_SCH_DPT_DT_formatted", when(col("TRN_SCH_DPT_DT").isNull, "").otherwise(date_format(col("TRN_SCH_DPT_DT"), "yyyyMMdd")))

    val imDF1 = IDGenerationEngine.createKeyForDF(inputDF2, "Planned_Event_Key", List("temp1", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS"))

    val transformDF1 = imDF1
      .withColumn("charTypeKeyOne", lit(characteristicTypeKey1))
      .withColumn("charTypeKeyTwo", lit(characteristicTypeKey2))

    val tDF2 = IDGenerationEngine.createKeyForDF(transformDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))

    val tDF3 = IDGenerationEngine.createKeyForDF(tDF2, "Planned_Event_Characteristic_Key_one", List("Planned_Event_Key", "charTypeKeyOne"))

    val tDF4 = tDF3
      .withColumn("charValueOne_Ts_localTime", concat(col("EST_DPT_DT"), lit(" "), regexp_replace(col("EST_DPT_TM"), "(\\d{2}).(\\d{2}).(\\d{2})", "$1:$2:$3")))

      .withColumn("charValueOne", expr("to_utc_timestamp(charValueOne_Ts_localTime, tz)"))
      .withColumn("charValueTwo_Ts_localTime", concat(col("TOPC_EST_DEP_DT"), lit(" "), regexp_replace(col("TOPC_EST_DEP_TM"), "(\\d{2}).(\\d{2}).(\\d{2})", "$1:$2:$3")))
      .withColumn("charValueTwo", expr("to_utc_timestamp(charValueTwo_Ts_localTime, tz)"))

    val tDF5 = IDGenerationEngine.createKeyForDF(tDF4, "Planned_Event_Characteristic_Key_two", List("Planned_Event_Key", "charTypeKeyTwo"))

    val tDF6 = IDGenerationEngine.createKeyForDF(tDF5, "Primary_Object_Key", List("TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted"))

    logger.debug("SparkDataFrameHelper::applyETAETDTransformationForTOPCDeparture::End")

    tDF6

  }

}