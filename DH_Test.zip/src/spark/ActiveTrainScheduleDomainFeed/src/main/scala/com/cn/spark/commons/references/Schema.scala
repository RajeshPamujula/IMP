package com.cn.spark.commons.references

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import scala.collection.Seq

object Schema {

  val atsDemoSchema = StructType(Seq(
    StructField("IngestionHeader", StructType(Seq(
      StructField("ING_CRT_TS", StringType, false),
      StructField("UUID", StringType, false))), false),
    StructField("ActiveTrainSchedule", StructType(Seq(
      StructField("header", StructType(Seq(
        StructField("TMS_ACTION_CODE", StringType, false),
        StructField("TMS_HDR_TMS", StringType, false),
        StructField("TMS_HDR_TRN_R", StructType(Seq(
          StructField("TMS_HDR_TRN_TYPE", StringType, false),
          StructField("TMS_HDR_TRN_SYM", StringType, false),
          StructField("TMS_HDR_TRN_SECT", StringType, false),
          StructField("TMS_HDR_TRN_DAY", StringType, false))), false))), false),
      StructField("trainId", StructType(Seq(
        StructField("TRN_SCH_DPT_DT", StringType, false))), false),
      StructField("trainSummary", StructType(Seq(
        StructField("USER_ID", StringType, false),
        StructField("EFF_DT", StringType, false),
        StructField("EXP_DT", StringType, false),
        StructField("TRN_SVC_TYP", StringType, false),
        StructField("TRN_SCH_CD", StringType, false),
        StructField("MAX_MPH", StringType, false),
        StructField("TRN_RPTG_GRP", StringType, false),
        StructField("OPER_STAT_CD", StringType, false))), false),
      StructField("station", ArrayType(StructType(Seq(
        StructField("trainSchedule", StructType(Seq(
          StructField("STN_STN_CARR_ABRV", StringType, false),
          StructField("STN_STN_FSAC", StringType, false),
          StructField("STN_SEQ_TS", StringType, false),
          StructField("STN_TYPE_CD", StringType, false),
          StructField("EST_DPT_DT", StringType, false),
          StructField("EST_DPT_TM", StringType, false),
          StructField("EST_DPT_DS_FLG", StringType, false),
          StructField("TOPC_EST_DEP_DT", StringType, false),
          StructField("TOPC_EST_DEP_TM", StringType, false),
          StructField("TOPC_EST_DEP_DS_FLG", StringType, false),
          StructField("EST_ARR_DS_FLG", StringType, false),
          StructField("TOPC_EST_ARR_DT", StringType, false),
          StructField("TOPC_EST_ARR_TM", StringType, false),
          StructField("TOPC_EST_ARR_DS_FLG", StringType, false),
          StructField("EST_ARR_DT", StringType, false),
          StructField("EST_ARR_TM", StringType, false),
          StructField("STN_TIME_ZN_IND", StringType, false),
          StructField("STN_SEQ_NBR", StringType, false),
          StructField("CREW_CHG", StringType, false),
          StructField("REWHL_PT", StringType, false),
          StructField("REFUEL_PT", StringType, false),
          StructField("REQ_INSP", StringType, false),          
          StructField("TJS_INCL", StringType, false))), false)))), false))), false)))

  val referenceDataSchema = StructType(Seq(
    StructField("type_cd", StringType, false),
    StructField("prnt_type_cd", StringType, false)))
}