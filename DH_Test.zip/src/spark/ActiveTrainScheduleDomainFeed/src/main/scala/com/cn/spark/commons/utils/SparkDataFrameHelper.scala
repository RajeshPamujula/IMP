package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.functions.date_format
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.functions.rtrim
import org.apache.spark.sql.functions.array
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.regexp_replace
import org.apache.spark.sql.functions.to_utc_timestamp
import org.apache.spark.sql.functions.explode
import org.apache.spark.sql.functions.expr
import com.cn.spark.idFactory.IDGenerationEngine
import org.apache.spark.sql.functions.concat
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.Constants

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def filterOutMessages(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::filterOutMessages::Start")

    val selectedDF = inputDF
      //.filter(trim(col("record.ActiveTrainSchedule.header.TMS_ACTION_CODE")) =!= "I" && trim(col("record.ActiveTrainSchedule.header.TMS_ACTION_CODE")) =!= "S")  
      .filter(trim(col("record.ActiveTrainSchedule.header.TMS_ACTION_CODE")) === "A" || trim(col("record.ActiveTrainSchedule.header.TMS_ACTION_CODE")) === "D" || trim(col("record.ActiveTrainSchedule.header.TMS_ACTION_CODE")) === "C" || trim(col("record.ActiveTrainSchedule.header.TMS_ACTION_CODE")) === "R")
	    .select(
        col("record.IngestionHeader.ING_CRT_TS").alias("SOR_INGT_CRT_TS"),
        col("record.IngestionHeader.UUID").alias("Correlation_Id"),
        trim(col("record.ActiveTrainSchedule.header.TMS_ACTION_CODE")).alias("TMS_ACTION_CODE"),
        col("record.ActiveTrainSchedule.header.TMS_HDR_TRN_R.TMS_HDR_TRN_TYPE").alias("TRN_TYPE"),
        col("record.ActiveTrainSchedule.header.TMS_HDR_TRN_R.TMS_HDR_TRN_SECT").alias("TRN_SECT"),
        col("record.ActiveTrainSchedule.header.TMS_HDR_TRN_R.TMS_HDR_TRN_SYM").alias("TRN_SYM"),
        col("record.ActiveTrainSchedule.header.TMS_HDR_TRN_R.TMS_HDR_TRN_DAY").alias("TRN_DAY"),
        col("record.ActiveTrainSchedule.trainId.TRN_SCH_DPT_DT").alias("TRN_SCH_DPT_DT"),
        trim(col("record.ActiveTrainSchedule.trainSummary.USER_ID")).alias("USER_ID"),
        col("record.ActiveTrainSchedule.trainSummary.EFF_DT").alias("EFF_DT"),
        col("record.ActiveTrainSchedule.trainSummary.EXP_DT").alias("EXP_DT"),
        col("record.ActiveTrainSchedule.trainSummary.TRN_SVC_TYP").alias("TRN_SVC_TYP"),
        col("record.ActiveTrainSchedule.trainSummary.TRN_SCH_CD").alias("TRN_SCH_CD"),
        col("record.ActiveTrainSchedule.trainSummary.MAX_MPH").alias("MAX_MPH"),
        col("record.ActiveTrainSchedule.trainSummary.TRN_RPTG_GRP").alias("TRN_RPTG_GRP"),
        col("record.ActiveTrainSchedule.trainSummary.OPER_STAT_CD").alias("OPER_STAT_CD"),
        col("SOR_READ_TS").alias("SOR_READ_TS"),
        col("record.ActiveTrainSchedule.header.TMS_HDR_TMS").alias("TMS_HDR_TMS"),
        col("record.ActiveTrainSchedule.station.trainSchedule.STN_STN_CARR_ABRV").alias("STN_STN_CARR_ABRV"),
        col("record.ActiveTrainSchedule.station.trainSchedule.STN_STN_FSAC").alias("STN_STN_FSAC"),
        col("record.ActiveTrainSchedule.station.trainSchedule.STN_SEQ_TS").alias("STN_SEQ_TS"),
        col("record.ActiveTrainSchedule.station.trainSchedule.STN_TYPE_CD").alias("STN_TYPE_CD"),
        col("record.ActiveTrainSchedule.station.trainSchedule.EST_DPT_DT").alias("EST_DPT_DT"),
        col("record.ActiveTrainSchedule.station.trainSchedule.EST_DPT_TM").alias("EST_DPT_TM"),
        col("record.ActiveTrainSchedule.station.trainSchedule.EST_DPT_DS_FLG").alias("EST_DPT_DS_FLG"),
        col("record.ActiveTrainSchedule.station.trainSchedule.TOPC_EST_DEP_DT").alias("TOPC_EST_DEP_DT"),
        col("record.ActiveTrainSchedule.station.trainSchedule.TOPC_EST_DEP_TM").alias("TOPC_EST_DEP_TM"),
        col("record.ActiveTrainSchedule.station.trainSchedule.TOPC_EST_DEP_DS_FLG").alias("TOPC_EST_DEP_DS_FLG"),
        col("record.ActiveTrainSchedule.station.trainSchedule.EST_ARR_DT").alias("EST_ARR_DT"),
        col("record.ActiveTrainSchedule.station.trainSchedule.EST_ARR_TM").alias("EST_ARR_TM"),
        col("record.ActiveTrainSchedule.station.trainSchedule.EST_ARR_DS_FLG").alias("EST_ARR_DS_FLG"),
        col("record.ActiveTrainSchedule.station.trainSchedule.TOPC_EST_ARR_DT").alias("TOPC_EST_ARR_DT"),
        col("record.ActiveTrainSchedule.station.trainSchedule.TOPC_EST_ARR_TM").alias("TOPC_EST_ARR_TM"),
        col("record.ActiveTrainSchedule.station.trainSchedule.TOPC_EST_ARR_DS_FLG").alias("TOPC_EST_ARR_DS_FLG"),
        col("record.ActiveTrainSchedule.station.trainSchedule.STN_TIME_ZN_IND").alias("STN_TIME_ZN_IND"),
        col("record.ActiveTrainSchedule.station.trainSchedule.STN_SEQ_NBR").alias("STN_SEQ_NBR"),
        col("record.ActiveTrainSchedule.station.trainSchedule.CREW_CHG").alias("CREW_CHG"),
        col("record.ActiveTrainSchedule.station.trainSchedule.REWHL_PT").alias("REWHL_PT"),
        col("record.ActiveTrainSchedule.station.trainSchedule.REFUEL_PT").alias("REFUEL_PT"),
        col("record.ActiveTrainSchedule.station.trainSchedule.REQ_INSP").alias("REQ_INSP"),
        col("record.ActiveTrainSchedule.station.trainSchedule.TJS_INCL").alias("TJS_INCL"),
        col("JSON_DATA").alias("JSON_DATA"),
        col("topic").alias("SOR_TPIC_NM"))

    logger.debug("SparkDataFrameHelper::filterOutMessages::End")
     
    selectedDF
  }

  def applyCommonTransformations(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransformation::Start")

    val systemKey = CommonsUtil.getRefData(referenceData, "System", "SRS-YIT")
    val transformDF = inputDF      
      .withColumn("TRN_SCH_DPT_DT_formatted", when(col("TRN_SCH_DPT_DT").isNull, "").otherwise(date_format(col("TRN_SCH_DPT_DT"), "yyyyMMdd")))
      .withColumn("Client_Identification", when((col("USER_ID").isNull || trim(col("USER_ID")) === ""), lit("SRS-YIT")).otherwise(col("USER_ID")))
      .withColumn("System_Key", lit(systemKey))
      .withColumn("Proc_Ts", regexp_replace(col("TMS_HDR_TMS"), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2}).(\\d{6})", "$1-$2-$3 $4:$5:$6.$7"))
      .withColumn("Event_Ts", regexp_replace(col("TMS_HDR_TMS"), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2}).(\\d{6})", "$1-$2-$3 $4:$5:$6.$7"))
      .withColumn("Proc_Ts_Tz_Dst_Cd", lit(Constants.DST_CD_UTC_DST_NO))
      .withColumn("Event_Ts_Tz_Dst_Cd", lit(Constants.DST_CD_UTC_DST_NO))

    val finalDF = IDGenerationEngine.createKeyForDF(transformDF, "Type_Sym_Sect_DptDt_key", List("TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted"))

    logger.debug("SparkDataFrameHelper::applyTransformation::End")
     
    finalDF
  }

  def applyConveyorCreatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorCreatedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val conveyorType = CommonsUtil.getRefData(referenceData, "Conveyor", "Train")
    val identificationTypeKey = CommonsUtil.getRefData(referenceData, "Identification Type", "Train Unique Id")
    val convCreatedDF = filteredDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Conveyor_Type_Key", lit(conveyorType))
      .withColumn("Conveyor_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Identification_Type_Key", lit(identificationTypeKey))
      .withColumn("Identification_Value", concat(col("TRN_TYPE"), col("TRN_SYM"), col("TRN_SECT"), col("TRN_SCH_DPT_DT_formatted")))
    val outputDF = IDGenerationEngine.createKeyForDF(convCreatedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyConveyorCreatedTransformation::End")
    outputDF
    
  }

  def applyConveyorDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val charTypeKey = CommonsUtil.getRefData(referenceData, "Characteristic", "Train Unique Id")
    val convDescribedDF = filteredDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Characteristic_Type_Key", lit(charTypeKey))
      .withColumn("Conveyor_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Characteristic_Value", concat(col("TRN_TYPE"), col("TRN_SYM"), col("TRN_SECT"), col("TRN_SCH_DPT_DT_formatted")))
    val convCharKeyDF = IDGenerationEngine.createKeyForDF(convDescribedDF, "Conveyor_Characteristic_key", List("Conveyor_Key", "Characteristic_Type_Key"))
    val convDescribedFinalDF = IDGenerationEngine.createKeyForDF(convCharKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedTransformation::End")
    convDescribedFinalDF
  }

  def applyConveyorDescribedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedUnpublishedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val convDescribedDF = filteredDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Conveyor_Key", col("Type_Sym_Sect_DptDt_key"))
    val convDescribedUnpublishedFinalDF = IDGenerationEngine.createKeyForDF(convDescribedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyConveyorDescribedUnpublishedTransformation::End")
    convDescribedUnpublishedFinalDF
  }
  
  def applyRoutePlannedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyRoutePlannedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val routeTypeKey = CommonsUtil.getRefData(referenceData, "Route", "Train Schedule")
    val identificationTypeKey = CommonsUtil.getRefData(referenceData, "Identification Type", "Train Schedule Id")
    val routePlannedDF = filteredDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Route_Type_Key", lit(routeTypeKey))
      .withColumn("Route_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Identification_Type_Key", lit(identificationTypeKey))
      .withColumn("Identification_Value", concat(col("TRN_TYPE"), col("TRN_SYM"), col("TRN_SECT"), col("TRN_SCH_DPT_DT_formatted")))
    val routePlannedFinalDF = IDGenerationEngine.createKeyForDF(routePlannedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Route_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyRoutePlannedTransformation::End")
    routePlannedFinalDF
  }

  def applyConveyorAssociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    val conveyorType = CommonsUtil.getRefData(referenceData, "Conveyor", "Train")
    val routeType = CommonsUtil.getRefData(referenceData, "Route", "Train Schedule")
    val associationType = CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Conveyor-Route")
    val convAssociatedDF = filteredDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Association_Type_Key", lit(associationType))
      .withColumn("Conveyor_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Conveyor_Type_Key", lit(conveyorType))
      .withColumn("Associated_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Associated_Object_Type_Key", lit(routeType))

    val convAssociatedKeyDF = IDGenerationEngine.createKeyForDF(convAssociatedDF, "Association_Key", List("Conveyor_Key", "Associated_Object_Key"))
    val convAssociatedFinalDF = IDGenerationEngine.createKeyForDF(convAssociatedKeyDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Association_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedTransformation::End")
    convAssociatedFinalDF
  }
  
   def applyConveyorAssociatedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedUnpublishedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val convAssociatedDF = filteredDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
    val convAssociatedUnpublishedFinalDF = IDGenerationEngine.createKeyForDF(convAssociatedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedUnpublishedTransformation::End")
    convAssociatedUnpublishedFinalDF
  }

  def applyConveyorRemovedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorRemovedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Removed")
    val conveyorType = CommonsUtil.getRefData(referenceData, "Conveyor", "Train")
    val identificationTypeKey = CommonsUtil.getRefData(referenceData, "Identification Type", "Train Unique Id")
    val convRemovedDF = filteredDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Conveyor_Type_Key", lit(conveyorType))
      .withColumn("Conveyor_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Identification_Type_Key", lit(identificationTypeKey))
      .withColumn("Identification_Value", concat(col("TRN_TYPE"), col("TRN_SYM"), col("TRN_SECT"), col("TRN_SCH_DPT_DT_formatted")))
    val convRemovedFinalDF = IDGenerationEngine.createKeyForDF(convRemovedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Conveyor_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyConveyorRemovedTransformation::End")
    convRemovedFinalDF

  }

  def applyRouteCancelledTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyRouteCancelledTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Removed")
    val routeTypeKey = CommonsUtil.getRefData(referenceData, "Route", "Train Schedule")
    val identificationTypeKey = CommonsUtil.getRefData(referenceData, "Identification Type", "Train Schedule Id")
    val routeCancelledDF = filteredDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Route_Type_Key", lit(routeTypeKey))
      .withColumn("Route_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Identification_Type_Key", lit(identificationTypeKey))
      .withColumn("Identification_Value", concat(col("TRN_TYPE"), col("TRN_SYM"), col("TRN_SECT"), col("TRN_SCH_DPT_DT_formatted")))
    val routeCancelledFinalDF = IDGenerationEngine.createKeyForDF(routeCancelledDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Route_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyRouteCancelledTransformation::End")
    routeCancelledFinalDF
  }

  def applyLocationAssociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyLocationAssociatedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val explodedDF = filteredDF.withColumn("vars", explode(CommonsUtil.array_zip_udf(array("STN_STN_CARR_ABRV", "STN_STN_FSAC", "STN_SEQ_TS")))).select(
      (col("*")), trim(col("vars")(0)).alias("STN_CARR_ABRV_EXP"), trim(col("vars")(1)).alias("STN_FSAC_EXP"), trim(col("vars")(2)).alias("STN_SEQ_TS_EXP"))
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    val associationType = CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Location-Route")
    val associationTypeKey = CommonsUtil.getRefData(referenceData, "Route", "Train Schedule")
    val locationTypeKey = CommonsUtil.getRefData(referenceData, "Location", "Station")
    val transformDF = explodedDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Association_Type_Key", lit(associationType))
      .withColumn("Associated_Object_Type_Key", lit(associationTypeKey))
      .withColumn("Location_Type_Key", lit(locationTypeKey))
      .withColumn("Associated_Object_Key", col("Type_Sym_Sect_DptDt_key"))

    val transformDF1 = IDGenerationEngine.createKeyForDF(transformDF, "Location_Key", List("STN_CARR_ABRV_EXP", "STN_FSAC_EXP"))
    val locationAssociatedDF = IDGenerationEngine.createKeyForDF(transformDF1, "Association_Key", List("Location_Key", "Associated_Object_Key", "STN_SEQ_TS_EXP")) //need to verify

    val locationAssociatedFinalDF = IDGenerationEngine.createKeyForDF(locationAssociatedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Location_Key", "Associated_Object_Key", "STN_SEQ_TS_EXP", "Client_Identification", "System_Key", "TMS_HDR_TMS"))

    logger.debug("SparkDataFrameHelper::applyLocationAssociatedTransformation::End")
    locationAssociatedFinalDF
  }
  
   def applyLocationAssociatedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyLocationAssociatedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D" || col("TMS_ACTION_CODE") === "R")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val transformDF = filteredDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))

    val locationAssociatedUnpublishedFinalDF = IDGenerationEngine.createKeyForDF(transformDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))

    logger.debug("SparkDataFrameHelper::applyLocationAssociatedUnpublishedTransformation::End")
    locationAssociatedUnpublishedFinalDF
  }

  def applyLocationAssociationDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyLocationAssociationDescribedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R" || col("TMS_ACTION_CODE") === "C")
    val explodedDF = filteredDF.withColumn("vars", explode(CommonsUtil.array_zip_udf(array("STN_STN_CARR_ABRV", "STN_STN_FSAC", "STN_SEQ_TS", "STN_TYPE_CD", "STN_SEQ_NBR", "CREW_CHG", "REWHL_PT", "REFUEL_PT", "REQ_INSP", "TJS_INCL")))).select(
      (col("*")), trim(col("vars")(0)).alias("STN_CARR_ABRV_EXP"), trim(col("vars")(1)).alias("STN_FSAC_EXP"), trim(col("vars")(2)).alias("STN_SEQ_TS_EXP"), col("vars")(3).alias("STN_TYPE_CD_EXP"), col("vars")(4).alias("STN_SEQ_NBR_EXP"),
      col("vars")(5).alias("CREW_CHG_EXP"), col("vars")(6).alias("REWHL_PT_EXP"), col("vars")(7).alias("REFUEL_PT_EXP"), col("vars")(8).alias("REQ_INSP_EXP"), col("vars")(9).alias("TJS_INCL_EXP"))

    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val CharacteristicType = CommonsUtil.getRefData(referenceData, "Characteristic", "Station Sequence Number")
    val CharacteristicType1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Station Type Code")
    val CharacteristicType2 = CommonsUtil.getRefData(referenceData, "Characteristic", "Station Sequence Timestamp")
    val CharacteristicType3 = CommonsUtil.getRefData(referenceData, "Characteristic", "Crew Change Indicator")
    val CharacteristicType4 = CommonsUtil.getRefData(referenceData, "Characteristic", "Re-Wheel Point")
    val CharacteristicType5 = CommonsUtil.getRefData(referenceData, "Characteristic", "Refuel Point")
    val CharacteristicType6 = CommonsUtil.getRefData(referenceData, "Characteristic", "Required Inspection Flag")
    val CharacteristicType7 = CommonsUtil.getRefData(referenceData, "Characteristic", "TJS Inclusive Flag")

    val transformDF = explodedDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Characteristic_Type_Key", lit(CharacteristicType))
      .withColumn("Characteristic_Type_Key1", lit(CharacteristicType1))
      .withColumn("Characteristic_Type_Key2", lit(CharacteristicType2))
      .withColumn("Characteristic_Type_Key3", lit(CharacteristicType3))
      .withColumn("Characteristic_Type_Key4", lit(CharacteristicType4))
      .withColumn("Characteristic_Type_Key5", lit(CharacteristicType5))
      .withColumn("Characteristic_Type_Key6", lit(CharacteristicType6))
      .withColumn("Characteristic_Type_Key7", lit(CharacteristicType7))
      .withColumn("Characteristic_Value", col("STN_SEQ_NBR_EXP"))
      .withColumn("Characteristic_Value1", col("STN_TYPE_CD_EXP"))
      .withColumn("Characteristic_Value2", col("STN_SEQ_TS_EXP"))
      .withColumn("Characteristic_Value3", col("CREW_CHG_EXP"))
      .withColumn("Characteristic_Value4", col("REWHL_PT_EXP"))
      .withColumn("Characteristic_Value5", col("REFUEL_PT_EXP"))
      .withColumn("Characteristic_Value6", col("REQ_INSP_EXP"))
      .withColumn("Characteristic_Value7", col("TJS_INCL_EXP"))
      .withColumn("Associated_Object_Key", col("Type_Sym_Sect_DptDt_key"))

    val transformDF1 = IDGenerationEngine.createKeyForDF(transformDF, "Location_Key", List("STN_CARR_ABRV_EXP", "STN_FSAC_EXP"))
    val transformDF2 = IDGenerationEngine.createKeyForDF(transformDF1, "Association_Key", List("Location_Key", "Associated_Object_Key", "STN_SEQ_TS_EXP"))
    val transformDF3 = IDGenerationEngine.createKeyForDF(transformDF2, "Association_Characteristic_Key", List("Association_Key", "Characteristic_Type_Key"))
    val transformDF4 = IDGenerationEngine.createKeyForDF(transformDF3, "Association_Characteristic_Key1", List("Association_Key", "Characteristic_Type_Key1"))
    val locationAssociationDescribedDF = IDGenerationEngine.createKeyForDF(transformDF4, "Association_Characteristic_Key2", List("Association_Key", "Characteristic_Type_Key2"))
    val locationAssociationDescribedDF1 = IDGenerationEngine.createKeyForDF(locationAssociationDescribedDF, "Association_Characteristic_Key3", List("Association_Key", "Characteristic_Type_Key3"))
    val locationAssociationDescribedDF2 = IDGenerationEngine.createKeyForDF(locationAssociationDescribedDF1, "Association_Characteristic_Key4", List("Association_Key", "Characteristic_Type_Key4"))
    val locationAssociationDescribedDF3 = IDGenerationEngine.createKeyForDF(locationAssociationDescribedDF2, "Association_Characteristic_Key5", List("Association_Key", "Characteristic_Type_Key5"))
    val locationAssociationDescribedDF4 = IDGenerationEngine.createKeyForDF(locationAssociationDescribedDF3, "Association_Characteristic_Key6", List("Association_Key", "Characteristic_Type_Key6"))
    val locationAssociationDescribedDF5 = IDGenerationEngine.createKeyForDF(locationAssociationDescribedDF4, "Association_Characteristic_Key7", List("Association_Key", "Characteristic_Type_Key7"))

    val locationAssociationDescribedFinalDF = IDGenerationEngine.createKeyForDF(locationAssociationDescribedDF5, "Domain_Event_Key", List("Domain_Event_Type_Key", "Association_Key", "STN_SEQ_TS_EXP", "Client_Identification", "System_Key", "TMS_HDR_TMS"))

    logger.debug("SparkDataFrameHelper::applyLocationAssociationDescribedTransformation::End")
    locationAssociationDescribedFinalDF
  }

    def applyLocationAssociationDescribedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyLocationAssociationDescribedUnpublishedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D" || col("TMS_ACTION_CODE") === "R")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    
    val transformDF = filteredDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))

    val locationAssociationDescribedUnpublishedFinalDF = IDGenerationEngine.createKeyForDF(transformDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "System_Key", "TMS_HDR_TMS"))

    logger.debug("SparkDataFrameHelper::applyLocationAssociationDescribedUnpublishedTransformation::End")
    locationAssociationDescribedUnpublishedFinalDF
  }
  
  def applyPlannedEventReportedDepartureTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventReportedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val explodedDF = filteredDF.withColumn("vars", explode(CommonsUtil.array_zip_udf(array("STN_TYPE_CD", "STN_TIME_ZN_IND", "STN_SEQ_TS", "EST_DPT_DT", "EST_DPT_TM")))).select(
      (col("*")), trim(col("vars")(0)).alias("STN_TYPE_CD_EXP"), trim(col("vars")(1)).alias("TIME_ZONE"), trim(col("vars")(2)).alias("STN_SEQ_TS_EXP"), trim(col("vars")(3)).alias("EST_DPT_DT_EXP"), trim(col("vars")(4)).alias("EST_DPT_TM_EXP"))

    val departureDF = explodedDF.filter(col("STN_TYPE_CD_EXP") =!= "D" && col("EST_DPT_DT_EXP") =!= "0001-01-01" && col("EST_DPT_DT_EXP").isNotNull)
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val plannedEventType = CommonsUtil.getRefData(referenceData, "Planned Event", "Train Event")

    // inputDF.printSchema()
    val plannedEventReportedDF = departureDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Planned_Event_Type_Key", lit(plannedEventType))
      .withColumn("Planned_Event_Value", lit("Departure"))

    val plannedEventReportedDF1 = IDGenerationEngine.createKeyForDF(plannedEventReportedDF, "Planned_Event_Key", List("Planned_Event_Value", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS_EXP"))
    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventReportedDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventReportedTransformation::End")
    outputDF

  }

  def applyPlannedEventReportedArrivalTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventReportedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val explodedDF = filteredDF.withColumn("vars", explode(CommonsUtil.array_zip_udf(array("STN_TYPE_CD", "STN_TIME_ZN_IND", "STN_SEQ_TS", "EST_ARR_DT", "EST_ARR_TM")))).select(
      (col("*")), trim(col("vars")(0)).alias("STN_TYPE_CD_EXP"), trim(col("vars")(1)).alias("TIME_ZONE"), trim(col("vars")(2)).alias("STN_SEQ_TS_EXP"), trim(col("vars")(3)).alias("EST_ARR_DT_EXP"), trim(col("vars")(4)).alias("EST_ARR_TM_EXP"))

    val arrivalDF = explodedDF.filter(col("STN_TYPE_CD_EXP") =!= "O" && col("EST_ARR_DT_EXP") =!= "0001-01-01" && col("EST_ARR_DT_EXP").isNotNull)
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val plannedEventType = CommonsUtil.getRefData(referenceData, "Planned Event", "Train Event")
    // inputDF.printSchema()
    val plannedEventReportedDF = arrivalDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Planned_Event_Type_Key", lit(plannedEventType))
      .withColumn("Planned_Event_Value", lit("Arrival"))

    val plannedEventReportedDF1 = IDGenerationEngine.createKeyForDF(plannedEventReportedDF, "Planned_Event_Key", List("Planned_Event_Value", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS_EXP"))
    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventReportedDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventReportedTransformation::End")
    outputDF

  }
  
    def applyPlannedEventReportedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventReportedUnpublishedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D" || col("TMS_ACTION_CODE") === "R")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
   
    val plannedEventReportedDF = filteredDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))

    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventReportedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventReportedUnpublishedTransformation::End")
    outputDF
    }
  
  def applyPlannedEventAssociatedDepartureTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventAssociatedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val explodedDF = filteredDF.withColumn("vars", explode(CommonsUtil.array_zip_udf(array("STN_TYPE_CD", "STN_STN_FSAC", "STN_SEQ_TS", "EST_DPT_DT", "STN_STN_CARR_ABRV")))).select(
      (col("*")), trim(col("vars")(0)).alias("STN_TYPE_CD_EXP"), trim(col("vars")(1)).alias("STN_FSAC_EXP"), trim(col("vars")(2)).alias("STN_SEQ_TS_EXP"), trim(col("vars")(3)).alias("EST_DPT_DT_EXP"), trim(col("vars")(4)).alias("STN_CARR_ABRV_EXP"))

    val departureDF = explodedDF.filter(col("STN_TYPE_CD_EXP") =!= "D" && col("EST_DPT_DT_EXP") =!= "0001-01-01" && col("EST_DPT_DT_EXP").isNotNull)
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    val plannedEventType = CommonsUtil.getRefData(referenceData, "Planned Event", "Train Event")
    val associationType = CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Event-Route")
    val associationObjectType = CommonsUtil.getRefData(referenceData, "Route", "Train Schedule")

    // inputDF.printSchema()
    val transformDF = departureDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Planned_Event_Type_Key", lit(plannedEventType))
      .withColumn("Planned_Event_Value", lit("Departure"))
      .withColumn("Association_Type_Key", lit(associationType))
      .withColumn("Associated_Object_Type_Key", lit(associationObjectType))
    val plannedEventAssociatedDF = IDGenerationEngine.createKeyForDF(transformDF, "Location_Key", List("STN_CARR_ABRV_EXP", "STN_FSAC_EXP"))
    val plannedEventAssociatedDF1 = IDGenerationEngine.createKeyForDF(plannedEventAssociatedDF, "Associated_Object_Key", List("Location_Key", "Type_Sym_Sect_DptDt_key", "STN_SEQ_TS_EXP"))
    val plannedEventAssociatedDF2 = IDGenerationEngine.createKeyForDF(plannedEventAssociatedDF1, "Planned_Event_Key", List("Planned_Event_Value", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS_EXP"))
    val plannedEventAssociatedDF3 = IDGenerationEngine.createKeyForDF(plannedEventAssociatedDF2, "Association_Key", List("Planned_Event_Key", "Associated_Object_Key")) //need to clarify

    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventAssociatedDF3, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventAssociatedTransformation::End")
    outputDF
  }
  
  def applyPlannedEventAssociatedArrivalTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventAssociatedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R")
    val explodedDF = filteredDF.withColumn("vars", explode(CommonsUtil.array_zip_udf(array("STN_TYPE_CD", "STN_STN_FSAC", "STN_SEQ_TS", "EST_ARR_DT", "STN_STN_CARR_ABRV")))).select(
      (col("*")), trim(col("vars")(0)).alias("STN_TYPE_CD_EXP"), trim(col("vars")(1)).alias("STN_FSAC_EXP"), trim(col("vars")(2)).alias("STN_SEQ_TS_EXP"), trim(col("vars")(3)).alias("EST_ARR_DT_EXP"), trim(col("vars")(4)).alias("STN_CARR_ABRV_EXP"))

    val arrivalDF = explodedDF.filter(col("STN_TYPE_CD_EXP") =!= "O" && col("EST_ARR_DT_EXP") =!= "0001-01-01" && col("EST_ARR_DT_EXP").isNotNull)
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    val plannedEventType = CommonsUtil.getRefData(referenceData, "Planned Event", "Train Event")
    val associationType = CommonsUtil.getRefData(referenceData, "Association", "Inter-BCD Event-Route")
    val associationObjectType = CommonsUtil.getRefData(referenceData, "Route", "Train Schedule")

    // inputDF.printSchema()
    val transformDF = arrivalDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Planned_Event_Type_Key", lit(plannedEventType))
      .withColumn("Planned_Event_Value", lit("Arrival"))
      .withColumn("Association_Type_Key", lit(associationType))
      .withColumn("Associated_Object_Type_Key", lit(associationObjectType))
    val plannedEventAssociatedDF = IDGenerationEngine.createKeyForDF(transformDF, "Location_Key", List("STN_CARR_ABRV_EXP", "STN_FSAC_EXP"))
    val plannedEventAssociatedDF1 = IDGenerationEngine.createKeyForDF(plannedEventAssociatedDF, "Associated_Object_Key", List("Location_Key", "Type_Sym_Sect_DptDt_key", "STN_SEQ_TS_EXP"))
    val plannedEventAssociatedDF2 = IDGenerationEngine.createKeyForDF(plannedEventAssociatedDF1, "Planned_Event_Key", List("Planned_Event_Value", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS_EXP"))
    val plannedEventAssociatedDF3 = IDGenerationEngine.createKeyForDF(plannedEventAssociatedDF2, "Association_Key", List("Planned_Event_Key", "Associated_Object_Key")) //need to clarify
    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventAssociatedDF3, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Associated_Object_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventAssociatedTransformation::End")
    outputDF
  }
  
    def applyPlannedEventAssociatedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventAssociatedUnpublishedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D" || col("TMS_ACTION_CODE") === "R")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    
    val transformDF = filteredDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(domainEventType))
    val outputDF = IDGenerationEngine.createKeyForDF(transformDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventAssociatedUnpublishedTransformation::End")
    outputDF
  }

  def applyRouteDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyRouteDescribedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R" || col("TMS_ACTION_CODE") === "C")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val charTypeKey1 = CommonsUtil.getRefData(referenceData, "Characteristic", "Effective Date")
    val charTypeKey2 = CommonsUtil.getRefData(referenceData, "Characteristic", "Expiry Date")
    val charTypeKey3 = CommonsUtil.getRefData(referenceData, "Characteristic", "Train Service Type")
    val charTypeKey4 = CommonsUtil.getRefData(referenceData, "Characteristic", "Train Schedule Code")
    val charTypeKey5 = CommonsUtil.getRefData(referenceData, "Characteristic", "Maximum MPH")
    val charTypeKey6 = CommonsUtil.getRefData(referenceData, "Characteristic", "Train Reporting Group")
    val charTypeKey7 = CommonsUtil.getRefData(referenceData, "Characteristic", "Operating Status Code")
    val routeDescribedDF = filteredDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Route_Key", col("Type_Sym_Sect_DptDt_Key"))
      .withColumn("Characteristic_Type_Key1", lit(charTypeKey1))
      .withColumn("Characteristic_Value1", col("EFF_DT"))
      .withColumn("Characteristic_Type_Key2", lit(charTypeKey2))
      .withColumn("Characteristic_Value2", col("EXP_DT"))
      .withColumn("Characteristic_Type_Key3", lit(charTypeKey3))
      .withColumn("Characteristic_Value3", col("TRN_SVC_TYP"))
      .withColumn("Characteristic_Type_Key4", lit(charTypeKey4))
      .withColumn("Characteristic_Value4", col("TRN_SCH_CD"))
      .withColumn("Characteristic_Type_Key5", lit(charTypeKey5))
      .withColumn("Characteristic_Value5", col("MAX_MPH"))
      .withColumn("Characteristic_Type_Key6", lit(charTypeKey6))
      .withColumn("Characteristic_Value6", col("TRN_RPTG_GRP"))
      .withColumn("Characteristic_Type_Key7", lit(charTypeKey7))
      .withColumn("Characteristic_Value7", col("OPER_STAT_CD"))

    val routeDescribedDF1 = IDGenerationEngine.createKeyForDF(routeDescribedDF, "Route_Characteristic_Key1", List("Route_Key", "Characteristic_Type_Key1"))
    val routeDescribedDF2 = IDGenerationEngine.createKeyForDF(routeDescribedDF1, "Route_Characteristic_Key2", List("Route_Key", "Characteristic_Type_Key2"))
    val routeDescribedDF3 = IDGenerationEngine.createKeyForDF(routeDescribedDF2, "Route_Characteristic_Key3", List("Route_Key", "Characteristic_Type_Key3"))
    val routeDescribedDF4 = IDGenerationEngine.createKeyForDF(routeDescribedDF3, "Route_Characteristic_Key4", List("Route_Key", "Characteristic_Type_Key4"))
    val routeDescribedDF5 = IDGenerationEngine.createKeyForDF(routeDescribedDF4, "Route_Characteristic_Key5", List("Route_Key", "Characteristic_Type_Key5"))
    val routeDescribedDF6 = IDGenerationEngine.createKeyForDF(routeDescribedDF5, "Route_Characteristic_Key6", List("Route_Key", "Characteristic_Type_Key6"))
    val routeDescribedDF7 = IDGenerationEngine.createKeyForDF(routeDescribedDF6, "Route_Characteristic_Key7", List("Route_Key", "Characteristic_Type_Key7"))

    val routeDescribedFinalDF = IDGenerationEngine.createKeyForDF(routeDescribedDF7, "Domain_Event_Key", List("Domain_Event_Type_Key", "Route_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyRouteDescribedTransformation::End")
    routeDescribedFinalDF
  }
  
    def applyRouteDescribedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyRouteDescribedUnpublishedTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val routeDescribedDF = filteredDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Route_Key", col("Type_Sym_Sect_DptDt_Key"))

    val routeDescribedUnpublishedFinalDF = IDGenerationEngine.createKeyForDF(routeDescribedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Route_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyRouteDescribedUnpublishedTransformation::End")
    routeDescribedUnpublishedFinalDF
  }

  def applyPlannedEventDescDepartureTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescDepartureTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R" || col("TMS_ACTION_CODE") === "C")
    val explodedDF = filteredDF.withColumn("vars", explode(CommonsUtil.array_zip_udf(array("STN_TIME_ZN_IND", "STN_SEQ_TS", "EST_DPT_DT", "EST_DPT_TM", "TOPC_EST_DEP_DT", "TOPC_EST_DEP_TM", "STN_TYPE_CD")))).select(
      (col("*")), trim(col("vars")(0)).alias("TIME_ZONE"), trim(col("vars")(1)).alias("STN_SEQ_TS_EXP"), trim(col("vars")(2)).alias("EST_DPT_DT_EXP"), trim(col("vars")(3)).alias("EST_DPT_TM_EXP"), trim(col("vars")(4)).alias("TOPC_EST_DT_EXP"), trim(col("vars")(5)).alias("TOPC_EST_DEP_TM_EXP"), trim(col("vars")(6)).alias("STN_TYPE_CD_EXP"))

    val departureDF = explodedDF.filter(col("STN_TYPE_CD_EXP") =!= "D" && col("EST_DPT_DT_EXP") =!= "0001-01-01" && col("EST_DPT_DT_EXP").isNotNull)
    val tzDF = CommonsUtil.getTimeZoneNameByCode(departureDF, "tz_name")    
    val Domain_Event_Type_Key = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val DepDF = tzDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(Domain_Event_Type_Key))
      .withColumn("DEPARTURE", lit("Departure"))
    
    val Planned_Event_KeyDF = IDGenerationEngine.createKeyForDF(DepDF, "Planned_Event_Key", List("DEPARTURE", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS_EXP"))
    //Start Iteration 1
    //(PRNT_TYPE_CD='Characteristic', TYPE_CD='Estimated Departure UTC'')
    
    val Characteristic_Type_Key = CommonsUtil.getRefData(referenceData, "Characteristic", "Estimated Departure UTC")
    val charTypeDF = Planned_Event_KeyDF
      .withColumn("Characteristic_Type_Key1", lit(Characteristic_Type_Key))
      .withColumn("tz", trim(col("tz_name")))
      .withColumn("EST_DPT_TS_CLEAN", regexp_replace(concat(col("EST_DPT_DT_EXP"), lit("-"), col("EST_DPT_TM_EXP")), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2})", "$1-$2-$3 $4:$5:$6"))
      .withColumn("Characteristic_Value1", expr("to_utc_timestamp(EST_DPT_TS_CLEAN, tz)"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Planned_Event_Characteristic_KeyDF = IDGenerationEngine.createKeyForDF(charTypeDF, "Planned_Event_Characteristic_Key1", List("Planned_Event_Key", "Characteristic_Type_Key1"))
    //End Iteration1
    //Start Iteration 2
    //GetHash Key (PRNT_TYPE_CD='Characteristic', TYPE_CD='TOPC Estimated Departure UTC'')   
    val Characteristic_Type_Key1 = CommonsUtil.getRefData(referenceData, "Characteristic", "TOPC Estimated Departure UTC")
    val charTypeDF1 = Planned_Event_Characteristic_KeyDF
      .withColumn("Characteristic_Type_Key2", lit(Characteristic_Type_Key1))
      .withColumn("TOPC_EST_DEP_TS_CLEAN", regexp_replace(concat(col("TOPC_EST_DT_EXP"), lit("-"), col("TOPC_EST_DEP_TM_EXP")), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2})", "$1-$2-$3 $4:$5:$6"))
      .withColumn("Characteristic_Value2", expr("to_utc_timestamp(TOPC_EST_DEP_TS_CLEAN, tz)"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Planned_Event_Characteristic_KeyDF1 = IDGenerationEngine.createKeyForDF(charTypeDF1, "Planned_Event_Characteristic_Key2", List("Planned_Event_Key", "Characteristic_Type_Key2"))
    //End Iteration2

    //Domain_Event_Key - Hash of target fields: Domain_Event_Type_Key,Transportation_Event_Key,Client_Identification,System_Key,Proc_Ts
    val outputDF = IDGenerationEngine.createKeyForDF(Planned_Event_Characteristic_KeyDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescDepartureTransformation::End")
    
    outputDF
  }
  
    def applyPlannedEventDescribedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescUnpublishedTransformation::Start")
   val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "D" || col("TMS_ACTION_CODE") === "R")
    val Domain_Event_Type_Key = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")
    val DepDF = filteredDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(Domain_Event_Type_Key))
 
    //Domain_Event_Key - Hash of target fields: Domain_Event_Type_Key,Transportation_Event_Key,Client_Identification,System_Key,Proc_Ts
    val outputDF = IDGenerationEngine.createKeyForDF(DepDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescUnpublishedTransformation::End")
     
    outputDF
  }

  def applyPlannedEventDescArrivalTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescArrivalTransformation::Start")
    val filteredDF = inputDF.filter(col("TMS_ACTION_CODE") === "A" || col("TMS_ACTION_CODE") === "R" || col("TMS_ACTION_CODE") === "C")
    val explodedDF = filteredDF.withColumn("vars", explode(CommonsUtil.array_zip_udf(array("STN_TIME_ZN_IND", "STN_SEQ_TS", "EST_ARR_DT", "EST_ARR_TM", "TOPC_EST_ARR_DT", "TOPC_EST_ARR_TM", "STN_TYPE_CD")))).select(
      (col("*")), trim(col("vars")(0)).alias("TIME_ZONE"), trim(col("vars")(1)).alias("STN_SEQ_TS_EXP"), trim(col("vars")(2)).alias("EST_ARR_DT_EXP"), trim(col("vars")(3)).alias("EST_ARR_TM_EXP"), trim(col("vars")(4)).alias("TOPC_EST_DT_EXP"), trim(col("vars")(5)).alias("TOPC_EST_ARR_TM_EXP"), trim(col("vars")(6)).alias("STN_TYPE_CD_EXP"))

    val filtered1DF = explodedDF.filter(col("STN_TYPE_CD_EXP") =!= "O" && col("EST_ARR_DT_EXP") =!= "0001-01-01" && col("EST_ARR_DT_EXP").isNotNull)

    val tzDF = CommonsUtil.getTimeZoneNameByCode(filtered1DF, "tz_name")   
    val Domain_Event_Type_Key = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val arrivalDF = tzDF.withColumn("Primary_Object_Key", col("Type_Sym_Sect_DptDt_key"))
      .withColumn("Domain_Event_Type_Key", lit(Domain_Event_Type_Key))
      .withColumn("ARRIVAL", lit("Arrival"))
    //Hash of SOR fields: 'Departure',TRN_TYPE,TRN_SYMB,TRN_SECT,TRN_SCH_DPT_DT,STN_SEQ_TS
    val Planned_Event_KeyDF = IDGenerationEngine.createKeyForDF(arrivalDF, "Planned_Event_Key", List("ARRIVAL", "TRN_TYPE", "TRN_SYM", "TRN_SECT", "TRN_SCH_DPT_DT_formatted", "STN_SEQ_TS_EXP"))
    //Start Iteration 1
    //(PRNT_TYPE_CD='Characteristic', TYPE_CD='Estimated Arrival UTC'')
    //val Characteristic_Type_KeyDF = referenceData.filter(col("prnt_type_cd") === "Characteristic" && col("type_cd") === "Estimated Arrival UTC")
    val Characteristic_Type_Key = CommonsUtil.getRefData(referenceData, "Characteristic", "Estimated Arrival UTC")
    val charTypeDF = Planned_Event_KeyDF
      .withColumn("Characteristic_Type_Key1", lit(Characteristic_Type_Key))
      .withColumn("tz", trim(col("tz_name")))
      .withColumn("EST_ARR_TS_CLEAN", regexp_replace(concat(col("EST_ARR_DT_EXP"), lit("-"), col("EST_ARR_TM_EXP")), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2})", "$1-$2-$3 $4:$5:$6"))
      .withColumn("Characteristic_Value1", expr("to_utc_timestamp(EST_ARR_TS_CLEAN, tz)"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Planned_Event_Characteristic_KeyDF = IDGenerationEngine.createKeyForDF(charTypeDF, "Planned_Event_Characteristic_Key1", List("Planned_Event_Key", "Characteristic_Type_Key1"))
    //End Iteration1
    //Start Iteration 2
    //GetHash Key PRNT_TYPE_CD='Characteristic', TYPE_CD='TOPC Estimated Arrival UTC'')    
    val Characteristic_Type_Key1 = CommonsUtil.getRefData(referenceData, "Characteristic", "TOPC Estimated Arrival UTC")
    val charTypeDF1 = Planned_Event_Characteristic_KeyDF
      .withColumn("Characteristic_Type_Key2", lit(Characteristic_Type_Key1))
      .withColumn("TOPC_EST_ARR_TS_CLEAN", regexp_replace(concat(col("TOPC_EST_DT_EXP"), lit("-"), col("TOPC_EST_ARR_TM_EXP")), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2})", "$1-$2-$3 $4:$5:$6"))
      .withColumn("Characteristic_Value2", expr("to_utc_timestamp(TOPC_EST_ARR_TS_CLEAN, tz)"))
    //Transportation_Event_Characteristic_Key Hash of :Transportation_Event_Key ,Characteristic_Type_Key
    val Planned_Event_Characteristic_KeyDF1 = IDGenerationEngine.createKeyForDF(charTypeDF1, "Planned_Event_Characteristic_Key2", List("Planned_Event_Key", "Characteristic_Type_Key2"))
    //End Iteration2

    //Domain_Event_Key - Hash of target fields: Domain_Event_Type_Key,Transportation_Event_Key,Client_Identification,System_Key,Proc_Ts
    val outputDF = IDGenerationEngine.createKeyForDF(Planned_Event_Characteristic_KeyDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "TMS_HDR_TMS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescArrivalTransformation::End")
     
    outputDF
  }
}