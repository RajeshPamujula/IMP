package com.cn.spark.service

import java.util.Properties

import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.log4j.Logger
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.Row

import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.configFactory.ApplicationConfigEngine
class PlannedEventReportedForEachWriter extends ForeachWriter[Row] with ApplicationConfigEngine with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  val kafkaProperties : Properties = CommonsUtil.getKafkaProperties()

  var producer: KafkaProducer[String, String] = _
  def open(partition_id: Long, epoch_id: Long) = {
    // Open connection. This method is optional in Python.
    logger.debug("PlannedEventReportedForEachWriter start:: open")
    producer = new KafkaProducer(kafkaProperties)
    logger.debug("PlannedEventReportedForEachWriter end:: open")
    true
  }

  //convert to json and write to kafka
  def process(row: Row) = {
    logger.debug("Start process() function PlannedEventReportedForEachWriter")
    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
    producer.send(new ProducerRecord(environmentValues.get("TRANSPORTATION_PLAN_EVT_RPT_PREPARED"), buildPlannedEventReportedJson(rowAsMap)))
    logger.debug("End process() function PlannedEventReportedForEachWriter")
  }

  def close(error: Throwable) = {
    logger.debug("Start close() PlannedEventReportedForEachWriter")
    producer.close()
    logger.debug("End close() PlannedEventReportedForEachWriter")
  }

  // build json message for Conveyor Created
  def buildPlannedEventReportedJson(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("PlannedEventReportedForEachWriter Start :: buildPlannedEventReportedJson")
    val currentTimeInUTC = CommonsUtil.getUTCTimeStamp    
    val msgHeaderJson = "{" + "\"DomainEventHeader\"" + ":" + "{" + "\"SOR_INGT_CRT_TS\"" + ":" + "\"" + rowAsMap("SOR_INGT_CRT_TS") + "\"" + "," + "\"SOR_READ_TS\"" + ":" + "\"" + rowAsMap("SOR_READ_TS") + "\"" + "," + "\"DE_CRT_TS\"" + ":" + "\"" + currentTimeInUTC + "\"" + "," + "\"SOR_TPIC_NM\"" + ":" + "\"" + rowAsMap("SOR_TPIC_NM") + "\"" +"," + "\"DE_META\"" + ":" + "\"" + rowAsMap("DE_META") + "\"" + "},"
    val msgBodyJson = "\"PlannedEventReported\"" + ":" + "{" + "\"Primary_Object_Key\"" + ":" + "\"" + rowAsMap("Primary_Object_Key") + "\""+ "," + "\"Domain_Event_Type_Key\"" + ":" + "\"" + rowAsMap("Domain_Event_Type_Key") + "\"" + "," + "\"Planned_Event_Key\"" + ":" + "\"" + rowAsMap("Planned_Event_Key") + "\"" + "," + "\"Planned_Event_Type_Key\"" + ":" + "\"" + rowAsMap("Planned_Event_Type_Key") + "\"" + "," + "\"Planned_Event_Value\"" + ":" + "\""+ rowAsMap("Planned_Event_Value") + "\"" + "," + "\"Domain_Event_Key\"" + ":" + "\"" + rowAsMap("Domain_Event_Key") + "\"" + "," + "\"Correlation_Id\"" + ":" + "\"" + rowAsMap("Correlation_Id") + "\"" + "," + "\"Client_Identification\"" + ":" + "\"" + rowAsMap("Client_Identification") + "\"" + "," + "\"System_Key\"" + ":" + "\"" + rowAsMap("System_Key") + "\"" + "," + "\"Proc_Ts\"" + ":" + "\"" + rowAsMap("Proc_Ts") + "\"" + "," + "\"Proc_Ts_Tz_Dst_Cd\"" + ":" + "\"" + rowAsMap("Proc_Ts_Tz_Dst_Cd") + "\"" + "," + "\"Event_Ts\"" + ":" + "\"" + rowAsMap("Event_Ts") + "\"" + "," + "\"Event_Ts_Tz_Dst_Cd\"" + ":" + "\"" + rowAsMap("Event_Ts_Tz_Dst_Cd") + "\"" + "}}"
    val plannedEventReportedfinalJson = msgHeaderJson + msgBodyJson        
    logger.debug("PlannedEventReportedForEachWriter End :: buildPlannedEventReportedJson")
     plannedEventReportedfinalJson
  }

}