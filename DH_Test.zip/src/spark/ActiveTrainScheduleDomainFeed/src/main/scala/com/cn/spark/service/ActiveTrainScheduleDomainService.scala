package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.from_json
import org.apache.spark.sql.functions.concat
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger

import com.cn.spark.commons.references.Schema
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.notificationFactory.ErrorNotificationEngine

class ActiveTrainScheduleDomainService(sourceTopic: String, errTopic: String) extends CommonFeed(sourceTopic: String) {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)

  //Broadcast any thing thats required
   val referenceDataDF= CommonsUtil.readReferenceDataFile(spark) 
  val refKeyValueDF = referenceDataDF.withColumn("KEY_CD",concat(col("prnt_type_cd"),lit("|"),col("type_cd"))).drop(col("type_cd")).drop(col("prnt_type_cd"))
  val referenceData = refKeyValueDF.select($"KEY_CD", $"TYPE_KEY").as[(String, String)].collect.toMap  
  val refMapData = spark.sparkContext.broadcast(referenceData)


  @transient lazy val timeInterval = applicationConf.getInt("timeInterval")
  @transient lazy val conveyorCreatedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorCreatedCheckpointDir")
  @transient lazy val conveyorDescribedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorDescribedCheckpointDir")
  @transient lazy val routePlannedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("routePlannedCheckpointDir")
  @transient lazy val routeConveyorMatchedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("routeConveyorMatchedCheckpointDir")
  @transient lazy val locationAssociatedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("locationAssociatedCheckpointDir")
  @transient lazy val locationAssociationDescribedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("locationAssociationDescribedCheckpointDir")
  @transient lazy val plannedEventReportedDPTCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventReportedDPTCheckpointDir")
  @transient lazy val plannedEventReportedARRCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventReportedARRCheckpointDir")
  @transient lazy val plannedEventAssociatedDPTCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventAssociatedDPTCheckpointDir")
  @transient lazy val plannedEventAssociatedARRCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventAssociatedARRCheckpointDir")
  @transient lazy val routeDescribedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("routeDescribedCheckpointDir")
  @transient lazy val conveyorRemovedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorRemovedCheckpointDir")
  @transient lazy val routeCancelledCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("routeCancelledCheckpointDir")
  @transient lazy val errorNotificationCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("errorNotificationCheckpointDir")
  @transient lazy val plannedEventDescArrCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventDescARRCheckpointDir")
  @transient lazy val plannedEventDescDPTCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventDescDPTCheckpointDir")
  @transient lazy val conveyorDescribedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorDescribedUnpublishedCheckpointDir")
  @transient lazy val conveyorAssociatedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("conveyorAssociatedUnpublishedCheckpointDir")
  @transient lazy val locationAssociatedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("locationAssociatedUnpublishedCheckpointDir")
  @transient lazy val locationAssociationDescribedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("locationAssociationDescribedUnpublishedCheckpointDir")
  @transient lazy val plannedEventReportedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventReportedUnpublishedCheckpointDir")
  @transient lazy val plannedEventAssociatedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventAssociatedUnpublishedCheckpointDir")
  @transient lazy val plannedEventDescribedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("plannedEventDescribedUnpublishedCheckpointDir")
  @transient lazy val routeDescribedUnpublishedCheckpoint = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("routeDescribedUnpublishedCheckpointDir")

  //Implementation of the trait. using Schema to fetch dataframe from the message.
  @Override
  def applySchema(dataset: Dataset[(String, String)]): DataFrame = {
    logger.info("ActiveTrainScheduleDomainService Start ::applySchema")
    //applying schema to json message
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA", from_json($"value", Schema.atsDemoSchema) as "record", col("topic"))

    //adding time stamp while reading
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(rawMsgDF, "SOR_READ_TS")
    logger.debug("ActiveTrainScheduleDomainService End ::applySchema")
    
    val filterDF = SparkDataFrameHelper.filterOutMessages(auditTimeStampDF)
     
    CommonsUtil.addDeMetaColumn(filterDF, "DE_META")

  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("ActiveTrainScheduleDomainService Start ::transformAndsinkStream")

    /*
   Check if required fields are null post the filter then redirect to error kafka and remove from the filtered DF. Header to  be updated with Source Kafka queue name
   only 5 fields TRN_SYM, TRN_TYPE, TRN_SECT, TRN_SCH_DPT_DT, USER_ID
   */
    val mainDF = ErrorNotificationEngine.addErrorColumnForDF(inputDF, List("TRN_SYM", "TRN_TYPE", "TRN_SECT", "TRN_SCH_DPT_DT","Correlation_Id"))

    //Filter Error message
    val errorDF = ErrorNotificationEngine.filterErrorMessage(mainDF)

    //Filter correct message
    val tempDF1 = ErrorNotificationEngine.dropColumn(mainDF, "JSON_DATA")
    val tempDF2 = ErrorNotificationEngine.filterCorrectMessage(tempDF1)
    val correctDF = ErrorNotificationEngine.dropColumn(tempDF2, "ERROR_KEY")

    val transformedDF = SparkDataFrameHelper.applyCommonTransformations(correctDF, refMapData.value)
     
    //CONVEYOR CREATED
    val convCreatedFinalDF = SparkDataFrameHelper.applyConveyorCreatedTransformation(transformedDF, refMapData.value)

    //CONVEYOR DESCRIBED
    val convDescribedFinalDF = SparkDataFrameHelper.applyConveyorDescribedTransformation(transformedDF, refMapData.value)

    //ROUTE PLANNED
    val routePlannedFinalDF = SparkDataFrameHelper.applyRoutePlannedTransformation(transformedDF, refMapData.value)

    //ROUTE-CONVEYOR MATCHED
    val convAssociatedFinalDF = SparkDataFrameHelper.applyConveyorAssociatedTransformation(transformedDF, refMapData.value)

    //locationAssociated
    val locationAssociatedFinalDF = SparkDataFrameHelper.applyLocationAssociatedTransformation(transformedDF, refMapData.value)

    //locationAssociated
    val locationAssociationDescribedFinalDF = SparkDataFrameHelper.applyLocationAssociationDescribedTransformation(transformedDF, refMapData.value)

    //PlannedEventReportedDeparture
    val plannedEventReportedDPTFinalDF = SparkDataFrameHelper.applyPlannedEventReportedDepartureTransformation(transformedDF, refMapData.value)

    //PlannedEventReportedArrivalTransformation
    val plannedEventReportedArrFinalDF = SparkDataFrameHelper.applyPlannedEventReportedArrivalTransformation(transformedDF, refMapData.value)

    //applyPlannedEventAssociatedDepartureTransformation
    val plannedEventAssociatedDPTFinalDF = SparkDataFrameHelper.applyPlannedEventAssociatedDepartureTransformation(transformedDF, refMapData.value)

    //applyPlannedEventAssociatedDepartureTransformation
    val plannedEventAssociatedARRFinalDF = SparkDataFrameHelper.applyPlannedEventAssociatedArrivalTransformation(transformedDF, refMapData.value)

    //applyRouteDescribedTransformation
    val routeDescribedFinalDF = SparkDataFrameHelper.applyRouteDescribedTransformation(transformedDF, refMapData.value)

    //applyPlannedEventDescDepartureTransformation
    val plannedEventDescDPTFinalDF = SparkDataFrameHelper.applyPlannedEventDescDepartureTransformation(transformedDF, refMapData.value)
    
    //applyPlannedEventDescArrivalTransformation
    val plannedEventDescArrFinalDF = SparkDataFrameHelper.applyPlannedEventDescArrivalTransformation(transformedDF, refMapData.value)
   
    //CONVEYOR REMOVED
    val convRemovedFinalDF = SparkDataFrameHelper.applyConveyorRemovedTransformation(transformedDF, refMapData.value)

    //ROUTE CANCELLED
    val routeCancelledFinalDF = SparkDataFrameHelper.applyRouteCancelledTransformation(transformedDF, refMapData.value)

    //Unpublish Events
    val conveyorDescribedUnpublishedFinalDF = SparkDataFrameHelper.applyConveyorDescribedUnpublishedTransformation(transformedDF, refMapData.value)
        
    val conveyorAssociatedUnpublishedFinalDF = SparkDataFrameHelper.applyConveyorAssociatedUnpublishedTransformation(transformedDF, refMapData.value)
        
    val locationAssociatedUnpublishedFinalDF = SparkDataFrameHelper.applyLocationAssociatedUnpublishedTransformation(transformedDF, refMapData.value)
        
    val locationAssociationDescribedUnpublishedFinalDF = SparkDataFrameHelper.applyLocationAssociationDescribedUnpublishedTransformation(transformedDF, refMapData.value)
        
    val plannedEventReportedUnpublishedFinalDF = SparkDataFrameHelper.applyPlannedEventReportedUnpublishedTransformation(transformedDF, refMapData.value)
        
    val plannedEventAssociatedUnpublishedFinalDF = SparkDataFrameHelper.applyPlannedEventAssociatedUnpublishedTransformation(transformedDF, refMapData.value)
    
    val plannedEventDescribedUnpublishedFinalDF = SparkDataFrameHelper.applyPlannedEventDescribedUnpublishedTransformation(transformedDF, refMapData.value)
     
    val routeDescribedUnpublishedFinalDF = SparkDataFrameHelper.applyRouteDescribedUnpublishedTransformation(transformedDF, refMapData.value)

   //send error messages to kafka Queue
    errorDF.writeStream.option("checkpointLocation", errorNotificationCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ErrorNotificationForEachWriter(errTopic, "ActiveTrainScheduleDomainFeed", sourceTopic)).start()

    convCreatedFinalDF.writeStream.option("checkpointLocation", conveyorCreatedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorCreatedForEachWriter).start()

    convDescribedFinalDF.writeStream.option("checkpointLocation", conveyorDescribedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDescribedForEachWriter).start()

    routePlannedFinalDF.writeStream.option("checkpointLocation", routePlannedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new RoutePlannedForEachWriter).start()

    convAssociatedFinalDF.writeStream.option("checkpointLocation", routeConveyorMatchedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociatedForEachWriter).start()

    locationAssociatedFinalDF.writeStream.option("checkpointLocation", locationAssociatedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new LocationAssociatedForEachWriter).start()

    locationAssociationDescribedFinalDF.writeStream.option("checkpointLocation", locationAssociationDescribedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new LocationAssociationDescribedForEachWriter).start()

    plannedEventReportedDPTFinalDF.writeStream.option("checkpointLocation", plannedEventReportedDPTCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventReportedForEachWriter).start()

    plannedEventReportedArrFinalDF.writeStream.option("checkpointLocation", plannedEventReportedARRCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventReportedForEachWriter).start()

    plannedEventAssociatedDPTFinalDF.writeStream.option("checkpointLocation", plannedEventAssociatedDPTCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventAssociatedForEachWriter).start()

    plannedEventAssociatedARRFinalDF.writeStream.option("checkpointLocation", plannedEventAssociatedARRCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventAssociatedForEachWriter).start()

    routeDescribedFinalDF.writeStream.option("checkpointLocation", routeDescribedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new RouteDescribedForEachWriter).start()
    
    plannedEventDescDPTFinalDF.writeStream.option("checkpointLocation", plannedEventDescDPTCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventDescribedForEachWriter).start()
    
    plannedEventDescArrFinalDF.writeStream.option("checkpointLocation", plannedEventDescArrCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventDescribedForEachWriter).start()

    convRemovedFinalDF.writeStream.option("checkpointLocation", conveyorRemovedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorRemovedForEachWriter).start()

    routeCancelledFinalDF.writeStream.option("checkpointLocation", routeCancelledCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new RouteCancelledForEachWriter).start()
    
    conveyorDescribedUnpublishedFinalDF.writeStream.option("checkpointLocation", conveyorDescribedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorDescribedUnpublishedForEachWriter).start()
    
    conveyorAssociatedUnpublishedFinalDF.writeStream.option("checkpointLocation", conveyorAssociatedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociatedUnpublishedForEachWriter).start()
    
    locationAssociatedUnpublishedFinalDF.writeStream.option("checkpointLocation", locationAssociatedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new LocationAssociatedUnpublishedForEachWriter).start()
    
    locationAssociationDescribedUnpublishedFinalDF.writeStream.option("checkpointLocation", locationAssociationDescribedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new LocationAssociationDescribedUnpublishedForEachWriter).start()
    
    plannedEventReportedUnpublishedFinalDF.writeStream.option("checkpointLocation", plannedEventReportedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventReportedUnpublishedForEachWriter).start()
    
    plannedEventAssociatedUnpublishedFinalDF.writeStream.option("checkpointLocation", plannedEventAssociatedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventAssociatedUnpublishedForEachWriter).start()
    
    plannedEventDescribedUnpublishedFinalDF.writeStream.option("checkpointLocation", plannedEventDescribedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new PlannedEventDescribedUnpublishedForEachWriter).start()
    
    routeDescribedUnpublishedFinalDF.writeStream.option("checkpointLocation", routeDescribedUnpublishedCheckpoint).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new RouteDescribedUnpublishedForEachWriter).start()

  }

}