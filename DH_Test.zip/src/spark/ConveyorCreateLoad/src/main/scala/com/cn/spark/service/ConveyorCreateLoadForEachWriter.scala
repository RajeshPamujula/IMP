package com.cn.spark.service

import java.sql.Connection
import java.sql.DriverManager

import org.apache.log4j.Logger
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.Row
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.configFactory.ApplicationConfigEngine
import java.util.Properties
import org.apache.kafka.clients.producer.KafkaProducer

class ConveyorCreateLoadForEachWriter(dbConfigParam: Properties, val ErrorNotificationTopic: String, val jobName: String, val sourceTopicName: String, targetUpsertTableName: String, domainTypeVal: String) extends ForeachWriter[Row] with ApplicationConfigEngine with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  lazy val conn: Connection = DriverManager.getConnection(dbConfigParam.getProperty("dbUrl"), dbConfigParam.getProperty("user"), dbConfigParam.getProperty("password"))
  //lazy val conn: Connection = JDBCConnectionFactory.getConnection(dbConfigParam.getProperty("user"), dbConfigParam.getProperty("password"),dbConfigParam.getProperty("dbUrl"))
  @transient lazy val kafkaProperties: Properties = CommonsUtil.getKafkaProperties()
  var producer: KafkaProducer[String, String] = _

  def open(partition_id: Long, epoch_id: Long) = {

    // Open connection.
    logger.debug("Start open ConveyorCreateLoadForEachWriter")
    producer = new KafkaProducer(kafkaProperties)
    conn
    logger.debug("End open ConveyorCreateLoadForEachWriter")
    true
  }

  def process(row: Row) = {
    logger.debug("Start process ConveyorCreateLoadForEachWriter")

    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
    val insertQuery = CommonsUtil.replaceNullString(buildQuery(rowAsMap))
    try {
      if (!rowAsMap("DOMN_EVT_TYPE_KEY").equals(domainTypeVal)) {
        CommonsUtil.saveTODB(insertQuery, conn, true, rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName)
        CommonsUtil.saveTODB(buildUpsertQuery(rowAsMap), conn, true, rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName)
      } else {
        CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, "Unrelated Domain Event Type:Unpublish")
      }
    }
     catch {
      case ne: NullPointerException => {
           CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, ne.printStackTrace().toString())
       }
      case se: Exception => {
        CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, se.getMessage)
      }
    }
    logger.debug("End process ConveyorCreateLoadForEachWriter")
  }

  def close(error: Throwable) = {
    logger.debug("Start close ConveyorCreateLoadForEachWriter")
    conn.close()
    producer.close()
    logger.debug("End close ConveyorCreateLoadForEachWriter")
  }

  def buildQuery(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("ConveyorCreateLoadForEachWriter Start:: buildQuery")
    val insertQueryString = "INSERT INTO " + dbConfigParam.getProperty("targetTableName") + "(CNVY_KEY,SOR_TPIC_NM,DOMN_EVT_META,CNVY_TYPE_KEY,ID_TYPE_KEY,ID_VAL,DOMN_EVT_KEY,DOMN_EVT_TYPE_KEY,SOR_CRLT_ID,SYS_KEY,CLNT_ID,SOR_INGT_CRT_TS,SOR_READ_TS,DOMN_EVT_CRT_TS,DOMN_EVT_READ_TS,SOR_PROC_TS,SOR_EVT_TS,SOR_EVT_TS_TZ_DST_CD,SOR_PROC_TS_TZ_DST_CD,DATA_HUB_CRT_TS)  VALUES('" +
      rowAsMap("CNVY_KEY") + "','" +
      rowAsMap("SOR_TPIC_NM") + "','" +
      rowAsMap("DOMN_EVT_META") + "','" +
      rowAsMap("CNVY_TYPE_KEY") + "','" +
      rowAsMap("ID_TYPE_KEY") + "','" +
      rowAsMap("ID_VAL") + "','" +
      rowAsMap("DOMN_EVT_KEY") + "','" +
      rowAsMap("DOMN_EVT_TYPE_KEY") + "','" +
      rowAsMap("SOR_CRLT_ID") + "','" +
      rowAsMap("SYS_KEY") + "','" +
      rowAsMap("CLNT_ID") + "','" +
      rowAsMap("SOR_INGT_CRT_TS") + "','" +
      rowAsMap("SOR_READ_TS") + "', '" +
      rowAsMap("DOMN_EVT_CRT_TS") + "','" +
      rowAsMap("DOMN_EVT_READ_TS") + "','" +
      rowAsMap("SOR_PROC_TS") + "','" +
      rowAsMap("SOR_EVT_TS") + "','" +
      rowAsMap("SOR_EVT_TS_TZ_DST_CD") + "','" +
      rowAsMap("SOR_PROC_TS_TZ_DST_CD") + "',CURRENT_TIMESTAMP)"
    logger.debug("ConveyorCreateLoadForEachWriter End:: buildQuery")
    CommonsUtil.replaceNullString(insertQueryString)
  }

  def buildUpsertQuery(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("ConveyorCreateLoadForEachWriter Start :: buildUpsertQuery")
    val upsertQueryString = "INSERT INTO " + targetUpsertTableName + "(CNVY_KEY,CNVY_TYPE_KEY, ACT_STUS_IND, ID_TYPE_KEY, ID_VAL, SOR_CRLT_ID, SYS_KEY, RPT_CLNT_ID, RPT_SOR_PROC_TS,SOR_EVT_TS, SOR_INGT_CRT_TS, SOR_READ_TS, DOMN_EVT_CRT_TS,DOMN_EVT_READ_TS,DATA_HUB_CRT_TS,SOR_TPIC_NM,DOMN_EVT_META,SOR_EVT_TS_TZ_DST_CD,SOR_PROC_TS_TZ_DST_CD) VALUES('" +
      rowAsMap("CNVY_KEY") + "','" +
      rowAsMap("CNVY_TYPE_KEY") + "','" +
      1 + "','" +
      rowAsMap("ID_TYPE_KEY") + "','" +
      rowAsMap("ID_VAL") + "','" +
      rowAsMap("SOR_CRLT_ID") + "','" +
      rowAsMap("SYS_KEY") + "','" +
      rowAsMap("CLNT_ID") + "','" +
      rowAsMap("SOR_PROC_TS") + "','" +
      rowAsMap("SOR_EVT_TS") + "','" +
      rowAsMap("SOR_INGT_CRT_TS") + "','" +
      rowAsMap("SOR_READ_TS") + "','" +
      rowAsMap("DOMN_EVT_CRT_TS") + "','" +
      rowAsMap("DOMN_EVT_READ_TS") + "',CURRENT_TIMESTAMP,'" +
      rowAsMap("SOR_TPIC_NM") + "','" +
      rowAsMap("DOMN_EVT_META") + "','" +
      rowAsMap("SOR_EVT_TS_TZ_DST_CD") + "','" +
      rowAsMap("SOR_PROC_TS_TZ_DST_CD") + "') ON CONFLICT(CNVY_KEY) DO UPDATE SET CNVY_TYPE_KEY = EXCLUDED.CNVY_TYPE_KEY,ACT_STUS_IND=EXCLUDED.ACT_STUS_IND,ID_TYPE_KEY= EXCLUDED.ID_TYPE_KEY,ID_VAL=EXCLUDED.ID_VAL, SOR_CRLT_ID=EXCLUDED.SOR_CRLT_ID, SYS_KEY=EXCLUDED.SYS_KEY,RPT_CLNT_ID=EXCLUDED.RPT_CLNT_ID,RPT_SOR_PROC_TS=EXCLUDED.RPT_SOR_PROC_TS,SOR_EVT_TS=EXCLUDED.SOR_EVT_TS,SOR_INGT_CRT_TS=EXCLUDED.SOR_INGT_CRT_TS,SOR_READ_TS=EXCLUDED.SOR_READ_TS,DOMN_EVT_CRT_TS=EXCLUDED.DOMN_EVT_CRT_TS,DOMN_EVT_READ_TS=EXCLUDED.DOMN_EVT_READ_TS,DATA_HUB_CRT_TS=EXCLUDED.DATA_HUB_CRT_TS,SOR_TPIC_NM=EXCLUDED.SOR_TPIC_NM,DOMN_EVT_META=EXCLUDED.DOMN_EVT_META,SOR_EVT_TS_TZ_DST_CD=EXCLUDED.SOR_EVT_TS_TZ_DST_CD,SOR_PROC_TS_TZ_DST_CD=EXCLUDED.SOR_PROC_TS_TZ_DST_CD WHERE " + targetUpsertTableName + ".SOR_EVT_TS<='" + rowAsMap("SOR_EVT_TS") + "'"

    logger.debug("ConveyorCreateLoadForEachWriter End :: buildUpsertQuery")
    CommonsUtil.replaceNullString(upsertQueryString)
  }

}