package com.cn.spark.commons.references

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import scala.collection.Seq

object Schema {

  val industrialReasonSchema = StructType(Seq(
    StructField("IngestionHeader", StructType(Seq(
      StructField("ING_CRT_TS", StringType, false),
      StructField("UUID", StringType, false))), false),
    StructField("IndustrialInstruction", StructType(Seq(
      StructField("CAR_NUMB", StringType, false),
      StructField("CAR_INIT", StringType, false),
      StructField("INDY_INSN", StringType, false),
      StructField("IBMSNAP_OPERATION", StringType, false))), false)))

  val referenceDataSchema = StructType(Seq(
    StructField("type_cd", StringType, false),
    StructField("prnt_type_cd", StringType, false)))
}