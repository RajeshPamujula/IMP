package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.functions.date_format
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.functions.rtrim
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.concat
import org.apache.spark.sql.functions.expr
import org.apache.spark.sql.functions.regexp_replace
import org.apache.spark.sql.functions.to_utc_timestamp
import org.apache.spark.sql.functions.explode
import com.cn.spark.idFactory.IDGenerationEngine
import com.cn.spark.commonsEngine
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.Constants

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def getMessages(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::filterOutMessages::Start")

    val selectedDF = inputDF
      .select(
        col("record.IngestionHeader.ING_CRT_TS").alias("SOR_INGT_CRT_TS"),
        col("record.IngestionHeader.UUID").alias("Correlation_Id"),
        col("SOR_READ_TS").alias("SOR_READ_TS"),
        trim(col("record.IndustrialInstruction.CAR_NUMB")).alias("CAR_NUMB"),
        col("record.IndustrialInstruction.CAR_INIT").alias("CAR_INIT"),
        col("record.IndustrialInstruction.INDY_INSN").alias("INDY_INSN"),
        col("record.IndustrialInstruction.IBMSNAP_OPERATION").alias("IBMSNAP_OPERATION"),
        col("JSON_DATA").alias("JSON_DATA"),
        col("topic").alias("SOR_TPIC_NM"))

    logger.debug("SparkDataFrameHelper::filterOutMessages::End")

    selectedDF
  }

  def applyCommonTransformations(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransformation::Start")
    val systemKey = CommonsUtil.getRefData(referenceData, "System", "SRS-YIT")
    val transformDFnew = inputDF
      .withColumn("Client_Identification", lit("SRS-YIT"))
      .withColumn("System_Key", lit(systemKey))
      .withColumn("Proc_Ts", regexp_replace(col("SOR_INGT_CRT_TS"), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2}).(\\d{6})", "$1-$2-$3 $4:$5:$6.$7"))
      .withColumn("Event_Ts", regexp_replace(col("SOR_INGT_CRT_TS"), "(\\d{4})-(\\d{2})-(\\d{2})-(\\d{2}).(\\d{2}).(\\d{2}).(\\d{6})", "$1-$2-$3 $4:$5:$6.$7"))
      .withColumn("Proc_Ts_Tz_Dst_Cd", lit(Constants.DST_CD_UTC_DST_NO))
      .withColumn("Event_Ts_Tz_Dst_Cd",lit(Constants.DST_CD_UTC_DST_NO))
    //Primary_Object_Key
    val transformDF = IDGenerationEngine.createKeyForDF(transformDFnew, "Primary_Object_Key", List("CAR_INIT", "CAR_NUMB"))
    logger.debug("SparkDataFrameHelper::applyTransformation::End")
    transformDF
  }

  def applyPlannedEventReportedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventReportedTransformation::Start")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val plannedEventType = CommonsUtil.getRefData(referenceData, "Planned Event", "Industrial Car Instruction")

    val transformDF = inputDF.filter(col("IBMSNAP_OPERATION") =!= "D")

    val plannedEventReportedDF = transformDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Planned_Event_Type_Key", lit(plannedEventType))
      .withColumn("Planned_Event_Value", lit("Industrial Instruction"))
    val plannedEventReportedDF1 = IDGenerationEngine.createKeyForDF(plannedEventReportedDF, "Planned_Event_Key", List("CAR_INIT", "CAR_NUMB", "Planned_Event_Value"))
    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventReportedDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventReportedTransformation::End")
    outputDF

  }

  def applyPlannedEventDescribedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescribedTransformation::Start")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Created")
    val CharTypeKey = CommonsUtil.getRefData(referenceData, "Characteristic", "Industrial Car Instruction")

    val transformDF = inputDF.filter(col("IBMSNAP_OPERATION") =!= "D")

    val plannedEventDescribedDF = transformDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Planned_Event_Value", lit("Industrial Instruction"))
      .withColumn("Characteristic_Type_Key", lit(CharTypeKey))
      .withColumn("Characteristic_Value", col("INDY_INSN"))

    val plannedEventDescribedDF1 = IDGenerationEngine.createKeyForDF(plannedEventDescribedDF, "Planned_Event_Key", List("CAR_INIT", "CAR_NUMB", "Planned_Event_Value"))
    val plannedEventDescribedDF2 = IDGenerationEngine.createKeyForDF(plannedEventDescribedDF1, "Planned_Event_Characteristic_Key", List("Planned_Event_Key", "Characteristic_Type_Key"))
    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventDescribedDF2, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescribedTransformation::End")
    outputDF

  }
  
    def applyPlannedEventDescribedUnpublishedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescribedUnpublishedTransformation::Start")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Unpublished")

    val transformDF = inputDF.filter(col("IBMSNAP_OPERATION") === "D")

    val plannedEventDescribedDF = transformDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))

    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventDescribedDF, "Domain_Event_Key", List("Domain_Event_Type_Key", "Primary_Object_Key", "Client_Identification", "System_Key", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventDescribedUnpublishedTransformation::End")
    outputDF

  }

  def applyPlannedEventRemovedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyPlannedEventRemovedTransformation::Start")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Removed")
    val plannedEventType = CommonsUtil.getRefData(referenceData, "Planned Event", "Industrial Car Instruction")

    val transformDF = inputDF.filter(col("IBMSNAP_OPERATION") === "D")

    val plannedEventRemovedDF = transformDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Planned_Event_Type_Key", lit(plannedEventType))
      .withColumn("Planned_Event_Value", lit("Industrial Instruction"))
    val plannedEventRemovedDF1 = IDGenerationEngine.createKeyForDF(plannedEventRemovedDF, "Planned_Event_Key", List("CAR_INIT", "CAR_NUMB", "Planned_Event_Value"))
    val outputDF = IDGenerationEngine.createKeyForDF(plannedEventRemovedDF1, "Domain_Event_Key", List("Domain_Event_Type_Key", "Planned_Event_Key", "Client_Identification", "System_Key", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyPlannedEventRemovedTransformation::End")
    outputDF

  }

  def applyConveyorAssociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedTransformation::Start")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Associated")
    val associationTypeKey = CommonsUtil.getRefData(referenceData, "Association", "Inter BCD Conveyor-Event")
    val conveyorTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Railcar")
    val associatedObjectTypeKey = CommonsUtil.getRefData(referenceData, "Planned Event", "Industrial Car Instruction")

    val transformDF = inputDF.filter(col("IBMSNAP_OPERATION") =!= "D")

    val conveyorAssociatedDF = transformDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Association_Type_Key", lit(associationTypeKey))
      .withColumn("Conveyor_Type_Key", lit(conveyorTypeKey))
      .withColumn("Associated_Object_Type_Key", lit(associatedObjectTypeKey))
      .withColumn("Planned_Event_Value", lit("Industrial Instruction"))
    val conveyorAssociatedDF1 = IDGenerationEngine.createKeyForDF(conveyorAssociatedDF, "Associated_Object_Key", List("CAR_INIT", "CAR_NUMB", "Planned_Event_Value"))
    val conveyorAssociatedDF2 = IDGenerationEngine.createKeyForDF(conveyorAssociatedDF1, "Conveyor_Key", List("CAR_INIT", "CAR_NUMB"))
    val conveyorAssociatedDF3 = IDGenerationEngine.createKeyForDF(conveyorAssociatedDF2, "Association_Key", List("Conveyor_Key", "Associated_Object_Key"))
    val outputDF = IDGenerationEngine.createKeyForDF(conveyorAssociatedDF3, "Domain_Event_Key", List("Domain_Event_Type_Key", "Association_Key", "Client_Identification", "System_Key", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorAssociatedTransformation::End")
    outputDF

  }
  
  def applyConveyorDisassociatedTransformation(inputDF: DataFrame, referenceData: Map[String, String]): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyConveyorDisassociatedTransformation::Start")
    val domainEventType = CommonsUtil.getRefData(referenceData, "Domain Event Type", "Disassociated")
    val associationTypeKey = CommonsUtil.getRefData(referenceData, "Association", "Inter BCD Conveyor-Event")
    val conveyorTypeKey = CommonsUtil.getRefData(referenceData, "Conveyor", "Railcar")
    val associatedObjectTypeKey = CommonsUtil.getRefData(referenceData, "Planned Event", "Industrial Car Instruction")

    val transformDF = inputDF.filter(col("IBMSNAP_OPERATION") === "D")

    val conveyorDisassociatedDF = transformDF.withColumn("Domain_Event_Type_Key", lit(domainEventType))
      .withColumn("Association_Type_Key", lit(associationTypeKey))
      .withColumn("Conveyor_Type_Key", lit(conveyorTypeKey))
      .withColumn("Associated_Object_Type_Key", lit(associatedObjectTypeKey))
      .withColumn("Planned_Event_Value", lit("Industrial Instruction"))
    val conveyorDisassociatedDF1 = IDGenerationEngine.createKeyForDF(conveyorDisassociatedDF, "Associated_Object_Key", List("CAR_INIT", "CAR_NUMB", "Planned_Event_Value"))
    val conveyorDisassociatedDF2 = IDGenerationEngine.createKeyForDF(conveyorDisassociatedDF1, "Conveyor_Key", List("CAR_INIT", "CAR_NUMB"))
    val conveyorDisassociatedDF3 = IDGenerationEngine.createKeyForDF(conveyorDisassociatedDF2, "Association_Key", List("Conveyor_Key", "Associated_Object_Key"))
    val outputDF = IDGenerationEngine.createKeyForDF(conveyorDisassociatedDF3, "Domain_Event_Key", List("Domain_Event_Type_Key", "Association_Key", "Client_Identification", "System_Key", "SOR_INGT_CRT_TS"))
    logger.debug("SparkDataFrameHelper::applyConveyorDisassociatedTransformation::End")
    outputDF

  }

  def applyActionCodeFilter(inputDF: DataFrame, filterValue: String): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyFilter::Start")
    val finalDF = inputDF.filter(col("TMS_ACTION_CODE") === filterValue)
    logger.debug("SparkDataFrameHelper::applyFilter::End")
    finalDF

  }
}