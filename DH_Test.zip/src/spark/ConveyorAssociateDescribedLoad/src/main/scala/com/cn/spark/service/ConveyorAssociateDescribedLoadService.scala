package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, from_json, lit, concat }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.references.ConveyorAssociateDescribedSchema
import org.apache.hadoop.security.alias.CredentialProviderFactory
import org.apache.commons.lang3.exception.ExceptionUtils
import java.util.Properties
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.idFactory.IDGenerationEngine

class ConveyorAssociateDescribedLoadService(sourceTopicName:String,ErrorNotificationTopic:String) extends CommonFeed(sourceTopicName:String) {

  import spark.implicits._

  val logger = Logger.getLogger(getClass.getName)
  logger.info("Start ConveyorAssociateDescribedLoadService transfromData")
  @transient lazy val transportAscDsctLoadCheckpointDir = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transportConvDescAsctLoadCheckpointDir")
  @transient lazy val targetTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("transportConvDescAsctTable")
  //Broadcast any thing thats required
  @transient lazy val jcekFileSystem = applicationConf.getString("jcekFileSystem")
  lazy val dbConfigParam: Properties = CommonsUtil.setPostgreConfig(targetTableName,jcekFileSystem)
  @transient lazy val timeInterval = applicationConf.getInt("timeInterval")

  lazy val targetUpsertTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("convAssocDesUpsertTableName")

  val domainTypeDF = spark.createDataFrame(Seq(("Unpublished", "Domain Event Type"),("Created", "Domain Event Type"))).toDF("TYPE_CD", "PRNT_TYPE_CD")
  val domainTypeFinalDF = IDGenerationEngine.createKeyForDF(domainTypeDF, "DOMAIN_EVENT_FLAG", List("TYPE_CD", "PRNT_TYPE_CD"))
  val domainType = domainTypeFinalDF.select(concat($"PRNT_TYPE_CD",lit("|"),$"TYPE_CD"),$"DOMAIN_EVENT_FLAG").as[(String, String)].collect.toMap
  val domainTypeVal = spark.sparkContext.broadcast(domainType)

  /*using IPDSchema.trnSheduleEvtSchema schema to fetch dataframe from the message.
  *@throws(classOf[Exception])
  *Input -  json message from Kafka
  *output - Dataframe
  */
  @Override
  def applySchema(dataset: Dataset[(String,String)]): DataFrame = {
    logger.debug("ConveyorAssociateDescribedLoadService Start::")

    val messageDF = dataset.select(col("value") as "JSON_DATA",from_json(CommonsUtil.preprocessJson($"value"), ConveyorAssociateDescribedSchema.conveyorAsocDescribedSchema) as "record")   
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(messageDF, "DOMN_EVT_READ_TS")
    logger.debug("ConveyorAssociateDescribedLoadService End ::applySchema")

    SparkDataFrameHelper.getMsgData(auditTimeStampDF)

  }

  /*Transformations will be applied for each batch and saved transformed data into respective sink.
   * Input -  message dataframe
   * output - Streaming query
   */
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("Start ConveyorAssociateDescribedLoadService::transformAndsinkStream")
    logger.info("Start ConveyorAssociateDescribedLoadService::transformAndsinkStream")
    val finalDF = SparkDataFrameHelper.applyTransformation(inputDF)
    finalDF.writeStream.option("checkpointLocation", transportAscDsctLoadCheckpointDir).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorAssociateDescribedLoadForEachWriter(dbConfigParam, ErrorNotificationTopic, "ConveyorAssociateDescribedLoad", sourceTopicName, targetUpsertTableName, domainTypeVal.value)).start()

  }

}
