import org.apache.log4j.Logger
import java.sql.BatchUpdateException
import org.apache.spark.SparkException
import org.apache.commons.lang3.exception.ExceptionUtils
import java.net.ConnectException
import com.cn.spark.service.ConveyorAssociateDescribedLoadService
import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.commonsEngine.CommonsUtil.isEmpty

object ConveyorAssociateDescribedLoad extends App with ApplicationConfigEngine {

  val logger = Logger.getLogger(getClass.getName)

  //System.setProperty("hadoop.home.dir", "U:\\winutils");
  logger.info("Start ConveyorAssociateDescribedLoadService")
  
  val sourceTopic = environmentValues.get(applicationConf.getString("KAFKA_SRC_TOPIC"))
  val errorTopic = environmentValues.get(applicationConf.getString("KAFKA_ERR_TOPIC"))
  if(!isEmpty(sourceTopic)){
    if(!isEmpty(errorTopic)){ 
      val conveyorAssociateDescribedLoadService = new ConveyorAssociateDescribedLoadService(sourceTopic,errorTopic)
  try {
  logger.info("Invoking ConveyorAssociateDescribedLoadService Service")
  conveyorAssociateDescribedLoadService.Start()
   } catch {
    case se: Exception => {
     val updateException: Throwable = ExceptionUtils.getRootCause(se)
      logger.error("Error While Starting ConveyorAssociateDescribedLoad" + updateException.printStackTrace())
    }

  }
   }else{
    logger.error("ErrorTopic name is null. Please pass it and run the job again!")
    throw new Exception("ErrorTopic name is null. Please pass it and run the job again!")
  }
   }else{
    logger.error("Source topic name is null. Please pass it and run the job again!")
    throw new Exception("Source topic name is null. Please pass it and run the job again!")
  }

  logger.info("End ConveyorAssociateDescribedLoadService")
}