package com.cn.spark.commons.references

import scala.collection.Seq

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.types.ByteType
import org.apache.spark.sql.types.BinaryType
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.types.AnyDataType
import org.apache.spark.sql.functions.concat
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.date_format
import org.apache.spark.sql.types.ArrayType

object ConveyorConditionChangedSchema extends Serializable {
  val logger = Logger.getLogger(getClass.getName)

   val conveyorConditionChangedSchema = StructType(Seq(
    StructField("DomainEventHeader", StructType(Seq(
      StructField("SOR_INGT_CRT_TS", StringType, false),
      StructField("SOR_READ_TS", StringType, false),
      StructField("DE_CRT_TS", StringType, false),
      StructField("SOR_TPIC_NM", StringType, false),
      StructField("DE_META", StringType, false))), false),
    StructField("ConveyorConditionChanged", StructType(Seq(
      StructField("Domain_Event_Key", StringType, false),
      StructField("Conveyor_Key", StringType, false),
      StructField("Domain_Event_Type_Key", StringType, false),
      StructField("Correlation_Id", StringType, false),
      StructField("System_Key", StringType, false),
      StructField("Client_Identification", StringType, false),
      StructField("Proc_Ts", StringType, false),
      StructField("Event_Ts", StringType, false),
      StructField("Event_Ts_Tz_Dst_Cd", StringType, false),
      StructField("Proc_Ts_Tz_Dst_Cd", StringType, false),
      StructField("ConditionCharacteristics", ArrayType(StructType(Seq(
        StructField("Condition_Characteristic_Key", StringType, false),
        StructField("Characteristic_Type_Key", StringType, false),
        StructField("Characteristic_Value", StringType, false)))), false))), false)))

}