package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.from_json
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.references.ConveyorConditionChangedSchema
import org.apache.hadoop.security.alias.CredentialProviderFactory
import org.apache.commons.lang3.exception.ExceptionUtils
import java.util.Properties
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.commonsEngine.CommonFeed
import com.cn.spark.idFactory.IDGenerationEngine

class ConveyorConditionChangedLoadService(sourceTopicName:String,ErrorNotificationTopic:String) extends CommonFeed(sourceTopicName:String) {

  import spark.implicits._

  val logger = Logger.getLogger(getClass.getName)
  logger.info("Start ConveyorConditionChangedLoadService transfromData")
  @transient lazy val transportConvCondChangedLoadCheckpointDir = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("transportConvCondChangedLoadCheckpointDir")
  @transient lazy val targetTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("transportConvCondCreatedTable")
  @transient lazy val targetUpsertTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("transportConvCondUpsertTable")

  //Broadcast any thing thats required
  @transient lazy val jcekFileSystem = applicationConf.getString("jcekFileSystem")
  lazy val dbConfigParam: Properties = CommonsUtil.setPostgreConfig(targetTableName,jcekFileSystem)
  @transient lazy val timeInterval = applicationConf.getInt("timeInterval")

  val domainTypeDF = spark.createDataFrame(Seq(("Unpublished", "Domain Event Type"))).toDF("TYPE_CD", "PRNT_TYPE_CD")
  val domainTypeFinalDF = IDGenerationEngine.createKeyForDF(domainTypeDF, "DOMAIN_EVENT_FLAG", List("TYPE_CD", "PRNT_TYPE_CD"))
  val domainType = domainTypeFinalDF.select($"DOMAIN_EVENT_FLAG").collect().toList.head.getString(0)
  val domainTypeVal = spark.sparkContext.broadcast(domainType)
  
  /*using  schema to fetch dataframe from the message.
  *@throws(classOf[Exception])
  *Input -  json message from Kafka
  *output - Dataframe
  */
  @Override
  def applySchema(dataset: Dataset[(String,String)]): DataFrame = {
    logger.debug("ConveyorConditionChangedLoadService Start::")

    val messageDF = dataset.select(col("value") as "JSON_DATA",from_json(CommonsUtil.preprocessJson($"value"), ConveyorConditionChangedSchema.conveyorConditionChangedSchema) as "record")   
    val auditTimeStampDF = CommonsUtil.addAuditTimeStamp(messageDF, "DOMN_EVT_READ_TS")
    logger.debug("ConveyorConditionChangedLoadService End ::applySchema")

    SparkDataFrameHelper.getMsgData(auditTimeStampDF)

  }

  /*Transformations will be applied for each batch and saved transformed data into respective sink.
   * Input -  message dataframe
   * output - Streaming query
   */
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("Start ConveyorConditionChangedLoadService::transformAndsinkStream")
    logger.info("Start ConveyorConditionChangedLoadService::transformAndsinkStream")
    val finalDF = SparkDataFrameHelper.applyTransformation(inputDF)
    finalDF.writeStream.option("checkpointLocation", transportConvCondChangedLoadCheckpointDir).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new ConveyorConditionChangedLoadForEachWriter(dbConfigParam, ErrorNotificationTopic, "ConveyorConditionChangedLoad", sourceTopicName,targetUpsertTableName,domainTypeVal.value)).start()

  }

}
