package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.functions.date_format
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.functions.when
import com.cn.spark.idFactory.IDGenerationEngine
import org.apache.spark.sql.functions.to_timestamp
import org.apache.spark.sql.functions.explode
import org.apache.spark.sql.types.BinaryType
import java.sql.DriverManager
import java.sql.PreparedStatement
import java.sql.Timestamp
import java.sql.Connection
import java.util.Properties

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  def updateTODB(updateDF: DataFrame, targetTableName: String, dbConfigParam: Properties) {
    logger.debug("Start updateToDB SparkDataFrameHelper")

    updateDF.coalesce(10).foreachPartition(partition =>

      {
        val db_size = 10000
        var st: PreparedStatement = null
        val conn: Connection = DriverManager.getConnection(dbConfigParam.getProperty("dbUrl"), dbConfigParam)
        partition.grouped(db_size).foreach(batch => {

          batch.foreach { row =>
            {              
                
                val EQP_INITINDX = row.fieldIndex("EQP_INIT")
                val EQP_INIT = row.getString(EQP_INITINDX)

                val EQP_NBRINDX = row.fieldIndex("EQP_NBR")
                val EQP_NBR = row.getString(EQP_NBRINDX)

                var IS_LGTH_FT: Short = null.asInstanceOf[Short]
                val IS_LGTH_FTINDX = row.fieldIndex("ISID_LGT_FT")
                if (row.get(IS_LGTH_FTINDX) != null)
                  IS_LGTH_FT = row.getShort(IS_LGTH_FTINDX)

                val OS_LGTH_FTINDX = row.fieldIndex("OSID_LGT_FT")
                val OS_LGTH_FT = row.getDecimal(OS_LGTH_FTINDX)

                val NBR_OF_PLFMINDX = row.fieldIndex("NBR_OF_PLFM")
                val NBR_OF_PLFM = row.getShort(NBR_OF_PLFMINDX)

                val ARTTINDX = row.fieldIndex("ARTT_CD")
                val ARTT = row.getString(ARTTINDX)

                val RCAR_TARE_WGT_IN_LBINDX = row.fieldIndex("TARE_WGT_LB")
                val RCAR_TARE_WGT_IN_LB = row.getInt(RCAR_TARE_WGT_IN_LBINDX)

                val TOT_WGT_ON_RAILINDX = row.fieldIndex("TOT_WGT_RAIL_TON")
                val TOT_WGT_ON_RAIL = row.getShort(TOT_WGT_ON_RAILINDX)

                val CAR_KINDINDX = row.fieldIndex("CAR_KIND")
                val CAR_KIND = row.getString(CAR_KINDINDX)
            
                val XTRM_HGT_ININDX = row.fieldIndex("XTRM_HGT_IN")
                val XTRM_HGT_IN = row.getShort(XTRM_HGT_ININDX)
                
                val XTRM_WDT_ININDX = row.fieldIndex("XTRM_WDT_IN")
                val XTRM_WDT_IN = row.getShort(XTRM_WDT_ININDX)
                
                val LOAD_LMTINDX = row.fieldIndex("LOAD_LMT")
                val LOAD_LMT = row.getShort(LOAD_LMTINDX)
                
                val AXLE_CDINDX = row.fieldIndex("AXLE_CD")
                val AXLE_CD = row.getString(AXLE_CDINDX)
                
                val GST_CDINDX = row.fieldIndex("GST_CD")
                val GST_CD = row.getString(GST_CDINDX)
                
                val AAR_EQP_TYPE_CDINDX = row.fieldIndex("AAR_EQP_TYPE_CD")
                val AAR_EQP_TYPE_CD = row.getString(AAR_EQP_TYPE_CDINDX)
                
                val BRNG_CDINDX = row.fieldIndex("BRNG_CD")
                val BRNG_CD = row.getString(BRNG_CDINDX)
                  
                val sqlString = "select * from " + targetTableName + " where EQP_INIT=? and EQP_NBR=?"

                var pstmt: PreparedStatement = conn.prepareStatement(sqlString)
                pstmt.setString(1, EQP_INIT)
                pstmt.setString(2, EQP_NBR)

                val rs = pstmt.executeQuery()
                var count1: Int = 0
                while (rs.next()) {
                  count1 = 1

                }

                var dmlOprtn = "NULL"
                if (count1 > 0)
                  dmlOprtn = "UPDATE"
                else
                  dmlOprtn = "INSERT"

                if (dmlOprtn == "UPDATE") {
                  val updateSqlString = "update " + targetTableName + " set ISID_LGT_FT=?,OSID_LGT_FT=?,NBR_OF_PLFM=?,ARTT_CD=?,TARE_WGT_LB=?,TOT_WGT_RAIL_TON=?,CAR_KIND=?,XTRM_HGT_IN=?,XTRM_WDT_IN=?,LOAD_LMT=?,AXLE_CD=?,GST_CD=?,AAR_EQP_TYPE_CD=?,BRNG_CD=? where EQP_INIT=? and EQP_NBR=?"
                  st = conn.prepareStatement(updateSqlString)

                 
                  
                  if (IS_LGTH_FT == null)
                    st.setShort(1, null.asInstanceOf[Short])
                  else
                    st.setShort(1, IS_LGTH_FT)
                  st.setBigDecimal(2, OS_LGTH_FT)
                  st.setShort(3, NBR_OF_PLFM)
                  st.setString(4, ARTT)
                  st.setInt(5, RCAR_TARE_WGT_IN_LB)
                  st.setShort(6, TOT_WGT_ON_RAIL)
                  st.setString(7, CAR_KIND)
                  st.setShort(8, XTRM_HGT_IN)
                  st.setShort(9, XTRM_WDT_IN)
                  st.setShort(10, LOAD_LMT)
                  st.setString(11, AXLE_CD)
                 
                  st.setString(12, GST_CD)
                  st.setString(13, AAR_EQP_TYPE_CD)
                  st.setString(14, BRNG_CD)
                  st.setString(15, EQP_INIT)
                  st.setString(16, EQP_NBR)
                  
                }

                st.addBatch()

              
            }
            st.executeBatch()

          }

        })

        conn.close()

      })

  }

}