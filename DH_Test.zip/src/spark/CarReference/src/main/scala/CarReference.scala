import java.util.Properties

import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.log4j.Level

import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.configFactory.SparkSessionConfigEngine
import com.cn.spark.idFactory.IDGenerationEngine
import org.apache.log4j.Level
import com.cn.spark.commons.utils.SparkDataFrameHelper
import org.apache.spark.sql.types._
import org.apache.spark.SparkException
import org.postgresql.util.PSQLException

object CarReference extends App with SparkSessionConfigEngine with ApplicationConfigEngine {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  //System.setProperty("hadoop.home.dir", "U:\\winutils\\")
  logger.setLevel(Level.INFO)
  logger.info("Execution Start")

  try {
    lazy val srcTableName: String = environmentValues.get("PG_RAW_TBL_PREFIX_STATION") + "." + applicationConf.getString("commonTumler")
    lazy val targetTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("rcarRefTable")
    @transient lazy val jcekFileSystem = applicationConf.getString("jcekFileSystem")
    lazy val dbConfigParam: Properties = CommonsUtil.setPostgreConfig(targetTableName, jcekFileSystem)
    val rawDF = CommonsUtil.getDataFromDB(spark, srcTableName, dbConfigParam)
    val targetDF = CommonsUtil.getDataFromDB(spark, targetTableName, dbConfigParam)

    val rawSelectDF = rawDF
      .select(
        "EQP_INIT",
        "EQP_NBR",
        "IS_LGTH_FT",
        "OSID_LGT",
        "ARTICLTD",
        "TARE_WGT",
        "TOT_WGT_RAIL",
        "CAR_KIND",
        "XTRM_WDT",
        "XTRM_HGT",
        "LOAD_LMT",
        "AXLES",
        "GST_CD",
        "EQP_TYP_AAR",
        "BRNG_CD",
        "INGT_CRT_TS")

    val rawFinalDF = rawSelectDF
      .withColumn("EQP_INIT", trim(col("EQP_INIT")))
      .withColumn("EQP_NBR", trim(col("EQP_NBR")))
      .withColumn("EQP_NBR", regexp_replace(col("EQP_NBR"), "^0*", ""))
      .withColumn("raw_unique_key", concat(col("EQP_INIT"), col("EQP_NBR")))

    val carDF = targetDF
      .withColumn("EQP_INIT", trim(col("EQP_INIT")))
      .withColumn("EQP_NBR", trim(col("EQP_NBR")))
      .withColumn("EQP_NBR", regexp_replace(col("EQP_NBR"), "^0*", ""))
      .withColumn("car_unique_key", concat(col("EQP_INIT"), col("EQP_NBR")))

    val joinDF = rawFinalDF.as("raw")
      .join(carDF.as("car"), col("raw.raw_unique_key") === col("car.car_unique_key"), "left")

    val newDF = joinDF
      .where(col("car_unique_key").isNull)
      .select("raw.*")
      .drop("raw_unique_key")
      .withColumn("ISID_LGT_FT", col("IS_LGTH_FT").cast(ShortType))
      .withColumn("OSID_LGT_FT", (((col("osid_lgt") - (col("osid_lgt") % 100)) / 100) + (col("osid_lgt") % 100 / 12.0)).cast(DecimalType(15, 10)))
      .withColumn("NBR_OF_PLFM_MID", col("ARTICLTD").cast(ShortType))
      .withColumn("NBR_OF_PLFM", when(col("NBR_OF_PLFM_MID").isNull, 1).otherwise(col("NBR_OF_PLFM_MID")))
      .withColumn("ARTT_CD", col("ARTICLTD"))
      .withColumn("TOT_WGT_RAIL_TON", col("TOT_WGT_RAIL").cast(ShortType))
      .withColumn("CAR_KIND", col("CAR_KIND"))
      .withColumn("TARE_WGT_LB", (col("TARE_WGT") * 1000).cast(IntegerType))
      .withColumn("XTRM_HGT_IN", col("XTRM_HGT"))
      .withColumn("XTRM_WDT_IN", col("XTRM_WDT"))
      .withColumn("AXLE_CD", col("AXLES"))
      .withColumn("GST_CD", trim(col("GST_CD")))
      .withColumn("AAR_EQP_TYPE_CD", col("EQP_TYP_AAR"))
      .withColumn("SOR_INGT_CRT_TS", col("INGT_CRT_TS"))
      .withColumn("CLNT_ID", lit("SRS-DB2-TUMLER"))
      .withColumn("NBR_OF_PLFM", col("NBR_OF_PLFM").cast(ShortType))
      .select(
        "EQP_INIT",
        "EQP_NBR",
        "ISID_LGT_FT",
        "OSID_LGT_FT",
        "NBR_OF_PLFM",
        "ARTT_CD",
        "TARE_WGT_LB",
        "TOT_WGT_RAIL_TON",
        "CAR_KIND",
        "XTRM_HGT_IN",
        "XTRM_WDT_IN",
        "LOAD_LMT",
        "AXLE_CD",
        "GST_CD",
        "AAR_EQP_TYPE_CD",
        "BRNG_CD",
        "CLNT_ID",
        "SOR_INGT_CRT_TS")

    val newDfWithKey = IDGenerationEngine.createKeyForDF(newDF, "RCAR_KEY", List("EQP_INIT", "EQP_NBR")).withColumn("RCAR_KEY", col("RCAR_KEY").cast(BinaryType))

    val updateDF = joinDF
      .filter(col("car_unique_key").isNotNull &&
        col("RCAR_KEY").isNotNull)
      .withColumn("ISID_LGT_FT_src", col("raw.IS_LGTH_FT").cast(ShortType))
      .withColumn("OSID_LGT_FT_src", (((col("raw.osid_lgt") - (col("raw.osid_lgt") % 100)) / 100) + (col("raw.osid_lgt") % 100 / 12.0)).cast(DecimalType(15, 10)))
      .withColumn("NBR_OF_PLFM_MID", col("raw.ARTICLTD").cast(ShortType))
      .withColumn("NBR_OF_PLFM_src", when(col("NBR_OF_PLFM_MID").isNull, 1).otherwise(col("NBR_OF_PLFM_MID")))
      .withColumn("ARTT_CD_src", col("raw.ARTICLTD"))
      .withColumn("TOT_WGT_RAIL_TON_src", col("raw.TOT_WGT_RAIL").cast(ShortType))
      .withColumn("CAR_KIND_src", col("raw.CAR_KIND"))
      .withColumn("TARE_WGT_LB_src", (col("raw.TARE_WGT") * 1000).cast(IntegerType))
      .withColumn("XTRM_HGT_IN_src", col("raw.XTRM_HGT"))
      .withColumn("XTRM_WDT_IN_src", col("raw.XTRM_WDT"))
      .withColumn("AXLE_CD_src", col("raw.AXLES"))
      .withColumn("GST_CD_src", trim(col("raw.GST_CD")))
      .withColumn("AAR_EQP_TYPE_CD_src", col("raw.EQP_TYP_AAR"))
      .filter((col("car_unique_key") === col("raw_unique_key")) &&
        ((col("ISID_LGT_FT_src") =!= col("car.ISID_LGT_FT")) ||
          (col("OSID_LGT_FT_src") =!= col("car.OSID_LGT_FT")) ||
          (col("NBR_OF_PLFM_src") =!= col("car.NBR_OF_PLFM")) ||
          (col("ARTT_CD_src") =!= col("car.ARTT_CD")) ||
          (col("TOT_WGT_RAIL_TON_src") =!= col("car.TOT_WGT_RAIL_TON")) ||
          (col("CAR_KIND_src") =!= col("car.CAR_KIND")) ||
          (col("TARE_WGT_LB_src") =!= col("car.TARE_WGT_LB")) ||
          (col("XTRM_HGT_IN_src") =!= col("car.XTRM_HGT_IN")) ||
          (col("XTRM_WDT_IN_src") =!= col("car.XTRM_WDT_IN")) ||
          (col("AXLE_CD_src") =!= col("car.AXLE_CD")) ||
          (col("GST_CD_src") =!= col("car.GST_CD")) ||
          (col("AAR_EQP_TYPE_CD_src") =!= col("car.AAR_EQP_TYPE_CD")) ||
          (col("raw.LOAD_LMT") =!= col("car.LOAD_LMT")) ||
          (col("raw.BRNG_CD") =!= col("car.BRNG_CD")) ||
          (col("ISID_LGT_FT_src").isNotNull && col("car.ISID_LGT_FT").isNull) ||
          (col("OSID_LGT_FT_src").isNotNull && col("car.OSID_LGT_FT").isNull) ||
          (col("NBR_OF_PLFM_src").isNotNull && col("car.NBR_OF_PLFM").isNull) ||
          (col("ARTT_CD_src").isNotNull && col("car.ARTT_CD").isNull) ||
          (col("TOT_WGT_RAIL_TON_src").isNotNull && col("car.TOT_WGT_RAIL_TON").isNull) ||
          (col("CAR_KIND_src").isNotNull && col("car.CAR_KIND").isNull) ||
          (col("TARE_WGT_LB_src").isNotNull && col("car.TARE_WGT_LB").isNull) ||
          (col("XTRM_HGT_IN_src").isNotNull && col("car.XTRM_HGT_IN").isNull) ||
          (col("XTRM_WDT_IN_src").isNotNull && col("car.XTRM_WDT_IN").isNull) ||
          (col("AXLE_CD_src").isNotNull && col("car.AXLE_CD").isNull) ||
          (col("GST_CD_src").isNotNull && col("car.GST_CD").isNull) ||
          (col("AAR_EQP_TYPE_CD_src").isNotNull && col("car.AAR_EQP_TYPE_CD").isNull) ||
          (col("raw.LOAD_LMT").isNotNull && col("car.LOAD_LMT").isNull) ||
          (col("raw.BRNG_CD").isNotNull && col("car.BRNG_CD").isNull)))
      .select(
        "raw.eqp_init",
        "raw.eqp_nbr",
        "raw.LOAD_LMT",
        "raw.BRNG_CD",
        "ISID_LGT_FT_src",
        "OSID_LGT_FT_src",
        "NBR_OF_PLFM_src",
        "ARTT_CD_src",
        "TOT_WGT_RAIL_TON_src",
        "CAR_KIND_src",
        "TARE_WGT_LB_src",
        "XTRM_HGT_IN_src",
        "XTRM_WDT_IN_src",
        "AXLE_CD_src",
        "GST_CD_src",
        "AAR_EQP_TYPE_CD_src")
      .withColumnRenamed("ISID_LGT_FT_src", "ISID_LGT_FT")
      .withColumnRenamed("OSID_LGT_FT_src", "OSID_LGT_FT")
      .withColumnRenamed("ARTT_CD_src", "ARTT_CD")
      .withColumnRenamed("TOT_WGT_RAIL_TON_src", "TOT_WGT_RAIL_TON")
      .withColumnRenamed("NBR_OF_PLFM_src", "NBR_OF_PLFM")
      .withColumnRenamed("CAR_KIND_src", "CAR_KIND")
      .withColumnRenamed("TARE_WGT_LB_src", "TARE_WGT_LB")
      .withColumnRenamed("XTRM_HGT_IN_src", "XTRM_HGT_IN")
      .withColumnRenamed("XTRM_WDT_IN_src", "XTRM_WDT_IN")
      .withColumnRenamed("AXLE_CD_src", "AXLE_CD")
      .withColumnRenamed("GST_CD_src", "GST_CD")
      .withColumnRenamed("AAR_EQP_TYPE_CD_src", "AAR_EQP_TYPE_CD")
      .withColumn("NBR_OF_PLFM", col("NBR_OF_PLFM").cast(ShortType))
      .select(
        "EQP_INIT",
        "EQP_NBR",
        "ISID_LGT_FT",
        "OSID_LGT_FT",
        "NBR_OF_PLFM",
        "ARTT_CD",
        "TARE_WGT_LB",
        "TOT_WGT_RAIL_TON",
        "CAR_KIND",
        "XTRM_HGT_IN",
        "XTRM_WDT_IN",
        "LOAD_LMT",
        "AXLE_CD",
        "GST_CD",
        "AAR_EQP_TYPE_CD",
        "BRNG_CD")

    try {
      logger.info("Update Table for CarReference start")
      SparkDataFrameHelper.updateTODB(updateDF, targetTableName, dbConfigParam)
    } catch {
      case pe: PSQLException => {
        logger.error("Not able to process data1: " + pe.getMessage)
      }
      case se: SparkException => {
        logger.error("Not able to process data2:" + se.getCause)
      }
    }

    try {
      logger.info("writing new data in table for CarReference")
      newDfWithKey.withColumn("DATA_HUB_CRT_TS", lit(current_timestamp())).write.mode("append").jdbc(dbConfigParam.getProperty("dbUrl"), targetTableName, dbConfigParam)
    } catch {
      case pe: PSQLException => {
        logger.error("Not able to process data3: " + pe.getMessage)
      }
      case se: SparkException => {
        logger.error("Not able to process data4:" + se.getCause)
      }
    }
  } catch {
    case pe: PSQLException => {
      logger.error("Not able to process data5: " + pe.getMessage)
    }
    case se: SparkException => {
      logger.error("Not able to process data6:" + se.getCause)
    }
    case ex: Exception => {
      logger.error("Not able to process data7:" + ex.getCause)
    }
  }
}