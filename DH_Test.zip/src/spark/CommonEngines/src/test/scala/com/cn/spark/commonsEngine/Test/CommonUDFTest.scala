package com.cn.spark.commonsEngine.Test

import java.util.{Calendar}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.commonsEngine.CommonUDF._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.SparkConf
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.junit.Assert._
import org.junit.{After, Before, Test}
import com.cn.spark.configFactory.Test.SparkSessionConfigEngineTest

class CommonUDFTest extends SparkSessionConfigEngineTest {
 @transient lazy val logger: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)
 
  import spark.implicits._
  
 @Before
  @Test def before() {
    println("Setup for CommonUDFTest")
    logger.setLevel(Level.ERROR)
  }  
  @Test def getDateTimeStrFromSplitDataUDFCompare(){
  	
  val case8DF = Seq(
      ("2019","12","3","2","01:34:45"),("2020","1","3","2","01:24:45")).toDF("CURR_YEAR","DST_STRT_MTH","DST_STRT_DOW","DST_STRT_MTH_DOW_OCUR","DST_STRT_TM")
  val case8FinalDF = case8DF.withColumn("DT_TM",getDateTimeStrFromSplitDataUDF(col("CURR_YEAR"), col("DST_STRT_MTH"), col("DST_STRT_DOW"), col("DST_STRT_MTH_DOW_OCUR"), col("DST_STRT_TM")))
  val case8OutDF = Seq(("2019","12","3","2","01:34:45","2019-12-10 01:34:45"),("2020","01","3","2","01:24:45","2020-01-14 01:24:45")).toDF("CURR_YEAR","DST_STRT_MTH","DST_STRT_DOW","DST_STRT_MTH_DOW_OCUR","DST_STRT_TM","DT_TM")
  
  val reorderedCase8FinalDF = new CommonsUtilTest().reorderColsInDataFrame(case8OutDF.columns,case8FinalDF)
  val difference8DF = reorderedCase8FinalDF.except(case8FinalDF)
  val diffCount8 = difference8DF.count()
  assertTrue("With DE_META Code to add DE_META column value there should not be any difference between testDF and expectedDF",(diffCount8)==0)
  }
  @After
  @Test def after() {
    println("Teardown for CommonUDFTest")
  }
}