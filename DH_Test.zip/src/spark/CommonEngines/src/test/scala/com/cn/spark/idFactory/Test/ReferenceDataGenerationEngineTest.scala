package com.cn.spark.idFactory.Test

import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructType
import org.junit.Assert._
import org.junit.Before
import org.junit.Test
import org.apache.spark.sql.functions._
import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.idFactory.ReferenceDataGenerationEngine
import org.junit.After
import com.cn.spark.commonsEngine.Test.CommonsUtilTest
import com.cn.spark.configFactory.Test.SparkSessionConfigEngineTest
import org.apache.spark.sql.types.StructField

class ReferenceDataGenerationEngineTest extends SparkSessionConfigEngineTest{
  @transient lazy val logger: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)
import spark.implicits._
   
     @Before
     @Test def before() {
    println("Setup for ReferenceDataGenerationEngine")
    logger.setLevel(Level.ERROR)
    var folderPath = getClass.getResource("/Ref_Type.csv/..").getPath
    }
  //--------------------------------------------------------------------referenceDataFromFile-----------------------------------------------------------------------

  val referenceDataSchema = StructType(Seq(
    StructField("type_cd", StringType, false),
    StructField("prnt_type_cd", StringType, false)))

    val filePath = getClass.getResource("/Ref_Type.csv").getPath
    val inputDF = spark.read.option("header",true).schema(referenceDataSchema).csv(filePath).toDF()
    val actualDF = ReferenceDataGenerationEngine.referenceDataFromFile(filePath, referenceDataSchema)

  @Test 
  def readFromFileCompare() {
    val reorderedDF=new CommonsUtilTest().reorderColsInDataFrame(actualDF.columns, inputDF)
    val differenceDF = reorderedDF.except(actualDF)
    val diffCount = differenceDF.count()
    assertTrue("Comparison for DF read from file should result in no difference",(diffCount)==0)
  }

 //--------------------------------------------------------------------applyReferenceDataTransformation-----------------------------------------------------------------------
    
  val referenceTransformationDataframe=ReferenceDataGenerationEngine.applyReferenceDataTransformation(actualDF)
  val expectedData=Seq(("Conveyor","Root","3493ad9d4afb34eab3546c41d316ee8de3d43103b6491d20dd9ed310703368e8","b6f6f8ec64f423159fbc5c34c52a6c2d360ea46e3b96cc56b14f468e910c3d66"),
      ("Route","Root","a7a2658ecc9c8451bebe08fcc1bf1eedf104629d66447d29e501601b874092cc","b6f6f8ec64f423159fbc5c34c52a6c2d360ea46e3b96cc56b14f468e910c3d66"))
  val expectedDF=expectedData.toDF("type_cd","prnt_type_cd","TYPE_KEY","PRNT_TYPE_KEY")
  
  @Test
 def referenceTransformationCompare(){
   val reorderedDF=new CommonsUtilTest().reorderColsInDataFrame(expectedDF.columns, referenceTransformationDataframe)
   val differenceDF = reorderedDF.except(expectedDF)
   val diffCount = differenceDF.count() 
   assertTrue("Comparison for Transformation DF should result in no difference",(diffCount)==0)
 }
  
  @After
  @Test def after() {
    println("Teardown for ReferenceDataGeneration")
  }
}