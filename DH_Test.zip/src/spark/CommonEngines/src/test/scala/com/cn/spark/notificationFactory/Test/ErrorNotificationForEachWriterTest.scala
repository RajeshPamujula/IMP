package com.cn.spark.notificationFactory.Test

import com.cn.spark.configFactory.ApplicationConfigEngine
import org.apache.log4j.Logger
import org.junit.Before
import org.junit.Test
import org.apache.log4j.Level
import org.apache.spark.sql.DataFrame
import com.cn.spark.service.ErrorNotificationForEachWriter
import org.junit.Assert._
import com.cn.spark.configFactory.Test.SparkSessionConfigEngineTest
import org.junit.After

class ErrorNotificationForEachWriterTest extends SparkSessionConfigEngineTest{
  @transient lazy val logger: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)
  import spark.implicits._
  
  @Before
  @Test def before() {
    println("Setup for CommonUtilsTest")
    logger.setLevel(Level.ERROR)
  }

  @Test
  def buildErrorNotificationJsonCheck(){
  val inputData1 = Seq(("NCLX", "00042", "165", null, "BO_CD is NULL","JSON_DATA"))
  val inputDF1 = inputData1.toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR", "BO_CD", "ERROR_KEY","JSON_DATA")  
  val row = inputDF1.first
  val rowAsMap = row.getValuesMap(row.schema.fieldNames)
  val actualData=new ErrorNotificationForEachWriter("ErrorNotificationDemo","buildErrorNotification","SourceTopicDemo").buildErrorNotificationJson(rowAsMap)
  assertNotNull("The ActualData should not be null",actualData)
  }
  
  @After
  @Test def after() {
    println("Teardown for IDGenerationEngineTest")
  }
}  
