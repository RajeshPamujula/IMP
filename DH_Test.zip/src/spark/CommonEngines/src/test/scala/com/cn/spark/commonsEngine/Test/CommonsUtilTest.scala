package com.cn.spark.commonsEngine.Test

import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.commonsEngine.CommonsUtil
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.SparkConf
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.junit.Assert._
import org.junit.{After, Before, Test}
import org.apache.spark.sql.functions._
import java.lang.ClassCastException
import org.apache.spark.sql.Row
import com.cn.spark.configFactory.Test.SparkSessionConfigEngineTest


class CommonsUtilTest extends SparkSessionConfigEngineTest{
  
    @transient lazy val logger: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)

 import spark.implicits._
 //To compare dataframes 
  def reorderColsInDataFrame(inputDFColArray: Array[String], df: DataFrame): DataFrame = {
    try{
      //if only array is not null
      val reorderedColumnNames: Array[String] = inputDFColArray
      df.select(reorderedColumnNames.head, reorderedColumnNames.tail: _*)
    }
    catch {
      case ex: Exception => {
        logger.error(ex.printStackTrace());
        null
      }
    }
  }

 @Before
  @Test def before() {
    println("Setup for CommonUtilsTest")
    logger.setLevel(Level.ERROR)
  }
  
  @Test def addAuditTimeStampCompare(){
  //Positive Test Case   
  val case1DF = Seq(("CN","880630","4"),("CN","880632","5"),("CN","880633","6")).toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR")
	val case1FinalDF = CommonsUtil.addAuditTimeStamp(case1DF, "SOR_READ_TS")
	
	assertTrue("With TIME_STAMP Code to add audit time stamp there should not be any difference between testDF and expectedDF",case1FinalDF.columns.size==4)
	
	}
    
  @Test def addDeMetaColumnCompare(){
  //Positive Test Case  
  val case2DF = Seq(("CN","880630","4"),("CN","880632","5"),("CN","880633","6")).toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR")
	val case2FinalDF = CommonsUtil.addDeMetaColumn(case2DF, "DE_META")
	val case2OutDF = Seq(("CN","880630","4",""),("CN","880632","5",""),("CN","880633","6","")).toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR","DE_META")
	
	val reorderedCase2FinalDF = reorderColsInDataFrame(case2OutDF.columns,case2FinalDF)
  val difference2DF = reorderedCase2FinalDF.except(case2OutDF)
  val diffCount2 = difference2DF.count()
  assertTrue("With DE_META Code to add DE_META column value there should not be any difference between testDF and expectedDF",(diffCount2)==0)
	}
  
  @Test def getUTCTimeStampCompare(){
  //Positive Test Case 
  val case1 = CommonsUtil.getUTCTimeStamp
	val casefinal = case1.matches("[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}.[0-9]{2}.[0-9]{2}")
	assertTrue("Comparision of date format of UTC code with expected format",(casefinal)==true)
	
  }
 
  @Test def replaceNullStringCompare(){
  //Positive Test Case 1
  val case2 = "INSERT INTO x (CAR_INIT,CAR_NUMB,TRN_SEQ_NBR,DE_META) VALUES(CN,880630,4,'NULL')"
  val case2Final = CommonsUtil.replaceNullString(case2)
  val case2out = "INSERT INTO x (CAR_INIT,CAR_NUMB,TRN_SEQ_NBR,DE_META) VALUES(CN,880630,4,null)"
  
  assertEquals("Comparision of string of null string code with expected format",case2Final,case2out)
  //Positive Test Case 2
  val case3 = "INSERT INTO x (CAR_INIT,CAR_NUMB,TRN_SEQ_NBR,DE_META) VALUES(CN,880630,4,'Null')"
  val case3Final = CommonsUtil.replaceNullString(case3)
  val case3out = "INSERT INTO x (CAR_INIT,CAR_NUMB,TRN_SEQ_NBR,DE_META) VALUES(CN,880630,4,null)"
  
  assertEquals("Comparision of string of null string code with expected format",case3Final,case3out)
  //Positive Test Case 3
  val case4 = "INSERT INTO x (CAR_INIT,CAR_NUMB,TRN_SEQ_NBR,DE_META) VALUES(CN,880630,4,'null')"
  val case4Final = CommonsUtil.replaceNullString(case4)
  val case4out = "INSERT INTO x (CAR_INIT,CAR_NUMB,TRN_SEQ_NBR,DE_META) VALUES(CN,880630,4,null)"
  
  assertEquals("Comparision of string of null string code with expected format",case4Final,case4out)
  }
 
  @Test def getTimeZoneNameByCodeCompare() {
  
  //Positive Test Case
  val case3DF = Seq("AKT","AT","CT","ET","HAT","MT","NT","PT","UTC_ET","Other")
                  .toDF("TIME_ZONE")
  val case3FinalDF = CommonsUtil.getTimeZoneNameByCode(case3DF, "TIME_ZONE_NM")
  val case3OutDF = Seq(
      ("AKT","America/Anchorage"),
      ("AT","America/Halifax"),
      ("CT","America/Winnipeg"),
      ("ET","America/Toronto"),
      ("HAT","America/Adak"),
      ("MT","America/Edmonton"),
      ("NT","America/St_Johns"),
      ("PT","America/Vancouver"),
      ("UTC_ET","America/Toronto"),
      ("Other","America/New_York")
   ).toDF("TIME_ZONE", "TIME_ZONE_NM")
  val reorderedCase3FinalDF = reorderColsInDataFrame(case3OutDF.columns,case3FinalDF)
  val difference3DF = reorderedCase3FinalDF.except(case3OutDF)
  val diffCount3 = difference3DF.count()
  assertTrue("With TIME_ZONE Code to Name Lookup there should not be any difference between testDF and expectedDF",(diffCount3)==0)
  //Negative Test Case
  val case4DF = Seq("AKT","AT","CT","ET","HeT","MT","NT","PT","UTC_ET","Other")
                  .toDF("TIME_ZONE")
  val case4FinalDF = CommonsUtil.getTimeZoneNameByCode(case4DF, "TIME_ZONE_NM")
  val case4OutDF = Seq(
      ("AKT","America/Anchorage"),
      ("AT","America/Halifax"),
      ("CT","America/Winnipeg"),
      ("ET","America/Toronto"),
      ("HeT",null),
      ("MT","America/Edmonton"),
      ("NT","America/St_Johns"),
      ("PT","America/Vancouver"),
      ("UTC_ET","America/Toronto"),
      ("Other","America/New_York")
   ).toDF("TIME_ZONE", "TIME_ZONE_NM")
  val reorderedCase4FinalDF = reorderColsInDataFrame(case4OutDF.columns,case4FinalDF)
  val difference4DF = reorderedCase4FinalDF.except(case4OutDF)
  val diffCount4 = difference4DF.count()
  assertFalse("With TIME_ZONE Code to Name Lookup there should not be any difference between testDF and expectedDF",(diffCount4)==0)

  }
 
  @Test def zip_udf_compare(){
  //Positive Test Case
  val case4DF = Seq((Seq("CN","CN","CN"),Seq("880630","880632","880633"),Seq("4","5","6")))
                  .toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR")
  val case4FinalDF = case4DF.withColumn("vars",explode(CommonsUtil.zip(col("CAR_INIT"),col("CAR_NUMB"),col("TRN_SEQ_NBR"))))
                              .select((col("*")),trim(col("vars._1")).alias("CAR_INIT_EXP"), trim(col("vars._2")).alias("CAR_NUMB_EXP"), trim(col("vars._3")).alias("TRN_SEQ_NBR_EXP"))
                              .select("CAR_INIT_EXP","CAR_NUMB_EXP","TRN_SEQ_NBR_EXP")
                              .withColumnRenamed("CAR_INIT_EXP", "CAR_INIT")
                              .withColumnRenamed("CAR_NUMB_EXP", "CAR_NUMB")
                              .withColumnRenamed("TRN_SEQ_NBR_EXP", "TRN_SEQ_NBR")                              
            
  val case4OutDF = Seq(
      ("CN","880630","4"),("CN","880632","5"),("CN","880633","6")
  ).toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR")
  
  val reorderedCase4FinalDF = reorderColsInDataFrame(case4OutDF.columns,case4FinalDF)
  val difference4DF = reorderedCase4FinalDF.except(case4OutDF)
  val diffCount4 = difference4DF.count()
  assertTrue("With Array to Zip udf > explode > select projection there should not be any difference between testDF and expectedDF",(diffCount4)==0)
  //Negative Test Case 1
  try {
  val case6DF = Seq((Seq("CN","CN","CN"),Seq("880630","880632","880633")))
                  .toDF("CAR_INIT","CAR_NUMB")
  val case6FinalDF = case6DF.withColumn("vars",explode(CommonsUtil.zip(col("CAR_INIT"),col("CAR_NUMB"))))
                              .select((col("*")),trim(col("vars._1")).alias("CAR_INIT_EXP"), trim(col("vars._2")).alias("CAR_NUMB_EXP"))
                              .select("CAR_INIT_EXP","CAR_NUMB_EXP")
                              .withColumnRenamed("CAR_INIT_EXP", "CAR_INIT")
                              .withColumnRenamed("CAR_NUMB_EXP", "CAR_NUMB")
                                                       
  fail("expected exception was not occured")
  } catch{
      case ex: Exception => {
        logger.error(ex.printStackTrace());
           }
        }
  //Negative Test Case 2
  try {
  val case7DF = Seq((Seq("CN","CN","CN"),Seq("880630","880632","880633")))
                  .toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR")
  val case7FinalDF = case7DF.withColumn("vars",explode(CommonsUtil.zip(col("CAR_INIT"),col("CAR_NUMB"),col("TRN_SEQ_NBR"))))
                              .select((col("*")),trim(col("vars._1")).alias("CAR_INIT_EXP"), trim(col("vars._2")).alias("CAR_NUMB_EXP"), trim(col("vars._3")).alias("TRN_SEQ_NBR_EXP"))
                              .select("CAR_INIT_EXP","CAR_NUMB_EXP","TRN_SEQ_NBR_EXP")
                              .withColumnRenamed("CAR_INIT_EXP", "CAR_INIT")
                              .withColumnRenamed("CAR_NUMB_EXP", "CAR_NUMB")
                              .withColumnRenamed("TRN_SEQ_NBR_EXP", "TRN_SEQ_NBR")
  fail("expected exception was not occured")
  } catch{
      case ex: Exception => {
        logger.error(ex.printStackTrace());
           }
        }
  }
  @Test def zipFiveColumns_udf_compare(){
  //Positive Test Case 1 
  val case5DF = Seq((Seq("CN","CN","CN"),Seq("880630","880632","880633"),Seq("4","5","6"),Seq("CYN","CYN","CYN"),Seq("980630","980632","980633")))
                  .toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR","CTNR_INIT","CTNR_NUMB")
  val case5FinalDF = case5DF.withColumn("vars",explode(CommonsUtil.zipFiveColumns(col("CAR_INIT"),col("CAR_NUMB"),col("TRN_SEQ_NBR"),col("CTNR_INIT"),col("CTNR_NUMB"))))
                              .select((col("*")),trim(col("vars._1")).alias("CAR_INIT_EXP"), trim(col("vars._2")).alias("CAR_NUMB_EXP"), trim(col("vars._3")).alias("TRN_SEQ_NBR_EXP"), trim(col("vars._4")).alias("CTNR_INIT_EXP"), trim(col("vars._5")).alias("CTNR_NUMB_EXP"))
                              .select("CAR_INIT_EXP","CAR_NUMB_EXP","TRN_SEQ_NBR_EXP","CTNR_INIT_EXP","CTNR_NUMB_EXP")
                              .withColumnRenamed("CAR_INIT_EXP", "CAR_INIT")
                              .withColumnRenamed("CAR_NUMB_EXP", "CAR_NUMB")
						                  .withColumnRenamed("TRN_SEQ_NBR_EXP", "TRN_SEQ_NBR") 
						                  .withColumnRenamed("CTNR_INIT_EXP", "CTNR_INIT")
							                .withColumnRenamed("CTNR_NUMB_EXP", "CTNR_NUMB")                            
            
  val case5OutDF = Seq(
      ("CN","880630","4","CYN","980630"),("CN","880632","5","CYN","980632"),("CN","880633","6","CYN","980633")
  ).toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR","CTNR_INIT","CTNR_NUMB")
    
  val reorderedCase5FinalDF = reorderColsInDataFrame(case5OutDF.columns,case5FinalDF)
  val difference5DF = reorderedCase5FinalDF.except(case5FinalDF)
  val diffCount5 = difference5DF.count()
  assertTrue("With Array to Zip udf > explode > select projection there should not be any difference between testDF and expectedDF",(diffCount5)==0)
  //Negative Test Case
  try {
  val case6DF = Seq((Seq("CN","CN","CN"),Seq("880630","880632","880633")))
                  .toDF("CAR_INIT","CAR_NUMB")
  val case6FinalDF = case6DF.withColumn("vars",explode(CommonsUtil.zipFiveColumns(col("CAR_INIT"),col("CAR_NUMB"))))
                              .select((col("*")),trim(col("vars._1")).alias("CAR_INIT_EXP"), trim(col("vars._2")).alias("CAR_NUMB_EXP"))
                              .select("CAR_INIT_EXP","CAR_NUMB_EXP")
                              .withColumnRenamed("CAR_INIT_EXP", "CAR_INIT")
                              .withColumnRenamed("CAR_NUMB_EXP", "CAR_NUMB")
                                                       
  fail("expected exception was not occured")
  } catch{
      case ex: Exception => {
        logger.error(ex.printStackTrace());
           }
        }
  }

  @Test def zipSevenColumns_udf_compare(){
  //Positive Test Case
  val case6DF = Seq((Seq("CN","CN","CN"),Seq("880630","880632","880633"),Seq("4","5","6"),Seq("CYN","CYN","CYN"),Seq("980630","980632","980633"),Seq("LOC1","LOC2","LOC3"),Seq("18060","18062","18063")))
                  .toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR","CTNR_INIT","CTNR_NUMB","FORMAT","PRODUCT_ID")
  val case6FinalDF = case6DF.withColumn("vars",explode(CommonsUtil.zipSevenColumns(col("CAR_INIT"),col("CAR_NUMB"),col("TRN_SEQ_NBR"),col("CTNR_INIT"),col("CTNR_NUMB"),col("FORMAT"),col("PRODUCT_ID"))))
                              .select((col("*")),trim(col("vars._1")).alias("CAR_INIT_EXP"), trim(col("vars._2")).alias("CAR_NUMB_EXP"), trim(col("vars._3")).alias("TRN_SEQ_NBR_EXP"), trim(col("vars._4")).alias("CTNR_INIT_EXP"), trim(col("vars._5")).alias("CTNR_NUMB_EXP"), trim(col("vars._6")).alias("FORMAT_EXP"), trim(col("vars._7")).alias("PRODUCT_ID_EXP"))
							                .select("CAR_INIT_EXP","CAR_NUMB_EXP","TRN_SEQ_NBR_EXP","CTNR_INIT_EXP","CTNR_NUMB_EXP","FORMAT_EXP","PRODUCT_ID_EXP")
                              .withColumnRenamed("CAR_INIT_EXP", "CAR_INIT")
                              .withColumnRenamed("CAR_NUMB_EXP", "CAR_NUMB")
						                  .withColumnRenamed("TRN_SEQ_NBR_EXP", "TRN_SEQ_NBR") 
						                  .withColumnRenamed("CTNR_INIT_EXP", "CTNR_INIT")
							                .withColumnRenamed("CTNR_NUMB_EXP", "CTNR_NUMB") 
							                .withColumnRenamed("FORMAT_EXP", "FORMAT")
							                .withColumnRenamed("PRODUCT_ID_EXP","PRODUCT_ID")                           
	val case6OutDF = Seq(
      ("CN","880630","4","CYN","980630","LOC1","18060"),("CN","880632","5","CYN","980632","LOC2","18062"),("CN","880633","6","CYN","980633","LOC3","18063")
  ).toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR","CTNR_INIT","CTNR_NUMB","FORMAT","PRODUCT_ID")
  
  val reorderedCase6FinalDF = reorderColsInDataFrame(case6OutDF.columns,case6FinalDF)
  val difference6DF = reorderedCase6FinalDF.except(case6OutDF)
  val diffCount6 = difference6DF.count()
  assertTrue("With Array to Zip udf > explode > select projection there should not be any difference between testDF and expectedDF",(diffCount6)==0)
  //Negative Test Case
  try {
  val case5DF = Seq((Seq("CN","CN","CN"),Seq("880630","880632","880633")))
                  .toDF("CAR_INIT","CAR_NUMB")
  val case5FinalDF = case5DF.withColumn("vars",explode(CommonsUtil.zipSevenColumns(col("CAR_INIT"),col("CAR_NUMB"))))
                              .select((col("*")),trim(col("vars._1")).alias("CAR_INIT_EXP"), trim(col("vars._2")).alias("CAR_NUMB_EXP"))
                              .select("CAR_INIT_EXP","CAR_NUMB_EXP")
                              .withColumnRenamed("CAR_INIT_EXP", "CAR_INIT")
                              .withColumnRenamed("CAR_NUMB_EXP", "CAR_NUMB")
                                                       
  fail("expected exception was not occured")
  } catch{
      case ex: Exception => {
        logger.error(ex.printStackTrace());
           }
        }
  }
  
  @Test def array_zip_udf_compare(){
  //Positive Test Case  
  val case7DF = Seq((Seq("CN","CN","CN"),Seq("880630","880632","880633"),Seq("4","5","6")))
                  .toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR")
  val case7FinalDF = case7DF.withColumn("vars",explode(CommonsUtil.array_zip_udf(array("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR"))))
                              .select((col("*")),trim(col("vars")(0)).alias("CAR_INIT_EXP"), trim(col("vars")(1)).alias("CAR_NUMB_EXP"), trim(col("vars")(2)).alias("TRN_SEQ_NBR_EXP"))
                              .select("CAR_INIT_EXP","CAR_NUMB_EXP","TRN_SEQ_NBR_EXP")
                              .withColumnRenamed("CAR_INIT_EXP", "CAR_INIT")
                              .withColumnRenamed("CAR_NUMB_EXP", "CAR_NUMB")
                              .withColumnRenamed("TRN_SEQ_NBR_EXP", "TRN_SEQ_NBR")                              
            
  val case7OutDF = Seq(
      ("CN","880630","4"),("CN","880632","5"),("CN","880633","6")
  ).toDF("CAR_INIT","CAR_NUMB","TRN_SEQ_NBR")
  
  val reorderedCase7FinalDF = reorderColsInDataFrame(case7OutDF.columns,case7FinalDF)
  val difference7DF = reorderedCase7FinalDF.except(case7OutDF)
  val diffCount7 = difference7DF.count()
  assertTrue("With Array to Zip udf > explode > select projection there should not be any difference between testDF and expectedDF",(diffCount7)==0)
  }
 
  @Test def isEmptyCheck(){
  //Positive Test Case 1 
  val case3 = ""
  val case3Final = CommonsUtil.isEmpty(case3)
  val case3out = true
  assertEquals("There should not be any difference between isEmpty output and expected output",case3Final,case3out)
  //Positive Test Case 2
  val case4 = " "
  val case4Final = CommonsUtil.isEmpty(case4)
  val case4out = true
  assertEquals("There should not be any difference between isEmpty output and expected output",case3Final,case3out)
  //Negative Test Case
  val case5 = "CN"
  val case5Final = CommonsUtil.isEmpty(case5)
  val case5out = false
  assertEquals("There should not be any difference between isEmpty output and expected output",case3Final,case3out)
  }

 @Test def buildErrorJsonForPGJobsCheck(){
 //Positive Test Case
 val case10DF = Seq(("CN","880630","{\"ConveyorAssociated\":{\"Domain_Event_Type_Key\":\"8eb3e769649d98d5e896398ded3b7bdb63bdaf6d53f440f4b9a8da51e8f74f40\",\"Association_Key\":\"a18c0c400ea5c4e7be2a32e51f0e26857bd248548aa2522ac48ba7133ae542c7\"}}")
  ).toDF("Domain_Event_Type_Key","Association_Key","JSON_DATA")
 val row = case10DF.first
 val rowAsMapData = row.getValuesMap(row.schema.fieldNames)
 val Result = CommonsUtil.buildErrorJsonForPGJobs(rowAsMapData,"ShipmentAssociationDomainLoad","TRANSPORTATION_SHP_ASSOC_PREPARED","PSQLException")
 assertNotNull("The result should not return NULL",Result)
  }
 
  @After
  @Test def after() {
    println("Teardown for CommonUtilsTest")
  }
 }
