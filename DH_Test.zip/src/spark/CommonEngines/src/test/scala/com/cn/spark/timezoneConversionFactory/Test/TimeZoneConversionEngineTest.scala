package com.cn.spark.timezoneConversionFactory.Test

import java.io.InputStream

import com.cn.spark.commonsEngine
import com.cn.spark.configFactory.ApplicationConfigEngine
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.junit.Assert._
import org.junit.{After, Before, Test}
import org.apache.spark.SparkConf
import com.cn.spark.timezoneConversionFactory.TimeZoneConversionEngine
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{abs, col, from_unixtime, unix_timestamp}
import org.apache.spark.sql.types.IntegerType
import org.junit.After
import org.junit.Before


class TimeZoneConversionEngineTest  extends ApplicationConfigEngine{
  @transient lazy val logger: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)

  private lazy val conf = new SparkConf()
    .set("spark.sql.shuffle.partitions", "10") // default shuffle partitions are 200 and good keep small shuffle partitions
    .set("spark.sql.cbo.enabled", applicationConf.getString("spark.sql.cbo.enabled"))
    .set("spark.master", applicationConf.getString("spark.master"))
    .set("spark.serializer", applicationConf.getString("spark.serializer"))
    .set("spark.streaming.stopGracefullyOnShutdown", applicationConf.getString("spark.streaming.stopGracefullyOnShutdown"))
    .set("spark.sql.crossJoin.enabled", applicationConf.getString("spark.sql.crossJoin.enabled"))
    .set("spark.streaming.backpressure.enabled", applicationConf.getString("spark.streaming.backpressure.enabled"))
    .set("spark.streaming.kafka.consumer.poll.ms", applicationConf.getString("spark.streaming.kafka.consumer.poll.ms"))

  implicit lazy val spark: SparkSession = SparkSession.builder
    .config(conf)
    .getOrCreate()

  var folderPath : String = ""

  //TODO: Move this to commons. Handle null comparisions
  def reorderColumnsInDataFrame(inputDFColArray: Array[String], df: DataFrame): DataFrame = {
    try{
      //if only array is not null
      val reorderedColumnNames: Array[String] = inputDFColArray
      df.select(reorderedColumnNames.head, reorderedColumnNames.tail: _*)
    }
    catch {
      case ex: Exception => {
        logger.error(ex.printStackTrace());
        null
      }
    }
  }

  @Before
  @Test def before() {
    println("Setup for TimeZoneConversionEngineTest")
    logger.setLevel(Level.ERROR)
    folderPath = getClass.getResource("/tz_dst.csv/..").getPath
  }

  //--------------------------------------------------------------------readFromFile-----------------------------------------------------------------------
  //Positive Testcases - readFromFile
  val filPath = getClass.getResource("/tz_dst.csv").getPath

  val inputDF = spark.read.option("header",true).option("inferschema",true).csv(filPath).toDF()
  val actualDF = TimeZoneConversionEngine.readFromFile(filPath)

  @Test def readFromFileCountRows() {
    assertEquals("Result of the file read using the TimeZoneConversionEngine.readFromFile and spark defualt should be the same",inputDF.count(),actualDF.count())
  }

  @Test def readFromFileCompareDataFrame() {
    //getDataFromFile("",False)
    inputDF.show()
    actualDF.show()
    val differenceDF = actualDF.except(inputDF)
    val diffCount = differenceDF.count()
    assertTrue("Comparison for DF read from file should result in no difference",(diffCount)==0)
  }

  //Negative Testcases - readFromFile
  @Test def readFromFileIsEmptyPath() {
    assertNull("Reading file from empty path should be handled and null to be returned",TimeZoneConversionEngine.readFromFile(""))
  }

  @Test def readFromFileIsNullPath() {
    assertNull("Reading file from null path should be handled and null to be returned",TimeZoneConversionEngine.readFromFile(null))
  }

  @Test def readFromFileIsWrongPath() {
    assertNull("Reading file from wrong path should be handled and null to be returned",TimeZoneConversionEngine.readFromFile("\\test\\tz_dst.csv"))
  }

  //--------------------------------------------------------------------readTimeZoneReferenceFiles-----------------------------------------------------------------------
  //Negative Testcases - readTimeZoneReferenceFiles
  @Test def readTimeZoneReferenceFilesIsEmptyPath() {
    assertNull("Reading TZ Ref files from empty path should be handled and null to be returned",TimeZoneConversionEngine.readFromFile(""))
  }

  @Test def readTimeZoneReferenceFilesIsNullPath() {
    assertNull("Reading TZ Ref files from null path should be handled and null to be returned",TimeZoneConversionEngine.readFromFile(null))
  }

  @Test def readTimeZoneReferenceFilesIsWrongPath() {
    assertNull("Reading TZ Ref files from wrong path should be handled and null to be returned",TimeZoneConversionEngine.readFromFile("\\test"))
  }

  //Positive Testcases - readFromFile
  @Test def readTimeZoneReferenceFilesCountRows() {
    val df = TimeZoneConversionEngine.readTimeZoneReferenceFiles(folderPath)
    assertEquals("Reading TZ Ref files and generation of reference data count should return 4547 rows",df.count(),4547)
  }

  //--------------------------------------------------------------------generateTimeZoneRefData-----------------------------------------------------------------------
  //TODO - smaller set
  //Positive Testcases - generateTimeZoneRefData - Covered as part of the test readTimeZoneReferenceFilesCountRows

  //Negative Testcases - generateTimeZoneRefData
  @Test def generateTimeZoneRefDataIsHandlingBadInput() {
    assertNull("Generate ReferenceData from null path should be handled and null to be returned",TimeZoneConversionEngine.generateTimeZoneRefData(null,null,null))
  }

  //--------------------------------------------------------------------ConvertToUTCStation-----------------------------------------------------------------------

  //Common Testcases - toUTCConversion
  @Test def convertToUTCStationCompare() {
    import spark.implicits._
    //enable only on local mode to test this individual method
    //folderPath = getClass.getResource("/tz_dst.csv/..").getPath
    val df = TimeZoneConversionEngine.readTimeZoneReferenceFiles(folderPath)
    //df.write.format("csv").option("header",true).mode("overwrite").save("C:\\Users\\189611\\Configurations\\files\\output.csv")
    val tzDataDF = spark.sparkContext.broadcast(df)
    import spark.implicits._

    //with TIME_ZONE
    val case1DF = Seq(
      ("2020-01-12 01:00:00.001", "BRAINTTER","ON","2020",commonsEngine.Constants.ET),
      ("2020-01-13 01:00:00.000", "BRAINTTER","ON","2020",commonsEngine.Constants.CT)
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","TIME_ZONE")
    val case1FinalDF = TimeZoneConversionEngine.toUTCConversion(case1DF, tzDataDF.value, "333")
    val caseOut1DF = Seq(
      ("2020-01-12 01:00:00.001", "BRAINTTER","ON","2020",commonsEngine.Constants.ET,"2020-01-12 06:00:00.001","106",null,"CN","42368"),
      ("2020-01-13 01:00:00.000", "BRAINTTER","ON","2020",commonsEngine.Constants.CT,"2020-01-13 06:00:00.000","106",null,"CN","42368")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","TIME_ZONE","UTC_TIME_FORMATTED","TZ_DST_CD","DST","STN_SCAC","FSAC")
    val reorderedCase1FinalDF = reorderColumnsInDataFrame(caseOut1DF.columns,case1FinalDF)
    val difference1DF = reorderedCase1FinalDF.except(caseOut1DF)
    val diffCount1 = difference1DF.count()
    assertTrue("With TIME_ZONE there should not be any difference between testDF and expectedDF",(diffCount1)==0)

    //with TIME_ZONE and DST
    val case2DF = Seq(
      ("2020-01-12 01:00:00.000", "BRAINTTER","ON","2020","ET","Y","NT"),
      ("2020-01-13 01:00:00.500", "BRAINTTER","ON","2020","CT","N","NT")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","TIME_ZONE","DST","TIMEZONE_LBL")
    val case2FinalDF = TimeZoneConversionEngine.toUTCConversion(case2DF, tzDataDF.value, "333")
    case2FinalDF.show(20,false)
    val caseOut2DF = Seq(
      ("2020-01-12 01:00:00.000", "BRAINTTER","ON","2020","ET","Y","2020-01-12 05:00:00.000","NT","105"),
      ("2020-01-13 01:00:00.500", "BRAINTTER","ON","2020","CT","N","2020-01-13 07:00:00.500","NT","108")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","TIME_ZONE","DST","UTC_TIME_FORMATTED","TIMEZONE_LBL","TZ_DST_CD")

    val reorderedCase2FinalDF = reorderColumnsInDataFrame(caseOut2DF.columns,case2FinalDF)
    val difference2DF = reorderedCase2FinalDF.except(caseOut2DF)
    val diffCount2 = difference2DF.count()
    assertTrue("With TIME_ZONE and DST there should not be any difference between testDF and expectedDF",(diffCount2)==0)

    //with NO TIME_ZONE and no StationKey, no DST
    val case3DF = Seq(
      ("2020-01-12 01:00:00.090", "BRAINTTER","ON","2020")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR")
    val case3FinalDF = TimeZoneConversionEngine.toUTCConversion(case3DF, tzDataDF.value, "")
    val caseOut3DF = Seq(
      ("2020-01-12 01:00:00.090", "BRAINTTER","ON","2020","2020-01-12 01:00:00.090",null)
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","UTC_TIME_FORMATTED","TZ_DST_CD")
    val reorderedCase3FinalDF = reorderColumnsInDataFrame(caseOut3DF.columns,case3FinalDF)
    val difference3DF = reorderedCase3FinalDF.except(caseOut3DF)
    val diffCount3 = difference3DF.count()
    assertTrue("With no TIME_ZONE and no DST and no station UTC is same as Local",(diffCount3)==0)
    assert(case3FinalDF.select("UTC_TIME_FORMATTED").head().getString(0)==caseOut3DF.select("UTC_TIME_FORMATTED").head.getString(0))

    //with NO TIME_ZONE but with StationKey and DST
    val case4DF = Seq(
      ("2020-01-12 01:00:00.999", "BRAINTTER","ON","2020","Y"),
      ("2019-01-13 01:00:00.000", "BRAINTTER","ON","2019","N")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","DST")
    val case4FinalDF = TimeZoneConversionEngine.toUTCConversion(case4DF, tzDataDF.value, "333")
    val caseOut4DF = Seq(
      ("2020-01-12 01:00:00.999", "BRAINTTER","ON","2020","Y","2020-01-12 05:00:00.999","105"),
      ("2019-01-13 01:00:00.000", "BRAINTTER","ON","2019","N","2019-01-13 06:00:00.000","106")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","DST","UTC_TIME_FORMATTED","TZ_DST_CD")
    val reorderedCase4FinalDF = reorderColumnsInDataFrame(caseOut4DF.columns,case4FinalDF)
    val difference4DF = reorderedCase4FinalDF.except(caseOut4DF)
    val diffCount4 = difference4DF.count()
    assertTrue("With no TIME_ZONE but with station/dst there should not be any difference between testDF and expectedDF",(diffCount4)==0)

    //with NO TIME_ZONE but with StationKey and no DST
    val case5DF = Seq(
      ("2020-01-12 01:00:00.000", "BRAINTTER","ON","2020")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR")
    val case5FinalDF = TimeZoneConversionEngine.toUTCConversion(case5DF, tzDataDF.value, "333")
    val caseOut5DF = Seq(
      ("2020-01-12 01:00:00.000", "BRAINTTER","ON","2020","2020-01-12 06:00:00.000","106")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","UTC_TIME_FORMATTED","TZ_DST_CD")
    val reorderedCase5FinalDF = reorderColumnsInDataFrame(caseOut5DF.columns,case5FinalDF)
    val difference5DF = reorderedCase5FinalDF.except(caseOut5DF)
    val diffCount5 = difference5DF.count()
    assertTrue("With no TIME_ZONE, no dst but with station there should not be any difference between testDF and expectedDF",(diffCount5)==0)

    //within DST period
    val case6DF = Seq(
        ("2020-08-08 01:00:00.100", "BRAINTTER","ON","2020","")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","DST")
    val case6FinalDF = TimeZoneConversionEngine.toUTCConversion(case6DF, tzDataDF.value, "333")
    assertTrue(case6FinalDF.select("UTC_TIME_FORMATTED").head().getString(0)=="2020-08-08 05:00:00.100")

    //outside DST period
    val case7DF = Seq(
      ("2020-12-12 01:00:00.000", "BRAINTTER","ON","2020","")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","DST")
    val case7FinalDF = TimeZoneConversionEngine.toUTCConversion(case7DF, tzDataDF.value, "333")
    val caseOut7DF = Seq(
      ("2020-12-12 01:00:00.000", "BRAINTTER","ON","2020","","2020-12-12 06:00:00.000","106")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","DST","UTC_TIME_FORMATTED","TZ_DST_CD")
    val reorderedCase7FinalDF = reorderColumnsInDataFrame(caseOut7DF.columns,case7FinalDF)
    val difference7DF = reorderedCase7FinalDF.except(caseOut7DF)
    val diffCount7 = difference7DF.count()
    assertTrue("Outside DST period there should not be any difference between testDF and expectedDF",(diffCount7)==0)

    //no records should be filtered out even if we have no station entry
    val case8DF = Seq(
      ("2020-01-13 01:00:00.000", "BRAINTTERS","ON","2020","N")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","DST")
    val case8FinalDF = TimeZoneConversionEngine.toUTCConversion(case8DF, tzDataDF.value, "333")
    val caseOut8DF = Seq(
       ("2020-01-13 01:00:00.000", "BRAINTTERS","ON","2020","N",null,null)
     ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","DST","UTC_TIME_FORMATTED","TZ_DST_CD")
     val reorderedCase8FinalDF = reorderColumnsInDataFrame(caseOut8DF.columns,case8FinalDF)
     val difference8DF = reorderedCase8FinalDF.except(caseOut8DF)
     val diffCount8 = difference8DF.count()
     assertTrue("With no station there should not be any filtering done and these should nto exist any difference between testDF and expectedDF",(diffCount8)==0)

    //return null if stationKey is null
    assertNotNull("return null if stationKey is null",TimeZoneConversionEngine.toUTCConversion(case8DF, tzDataDF.value, null))

    //return null if stationKey is not scac or 333
    assertNull("return null if stationKey is not scac or 333",TimeZoneConversionEngine.toUTCConversion(case8DF, tzDataDF.value, "test"))

    val case9DF = Seq(
      ("2020-01-13 01:00:00.000", "BRAINTTERS","ON","N")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","DST")
    //return null if LOCAL_TIME is null
    assertNull("return null if LOCAL_TIME is null",TimeZoneConversionEngine.toUTCConversion(case9DF, tzDataDF.value, null))

    //no records should be filtered out even if we have no TZ entry
    val case10DF = Seq(
      ("2020-01-12 01:00:00.000", "BRAINTTER","ON","2020","ETA","Y","NT"),
      ("2020-01-13 01:00:00.000", "BRAINTTER","ON","2020","CTA","N","NT")
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","TIME_ZONE","DST","TIMEZONE_LBL")
    val case10FinalDF = TimeZoneConversionEngine.toUTCConversion(case10DF, tzDataDF.value, "333")
    val caseOut10DF = Seq(
      ("2020-01-12 01:00:00.000", "BRAINTTER","ON","2020","ETA","Y",null,"NT",null),
      ("2020-01-13 01:00:00.000", "BRAINTTER","ON","2020","CTA","N",null,"NT",null)
    ).toDF("LOCAL_TIME", "STN_333", "STN_PRST","LOCAL_YEAR","TIME_ZONE","DST","UTC_TIME_FORMATTED","TIMEZONE_LBL","TZ_DST_CD")

    val reorderedCase10FinalDF = reorderColumnsInDataFrame(caseOut10DF.columns,case10FinalDF)
    val difference10DF = reorderedCase10FinalDF.except(caseOut10DF)
    val diffCount10 = difference10DF.count()
    assertTrue("With no TIME_ZONE match we should have null utc column",(diffCount10)==0)

    //within DST period - CHECK WITH FSAC
    val case11DF = Seq(
        ("2020-08-08 01:00:00.100", "CN","58346","2020","")
    ).toDF("LOCAL_TIME", "STN_SCAC", "FSAC","LOCAL_YEAR","DST")
    val case11FinalDF = TimeZoneConversionEngine.toUTCConversion(case11DF, tzDataDF.value, "SCAC")
    assertTrue(case11FinalDF.select("UTC_TIME_FORMATTED").head().getString(0)=="2020-08-08 06:00:00.100")

  }

  //Negative Testcases - toUTCConversion
  @Test def convertToUTCStationIsHandlingNullInputs(): Unit = {
    assertNull("When passed null inputs the error should be handled and return null", TimeZoneConversionEngine.toUTCConversion(null, null, "333"))
  }

  import org.apache.spark.sql.functions.{ col, lit,concat }

  @Test def test_ms(): Unit = {
    val timeZoneFormat = "YYYY-MM-dd HH:mm:ss:SSS"
    import spark.implicits._
    val case11DF = Seq(
      ("2020-08-08 01:00:00:100","5")
    ).toDF("LOCAL_TIME","UTC_OFST_VAL_HR_DST_NO")
    val inputDFFormatted =  case11DF
      .withColumn("LOCAL_TIME_FORMATTED",col("LOCAL_TIME"))
      .withColumn("MILLISECOND_ONLY",col("LOCAL_TIME_FORMATTED").substr(-3,3))
      .withColumn("final",   from_unixtime(unix_timestamp(col("LOCAL_TIME_FORMATTED")).plus(abs(col("UTC_OFST_VAL_HR_DST_NO").cast(IntegerType)) * 60 * 60), timeZoneFormat))
      .withColumn("final_with_ms",concat(col("final"),lit("."),col("MILLISECOND_ONLY")))
    inputDFFormatted.show(20,false)
  }

  @After
  @Test def after() {
    println("Teardown for TimeZoneConversionEngineTest")
  }
}