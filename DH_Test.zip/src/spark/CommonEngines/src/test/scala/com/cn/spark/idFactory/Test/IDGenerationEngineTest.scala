package com.cn.spark.idFactory.Test

import com.cn.spark.configFactory.ApplicationConfigEngine
import org.apache.log4j.Logger
import org.junit.Test
import org.junit.Assert._
import com.cn.spark.idFactory.IDGenerationEngine
import org.junit.Before
import org.apache.spark.sql.functions._
import org.junit.After
import com.cn.spark.commonsEngine.Test.CommonsUtilTest
import org.apache.log4j.Level
import com.cn.spark.configFactory.Test.SparkSessionConfigEngineTest

class IDGenerationEngineTest extends SparkSessionConfigEngineTest{
  @transient lazy val logger: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)
import spark.implicits._
    @Before
    @Test def before() {
    println("Setup for IDGenerationEngineTest")
    logger.setLevel(Level.ERROR)
  }
  
  val sampleInputData = Seq(("CN", "880630", "4"), ("CN", "880632", "5"), ("CN", "880633", "6"))
  val inputDF = sampleInputData.toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR")
  val actualDF = IDGenerationEngine.createKeyForDF(inputDF, "TrainConsist", List("CAR_INIT", "CAR_NUMB"))
  val expectedDF=Seq(("CN", "880630", "4","9b9cadbeb070192b46337a22fab361b8e7e60ac00edd639ceadb144649bd482d"), 
      ("CN", "880632", "5","530f8b12063fb2b62851a66e7df36f2ddc0ec59f7b6cf05ef74b78589912ce5c"), 
      ("CN", "880633", "6","0d8ffb9397ee0935edd9d6196ae68f63bc7d47fd7c263bed0b0884d51e5e19ae")).toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR","TrainConsist")
  
  @Test
  def createKeyCompare(){
    val reorderedDF=new CommonsUtilTest().reorderColsInDataFrame(expectedDF.columns, actualDF)
    val differenceDF = reorderedDF.except(expectedDF)
    val diffCount = differenceDF.count()
    assertTrue("There should be no difference between expected and Transform dataframe",(diffCount)==0)
  }
  
  @After
  @Test def after() {
    println("Teardown for IDGenerationEngineTest")
  }
}
