package com.cn.spark.configFactory.Test

import java.util.Properties
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import com.typesafe.config.Config
import com.typesafe.config.ConfigFactory

trait SparkSessionConfigEngineTest {

  val applicationConf = ConfigFactory.load("application.conf")
  private lazy val conf = new SparkConf()
    .set("spark.sql.shuffle.partitions", "10") // default shuffle partitions are 200 and good keep small shuffle partitions
    .set("spark.sql.cbo.enabled", applicationConf.getString("spark.sql.cbo.enabled"))
    .set("spark.master", applicationConf.getString("spark.master")) // need to remove while running in cluster
    .set("spark.serializer", applicationConf.getString("spark.serializer"))
    .set("spark.streaming.stopGracefullyOnShutdown", applicationConf.getString("spark.streaming.stopGracefullyOnShutdown"))
    .set("spark.sql.crossJoin.enabled", applicationConf.getString("spark.sql.crossJoin.enabled")) //getting crossjoin error
    .set("spark.streaming.backpressure.enabled", applicationConf.getString("spark.streaming.backpressure.enabled"))
    .set("spark.streaming.kafka.consumer.poll.ms", applicationConf.getString("spark.streaming.kafka.consumer.poll.ms"))

  implicit lazy val spark: SparkSession = SparkSession.builder
    .config(conf)
    .getOrCreate()
}

