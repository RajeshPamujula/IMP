package com.cn.spark.notificationFactory.Test

import com.cn.spark.configFactory.ApplicationConfigEngine
import org.apache.log4j.Logger
import com.cn.spark.notificationFactory.ErrorNotificationEngine
import org.junit.Test
import org.junit.Assert._
import org.apache.spark.sql.functions._
import com.cn.spark.commonsEngine.Test.CommonsUtilTest
import org.junit.After
import org.junit.Before
import org.apache.log4j.Level
import com.cn.spark.configFactory.Test.SparkSessionConfigEngineTest

class ErrorNotificationEngineTest extends SparkSessionConfigEngineTest{
  @transient lazy val logger: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)
import spark.implicits._  

  @Before
  @Test def before() {

    println("Setup for ErrorNotificationEngineTest")
    logger.setLevel(Level.ERROR)
  }

  //--------------------------------------------------------------------addErrorColumnForDF-----------------------------------------------------------------------

  val inputData = Seq(("NCLX", "00042", "165", null), ("PROX", "031145", null, "S"))
  val inputDF = inputData.toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR", "BO_CD")
  val actualDF = ErrorNotificationEngine.addErrorColumnForDF(inputDF, List("TRN_SEQ_NBR", "BO_CD"))
  val expectedData = Seq(("NCLX", "00042", "165", null, "BO_CD is NULL"), ("PROX", "031145", null, "S", "TRN_SEQ_NBR is NULL"))
  val expectedDF = expectedData.toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR", "BO_CD", "ERROR_KEY")

  @Test
  def addErrorColumnCompare() {
    // Filling the null values with 0 for dataframe Compare
    val transformactualDF = actualDF.na.fill(0)
    val transformExpectedDF = expectedDF.na.fill(0)

    val reorderedDF = new CommonsUtilTest().reorderColsInDataFrame(transformExpectedDF.columns, transformactualDF)
    val differenceDF = reorderedDF.except(transformExpectedDF)
    val diffCount = differenceDF.count()
    assertTrue("There should be no difference between expected and Transform dataframe", (diffCount) == 0)
  }

  //--------------------------------------------------------------------filterErrorMessage-----------------------------------------------------------------------

  val inputData1 = Seq(("NCLX", "00042", "165", null, "BO_CD is NULL"), ("PROX", "031145", null, "S", "TRN_SEQ_NBR is NULL"), ("NCLX", "000212", "187", "F", ""))
  val inputDF1 = inputData1.toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR", "BO_CD", "ERROR_KEY")
  val actualDF1 = ErrorNotificationEngine.filterErrorMessage(inputDF1)
  val expectedDF1 = Seq(("NCLX", "00042", "165", null, "BO_CD is NULL"), ("PROX", "031145", null, "S", "TRN_SEQ_NBR is NULL"))
    .toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR", "BO_CD", "ERROR_KEY")

  @Test
  def filterErrorMessageCompare() {
    val reorderedDF = new CommonsUtilTest().reorderColsInDataFrame(expectedDF1.columns, actualDF1)
    val differenceDF = reorderedDF.except(expectedDF1)
    val diffCount = differenceDF.count()
    assertTrue("There should be no difference between expected and Transform dataframe", (diffCount) == 0)
  }

  //--------------------------------------------------------------------filterCorrectMessage-----------------------------------------------------------------------

  val inputDataDF2 = Seq(("NCLX", null, "165", "     CAR_NUMB is NULL     ")).toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR", "ERROR_KEY")
  val actualDF2 = ErrorNotificationEngine.filterCorrectMessage(inputDataDF2)
  val expectedDF2 = Seq(("NCLX", null, "165", "CAR_NUMB is NULL")).toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR", "ERROR_KEY")

  @Test
  def filterCorrectMessageCompare() {
    val reorderedDF = new CommonsUtilTest().reorderColsInDataFrame(expectedDF2.columns, actualDF2)
    val differenceDF = reorderedDF.except(expectedDF2)
    val diffCount = differenceDF.count()
    assertTrue("There should be no difference between expected and Transform dataframe", (diffCount) == 0)
  }
  //--------------------------------------------------------------------dropColumn------------------------------------------------------------------------

  val inputDataDF3 = Seq(("NCLX", "00042", "165", ""), ("PROX", "031145", "133", "")).toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR", "BO_CD")
  val actualDF3 = ErrorNotificationEngine.dropColumn(inputDataDF3, "BO_CD")
  val expectedDF3 = Seq(("NCLX", "00042", "165"), ("PROX", "031145", "133")).toDF("CAR_INIT", "CAR_NUMB", "TRN_SEQ_NBR")

  @Test
  def dropColumnCompare() {
    val reorderedDF = new CommonsUtilTest().reorderColsInDataFrame(expectedDF3.columns, actualDF3)
    val differenceDF = reorderedDF.except(expectedDF3)
    val diffCount = differenceDF.count()
    assertTrue("There should be no difference between expected and Transform dataframe", (diffCount) == 0)
  }

  @After
  @Test def after() {
    println("Teardown for ErrorNotificationEngineTest")
  }
}