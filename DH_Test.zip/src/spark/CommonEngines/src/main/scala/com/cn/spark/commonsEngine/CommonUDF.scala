package com.cn.spark.commonsEngine

import java.util.{Calendar}
import org.apache.log4j.Logger
import scala.collection.immutable.HashMap
import org.apache.spark.sql.functions.udf

object CommonUDF {
  val logger = Logger.getLogger(getClass.getName)



  //Method call Implementations
  val getDateTimeStrFromSplitData = (year: String, month: String, dayOfWeek: String, weekOfMonth: String, ts: String) => {
    try {
      val cacheCalendar = Calendar.getInstance()
      //Gregorian calendar by default
      val daysOfWeek = HashMap((1 -> Calendar.SUNDAY), (2 -> Calendar.MONDAY), (3 -> Calendar.TUESDAY), (4 -> Calendar.WEDNESDAY), (5 -> Calendar.THURSDAY), (6 -> Calendar.FRIDAY), (7 -> Calendar.SATURDAY))
      val months = HashMap((1 -> Calendar.JANUARY), (2 -> Calendar.FEBRUARY), (3 -> Calendar.MARCH), (4 -> Calendar.APRIL), (5 -> Calendar.MAY), (6 -> Calendar.JUNE), (7 -> Calendar.JULY), (8 -> Calendar.AUGUST), (9 -> Calendar.SEPTEMBER), (10 -> Calendar.OCTOBER), (11 -> Calendar.NOVEMBER), (12 -> Calendar.DECEMBER))

      cacheCalendar.set(Calendar.YEAR, year.toInt)
      cacheCalendar.set(Calendar.MONTH, months.get(month.toInt).get)
      cacheCalendar.set(Calendar.DAY_OF_WEEK_IN_MONTH, weekOfMonth.toInt)
      cacheCalendar.set(Calendar.DAY_OF_WEEK, daysOfWeek.get(dayOfWeek.toInt).get)
      val date = cacheCalendar.get(Calendar.DATE)
      val dateTime = year + "-" + month + "-" + date + " " + ts
      dateTime
    }
    catch {
      case ex: Exception => {
        logger.error(ex.printStackTrace());
        null
      }
    }
  }

  //UDF Declarations
  val getDateTimeStrFromSplitDataUDF = udf(getDateTimeStrFromSplitData)
}