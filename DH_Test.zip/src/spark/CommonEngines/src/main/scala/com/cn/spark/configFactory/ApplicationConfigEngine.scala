package com.cn.spark.configFactory

import scala.collection.mutable.Map

import org.apache.log4j.Logger

import com.typesafe.config.Config

trait ApplicationConfigEngine {

  @transient lazy val applicationConf: Config = MainConfigEngine.load();
  @transient lazy val environmentValues = System.getenv()
  @transient lazy val loggerConfig = Logger.getLogger(getClass.getName)

}