package com.cn.spark.commonsEngine

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import scala.collection.Seq

object Schema {
    val referenceDataSchema = StructType(Seq(
    StructField("type_cd", StringType, false),
    StructField("prnt_type_cd", StringType, false)))
  }
