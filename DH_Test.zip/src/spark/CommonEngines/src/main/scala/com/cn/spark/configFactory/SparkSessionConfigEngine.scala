package com.cn.spark.configFactory

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

/***
 *  Helps to maintain single spark session object
 *  Common place to make spark config changes
 * 
 *  @author Ramanjee Madasu
 */

trait SparkSessionConfigEngine extends ApplicationConfigEngine {

  private lazy val conf = new SparkConf()
    .set("spark.sql.shuffle.partitions", applicationConf.getString("spark.sql.shuffle.partitions")) // default shuffle partitions are 200 and good keep small shuffle partitions
    .set("spark.sql.cbo.enabled", applicationConf.getString("spark.sql.cbo.enabled"))
    .set("spark.master", applicationConf.getString("spark.master")) // need to remove while running in cluster
    .set("spark.serializer", applicationConf.getString("spark.serializer"))
    .set("spark.streaming.stopGracefullyOnShutdown", applicationConf.getString("spark.streaming.stopGracefullyOnShutdown"))
    .set("spark.sql.crossJoin.enabled", applicationConf.getString("spark.sql.crossJoin.enabled")) //getting crossjoin error
    .set("spark.streaming.backpressure.enabled", applicationConf.getString("spark.streaming.backpressure.enabled"))
    .set("spark.streaming.kafka.consumer.poll.ms", applicationConf.getString("spark.streaming.kafka.consumer.poll.ms"))
    
    

  implicit lazy val spark: SparkSession = SparkSession.builder
    .config(conf)
    .getOrCreate()
}
