package com.cn.spark.timezoneConversionFactory

import java.util.Calendar

import com.cn.spark.commonsEngine.CommonUDF.getDateTimeStrFromSplitDataUDF
import org.apache.spark.sql.functions.{ col, lit,concat }
import com.cn.spark.configFactory.SparkSessionConfigEngine
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, LongType}

object TimeZoneConversionEngine extends SparkSessionConfigEngine {

  val logger = Logger.getLogger(getClass.getName)

  @Override
  def generateTimeZoneRefData(station_tz_dst_DF: DataFrame, dst_rule_DF: DataFrame, tz_dst_DF: DataFrame): DataFrame = {
    logger.debug("Start :: generateTimeZoneRefData")
    try {
      //dst rule filter unnecessary columns
      val curr_year = Calendar.getInstance.get(Calendar.YEAR)

      //Filter dst_data rules for latest/valid year
      val dstRuleGroupByDF = dst_rule_DF.groupBy("DST_RULE_ID").agg(max("DST_VALD_YR").as("DST_VALD_YR_MAX"))
      val dstRuleFinalDF = dstRuleGroupByDF.join(dst_rule_DF, "DST_RULE_ID").filter(col("DST_VALD_YR") === col("DST_VALD_YR_MAX"))
        .withColumn("CURR_YEAR", lit(curr_year))
        .withColumn("CURRENTYR_START_DST", getDateTimeStrFromSplitDataUDF(col("CURR_YEAR"), col("DST_STRT_MTH"), col("DST_STRT_DOW"), col("DST_STRT_MTH_DOW_OCUR"), col("DST_STRT_TM")))
        .withColumn("CURRENTYR_END_DST", getDateTimeStrFromSplitDataUDF(col("CURR_YEAR"), col("DST_END_MTH"), col("DST_END_DOW"), col("DST_END_MTH_DOW_OCUR"), col("DST_END_TM")))
      //print("dstRuleFinalDF count " + dstRuleFinalDF.count())
      //station rule association
      val stationRuleAssociationFinalDF = station_tz_dst_DF.join(dstRuleFinalDF, station_tz_dst_DF("DST_RULE_ID") === dstRuleFinalDF("DST_RULE_ID"), "left")
      //time zone transformations
      val tzDstTransformDF = tz_dst_DF
        //Confirmed with Simon that UTC will never have DST hence we are good in the following scenario
        .withColumn("UTC_OFST_VAL_HR_DST_YES", when(col("DST_IND") === "Y", col("UTC_OFST_VAL_HR")).otherwise("0.0"))
        .withColumn("UTC_OFST_VAL_HR_DST_NO", when(col("DST_IND") === "N", col("UTC_OFST_VAL_HR")).otherwise("0.0"))
        .withColumn("TZ_DST_CD_YES", when(col("DST_IND") === "Y", col("TZ_DST_CD").cast(IntegerType)))
        .withColumn("TZ_DST_CD_NO", when(col("DST_IND") === "N", col("TZ_DST_CD").cast(IntegerType)))
      val tzDstGroupByDF = tzDstTransformDF.groupBy(col("TZ_LBL")).agg(min("UTC_OFST_VAL_HR_DST_YES").as("UTC_OFST_VAL_HR_DST_YES"), min("UTC_OFST_VAL_HR_DST_NO").as("UTC_OFST_VAL_HR_DST_NO"),max("TZ_DST_CD_YES").as("TZ_DST_CD_YES"),max("TZ_DST_CD_NO").as("TZ_DST_CD_NO"))
      //rule timezone association
      val stationRuleTimeZoneAssociationFinalDF = stationRuleAssociationFinalDF.join(tzDstGroupByDF, stationRuleAssociationFinalDF("OPER_TZ_LBL") === tzDstGroupByDF("TZ_LBL"),"left").select("STN_SCAC", "FSAC", "STN_333", "STN_PRST", "DST_IND", "OPER_TZ_LBL", "OPER_DST_RULE_ID", "DST_VALD_YR", "DST_STRT_MTH", "DST_STRT_DOW", "DST_STRT_MTH_DOW_OCUR", "DST_STRT_TM", "DST_END_MTH", "DST_END_DOW", "DST_END_MTH_DOW_OCUR", "DST_END_TM", "CURRENTYR_START_DST", "CURRENTYR_END_DST", "UTC_OFST_VAL_HR_DST_YES", "UTC_OFST_VAL_HR_DST_NO", "TZ_DST_CD_YES", "TZ_DST_CD_NO")
      logger.debug("End :: generateTimeZoneRefData")
      stationRuleTimeZoneAssociationFinalDF
    }
    catch {
      case ex: Exception => {
        logger.error(ex.printStackTrace());
        null
      }
    }
  }

  /* Mandatory columns in inputDF are : LOCAL_TIME (format : YYYY-MM-dd HH:mm:ss.SSS), LOCAL_YEAR, DST, (STN_SCAC & FSAC) OR (STN_333 & STN_PRST)
     Optional columns in inputDF are : DST, TIME_ZONE (Bur if these exist then they should exist with the same name)
     Mandatory variable : stationKey - either can be SCAC or 333
     common for time_zone 2024-01-12 01:00:00 and all columns that will be used here should be trimmed in common transformations for each publish job*/
  def toUTCConversion(inputDF: DataFrame, refData: DataFrame, stationKey: String): DataFrame = {
    try {
      val timeZoneFormat = "yyyy-MM-dd HH:mm:ss"
      val inputDFFormatted = inputDF
          .withColumn("MILLISECOND_ONLY", expr("substring(LOCAL_TIME, instr(LOCAL_TIME,'.')+1, length(LOCAL_TIME)-1)"))

      if (!inputDFFormatted.columns.contains("LOCAL_TIME") || !inputDFFormatted.columns.contains("LOCAL_YEAR")) {
        logger.error("LOCAL_TIME or LOCAL_YEAR is missing " + inputDFFormatted("LOCAL_TIME") + "or" + inputDFFormatted("LOCAL_YEAR"))
        return null
      }
      var inputAndReferenceAssociationDF = spark.emptyDataFrame
      var inputUpdatedDF = spark.emptyDataFrame
      var finalDF = spark.emptyDataFrame

      //If TIME_ZONE exist and DST exist
      if (inputDFFormatted.columns.contains("TIME_ZONE") && inputDFFormatted.columns.contains("DST")) {
        val tz_dst_recreation = refData.select(col("OPER_TZ_LBL"),col("UTC_OFST_VAL_HR_DST_YES"),col("UTC_OFST_VAL_HR_DST_NO"),col("TZ_DST_CD_YES"),col("TZ_DST_CD_NO")).groupBy(col("OPER_TZ_LBL")).agg(min("UTC_OFST_VAL_HR_DST_YES").as("UTC_OFST_VAL_HR_DST_YES"), min("UTC_OFST_VAL_HR_DST_NO").as("UTC_OFST_VAL_HR_DST_NO"), max("TZ_DST_CD_YES").as("TZ_DST_CD_YES"), max("TZ_DST_CD_NO").as("TZ_DST_CD_NO"))
        val resultDF = inputDFFormatted.join(tz_dst_recreation, tz_dst_recreation("OPER_TZ_LBL") === inputDFFormatted("TIME_ZONE"), "left")
        finalDF = resultDF.withColumn("UTC_TIME",
          when(col("DST") === "Y", from_unixtime(unix_timestamp(col("LOCAL_TIME")).plus(abs(col("UTC_OFST_VAL_HR_DST_YES").cast(IntegerType)) * 60 * 60), timeZoneFormat))
            .when(col("DST") === "N", from_unixtime(unix_timestamp(col("LOCAL_TIME")).plus(abs(col("UTC_OFST_VAL_HR_DST_NO").cast(IntegerType)) * 60 * 60), timeZoneFormat)))
          .withColumn("TZ_DST_CD",
            when(col("DST") === "Y", col("TZ_DST_CD_YES"))
              .when(col("DST") === "N", col("TZ_DST_CD_NO")))
        //inputDFFormatted.withColumn("UTC_TIME", expr("to_utc_timestamp(LOCAL_TIME, TIME_ZONE)"))
        //finalDF
      }
      //If TIME_ZONE or/and DST does not exist
      else {
        var stationKeyCleansed = ""
        if (stationKey != null && !stationKey.isEmpty) {
          logger.info("stationKey is missing " + stationKey)
          stationKeyCleansed = stationKey.trim().toLowerCase()
        }
        else {
          //Id station does not exist. Local Time will be UTC Time. Cannot convert without station information being available
          inputUpdatedDF = inputDFFormatted
            .withColumn("UTC_TIME",from_unixtime(unix_timestamp(col("LOCAL_TIME")), timeZoneFormat))
            .withColumn("TZ_DST_CD", lit(null))
            .withColumn("UTC_TIME_FORMATTED", concat(col("UTC_TIME"), lit("."), col("MILLISECOND_ONLY")))
            .drop("MILLISECOND_ONLY")
            .drop("UTC_TIME")
          //return inputUpdatedDF
        }
        //If station exist then check for DST on SOR
        if (!inputDFFormatted.columns.contains("DST")) {
          inputUpdatedDF = inputDFFormatted.withColumn("DST", lit(null))
        } else {
          inputUpdatedDF = inputDFFormatted
        }           
        if (stationKeyCleansed == "scac") {
          inputAndReferenceAssociationDF = inputUpdatedDF.join(refData, Seq("STN_SCAC", "FSAC"), "left")
        }
        else if (stationKeyCleansed == "333") {
          inputAndReferenceAssociationDF = inputUpdatedDF.join(refData, Seq("STN_333", "STN_PRST"), "left")
        }
        else {
          logger.info("stationKey is not valid " + stationKey)
          return null
        }
        val curr_year = Calendar.getInstance.get(Calendar.YEAR)

        //Use pre-calculated START and END times for performance reasons for current year. Activate for previous and future years as well if we see enough volumes that we should consider
        val inputAndReferenceAssociationWithTSInSecDF = inputAndReferenceAssociationDF
          .withColumn("LOCAL_TIME_TS_IN_SEC", to_timestamp(col("LOCAL_TIME")).cast(LongType))
          .withColumn("DST_START_TIME_TS_IN_SEC", to_timestamp(col("CURRENTYR_START_DST")).cast(LongType))
          .withColumn("DST_END_TIME_TS_IN_SEC", to_timestamp(col("CURRENTYR_END_DST")).cast(LongType))
        val inputAndReferenceAssociationWithDSTActDF = inputAndReferenceAssociationWithTSInSecDF.withColumn("DST_ACTIVATION",
          when(col("LOCAL_YEAR") === lit(curr_year),
            when((col("LOCAL_TIME_TS_IN_SEC") - col("DST_START_TIME_TS_IN_SEC") > 0) && (col("LOCAL_TIME_TS_IN_SEC") - col("DST_END_TIME_TS_IN_SEC") < 0), lit("Y")).otherwise(lit("N")))
            .otherwise(when((col("LOCAL_TIME_TS_IN_SEC") - to_timestamp(getDateTimeStrFromSplitDataUDF(col("LOCAL_YEAR"), col("DST_STRT_MTH"), col("DST_STRT_DOW"), col("DST_STRT_MTH_DOW_OCUR"), col("DST_STRT_TM"))).cast(LongType) > 0) && (col("LOCAL_TIME_TS_IN_SEC") - to_timestamp(getDateTimeStrFromSplitDataUDF(col("LOCAL_YEAR"), col("DST_END_MTH"), col("DST_END_DOW"), col("DST_END_MTH_DOW_OCUR"), col("DST_END_TM"))).cast(LongType) < 0), lit("Y")).otherwise(lit("N"))))
        finalDF = inputAndReferenceAssociationWithDSTActDF.withColumn("UTC_TIME",
          when(col("DST") === "Y", from_unixtime(unix_timestamp(col("LOCAL_TIME")).plus(abs(col("UTC_OFST_VAL_HR_DST_YES").cast(IntegerType)) * 60 * 60), timeZoneFormat))
            .when(col("DST") === "N", from_unixtime(unix_timestamp(col("LOCAL_TIME")).plus(abs(col("UTC_OFST_VAL_HR_DST_NO").cast(IntegerType)) * 60 * 60), timeZoneFormat))
            .otherwise(when(col("DST_IND") === "Y",
              when(col("DST_ACTIVATION") === "Y", from_unixtime(unix_timestamp(col("LOCAL_TIME")).plus(abs(col("UTC_OFST_VAL_HR_DST_YES").cast(IntegerType)) * 60 * 60), timeZoneFormat))
                when(col("DST_ACTIVATION") === "N", from_unixtime(unix_timestamp(col("LOCAL_TIME")).plus(abs(col("UTC_OFST_VAL_HR_DST_NO").cast(IntegerType)) * 60 * 60), timeZoneFormat)))
              .otherwise(from_unixtime(unix_timestamp(col("LOCAL_TIME")).plus(abs(col("UTC_OFST_VAL_HR_DST_NO").cast(IntegerType)) * 60 * 60), timeZoneFormat))))
          .withColumn("TZ_DST_CD",
            when(col("DST") === "Y", col("TZ_DST_CD_YES"))
              .when(col("DST") === "N", col("TZ_DST_CD_NO"))
              .otherwise(when(col("DST_IND") === "Y",
                when(col("DST_ACTIVATION") === "Y", col("TZ_DST_CD_YES"))
                  when(col("DST_ACTIVATION") === "N", col("TZ_DST_CD_NO")))
                .otherwise(col("TZ_DST_CD_NO")))
          )
        //finalDF
      }
      finalDF
        .drop("TZ_DST_CD_YES")
        .drop("TZ_DST_CD_NO")
        .drop("DST_IND")
        .drop("OPER_TZ_LBL")
        .drop("OPER_DST_RULE_ID")
        .drop("DST_VALD_YR")
        .drop("DST_STRT_MTH")
        .drop("DST_STRT_DOW")
        .drop("DST_STRT_MTH_DOW_OCUR")
        .drop("DST_STRT_TM")
        .drop("DST_END_MTH")
        .drop("DST_END_DOW")
        .drop("DST_END_MTH_DOW_OCUR")
        .drop("DST_END_TM")
        .drop("CURRENTYR_START_DST")
        .drop("CURRENTYR_END_DST")
        .drop("UTC_OFST_VAL_HR_DST_YES")
        .drop("UTC_OFST_VAL_HR_DST_NO")
        .drop("DST_ACTIVATION")
        .drop("LOCAL_TIME_TS_IN_SEC")
        .drop("DST_START_TIME_TS_IN_SEC")
        .drop("DST_END_TIME_TS_IN_SEC")
        .withColumn("UTC_TIME_FORMATTED", concat(col("UTC_TIME"), lit("."), col("MILLISECOND_ONLY")))
        .drop("MILLISECOND_ONLY")
        .drop("UTC_TIME")
    }
    catch {
      case ex: Exception => {
        logger.error(ex.printStackTrace());
        null
      }
    }
  }

  //TODO: Move this to common file
  def readFromFile(filePath: String): DataFrame = {
    logger.debug("ReferenceDataGenerationEngine Start :: referenceDataFromFile")
    try {
      val referenceDF = spark.read.option("header", true).option("inferschema", true).csv(filePath)
      referenceDF
    }
    catch {
      case ex: Exception => {
        logger.error(s"File $filePath not found " + ex.printStackTrace());
        null
      }
    }
  }

  //TODO : Trim all columns in df udf
  def readTimeZoneReferenceFiles(filePathDir: String): DataFrame = {
    logger.debug("ReferenceDataGenerationEngine Start :: referenceDataFromFile")
    try {
      val station_tz_dst_DF = readFromFile(filePathDir + "/station_tz_dst.csv")
      val dst_rule_DF = readFromFile(filePathDir + "/dst_rule.csv")
      val tz_dst_DF = readFromFile(filePathDir + "/tz_dst.csv")
     /* print("station_tz_dst_DF count " + station_tz_dst_DF.count())
      print("dst_rule_DF count " + dst_rule_DF.count())
      print("tz_dst_DF count " + tz_dst_DF.count())*/
      val findf = generateTimeZoneRefData(station_tz_dst_DF, dst_rule_DF, tz_dst_DF)
//      print("findf count " + findf.count())
      findf
    }
    catch {
      case ex: Exception => {
        logger.error(s"File $filePathDir not found " + ex.printStackTrace());
        null
      }
    }
  }
}
