package com.cn.spark.service

import java.util.Properties

import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.log4j.Logger
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.rtrim
import com.cn.spark.commonsEngine.CommonsUtil

class ErrorNotificationForEachWriter(val ErrorNotificationTopic: String, val jobName: String, val sourceTopicName: String) extends ForeachWriter[Row] with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  @transient lazy val kafkaProperties: Properties = CommonsUtil.getKafkaProperties()

  var producer: KafkaProducer[String, String] = _
  def open(partition_id: Long, epoch_id: Long) = {
    // Open connection. This method is optional in Python.
    logger.debug("ErrorNotificationForEachWriter start:: open")
    producer = new KafkaProducer(kafkaProperties)
    logger.debug("ErrorNotificationForEachWriter end:: open")
    true
  }

  //convert to json and write to kafka
  def process(row: Row) = {
    logger.debug("Start process() function ErrorNotificationForEachWriter")
    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
    producer.send(new ProducerRecord(ErrorNotificationTopic, buildErrorNotificationJson(rowAsMap)))
    logger.debug("End process() function ErrorNotificationForEachWriter")
  }

  def close(error: Throwable) = {
    logger.debug("Start close() ErrorNotificationForEachWriter")
    producer.close()
    logger.debug("End close() ErrorNotificationForEachWriter")
  }

  // build json message for Conveyor Created
  def buildErrorNotificationJson(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("ErrorNotificationForEachWriter Start :: buildErrorNotificationJson")   
    val currentTimeInUTC = CommonsUtil.getUTCTimeStamp   
    val msgHeaderJson = "" + rowAsMap("JSON_DATA").toString().dropRight(1) +""
    val msgBodyJson = "," + "\"LogHeader\"" + ":" + "{" + "\"ERROR_TO_DE\"" + ":" + "\"" + rowAsMap("ERROR_KEY") +  "\"" +"," + "\"RAW_KAFKA_QUEUE_NAME\"" + ":" + "\"" + sourceTopicName + "\"" + "," + "\"SPARK_JOB_NAME\"" + ":" + "\"" + jobName + "\"" + "," + "\"ERROR_TS\"" + ":" + "\"" + currentTimeInUTC + "\"" + "}}"
    val ErrorNotificationfinalJson = msgHeaderJson + msgBodyJson
    logger.info("ErrorNotificationForEachWriter End :: buildErrorNotificationJson" + ErrorNotificationfinalJson)
    ErrorNotificationfinalJson
  }

}