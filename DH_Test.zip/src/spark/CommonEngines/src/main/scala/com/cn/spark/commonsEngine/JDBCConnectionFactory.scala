package com.cn.spark.commonsEngine

import org.apache.commons.dbcp2.BasicDataSource
import java.sql.Connection
import org.apache.log4j.Logger
import java.sql.SQLException

object JDBCConnectionFactory{
  val logger = Logger.getLogger(getClass.getName)
 def getDataSource(userName:String,password:String,dbUrl:String) = {
    logger.debug("JDBCConnectionFactory::getDataSource::Start")
    val connectionPool = new BasicDataSource()
    connectionPool.setUsername(userName)
    connectionPool.setPassword(password)
    connectionPool.setUrl(dbUrl)
    connectionPool.setMaxTotal(1)
    connectionPool.setMaxWaitMillis(3)
    connectionPool.setMaxIdle(1)
    connectionPool.setInitialSize(1)
    logger.debug("JDBCConnectionFactory::getDataSource::End")
    connectionPool
  }
  
  def getConnection(userName:String,password:String,dbUrl:String):Connection={
    logger.debug("JDBCConnectionFactory::getConnection::Start")
    var conn:Connection=null
    try{
    conn = getDataSource(userName,password,dbUrl).getConnection
    }
     catch {
      case ex: SQLException => {
        logger.error(s"Error while calling getting connection " + ex.printStackTrace())
      }
    }
     logger.debug("JDBCConnectionFactory::getConnection::end")
     conn
  }
}