package com.cn.spark.idFactory

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.types.StructType

import com.cn.spark.configFactory.SparkSessionConfigEngine

object ReferenceDataGenerationEngine extends SparkSessionConfigEngine {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)

 @Override
  def applyReferenceDataTransformation(referenceDF: DataFrame): DataFrame = {
    logger.debug("ReferenceDataGenerationEngine Start :: applyReferenceDataTransformation")
    val typeKeyDF = IDGenerationEngine.createKeyForDF(referenceDF, "TYPE_KEY", List("type_cd", "prnt_type_cd"))
    val printTypeKeyDF = typeKeyDF.as("ref1").join(typeKeyDF.as("ref2"), trim($"ref1.prnt_type_cd") === trim($"ref2.type_cd")).select(trim($"ref1.type_cd") as "type_cd", trim($"ref1.prnt_type_cd") as "prnt_type_cd", $"ref1.TYPE_KEY", $"ref2.TYPE_KEY" as "PRNT_TYPE_KEY")
    val finalDF = printTypeKeyDF.filter($"type_key"=!=$"prnt_type_key" || $"type_cd"==="N/A").distinct()
    //Schema : "type_cd","prnt_type_cd","TYPE_KEY","PRNT_TYPE_KEY"
    logger.debug("ReferenceDataGenerationEngine End :: applyReferenceDataTransformation")
    finalDF
  }

  def referenceDataFromFile(filePath: String, schema: StructType): DataFrame = {
    logger.debug("ReferenceDataGenerationEngine Start :: referenceDataFromFile")
    val referenceDF = spark.read.option("header",true).schema(schema).csv(filePath)
    logger.debug("ReferenceDataGenerationEngine End :: referenceDataFromFile")
    referenceDF
  }
}