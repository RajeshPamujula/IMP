package com.cn.spark.configFactory
import java.nio.file.Paths

import org.apache.log4j.Level
import org.apache.log4j.Logger

import com.typesafe.config.Config
import com.typesafe.config.ConfigFactory

object MainConfigEngine {
  var applicationConf: Config = _
  @transient lazy val logger: Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)
  logger.setLevel(Level.INFO)
  logger.info("Execution Start")

  def load(): Config = {
    if (Option(System.getProperty("config.file.name")) != None) {
      val confFile = Paths.get(System.getProperty("config.file.name")).toFile
      applicationConf = ConfigFactory.parseFile(confFile)

    } else { // to load the config file from inside folder
      applicationConf = ConfigFactory.load("application.conf")

    }
    return applicationConf
  }

}