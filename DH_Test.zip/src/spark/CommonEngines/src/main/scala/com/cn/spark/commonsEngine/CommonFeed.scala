package com.cn.spark.commonsEngine
import java.net.ConnectException
import java.net.SocketException

import org.apache.commons.lang3.exception.ExceptionUtils
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.StreamingQueryException
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import com.cn.spark.commonsEngine.Constants._
import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.configFactory.SparkSessionConfigEngine

abstract class CommonFeed(sourceTopic:String) extends SparkSessionConfigEngine with ApplicationConfigEngine {
  val log: Logger = LoggerFactory.getLogger(getClass)
  var isStopRequested: Boolean = false
  log.info("CommonFeed commonsEngine sourceTopic: "+sourceTopic)
  def Start(): Unit = {

    log.info("-> CommonFeed start()")
    val sourceDataSet = readInputStream()
    val transformedDF = applySchema(sourceDataSet)
    val streamingQuery = transformAndsinkStream(transformedDF)
    try {
      streamingQuery.awaitTermination()
    } catch {
      case streamingException: StreamingQueryException =>
        {
          val exception: Throwable = ExceptionUtils.getRootCause(streamingException)
          if (exception.isInstanceOf[ConnectException] || exception.isInstanceOf[SocketException]) {
            log.error("Database connection issue : " + exception);
            isStopRequested = true
          }
        }

      case generalException: Exception =>
        {
          val exception: Throwable = ExceptionUtils.getRootCause(generalException)
          log.error("Job is aborting with exception: " + exception);
          isStopRequested = true
        }
    } finally {
      if (isStopRequested) {
        log.info("Job will attempt to stop gracefully the spark structured streaming query")
        streamingQuery.stop()
        log.info("-> end()")
      }
    }
  }

  def readInputStream(): Dataset[(String,String)] = {
    import spark.implicits._

    val inputStream = spark.readStream
      .format(KAFKA)
      .option(KAFKA_BOOTSTRAP_SERVERS, environmentValues.get("KAFKA_BROKER_HOST"))
      .option(SUBSCRIBE, sourceTopic)
      .option(SECURE_PROTOCOL, applicationConf.getString("security.protocol"))
      .option(FETCH_BYTES, applicationConf.getString("fetchBytes"))
      .option(MAX_POLL_RECORDS, applicationConf.getString("max.poll.records"))
      .option(STARTING_OFFSETS, applicationConf.getString("startingOffsets"))
      .option(FAIL_ON_DATA_LOSS, applicationConf.getString("failOnDataLoss"))
      .option(MAX_OFFSETS_PER_TRIGGER, applicationConf.getInt("maxOffsetsPerTrigger"))
      .load()
      .selectExpr("CAST(value AS STRING)","CAST(topic AS STRING)").as[(String,String)]
    inputStream
  }

  def applySchema(dataset: Dataset[(String,String)]): DataFrame

  def transformAndsinkStream(transformedDF: DataFrame): StreamingQuery

}