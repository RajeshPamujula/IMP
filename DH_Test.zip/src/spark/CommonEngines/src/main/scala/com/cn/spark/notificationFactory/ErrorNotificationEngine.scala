package com.cn.spark.notificationFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.functions.concat
import org.apache.spark.sql.functions.length
import org.apache.spark.sql.functions.rtrim

object ErrorNotificationEngine {

  def addErrorColumnForDF(inputDF: DataFrame, columnNames: List[String]): DataFrame = {

    val DataFrameWithErrorKey = inputDF.withColumn("ERROR_KEY", rtrim(concat(columnNames.map(c => when(col(c).isNull, c + " is NULL and ").otherwise(lit(""))): _*), " and "))
    DataFrameWithErrorKey

  }

  def filterErrorMessage(inputDf: DataFrame): DataFrame = {

    val filterErrorMessageDF = inputDf.select(col("*")).filter(length(col("ERROR_KEY")) >= 1)
    filterErrorMessageDF

  }

  def filterCorrectMessage(inputDf: DataFrame): DataFrame = {

    val filterCorrectMessageDF = inputDf.select(col("*")).filter(trim(col("ERROR_KEY")) === "")
    filterCorrectMessageDF

  }

  def dropColumn(inputDf: DataFrame, columName: String): DataFrame = {
    inputDf.drop(columName)

  }

}