package com.cn.spark.commonsEngine

import java.util.Properties
import java.sql.Connection
import java.sql.DriverManager
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

import org.apache.log4j.Logger
import org.apache.spark.SparkException
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Column
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.regexp_replace
import org.apache.spark.sql.functions.current_timestamp
import org.postgresql.util.PSQLException
import org.apache.spark.sql.functions.{ col, current_timestamp, lit, udf, when, concat, trim }
import com.cn.spark.configFactory.ApplicationConfigEngine
import com.cn.spark.idFactory.ReferenceDataGenerationEngine

import java.util.Properties

import org.apache.commons.lang3.exception.ExceptionUtils
import org.apache.hadoop.security.alias.CredentialProviderFactory
import java.sql.PreparedStatement

import org.apache.spark.SparkException
import org.postgresql.util.PSQLException
import java.sql.Connection

import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerRecord
import com.cn.spark.notificationFactory.ErrorNotificationEngine
import com.cn.spark.idFactory.ReferenceDataGenerationEngine

import scala.util.Try
import com.cn.spark.idFactory.ReferenceDataGenerationEngine

object CommonsUtil extends ApplicationConfigEngine {
  val logger = Logger.getLogger(getClass.getName)
  // setting postgres configuration data
  def setPostgreConfig(targetTableName: String, fileSys: String): Properties = {
    logger.debug("CommonsUtil Start::setPostgreConfig")
    //getting password from file
    implicit lazy val dbConnectionParams: Properties = new Properties()

    dbConnectionParams.setProperty("dbUrl", environmentValues.get("PG_CONN_URL"))
    dbConnectionParams.setProperty("user", environmentValues.get("PG_USER"))
    dbConnectionParams.setProperty("targetTableName", targetTableName)
    dbConnectionParams.setProperty("driver", environmentValues.get("PG_DRIVER"))

    val postgresCryptedPwdPath = environmentValues.get("PG_PWD_FILE")
    val postgresPwdAlias = environmentValues.get("PG_PWD_ALIAS")
    val jceksPath = s"jceks://$fileSys$postgresCryptedPwdPath"
    try {
      @transient lazy val configuration = new org.apache.hadoop.conf.Configuration()
      configuration.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH, jceksPath)
      val postgresPassword: String = configuration.getPassword(postgresPwdAlias).mkString
      dbConnectionParams.setProperty("password", postgresPassword)
    } catch {
      case se: Exception => {
        val updateException: Throwable = ExceptionUtils.getRootCause(se)
        loggerConfig.error("Error While reading password file" + updateException.getMessage)
      }
    }
    logger.debug("CommonsUtil End::setPostgreConfig")
    dbConnectionParams
  }

  //function to execute insert query
  def saveTODB(query: String, conn: Connection, publishMessage: Boolean = false, rowAsMap: Map[String, Nothing] = null, producer: KafkaProducer[String, String] = null, ErrorNotificationTopic: String = null, jobName: String = null, sourceTopicName: String = null): Unit = {
    logger.debug("CommonsUtil Start:: saveTODB")
    try {
      if (conn != null) {
        val pstmt: PreparedStatement = conn.prepareStatement(query)
        pstmt.execute()
      }
    } catch {
      case pe: PSQLException => {
        logger.error("PSQLException: Query to insert data: " + query + "\n" + pe.printStackTrace())
        //send error Data to producer.
        if (publishMessage == true) {
          publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, pe.getMessage)
        }

      }
      case se: SparkException => {
        logger.error("SparkException: Query to insert event data: " + query + "\n" + se.printStackTrace)
      }
    }
    logger.debug("CommonsUtil Start:: saveTODB")
  }

  //generate audit time stamp for reading
  def addAuditTimeStamp(inputDf: DataFrame, colName: String): DataFrame = {
    inputDf.withColumn(colName, lit(current_timestamp()))
  }

  //generate audit time stamp for reading
  def addDeMetaColumn(inputDf: DataFrame, colName: String): DataFrame = {
    inputDf.withColumn(colName, lit(""))
  }

  //generate utc time
  def getUTCTimeStamp(): String = {
    val date: Date = new Date()
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    dateFormat.format(date)
  }

  //Get the data from db based on given table name
  def getDataFromDB(spark: SparkSession, tableName: String, dbConnectionParams: Properties): DataFrame = {
    spark.read.format("jdbc").option("url", dbConnectionParams.getProperty("dbUrl")).option("driver", dbConnectionParams.getProperty("driver")).option("user", dbConnectionParams.getProperty("user"))
      .option("password", dbConnectionParams.getProperty("password")).option("dbtable", tableName).load()

  }

  def publishErrorMessage(rowAsMap: Map[String, Nothing], producer: KafkaProducer[String, String], ErrorNotificationTopic: String, jobName: String = null, sourceTopicName: String = null, ErrorMessage: String = null) {
    logger.info("PublishErrorMessages Start")
    producer.send(new ProducerRecord(ErrorNotificationTopic, buildErrorJsonForPGJobs(rowAsMap, jobName, sourceTopicName, ErrorMessage)))
    logger.info("PublishErrorMessages End")

  }

  def replaceNullString(insertQueryString: String): String = {

    val insertQuery = insertQueryString.replaceAll("'null'", "null").replaceAll("'NULL'", "null").replaceAll("'Null'", "null")
    insertQuery
  }

  // build json message for PG job
  def buildErrorJsonForPGJobs(rowAsMap: Map[String, Nothing], jobName: String = null, sourceTopicName: String = null, ErrorMessage: String = null): String = {
    logger.debug("ErrorNotificationForEachWriter Start :: buildErrorJsonForImplement")
    val currentTimeInUTC = CommonsUtil.getUTCTimeStamp
    val msgHeaderJson = "" + rowAsMap("JSON_DATA").toString().dropRight(1) + ""
    val ErrorMessages = "" + ErrorMessage.replaceAll("[^\\w_:.]+", " ") + ""

    val msgBodyJson = "," + "\"LogHeader\"" + ":" + "{" + "\"ERROR_TO_DE\"" + ":" + "\"" + ErrorMessages + "\"" + "," + "\"RAW_KAFKA_QUEUE_NAME\"" + ":" + "\"" + sourceTopicName + "\"" + "," + "\"SPARK_JOB_NAME\"" + ":" + "\"" + jobName + "\"" + "," + "\"ERROR_TS\"" + ":" + "\"" + currentTimeInUTC + "\"" + "}}"

    val ErrorNotificationfinalJson = msgHeaderJson + msgBodyJson

    logger.info("ErrorNotificationForEachWriter End :: buildErrorNotificationJson" + ErrorNotificationfinalJson)
    ErrorNotificationfinalJson
  }

  def getTimeZoneNameByCode(inputDF: DataFrame, columnName: String): DataFrame = {
    inputDF.withColumn(columnName, when(col("TIME_ZONE") === "AKT", Constants.AKT)
      .otherwise(when(col("TIME_ZONE") === "AT", Constants.AT)
        .otherwise(when(col("TIME_ZONE") === "CT", Constants.CT)
          .otherwise(when(col("TIME_ZONE") === "ET", Constants.ET)
            .otherwise(when(col("TIME_ZONE") === "HAT", Constants.HAT)
              .otherwise(when(col("TIME_ZONE") === "MT", Constants.MT)
                .otherwise(when(col("TIME_ZONE") === "NT", Constants.NT)
                  .otherwise(when(col("TIME_ZONE") === "PT", Constants.PT)
                    .otherwise(when(col("TIME_ZONE") === "UTC_ET", Constants.UTC_ET)
                      .otherwise(Constants.Other))))))))))
  }

  //common UDF'S
  val zip = udf((xs: Seq[String], ys: Seq[String], zs: Seq[String]) => Try((xs, ys, zs).zipped.toSeq).toOption)

  val zipFiveColumns = udf((ts: Seq[String], us: Seq[String], xs: Seq[String], ys: Seq[String], zs: Seq[String]) => Try(for (((((t, u), x), y), z) <- ts zip us zip xs zip ys zip zs) yield (t, u, x, y, z)).toOption)
  //String empty or null check
  def isEmpty(x: String) = x == null || x.trim.isEmpty
  val zipSevenColumns = udf((ts: Seq[String], us: Seq[String], vs: Seq[String], ws: Seq[String], xs: Seq[String], ys: Seq[String], zs: Seq[String]) => Try(for (((((((t, u), v), w), x), y), z) <- ts zip us zip vs zip ws zip xs zip ys zip zs) yield (t, u, v, w, x, y, z)).toOption)

  val array_zip_udf = udf((cols: Seq[Seq[String]]) => Try(cols.transpose).toOption)

  def getRefData(refData: Map[String, String], prnt_type_cd: String, type_cd: String): String = {
    try {
      refData.getOrElse(prnt_type_cd + "|" + type_cd, throw new Exception("Ref Type Missing:" + prnt_type_cd + "|" + type_cd)).toString()
    } catch {
      case ex: Exception => {
        logger.error(s"Error while calling getRefData " + ex.printStackTrace());
        System.exit(1)
        null
      }
    }
  }

  def readReferenceDataFile(spark: SparkSession): DataFrame = {
    try {
      lazy val referenceDataDir = environmentValues.get("SPARK_REFERENCE_DATA_DIR") + "/" + applicationConf.getString("referenceDataDir")
      val referenceDataFileDF = ReferenceDataGenerationEngine.referenceDataFromFile(referenceDataDir, Schema.referenceDataSchema)
      val transformDF = referenceDataFileDF.select(trim(col("type_cd")).alias("type_cd"),trim(col("prnt_type_cd")).alias("prnt_type_cd"))
      val naDF = spark.createDataFrame(Seq(("N/A", "N/A"))).toDF("type_cd", "prnt_type_cd")
      val fileUnionDF = naDF.union(transformDF)
      ReferenceDataGenerationEngine.applyReferenceDataTransformation(fileUnionDF)
    } catch {
      case ex: Exception => {
        logger.error(s"Error while calling readReferenceDataFile " + ex.printStackTrace());
        null
      }
    }
  } 

  /*
   * Getting Kafka properties are common across all the jobs
   */

  def getKafkaProperties() :Properties = {
  logger.debug("CommonsUtil Start::getKafkaProperties")
  implicit lazy val kafkaProperties: Properties = new Properties()
  kafkaProperties.put("bootstrap.servers", environmentValues.get("KAFKA_BROKER_HOST"))
  kafkaProperties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  kafkaProperties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  kafkaProperties.put("security.protocol", applicationConf.getString("security.protocol"))
  kafkaProperties.put("compression.type", applicationConf.getString("compression.type"))
  kafkaProperties.put("linger.ms", applicationConf.getString("linger.ms"))
  logger.debug("CommonsUtil End::getKafkaProperties")
  kafkaProperties
  }
  
  def preprocessJson(jsonStr: Column): Column = {
    try {
        regexp_replace(jsonStr,"'", "''")
    } catch {
      case ex:Exception => {
       logger.error(s"Error while calling readReferenceDataFile " + ex.printStackTrace());
       null
      }
    }
  }
}