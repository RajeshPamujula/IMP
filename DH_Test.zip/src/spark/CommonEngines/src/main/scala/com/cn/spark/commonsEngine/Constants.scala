package com.cn.spark.commonsEngine

object Constants {

  //Timezone configurations
  val AKT = "America/Anchorage"
  val AT = "America/Halifax"
  val CT = "America/Winnipeg"
  val ET = "America/Toronto"
  val HAT = "America/Adak"
  val MT = "America/Edmonton"
  val NT = "America/St_Johns"
  val PT = "America/Vancouver"
  val UTC_ET = "America/Toronto"
  val Other = "America/New_York"
  val DST_CD_UTC_DST_NO = 100
  
  //Kafka configurations
  val TOPIC = "topic"
  val RAW_TOPIC = "rawTopic"
  val ENTERPRISE_TOPIC = "enterpriseTopic"
  val ENABLE_AUTO_COMMIT = "enable.auto.commit"
  val KEY_DESERIALIZER = "key.deserializer"
  val VALUE_DESERIALIZER = "value.deserializer"
  val KAFKA_BOOTSTRAP_SERVERS = "kafka.bootstrap.servers"
  val SUBSCRIBE = "subscribe"
  val SECURE_PROTOCOL = "kafka.security.protocol"
  val MAX_POLL_RECORDS = "kafka.max.poll.records"
  val FETCH_BYTES = "kafka.max.partition.fetch.bytes"
  val STARTING_OFFSETS = "startingOffsets"
  val ENDING_OFFSETS = "latest"
  val KAFKA = "kafka"
  val MAX_OFFSETS_PER_TRIGGER = "maxOffsetsPerTrigger"
  val FAIL_ON_DATA_LOSS = "failOnDataLoss"
}