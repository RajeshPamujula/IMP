package com.cn.spark.idFactory

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions.sha2

object IDGenerationEngine {

  val logger = Logger.getLogger(getClass.getName)

  def createKeyForDF(inputDF: DataFrame, newColumnName: String, columnNames: List[String]): DataFrame = {

    val finalDF = inputDF.withColumn(newColumnName, sha2(concat_ws("", columnNames.map(c => col(c)): _*), 256))
    finalDF

  }

}