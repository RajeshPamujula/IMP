package com.cn.spark.service

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.{ col, from_json, lit, concat }
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.Trigger
import com.cn.spark.commons.utils.SparkDataFrameHelper
import com.cn.spark.commonsEngine.CommonFeed
import java.util.Properties

import org.apache.commons.lang3.exception.ExceptionUtils
import org.apache.hadoop.security.alias.CredentialProviderFactory
import com.cn.spark.commons.references.CarReferenceSchema
import com.cn.spark.commonsEngine.CommonsUtil
import com.cn.spark.idFactory.IDGenerationEngine

class CarReferenceLoadService(sourceTopicName: String, ErrorNotificationTopic: String) extends CommonFeed(sourceTopicName: String) {
  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)
  @transient lazy val carReferenceLoadCheckpointDir = environmentValues.get("SPARK_CHKPT_DIR") + "/" + applicationConf.getString("carReferenceLoadCheckpointDir")
  lazy val targetTableName: String = environmentValues.get("PG_PREPARED_TBL_PREFIX") + "." + applicationConf.getString("carReferenceTableName")
  //Broadcast any thing thats required
  @transient lazy val jcekFileSystem = applicationConf.getString("jcekFileSystem")
  lazy val dbConfigParam: Properties = CommonsUtil.setPostgreConfig(targetTableName, jcekFileSystem)
  lazy val timeInterval = applicationConf.getString("timeInterval")

  //Implementation of the trait. using Schema to fetch dataframe from the message.
  @Override
  def applySchema(dataset: Dataset[(String, String)]): DataFrame = {
    logger.info("CarReferenceLoadService Start ::applySchema")
    //applying schema to json message
    val rawMsgDF = dataset.select(col("value") as "JSON_DATA", from_json(CommonsUtil.preprocessJson($"value"), CarReferenceSchema.carReferenceSchema) as "record")
    //adding time stamp while reading
    // val auditTimeStampDF = SparkDataFrameHelper.addAuditTimeStamp(rawMsgDF, "DOMN_EVT_READ_TS")
    logger.debug("CarReferenceLoadService End ::applySchema")
    SparkDataFrameHelper.getMessage(rawMsgDF)
  }

  //Implementation of the trait. Transformations will be applied for each batch.
  @Override
  def transformAndsinkStream(inputDF: DataFrame): StreamingQuery = {
    logger.debug("CarReferenceLoadService Start ::transformAndsinkStream")

    val carReferenceFinalDF = SparkDataFrameHelper.applyTransformation(inputDF)
    //carReferenceFinalDF.writeStream.format("console").start()
    carReferenceFinalDF.writeStream.option("checkpointLocation", carReferenceLoadCheckpointDir).trigger(Trigger.ProcessingTime(timeInterval + " seconds")).foreach(new CarReferenceLoadForEachWriter(dbConfigParam, ErrorNotificationTopic, "CarReferenceLoad", sourceTopicName, targetTableName)).start()
   
    // carReferenceFinalDF.writeStream.option("checkpointLocation", carReferenceLoadCheckpointDir).trigger(Trigger.Once()).foreach(new CarReferenceLoadForEachWriter(dbConfigParam, ErrorNotificationTopic, "CarReferenceLoad", sourceTopicName, targetTableName)).start()
   
    
    

  }
}