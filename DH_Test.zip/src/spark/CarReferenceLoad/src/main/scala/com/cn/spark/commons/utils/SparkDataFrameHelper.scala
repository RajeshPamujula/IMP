package com.cn.spark.commons.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{ col, regexp_replace, current_timestamp, date_format, lit, trim, when }
import com.cn.spark.idFactory.IDGenerationEngine
import org.apache.spark.sql.functions.to_timestamp
import org.apache.spark.sql.functions.explode
import org.apache.spark.sql.types.{ BinaryType, DecimalType, ShortType, IntegerType }

object SparkDataFrameHelper {
  val logger = Logger.getLogger(getClass.getName)

  //generate audit time stamp for reading
  def addAuditTimeStamp(inputDf: DataFrame, colName: String): DataFrame = {
    inputDf.withColumn(colName, lit(current_timestamp()))
  }

  def getMessage(CarReferenceSourceDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::getMessage::Start")

    val selectedDF = CarReferenceSourceDF
      .select(
        col("record.IngestionHeader.INGT_CRT_TS").alias("SOR_INGT_CRT_TS"),
        col("record.IngestionHeader.PRODUCT_ID").alias("PRODUCT_ID"),
        col("record.IngestionHeader.INGT_UUID").alias("UUID"),
        trim(col("record.Umler.EQP_INIT")).alias("EQP_INIT"),
        regexp_replace(trim(col("record.Umler.EQP_NBR")), "^0*", "").alias("EQP_NBR"),
        col("record.Umler.IS_LGTH_FT").alias("IS_LGTH_FT"),
        col("record.Umler.OSID_LGT").alias("OSID_LGT"),
        col("record.Umler.ARTICLTD").alias("ARTICLTD"),
        col("record.Umler.TARE_WGT").alias("TARE_WGT"),
        col("record.Umler.TOT_WGT_RAIL").alias("TOT_WGT_RAIL"),
        col("record.Umler.CAR_KIND").alias("CAR_KIND"),
        col("record.Umler.XTRM_HGT").alias("XTRM_HGT_IN"),
        col("record.Umler.XTRM_WDT").alias("XTRM_WDT_IN"),
        col("record.Umler.LOAD_LMT").alias("LOAD_LMT"),
        col("record.Umler.AXLES").alias("AXLE_CD"),
        trim(col("record.Umler.GST_CD")).alias("GST_CD"),
        col("record.Umler.EQP_TYP_AAR").alias("AAR_EQP_TYPE_CD"),
        col("record.Umler.BRNG_CD").alias("BRNG_CD"),
        col("JSON_DATA").alias("JSON_DATA"))

    logger.debug("End getMsgData() CarReferenceSchema")

    selectedDF
  }

  def applyTransformation(inputDF: DataFrame): DataFrame = {
    logger.debug("SparkDataFrameHelper::applyTransformation::Start")
    val transformDF = inputDF
      .withColumn("ISID_LGT_FT", col("IS_LGTH_FT").cast(ShortType))
      .withColumn("OSID_LGT_FT", (((col("OSID_LGT") - (col("OSID_LGT") % 100)) / 100) + (col("OSID_LGT") % 100 / 12.0)).cast(DecimalType(15, 10)))
      .withColumn("NBR_OF_PLFM_MID", col("ARTICLTD").cast(ShortType))
      .withColumn("NBR_OF_PLFM", when(col("NBR_OF_PLFM_MID").isNull, 1).otherwise(col("NBR_OF_PLFM_MID")))
      .withColumn("ARTT_CD", col("ARTICLTD"))
      .withColumn("TOT_WGT_RAIL_TON", col("TOT_WGT_RAIL").cast(ShortType))
      .withColumn("TARE_WGT_LB", (col("TARE_WGT") * 1000).cast(IntegerType))
      .withColumn("CLNT_ID", lit("SRS-DB2-TUMLER"))
      //.withColumn("NBR_OF_PLFM", col("NBR_OF_PLFM").cast(ShortType))
      .drop("NBR_OF_PLFM_MID")
    val rawDF = IDGenerationEngine.createKeyForDF(transformDF, "RCAR_KEY", List("EQP_INIT", "EQP_NBR"))
    logger.debug("SparkDataFrameHelper::applyTransformation::End")
    rawDF
  }

  //val targetDF = CommonsUtil.getDataFromDB(spark, targetTableName, dbConfigParam)

}