package com.cn.spark.commons.references

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import scala.collection.Seq

object CarReferenceSchema {

  val carReferenceSchema = StructType(Seq(
    StructField("IngestionHeader", StructType(Seq(
      StructField("INGT_CRT_TS", StringType, false),
      StructField("PRODUCT_ID", StringType, false),
      StructField("INGT_UUID", StringType, false))), false),
    StructField("Umler", StructType(Seq(
      StructField("EQP_INIT", StringType, false),
      StructField("EQP_NBR", StringType, false),
      StructField("IS_LGTH_FT", StringType, false),
      StructField("OSID_LGT", StringType, false),
      StructField("ARTICLTD", StringType, false),
      StructField("TARE_WGT", StringType, false),
      StructField("TOT_WGT_RAIL", StringType, false),
      StructField("CAR_KIND", StringType, false),      
      StructField("XTRM_WDT", StringType, false),
      StructField("XTRM_HGT", StringType, false),
      StructField("LOAD_LMT", StringType, false),
      StructField("AXLES", StringType, false),
      StructField("GST_CD", StringType, false),
      StructField("EQP_TYP_AAR", StringType, false),
      StructField("BRNG_CD", StringType, false))))))
}
