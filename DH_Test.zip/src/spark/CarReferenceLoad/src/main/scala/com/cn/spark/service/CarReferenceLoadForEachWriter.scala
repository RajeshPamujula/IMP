package com.cn.spark.service

import java.sql.Connection
import java.sql.DriverManager
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp

import org.apache.log4j.Logger
import org.apache.spark.SparkException
import org.apache.spark.sql.ForeachWriter
import org.apache.spark.sql.Row
import org.postgresql.util.PSQLException

import com.cn.spark.configFactory.ApplicationConfigEngine
import org.apache.kafka.clients.producer.KafkaProducer
import java.util.Properties
import com.cn.spark.commonsEngine.CommonsUtil

class CarReferenceLoadForEachWriter(dbConfigParam: Properties, val ErrorNotificationTopic: String, val jobName: String, val sourceTopicName: String, val targetTableName: String) extends ForeachWriter[Row] with ApplicationConfigEngine with Serializable {

  @transient lazy val logger = Logger.getLogger(getClass.getName)
  lazy val conn: Connection = DriverManager.getConnection(dbConfigParam.getProperty("dbUrl"), dbConfigParam.getProperty("user"), dbConfigParam.getProperty("password"))
  @transient lazy val kafkaProperties: Properties = CommonsUtil.getKafkaProperties()
  var producer: KafkaProducer[String, String] = _
  def open(partition_id: Long, epoch_id: Long) = {
    // Open connection. This method is optional in Python.
    logger.debug("CarReferenceLoadForEachWriter start:: open")
    producer = new KafkaProducer(kafkaProperties)
    conn
    logger.debug("CarReferenceLoadForEachWriter end:: open")
    true
  }

  //convert to json and write to postgre
  def process(row: Row) = {
    logger.debug("CarReferenceLoadForEachWriter Start:: process")
    val rowAsMap = row.getValuesMap(row.schema.fieldNames)
    try {
      val outputDF = CommonsUtil.saveTODB(buildUpsertQuery(rowAsMap), conn, true, rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName)

    } catch {
      case ne: NullPointerException => {
        CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, ne.printStackTrace().toString())
      }
      case se: Exception => {
        CommonsUtil.publishErrorMessage(rowAsMap, producer, ErrorNotificationTopic, jobName, sourceTopicName, se.getMessage)
      }
    }
    logger.debug("CarReferenceLoadForEachWriter End:: process")
  }

  def close(error: Throwable) = {
    logger.debug("Start close() CarReferenceLoadForEachWriter")
    conn.close()
    producer.close()
    logger.debug("End close() CarReferenceLoadForEachWriter")
  }

  def buildUpsertQuery(rowAsMap: Map[String, Nothing]): String = {
    logger.debug("CarReferenceLoadForEachWriter Start :: buildUpsertQuery")
    val queryString = "INSERT INTO " + targetTableName + "(RCAR_KEY, EQP_INIT, EQP_NBR, ISID_LGT_FT, OSID_LGT_FT, NBR_OF_PLFM, ARTT_CD, TARE_WGT_LB, TOT_WGT_RAIL_TON, CAR_KIND, XTRM_HGT_IN, XTRM_WDT_IN, LOAD_LMT, AXLE_CD, GST_CD, AAR_EQP_TYPE_CD,DATA_HUB_CRT_TS, BRNG_CD,CLNT_ID,SOR_INGT_CRT_TS) VALUES('" +
      rowAsMap("RCAR_KEY") + "','" +
      rowAsMap("EQP_INIT") + "','" +
      rowAsMap("EQP_NBR") + "','" +
      rowAsMap("ISID_LGT_FT") + "','" +
      rowAsMap("OSID_LGT_FT") + "','" +
      rowAsMap("NBR_OF_PLFM") + "','" +
      rowAsMap("ARTT_CD") + "','" +
      rowAsMap("TARE_WGT_LB") + "','" +
      rowAsMap("TOT_WGT_RAIL_TON") + "','" +
      rowAsMap("CAR_KIND") + "','" +
      rowAsMap("XTRM_HGT_IN") + "','" +
      rowAsMap("XTRM_WDT_IN") + "','" +
      rowAsMap("LOAD_LMT") + "','" +
      rowAsMap("AXLE_CD") + "','" +
      rowAsMap("GST_CD") + "','" +
      rowAsMap("AAR_EQP_TYPE_CD") + "',CURRENT_TIMESTAMP,'" +
      rowAsMap("BRNG_CD") + "','" +
      rowAsMap("CLNT_ID") + "','" +
      rowAsMap("SOR_INGT_CRT_TS") + "') ON CONFLICT(RCAR_KEY) DO UPDATE SET ISID_LGT_FT = EXCLUDED.ISID_LGT_FT, OSID_LGT_FT = EXCLUDED.OSID_LGT_FT, NBR_OF_PLFM=EXCLUDED.NBR_OF_PLFM, ARTT_CD=EXCLUDED.ARTT_CD, TARE_WGT_LB=EXCLUDED.TARE_WGT_LB,TOT_WGT_RAIL_TON=EXCLUDED.TOT_WGT_RAIL_TON,CAR_KIND=EXCLUDED.CAR_KIND,XTRM_HGT_IN=EXCLUDED.XTRM_HGT_IN,XTRM_WDT_IN=EXCLUDED.XTRM_WDT_IN,LOAD_LMT=EXCLUDED.LOAD_LMT,AXLE_CD=EXCLUDED.AXLE_CD,GST_CD=EXCLUDED.GST_CD,AAR_EQP_TYPE_CD=EXCLUDED.AAR_EQP_TYPE_CD,BRNG_CD=EXCLUDED.BRNG_CD,SOR_INGT_CRT_TS=EXCLUDED.SOR_INGT_CRT_TS WHERE " + targetTableName + ".SOR_INGT_CRT_TS<=EXCLUDED.SOR_INGT_CRT_TS and CONCAT(" + targetTableName + ".ISID_LGT_FT," + targetTableName + ".OSID_LGT_FT," + targetTableName + ".NBR_OF_PLFM," + targetTableName + ".ARTT_CD," + targetTableName + ".TARE_WGT_LB," + targetTableName + ".TOT_WGT_RAIL_TON," + targetTableName + ".CAR_KIND," + targetTableName + ".XTRM_HGT_IN," + targetTableName + ".XTRM_WDT_IN," + targetTableName + ".LOAD_LMT," + targetTableName + ".AXLE_CD," + targetTableName + ".GST_CD," + targetTableName + ".AAR_EQP_TYPE_CD," + targetTableName + ".BRNG_CD) <> CONCAT(EXCLUDED.ISID_LGT_FT,EXCLUDED.OSID_LGT_FT,EXCLUDED.NBR_OF_PLFM,EXCLUDED.ARTT_CD,EXCLUDED.TARE_WGT_LB,EXCLUDED.TOT_WGT_RAIL_TON,EXCLUDED.CAR_KIND,EXCLUDED.XTRM_HGT_IN,EXCLUDED.XTRM_WDT_IN,EXCLUDED.LOAD_LMT,EXCLUDED.AXLE_CD,EXCLUDED.GST_CD,EXCLUDED.AAR_EQP_TYPE_CD,EXCLUDED.BRNG_CD)"

    logger.debug("CarReferenceLoadForEachWriter End :: buildUpsertQuery")
    //println("queryString==" + queryString)
    CommonsUtil.replaceNullString(queryString)

  }
}