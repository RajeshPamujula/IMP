# Domain queues for Active Train Schedule
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.cnvyCrt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.cnvyDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.rtePlan.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.cnvyRmv.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.rteCanc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.rteDsc.v2

# Error queue for publish messages
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.rteErr.v2

# Domain queues for Train Reporting
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.trspEvtRpt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.trspEvtAsct.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.cnvyAsct.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.cnvyAsctDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.asetAsct.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.asetAsctDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.asetCrt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.asetDsc.v2

# Domain queues for Car Inventory
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.cnvyCondCrt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.trspEvtAsctDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.tripCrt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.tripDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.locAsct.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.locAsctDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.tripAsct.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.shipAsctDsc.v2
       
#  Error queue for implement messages
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.dhPGLogs.v2

# Domain queues for Train Consist
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.planEvtRpt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.planEvtAsct.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.trspEvtDsc.v2

# Domain queues for Industrial Instruction/Reason
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.planEvtDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.planEvtRmv.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.cnvyDasc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.planEvtDscChg.v2

# Domain queues for Waybill
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.shipDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.shipCrt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.shipAsct.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.shipCondCrt.v2

# Domain queues for Gate Event
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.trspEvtRmv.v2

# Domain queues for Motor Carrier
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.busPrtrCrt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.busPrtrCondCrt.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.busPrtrDsc.v2
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.busPrtrRmv.v2

# Domain queues for Intermodal Bad Order
./kafka-topics.sh --create --zookeeper ${ZOOKEEPER_PARAM} --replication-factor ${REPLICATIONFACTOR_PARAM} --partitions ${PARTITIONS_PARAM} --topic prd.tm.prepared.cnvyCondChg.v2
