#!/usr/bin/env python
# coding: utf-8

'''
  Usage   :        Use the script to run sanity queries to check record count in last 10mins in PostgreSQL tables
                   spark-submit tm_pgsql_sanity_monitoring_queries.py
  Author  :        Uma Rajamanickam (xt25897) (Copied from tm_pgsql_monitoring_queries.py creatd by Yonghua Wu)
  Created :        2020-04-21
  Changed :
'''

import psycopg2
import pandas as pd
from datetime import datetime
import os,sys

user_name = os.environ["PG_USER"]
pgsql_conn_str = os.environ["PG_CONN_URL"]
jks_path = r'jceks://' + os.environ["PG_PWD_FILE"]
alias_name = os.environ["PG_PWD_ALIAS"]
pgsql_schema = os.environ['PG_PREPARED_SCHEMA']

if '' in [user_name,pgsql_conn_str,jks_path,alias_name]:
    print('Error: PostgreSQL config is missing, check your ENV setting!')
    sys.exit(-1)

host = pgsql_conn_str.split(':')[2][2:]
port = pgsql_conn_str.split(':')[3].split('/')[0]
pg_db = pgsql_conn_str.split(':')[3].split('/')[1]

# to retrieve the passwd from jave keystore
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("yarn").appName(user_name+"_"+"tm_pgsql_audit_sanity_check").getOrCreate()

x = spark.sparkContext._jsc.hadoopConfiguration()
x.set("hadoop.security.credential.provider.path", jks_path)
a = x.getPassword(alias_name)

passwd = ""
for i in range(a.__len__()):
    passwd = passwd + str(a.__getitem__(i))

pd.set_option('display.max_colwidth', 100)
pd.set_option('display.max_rows', 999)
pd.set_option('display.width', 1000)

def generate_header(user):
    header  = ["-" * 146]
    header += [(" " * 37) + ("*" * 22) + " PostgreSQL Sanity Check Report for Data count " + ("*" * 22) + (" " * 38)]
    header += ["-" * 146]
    header += [""]
    header += ["UTC Date and Time : " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
    header += ["User              : " + user]
    header += [""]
    return "\n".join(header)

def generate_footer():
    footer  = [""]
    footer += ["-" * 146]
    footer += ["Ending " + __file__ + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d-%H.%M.%S")]
    footer += ["-" * 146]
    return "\n".join(footer)


if __name__ == '__main__':

    # connect to PostgreSQL DB
    conn = psycopg2.connect(database=pg_db, user=user_name, password=passwd, host=host, port=port)
    conn.autocommit = True
    stmt = "select table_name, sor_de_name, description, actual_output from {}.f_run_dh_sanity_monitoring_queries();".format(pgsql_schema)
    df = pd.read_sql_query(stmt, conn)

    # Print Report
    print(generate_header(os.environ["USER"]))
    print(df.to_string(index=False))
    print(generate_footer())

    # clean-up
    if(conn):
        conn.close()
