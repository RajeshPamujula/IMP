#!/bin/bash

# "**********************************************************************************"
# Usage          : bash spark_monitoring.sh <PIN> <ENV>
# condition      : 1. /hadoop/developers/<PIN>/deployment/CN.bundle.pem
#                : 2. /hadoop/developers/<PIN>/deployment/ENV_DEV.sh
# "**********************************************************************************"

export currentDirectory=`dirname $0`

export PATH=/opt/python3/bin:$PATH

export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;

if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
fi

USER=${1}
mode=deployment
env=$2 #[SB|QA|INT|PROD]

# Sourcing Environment Variables from the SetEnv scripts
if [ "$env" != "" ]; then
    case $env in
        "SB"|"QA"|"INT"|"PROD" )
            kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
            klist > /dev/null 2>&1
            source ${currentDirectory}/../utilities/ENV_${env}.sh > /dev/null 2>&1
            ;;

        * )         
            echo "Invalid ENV option: "$env
            usage
            exit -1
            ;;
    esac
else
    usage
    exit -1
fi

# Declaring Environment variables
export DH_TENANT=${DH_TENANT}
export DH_ENV=${DH_ENV}
export SPARK_HISTORY_SERVER=${SPARK_HISTORY_SERVER}
export SPARK_HISTORY_PORT=${SPARK_HISTORY_PORT}
export SPARK_JOB_PREFIX=${SPARK_JOB_PREFIX}
export hostEnv=`hostname`
export username=${USER}
export TARGET_EMAILS_LIST=${TARGET_EMAILS_LIST}
export EMAIL_TO=${TARGET_EMAILS_LIST}

# add Python3 path
export PATH=/opt/python3/bin:$PATH

# Log file
LOG_PATH=$SPARK_LOG
if [[ ! -e $LOG_PATH ]]; then
    mkdir -p $LOG_PATH
fi
rm $LOG_PATH/tm_spark_monitoring_*.txt >/dev/null 2>&1
LOGFILE=${LOG_PATH}/tm_spark_monitoring_$$.txt
touch ${LOGFILE}
chmod 777 ${LOGFILE}

python -W ignore ${currentDirectory}/tm_spark_monitoring.py -u ${USER} 1> ${LOGFILE} 2>/dev/null
RC=$?

function email_notify(){

       if [ $# -ne 3 ]; then
         echo "Usage:"
         echo ""
         echo "$0 \"Subject\" \"To_adresses\" file_to_email"
         echo ""
         exit 8
       fi

       SUBJECT=$1
       TO=$2
       FILE=$3

       if [ ! -f ${LOGFILE} ]
       then
         echo "Error, file not found: ${FILE}"
         exit 8
       fi
(
cat <<EOF
From: ${USER}@`hostname --fqdn`
To: ${TO}
Subject: ${SUBJECT}
MIME-Version: 1.0
Content-Type: text/html
Content-Disposition: inline
<html>
<body>
<pre style="font: monospace">
EOF

cat ${FILE}

echo "</pre></body></html>"
) | /usr/sbin/sendmail -t

}

email_notify "${DH_ENV} Spark Monitoring Checks (`date +%Y-%m-%d`)" "${EMAIL_TO}" ${LOGFILE}

exit $RC

