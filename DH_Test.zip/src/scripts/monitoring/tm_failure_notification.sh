#!/usr/bin/bash

# "**********************************************************************************"
#
# Usage          : bash tm_failure_notification.sh -h
# Author         : 189485@CN.CA
# Example        : bash tm_failure_notification.sh -u PIN -e INT
#                  bash tm_failure_notification.sh -u PIN -e INT -d "2020-04-25"
# 
# "**********************************************************************************"

export currentDirectory=`dirname $0`
export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;

USER=${USER}

usage()
{
    echo "usage: bash tm_failure_notification.sh -u PIN -e INT [-d \"yyyy-mm-dd\"]"
	echo "       -d is optional, by default the date range is [yesterday, today)"
	echo "       if -d is present, the date range changes to [\"yyyy-mm-dd\", today)"
}

if [ $# -eq 0 ]; then
    echo "No arguments supplied"
	usage
fi

while [ "$1" != "" ]; do
    case $1 in
        -u | --username )       shift
	                            USER=$1
				                ;;
        -e | --env)             shift
                                env=$1
                                ;;
        -d | --date )           shift
                                opt_date=$1
                                ;;								
        -h | --help )           usage
                                exit
                                ;;
        * )                     usage
                                exit 1
    esac
    shift
done


# setup env
if [ "$env" != "" ]; then
    case $env in
        "SB"|"QA"|"INT"|"PROD" )
            kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
            klist > /dev/null 2>&1
            source ${currentDirectory}/../utilities/ENV_${env}.sh > /dev/null 2>&1
            ;;
        * )         
            echo "ERROR: Invalid ENV option: "$env
            usage
            exit -1
            ;;
    esac
else
    usage
    exit -1
fi

if [ "$opt_date" != "" ]; then
    if [[ $opt_date =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]];then
        opt_date="-d "$opt_date
    else 
        echo "ERROR: Date $opt_date is in an invalid format (not YYYY-MM-DD)"
		usage
		exit -1
    fi
fi

# Declaring Environment variables
export DH_ENV=${DH_ENV}
export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client
export SPARK_HISTORY_SERVER=${SPARK_HISTORY_SERVER}
export SPARK_HISTORY_PORT=${SPARK_HISTORY_PORT}
export SPARK_JOB_PREFIX=${SPARK_JOB_PREFIX}
export hostEnv=`hostname`
export EMAIL_TO=${TARGET_EMAILS_LIST}
export SPARK_CONF_FILE=${SPARK_CONF_DIR}/spark.conf

# add Python3 path
export PATH=/opt/python3/bin:$PATH

# timestamp
ts=`date "+%Y_%m_%d_%H_%M_%S"`

# Log file
LOG_PATH=$SPARK_LOG
if [[ ! -e $LOG_PATH ]]; then
    mkdir -p $LOG_PATH
fi
rm -f $LOG_PATH/tm_failure_notification_*.txt >/dev/null 2>&1
LOGFILE=${LOG_PATH}/tm_failure_notification_${ts}.txt
touch ${LOGFILE}
chmod 777 ${LOGFILE}
  
echo spark-submit --master yarn --name "tm_failure_notification" --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA  --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE --jars $BUILD_PATH/jars/spark-sql-kafka-0-10_2.11-2.3.2.jar,$BUILD_PATH/jars/kafka-clients-0.10.2.2.jar ./tm_failure_notification.py -t $EMAIL_TO ${opt_date} >> ${LOGFILE} 2>&1
 
spark-submit --master yarn --name "tm_failure_notification" --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA  --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE --jars $BUILD_PATH/jars/spark-sql-kafka-0-10_2.11-2.3.2.jar,$BUILD_PATH/jars/kafka-clients-0.10.2.2.jar ./tm_failure_notification.py -t $EMAIL_TO ${opt_date} >> ${LOGFILE} 2>&1

