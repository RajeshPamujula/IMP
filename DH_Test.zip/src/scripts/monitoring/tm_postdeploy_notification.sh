#!/bin/bash

# "**********************************************************************************"
# Usage          : bash spark_monitoring.sh <PIN>
# condition      : 1. /hadoop/developers/<PIN>/deployment/CN.bundle.pem
#                : 2. /hadoop/developers/<PIN>/deployment/ENV_DEV.sh
# "**********************************************************************************"


if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
fi

USER=${1}
mode=deployment
host=`hostname -s`
len=${#host}
env=${host:${len}-1 : 1}

case ${env} in
  "d")
         #echo "Setting Environment variables for Dev"
         kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
         klist > /dev/null 2>&1
         source ${currentDirectory}/../utilities/ENV_DEV.sh > /dev/null 2>&1
         ;;
  "p")
         #echo "Setting Environment variables for Prod"
         kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
         klist > /dev/null 2>&1
         source ${currentDirectory}/../utilities/ENV_PROD.sh > /dev/null 2>&1
         ;;
  *)
         echo "Unknown Environment"
         exit 1
         ;;
esac

# Declaring Environment variables
export DH_TENANT=${DH_TENANT}
export DH_ENV=${DH_ENV}
export SPARK_HISTORY_SERVER=${SPARK_HISTORY_SERVER}
export SPARK_HISTORY_PORT=${SPARK_HISTORY_PORT}
export SPARK_JOB_PREFIX=${SPARK_JOB_PREFIX}
export hostEnv=`hostname`
export username=${USER}
export POSTDEPLOY_EMAIL_LIST=${POSTDEPLOY_EMAIL_LIST}
export EMAIL_TO=${POSTDEPLOY_EMAIL_LIST}
export SUBJECT=${SUBJECT}
export BUILD_PATH=${BUILD_PATH}

# add Python3 path
export PATH=/opt/python3/bin:$PATH

# Log file
LOGPATH="${BUILD_PATH}"/logs
mkdir -p "$LOGPATH"
#rm "$LOGPATH/*" >/dev/null 2>&1
LOGFILE="$LOGPATH/$$.txt"
touch ${LOGFILE}
chmod 777 ${LOGFILE}


# Mail File
#POSTDEPLOY_MESSAGE='/hadoop/developers/build/postDeploy.txt'
POSTDEPLOY_MESSAGE=${BUILD_PATH}'/postDeploy.txt'

function email_notify(){

       if [ $# -ne 3 ]; then
         echo "Usage:"
         echo ""
         echo "$0 \"Subject\" \"To_adresses\" file_to_email"
         echo ""
         exit 8
       fi

       SUBJECT=$1
       TO=$2
       FILE=$3ILFILE

       if [ ! -f ${POSTDEPLOY_MESSAGE} ]
       then
         echo "Error, file not found: ${FILE}"
         exit 8
       fi
(
cat <<EOF
From: ${USER}@`hostname --fqdn`
To: ${POSTDEPLOY_EMAIL_LIST}
Subject: ${SUBJECT}
MIME-Version: 1.0
Content-Type: text/html
Content-Disposition: inline
<html>
<body>
<pre style="font: monospace">
EOF

cat ${POSTDEPLOY_MESSAGE}

echo "</pre></body></html>"
) | /usr/sbin/sendmail -t

}

email_notify "${DH_ENV} Post-Deployment Notification (`date +%Y-%m-%d`)" "${EMAIL_TO}" "${POSTDEPLOY_MESSAGE}"

exit $RC

