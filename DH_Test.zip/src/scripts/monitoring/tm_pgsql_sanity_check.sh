#!/usr/bin/bash

# "**********************************************************************************"
#
# Usage          : bash tm_pgsql_sanity_check.sh -h
# Author         : 189485@CN.CA
# Example        : bash tm_pgsql_sanity_check.sh -u PIN -e INT
# 
# "**********************************************************************************"

export currentDirectory=`dirname $0`
export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;

USER=${USER}

usage()
{
    echo "usage: bash tm_pgsql_sanity_check.sh -u PIN -e INT -f path/sanity_check.csv"
}

if [ $# -eq 0 ]; then
    echo "No arguments supplied"
	usage
	exit 1
fi

while [ "$1" != "" ]; do
    case $1 in
        -u | --username )       shift
	                            USER=$1
				                ;;
        -e | --env)             shift
                                env=$1
                                ;;
        -d | --date )           shift
                                opt_date=$1
                                ;;
        -f | --file )           shift
                                csv_file=$1
                                ;;								
        -h | --help )           usage
                                exit
                                ;;
        * )                     usage
                                exit 1
    esac
    shift
done


# setup env
if [ "$env" != "" ]; then
    case $env in
        "SB"|"QA"|"INT"|"PROD" )
            kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
            klist > /dev/null 2>&1
            source ${currentDirectory}/../utilities/ENV_${env}.sh > /dev/null 2>&1
            ;;
        * )         
            echo "ERROR: Invalid ENV option: "$env
            usage
            exit -1
            ;;
    esac
else
    usage
    exit -1
fi

# check if sanity check CSV file exists
if [[ ! -e $csv_file ]]; then
    printf "%s\t%s\n" "[ERROR] Sanity check CSV file: $csv_file is not found!"
    exit -1
fi


# Declaring Environment variables
export DH_ENV=${DH_ENV}
export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client
export SPARK_HISTORY_SERVER=${SPARK_HISTORY_SERVER}
export SPARK_HISTORY_PORT=${SPARK_HISTORY_PORT}
export SPARK_JOB_PREFIX=${SPARK_JOB_PREFIX}
export hostEnv=`hostname`
export EMAIL_TO=${TARGET_EMAILS_LIST}
export SPARK_CONF_FILE=${SPARK_CONF_DIR}/spark.conf
export SANITY_CHECK_CSV=$csv_file

# add Python3 path
export PATH=/opt/python3/bin:$PATH

# timestamp
ts=`date "+%Y_%m_%d_%H_%M_%S"`

# Log file
LOG_PATH=$SPARK_LOG
if [[ ! -e $LOG_PATH ]]; then
    mkdir -p $LOG_PATH
fi
rm -f $LOG_PATH/tm_pgsql_sanity_check_*.txt >/dev/null 2>&1
LOGFILE=${LOG_PATH}/tm_pgsql_sanity_check_${ts}.txt
touch ${LOGFILE}
chmod 777 ${LOGFILE}

echo spark-submit ./tm_pgsql_sanity_check.py -f $SANITY_CHECK_CSV -t $EMAIL_TO >> ${LOGFILE} 2>&1
spark-submit ./tm_pgsql_sanity_check.py -f $SANITY_CHECK_CSV -t $EMAIL_TO >> ${LOGFILE} 2>&1

