#!/usr/bin/env python
# coding: utf-8

'''
  Usage   :        Use the script to record the size and row count of PostgreSQL tables
                   spark-submit tm_pgsql_monitoring.py
  Author  :        Jun Dai (189485)
  Created :        2019-12-05
  Changed :        2019-12-18 Raphael MARY - Removed filter to show only 10 tables
  Updated :        2020-05-20 Parameterize schema list
'''

import psycopg2
import collections
import pandas as pd
from datetime import datetime
import sqlalchemy
import argparse
import os,sys

# read vars from env file
try:
    user_name = os.environ["PG_USER"]
    pgsql_conn_str = os.environ["PG_CONN_URL"]
    jks_path = r'jceks://' + os.environ["PG_PWD_FILE"]
    alias_name = os.environ["PG_PWD_ALIAS"]
    schema_str = os.environ["PG_SCHEMA_LIST"]
    pgsql_schema = os.environ['PG_RAW_SCHEMA']
except KeyError as e:
    print("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
    sys.exit(-1)
    
        
# java keystore
# cmd to create jceks:    "hadoop credential create postgres.password.alias -provider jceks:/path/to/postgres.password.jceks"
# jks_path = "jceks://path/to/postgres.password.jceks"
# alias_name = "postgres.password.alias"
# source ..//utilities/ENV_*.sh

# Audit rpt will be written back to postgreSQL
# - current row count
# - current table size
# schema_list = ['tm_raw','tm_prepared','tm_trusted']
schema_str = ','.join("'{0}'".format(w) for w in schema_str.split(','))

# postgreSQL
pgsql_audit_tbl_name = 'dbo_monitoring_tblload' #os.environ['PG_'].split('.')[1]

if '' in [user_name,pgsql_conn_str,jks_path,alias_name]:
    print('Error: PostgreSQL config is missing, check your ENV setting!')
    sys.exit(-1)

host = pgsql_conn_str.split(':')[2][2:]
port = pgsql_conn_str.split(':')[3].split('/')[0]
pg_db = pgsql_conn_str.split(':')[3].split('/')[1]

# to retrieve the passwd from jave keystore
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("yarn").appName("tm_pgsql_audit").getOrCreate()

x = spark.sparkContext._jsc.hadoopConfiguration()
x.set("hadoop.security.credential.provider.path", jks_path)
a = x.getPassword(alias_name)

passwd = ""
for i in range(a.__len__()):
    passwd = passwd + str(a.__getitem__(i))

# get the full table list for each schema
# return dict => {'schema name', [list of tables]}
def get_table_list(conn):
    cur = conn.cursor()
    stmt = "select table_schema, table_name from information_schema.tables where table_schema in ("+schema_str+") and table_type='BASE TABLE';"
    cur.execute(stmt)
    rows = cur.fetchall()           
    conn.commit()
    cur.close()
    
    if(rows):
        c = collections.defaultdict(list)
        for a,b in rows:
            c[a].append(b)        
        return dict(c.items())
    else:
        return None

# create Pandas data frame
def create_audit_df(conn, schema_tbl_dict):
    df = pd.DataFrame(columns=['exec_date', 'schema_name', 'tbl_name','tbl_size','row_count'])
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # iterate the schema_table_dict to get table size and row count
    cur = conn.cursor()
    for key,value in schema_tbl_dict.items():
        for tbl in value:
            tbl_name = key+'.'+tbl
            stmt = "SELECT  pg_relation_size ('"+tbl_name+"'), count(*) from "+tbl_name+";"
            cur.execute(stmt)
            rows = cur.fetchone()
            df = df.append({'exec_date':ts , 'schema_name':key , 'tbl_name':tbl ,'tbl_size':rows[0] ,'row_count':rows[1] }, ignore_index=True)
    df['exec_date']= pd.to_datetime(df['exec_date'])        
    conn.commit()
    cur.close()
    return df

def sample_df(df):
    df_s = df.loc[df['tbl_name'] != pgsql_audit_tbl_name].sort_values(by =['exec_date', 'schema_name', 'tbl_name'])
    return df_s

def write_df_to_pgsql(df):
    conn_str = "postgresql://{0}:{1}@{2}:{3}/{4}".format(user_name,passwd,host,port,pg_db)
    engine = sqlalchemy.create_engine(conn_str)
    df.to_sql(pgsql_audit_tbl_name, engine, schema=pgsql_schema.lower(),if_exists='append',index=False)
    

def generate_header(user):
    header  = ["-" * 146]
    header += [(" " * 37) + ("*" * 22) + " PostgreSQL Monitoring Report " + ("*" * 22) + (" " * 38)]
    header += ["-" * 146]
    header += [""]
    header += ["UTC Date and Time : " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
    header += ["User              : " + user]
    header += [""]    
    return "\n".join(header)

def generate_footer():
    footer  = [""]
    footer += ["-" * 146]
    footer += ["Ending " + __file__ + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d-%H.%M.%S")]
    footer += ["-" * 146]    
    return "\n".join(footer)
    
    
if __name__ == '__main__': 

    # connect to PostgreSQL DB
    conn = psycopg2.connect(database=pg_db, user=user_name, password=passwd, host=host, port=port)
    #print("{0} INFO: Connected to: {1}/{2}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), host,pg_db))

    df = create_audit_df(conn, get_table_list(conn))
    # Persist the audit result to postgreSQL
    write_df_to_pgsql(df)

    # Print Report
    print(generate_header(os.environ["USER"]))
    #print("{0} INFO: Records are written to {1}/{2}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"),pg_db,pgsql_audit_tbl_name))  
    print(sample_df(df).to_string(index=False))
    print(generate_footer())
    
    # clean-up
    if(conn):
        conn.close()
