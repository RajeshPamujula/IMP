#!/usr/bin/env python
# coding: utf-8

'''
  Usage   :        Use the script to run monitoring queries to check data integrity in PostgreSQL tables
                   spark-submit tm_pgsql_monitoring_queries.py
  Author  :        Yonghua Wu (xt26821) (Copied from tm_pgsql_monitoring.py creatd by Dai Jun)
  Created :        2020-01-03
  Changed :
'''

import psycopg2
import collections
import pandas as pd
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
import sqlalchemy
import argparse
import os,sys
import logging

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--to', action='store', dest='to_',
                        help="receiver's email address")
    args = parser.parse_args()

    # must provide at least one arg of --email or --db
    #if not (args.send_email or args.db_insert):
    #   parser.error("Must provide at least one of the arguments: --db or --email")

    # must provide a recipient with -t if --email is specified
    #if args.send_email and not args.to_:
    #   parser.error("Must provide --to [email address] if --email is given.")

    return args

def send_email(subj,from_,to_,msg_body):
    """Send email to receiver

    Args:
        subj:      Email's subject
        from_:     Sender's email address
        to_:       Receiver's email address
        msg_body:  Email body in hmtl format
    Returns:

    """
    msg = MIMEMultipart('alternative')
    msg["From"] = from_
    msg["To"] = to_
    msg["Subject"] = subj
    HTML_BODY = MIMEText(msg_body, 'html')
    msg.attach(HTML_BODY)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    if (sys.version_info > (3, 0)):
        p.communicate(msg.as_bytes())
    else:
        p.communicate(msg.as_string())

# java keystore
# cmd to create jceks:    "hadoop credential create postgres.password.alias -provider jceks:/path/to/postgres.password.jceks"
# jks_path = "jceks://path/to/postgres.password.jceks"
# alias_name = "postgres.password.alias"
# source ..//utilities/ENV_*.sh
user_name = os.environ["PG_USER"]
pgsql_conn_str = os.environ["PG_CONN_URL"]
jks_path = r'jceks://' + os.environ["PG_PWD_FILE"]
alias_name = os.environ["PG_PWD_ALIAS"]
pgsql_schema = os.environ["PG_PREPARED_SCHEMA"]

if '' in [user_name,pgsql_conn_str,jks_path,alias_name]:
    print('Error: PostgreSQL config is missing, check your ENV setting!')
    sys.exit(-1)

host = pgsql_conn_str.split(':')[2][2:]
port = pgsql_conn_str.split(':')[3].split('/')[0]
pg_db = pgsql_conn_str.split(':')[3].split('/')[1]

# to retrieve the passwd from jave keystore
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("yarn").appName("tm_pgsql_audit_data_integrity").getOrCreate()

x = spark.sparkContext._jsc.hadoopConfiguration()
x.set("hadoop.security.credential.provider.path", jks_path)
a = x.getPassword(alias_name)

passwd = ""
for i in range(a.__len__()):
    passwd = passwd + str(a.__getitem__(i))

pd.set_option('display.max_colwidth', 100)
pd.set_option('display.max_rows', 999)
pd.set_option('display.width', 1000)

#def generate_header(user):
#    header  = ["-" * 146]
#    header += [(" " * 37) + ("*" * 22) + " PostgreSQL Monitoring Report for Data Integrity " + ("*" * 22) + (" " * 38)]
#    header += ["-" * 146]
#    header += [""]
#    header += ["UTC Date and Time : " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
#    header += ["User              : " + user]
#    header += [""]
#    return "\n".join(header)

#def generate_footer():
#    footer  = [""]
#    footer += ["-" * 146]
#    footer += ["Ending " + __file__ + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d-%H.%M.%S")]
#    footer += ["-" * 146]
#    return "\n".join(footer)

def generate_header(user):
    header  = ["PostgreSQL Monitoring Report for Data Integrity"]
    header += ["<hr>"]
    header += [""]
    header += ["UTC Date and Time: " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
    header += ["User: " + user]
    header += [""]
    return "<br>".join(header)

def generate_footer():
    footer  = [""]
    footer += ["<hr>"]
    footer += ["Ending " + os.path.basename(__file__) + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d-%H.%M.%S")]
    footer += ["<hr>"]
    return "<br>".join(footer)

if __name__ == '__main__':

    args = get_args()

    # connect to PostgreSQL DB
    conn = psycopg2.connect(database=pg_db, user=user_name, password=passwd, host=host, port=port)
    conn.autocommit = True
    #print("{0} INFO: Connected to: {1}/{2}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), host,pg_db))

    stmt = "select quality_class, table_name, domn_nm, description, expected_output, actual_output from {}.f_run_dh_integrity_controls_queries() order by domn_nm, quality_class, description;".format(pgsql_schema)
    df = pd.read_sql_query(stmt, conn)

    # Print Report
    print(generate_header(os.environ["USER"]))
    #print("{0} INFO: Records are written to {1}/{2}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"),pg_db,pgsql_audit_tbl_name))
    print(df.to_string(index=False))
    print(generate_footer())

    # clean-up
    if(conn):
        conn.close()

    if args.to_:
        # Email Report
        report  = generate_header(os.environ["USER"])
        report += "<br>"
        report += df.to_html()
        report += "<br>"
        report += generate_footer()

        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        subj = "PostgreSQL Data Integrity Checks ({ts})".format(ts=ts)
        from_ = os.getenv("USER") + '@CN.CA'
        to_ = args.to_
        send_email(subj,from_,to_,report)


