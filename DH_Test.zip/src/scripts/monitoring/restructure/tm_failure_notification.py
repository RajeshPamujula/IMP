#!/opt/python3/bin/python
# coding: utf-8

'''
  Usage   :        spark-submit tm_monitoring_notification.py -h
  Author  :        Jun Dai (189485) / Brendan McGarry (193459) / Rajesh Pamujula (xt25766)
  Created :        2020-04-26
  Desc    :
      -e flag for whether to send a notification email; default is false
      -b flag for whether to save results in the db; default is false
      -t receiver's email address
      -d optional start date, format: yyyy-mm-dd, eg: 2020-04-25
      
  New update : The updated script will retrieve all the errors until script run datetime 
              and override it in the table if already exists
              added ERROR_Date,SOR_TPIC_NM column in table and renamed error_queue to source_que
              Updated Email header and footer

  Example :
        spark-submit --name "tm_failure_notification" --master yarn --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE --jars $BUILD_PATH/jars/spark-sql-kafka-0-10_2.11-2.3.2.jar,$BUILD_PATH/jars/kafka-clients-0.10.2.2.jar \
        ./tm_failure_notification.py [--db] [--email -t <email address>]
        where either --db or --email and -t are required.
'''
from pyspark.sql.types import StructType, StringType, StructField, TimestampType
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import sqlalchemy
#import time
from datetime import datetime,date,timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
import sys,os
import argparse
import logging
import psycopg2
import pandas as pd

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--to', action='store', dest='to_',
                        help="receiver's email address")
    parser.add_argument('-e', '--email', action='store_true', dest='send_email',
                        help="flag for whether to send an email")
    parser.add_argument('--db', action='store_true', dest='db_insert',
                        help="flag for whether to store in the database")
    parser.add_argument('-d', action='store', dest='opt_date', default='',
                        help="optional start date, format: yyyy-mm-dd")
    args = parser.parse_args()
    
    # must provide at least one arg of --email or --db
    if not (args.send_email or args.db_insert):
        parser.error("Must provide at least one of the arguments: --db or --email")
    
    # must provide a recipient with -t if --email is specified
    if args.send_email and not args.to_:
        parser.error("Must provide --to [email address] if --email is given.")
    
    return args

def send_email(subj,from_,to_,msg_body):
    """Send email to receiver
    
    Args:
        subj:      Email's subject
        from_:     Sender's email address
        to_:       Receiver's email address
        msg_body:  Email body in hmtl format
    Returns:
        
    """
    msg = MIMEMultipart('alternative')
    msg["From"] = from_
    msg["To"] = to_
    msg["Subject"] = subj
    HTML_BODY = MIMEText(msg_body, 'html')
    msg.attach(HTML_BODY)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    if (sys.version_info > (3, 0)):
        res = p.communicate(msg.as_bytes())
    else:
        p.communicate(msg.as_string())


def define_schema():
    return StructType([StructField("LogHeader",
                           StructType([StructField("ERROR_TO_DE",StringType(),True),
                                       StructField("RAW_KAFKA_QUEUE_NAME",StringType(),True),
                                       StructField("SPARK_JOB_NAME",StringType(),True),
                                       StructField("ERROR_TS",TimestampType(),True)])),
           StructField("DomainEventHeader",
                           StructType([StructField("SOR_TPIC_NM",StringType(),True)
                                      ]),True)])
    

def getMaxDate_FromDB(self):
    try:
        envDict["pg"]
        user_name=self.config["pg"]["user"]
        passwd=self._pg_pwd
        host=self.config["pg"]["host"]
        port=self.config["pg"]["port"]
        pg_db=self.config["pg"]["db"]
        connection = psycopg2.connect(database=pg_db, user=user_name, password=passwd, host=host, port=port)
        connection.autocommit = True
        cursor = connection.cursor()
        stmt = """select date(coalesce((max(ERROR_DATE)),current_date-7)) from {}.dh_monitor_error_queue""".format(os.environ["PG_PREPARED_SCHEMA"])
        cursor.execute(stmt)
        my_record = cursor.fetchone()
        maxDate_lastRun = my_record[0]
        date_format = "%Y-%m-%d"
        dbDate = datetime.strptime(str(maxDate_lastRun), date_format)
        curDate = datetime.strptime(str(date.today()), date_format)
        daysDiff = curDate - dbDate
        return int(daysDiff.days)
        cursor.close()
        connection.close()
    except Exception as err:
        print(err)
        if connection:
            connection.close()
        return int(daysDiff.days)
    #return maxDate_lastRun

def add_date_range(args,last_run_day):
    """create or modify the date range
       The default date range is from yesterday to today, today is not included.
       If the argument "opt_date" is present,
       first check if "opt_date" is valid,
       if valid, use it as start date otherwise use yesterday.
       
    Args:
        args: a Namespace object containing the arguments to the command.
    Returns:
        
    """
    # calculate date range
    today = date.today()
    yesterday = today - timedelta(days = int(last_run_day))
    #yesterday = today - timedelta(days = 7)
    args.ts_from = yesterday
    args.ts_to = today
    if args.opt_date and args.opt_date.strip() != "":
        try:
            ts_from = datetime.strptime(args.opt_date, "%Y-%m-%d").date()
            if ts_from > yesterday:
                logging.warning("Invalid date is given {}, query the date from yesterday instead.".format(ts_from))
            else:
                args.ts_from = ts_from
        except Exception as e:
            logging.error(e)
            sys.exit(-1)


def generate_header(user):
    header  = ["Failure Notification Report"]
    header += ["<hr>"]
    header += [""]
    header += ["UTC Date and Time: " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
    header += ["User: " + user]
    header += [""]
    return "<br>".join(header)

def generate_footer():
    footer  = [""]
    footer += ["<hr>"]
    footer += ["Ending " + os.path.basename(__file__) + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d-%H.%M.%S")]
    footer += ["<hr>"]
    return "<br>".join(footer)

def get_pg_conn_params(pgsql_conn_str):
    host = pgsql_conn_str.split(':')[2][2:]
    port = pgsql_conn_str.split(':')[3].split('/')[0]
    pg_db = pgsql_conn_str.split(':')[3].split('/')[1]
    return host, port, pg_db


class FailureNotificationService(object):
    """A class to read failure message from Kafka topics,
       using default date range [Yesterday, Today),
       where Today is not included,
       generate report then send out by email.
       Kafka batch query is used.
       
    Attributes:
        config: combines both application arguments and environmental variables
        schema: spark dataframe schema, it's a subset of JSON schema
    """
    
    def __init__(self,schema,**configs):
        self.config = configs
        self.schema = schema
        user = os.environ['USER']
        self.spark  = SparkSession.builder.master("yarn").appName(user + "_tm_flr_notif_script").getOrCreate()
        self._pg_pwd = self._get_pg_pwd()
        
    def run(self):
        raw_df = self.readStream()
        transformed_df = self.transform(raw_df)
        self.sink(transformed_df)
    
    def readStream(self):
        df = self.spark \
          .read \
          .format("kafka") \
          .option("kafka.bootstrap.servers", self.config["kafka_brokers"]) \
          .option("kafka.security.protocol", "SASL_PLAINTEXT") \
          .option("subscribe", self.config["topic"]) \
          .option("startingOffsets", "earliest") \
          .option("kafka.request.timeout.ms","150000") \
          .load().selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
        return df.select(F.from_json(F.col("value").cast(StringType()), self.schema).alias("message")).select("message.*")
        
    def transform(self,raw_df):
        # Transformation
        # Omit the details, "Detail:.*"
        # group by "SPARK_JOB_NAME","ERROR_TO_DE" and order by "Count"
        kafkaDF = raw_df.select(
            raw_df.DomainEventHeader.SOR_TPIC_NM.alias("SOR_TPIC_NM"),
            raw_df.LogHeader.ERROR_TS.alias("ERROR_TS"),
            raw_df.LogHeader.SPARK_JOB_NAME.alias("SPARK_JOB_NAME"),
            raw_df.LogHeader.RAW_KAFKA_QUEUE_NAME.alias("RAW_KAFKA_QUEUE_NAME"),
            F.regexp_replace(raw_df.LogHeader.ERROR_TO_DE,"Detail:.*","").alias("ERROR_TO_DE"),
            F.date_format(raw_df.LogHeader.ERROR_TS,"yyyy-MM-dd").alias("ERROR_DATE").cast("date"))
            #F.split((raw_df.LogHeader.ERROR_TS," ").getItem(0)).alias("ERROR_DATE")
            #split(col("State_Name"), "-").getItem(0))
            #kafkaDF.kafkaDF.ERROR_TS
        kafkaDF = kafkaDF.filter((kafkaDF.ERROR_TS >= F.to_date(F.lit(self.config["ts_from"]))) & (kafkaDF.ERROR_TS < F.to_date(F.lit(self.config["ts_to"]))))
        return kafkaDF.groupBy(["SOR_TPIC_NM","SPARK_JOB_NAME","RAW_KAFKA_QUEUE_NAME","ERROR_TO_DE","ERROR_DATE"]).count().alias("Count").orderBy("Count",ascending=False).select(["SOR_TPIC_NM","SPARK_JOB_NAME","Count","RAW_KAFKA_QUEUE_NAME","ERROR_TO_DE","ERROR_DATE"])
    
    def add_cols(self, transformed_df):
        exec_date = datetime.now()
        appended_df = transformed_df \
            .withColumnRenamed("SPARK_JOB_NAME", "JOB_NAME") \
            .withColumnRenamed("RAW_KAFKA_QUEUE_NAME", "SOURCE_QUEUE") \
            .withColumnRenamed("Count", "ERROR_COUNT") \
            .withColumn("EXEC_DATE", F.lit(exec_date)) \
            .select("SOR_TPIC_NM","JOB_NAME", "EXEC_DATE", "SOURCE_QUEUE", "ERROR_COUNT", "ERROR_TO_DE","ERROR_DATE").orderBy("ERROR_DATE",ascending=False)
        
        # lowercase the column names for Postgres DB insert
        appended_df = appended_df.select(
            [F.col(col_name).alias(col_name.lower()) for col_name in appended_df.columns]
        )
        return appended_df
    
    def sink(self,transformed_df):
        if self.config['send_email']:
            # generate report
            pdf = transformed_df.toPandas()
            
            report  = generate_header(os.environ["USER"])
            report += "<br>"
            report += pdf.to_html()
            report += "<br>"
            report += generate_footer()
            
            #email_content = pdf.to_html(index=False)
            email_content = report
            from_ = os.getenv("USER") + '@CN.CA'
            
            # send by email
            if not self.config["to_"].upper().endswith('@CN.CA'):
               self.config["to_"] += '@CN.CA'
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            from_ts = self.config["ts_from"].strftime("%Y-%m-%d")
            to_ts = self.config["ts_to"].strftime("%Y-%m-%d")
            subj = "Failure Notification Report [{} to {}] on {}".format(from_ts,to_ts,ts)
            send_email(subj,from_,self.config["to_"],email_content)
        
        if self.config['db_insert']:
            #self.write_df_to_pgsql(self.add_cols(transformed_df).toPandas())
            # upserting reach record from dataframe to PostGres table untill records ends
            self.upsert_df_to_pgsql(pd.DataFrame(self.add_cols(transformed_df).toPandas()))
    
    def write_df_to_pgsql(self,df):
        conn_str = "postgresql://{user}:{passwd}@{host}:{port}/{db}".format(
            user=self.config["pg"]["user"],
            passwd=self._pg_pwd,
            host=self.config["pg"]["host"],
            port=self.config["pg"]["port"],
            db=self.config["pg"]["db"])
        engine = sqlalchemy.create_engine(conn_str)
        df.to_sql(self.config["pg_error_queue_tbl_name"], engine, schema=self.config["pg"]["schema"].lower(), if_exists='append', index=False)
    
    ### upsert the all the records from datadrame to db table
    def upsert_df_to_pgsql(self,df):

        if len(df) > 0:
            try:
                conn = psycopg2.connect(database=self.config["pg"]["db"], user=self.config["pg"]["user"], password=self._pg_pwd, host=self.config["pg"]["host"], port=self.config["pg"]["port"])
                #print("Successfully connected to PostGreSQL Database")
                conn.autocommit = True
                cursor = conn.cursor()
                #df.reset_index(drop=True)
                df=pd.DataFrame(df)
                df["exec_date"]=pd.to_datetime(df["exec_date"])
                df["error_date"]=pd.to_datetime(df["error_date"])
                for dfrownumber in range(len(df)):
                    
                    # Conditional filter to verify any records is null or empty and replace with topic name
                    if str(df["sor_tpic_nm"][dfrownumber])=="nan" or str(df["sor_tpic_nm"][dfrownumber])=="" or str(df["sor_tpic_nm"][dfrownumber])=="None" or type(df["sor_tpic_nm"][dfrownumber])==float:
                        SOR_TPIC_NM=str(df["source_queue"][dfrownumber])
                    else:
                        SOR_TPIC_NM = str(df["sor_tpic_nm"][dfrownumber])
                        
                    #SOR_TPIC_NM = str(df["sor_tpic_nm"][dfrownumber])
                    JOB_NAME = str(df["job_name"][dfrownumber])
                    EXEC_DATE = str(df["exec_date"][dfrownumber])
                    SOURCE_QUEUE = str(df["source_queue"][dfrownumber])
                    error_count = int(df["error_count"][dfrownumber])
                    ERROR_TO_DE = str(df["error_to_de"][dfrownumber])
                    ERROR_DATE = str(df["error_date"][dfrownumber])
                    upsertQuery = """INSERT INTO {schema}.dh_monitor_error_queue (SOR_TPIC_NM, JOB_NAME, EXEC_DATE, SOURCE_QUEUE, error_count, ERROR_TO_DE, ERROR_DATE) VALUES({SOR_TPIC_NM}, {JOB_NAME}, {EXEC_DATE}, {SOURCE_QUEUE}, {error_count},{ERROR_TO_DE},{ERROR_DATE}) ON conflict (SOR_TPIC_NM,job_name, error_to_de,ERROR_DATE) DO UPDATE SET EXEC_DATE = EXCLUDED.EXEC_DATE,error_count = EXCLUDED.error_count WHERE {schema}.dh_monitor_error_queue.ERROR_DATE ={ERROR_DATE}""".format(SOR_TPIC_NM="'" + SOR_TPIC_NM +"'", JOB_NAME="'" + JOB_NAME + "'", EXEC_DATE="'" + EXEC_DATE + "'", SOURCE_QUEUE="'" + SOURCE_QUEUE + "'", error_count=int(error_count),ERROR_TO_DE="'"+ERROR_TO_DE+"'",ERROR_DATE="'"+ERROR_DATE+"'",schema=os.environ["PG_PREPARED_SCHEMA"])            
                    cursor.execute(upsertQuery)
                
                cursor.close()
                conn.close()
            except Exception as err:
                print("ERROR has occured: - "+err)
                exit(RC_ERROR)
            
            if conn:
                conn.close()    
    
    
    def _get_pg_pwd(self):
        hadoop_conf = self.spark.sparkContext._jsc.hadoopConfiguration()
        hadoop_conf.set("hadoop.security.credential.provider.path", self.config["jks_path"])
        pw_obj = hadoop_conf.getPassword(self.config["pg"]["alias_name"])   
        passwd = ''.join([str(pw_obj.__getitem__(i)) for i in range(pw_obj.__len__())])
        return passwd


if __name__ == '__main__':
    # config logging
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(level=logging.INFO, format=FORMAT)
    # arguments + env vars
    # Set environment variables
    #args = get_args()
    #add_date_range(args,7)
    envDict = {}
    try:
        envDict["jks_path"] = r'jceks://' + os.environ["PG_PWD_FILE"]
        pg_user             = os.environ["PG_USER"]
        pgsql_conn_str      = os.environ["PG_CONN_URL"]
        alias_name          = os.environ["PG_PWD_ALIAS"]
        pgsql_schema        = os.environ["PG_PREPARED_SCHEMA"]
        
        envDict["kafka_brokers"]        = os.environ["KAFKA_BROKER_HOST"]
        topic_trans_rte_err_prepared    = os.environ["TRANSPORTATION_RTE_ERR_PREPARED"]
        topic_trans_dh_pglogs_prepared  = os.environ["TRANSPORTATION_DH_PGLOGS_PREPARED"]
        envDict["topic"] = ','.join([topic_trans_rte_err_prepared,topic_trans_dh_pglogs_prepared])
    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        exit(RC_ERROR)
    
    envDict["pg_error_queue_tbl_name"] = "dh_monitor_error_queue"
    pg_host, pg_port, pg_db = get_pg_conn_params(pgsql_conn_str)
    envDict["pg"] = {
        "user": pg_user,
        "host": pg_host,
        "port": pg_port,
        "db": pg_db,
        "alias_name": alias_name,
        "schema": pgsql_schema,
    }
    
    # Python3 only
    args = get_args()
    # Get max data from error table and passing to data_range function as a argument
    add_date_range(args,7)
    
    configs = {**vars(args),**envDict}
    schema = define_schema()
    flr_notif_service = FailureNotificationService(schema,**configs)
    flr_notif_service.run()
    exit(RC_SUCCESS)
