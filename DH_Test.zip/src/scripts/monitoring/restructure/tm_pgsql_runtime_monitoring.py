#!/usr/bin/env python
# coding: utf-8

'''
  Usage   :        Use the script to run sanity queries to check record count in last 10mins in PostgreSQL tables
                   spark-submit tm_pgsql_sanity_monitoring_queries.py
  Author  :        Uma Rajamanickam (xt25897) / Yonghua Wu / Brendan McGarry/Rajesh Pamujula
  Created :        2020-04-21
  Usage   :        spark-submit --name "tm_pgsql_sanity_monitoring" --master yarn --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE --jars $BUILD_PATH/jars/spark-sql-kafka-0-10_2.11-2.3.2.jar,$BUILD_PATH/jars/kafka-clients-0.10.2.2.jar \
                   ./tm_pgsql_sanity_monitoring.py [--db] [--email -t $EMAIL_TO $email]
                   where either --db or --email and -t are required.
  New Update :     updated script will run loop multiple times until current_date -1 from last execution date(stats_date)
                      added new columns (status_date,status_interval) for easy data analisys from table
                   -
'''

import psycopg2
import pandas as pd
from datetime import datetime,timedelta,date
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
import sqlalchemy
import os,sys
import argparse

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--to', action='store', dest='to_',
                        help="receiver's email address")
    parser.add_argument('-e', '--email', action='store_true', dest='send_email',
                        help="flag for whether to send an email")
    parser.add_argument('--db', action='store_true', dest='db_insert',
                        help="flag for whether to store in the database")
    parser.add_argument('-d', action='store', dest='opt_date', default='',
                        help="optional start date, format: yyyy-mm-dd")
    args = parser.parse_args()
    
    # must provide at least one arg of --email or --db
    if not (args.send_email or args.db_insert):
        parser.error("Must provide at least one of the arguments: --db or --email")
    
    # must provide a recipient with -t if --email is specified
    if args.send_email and not args.to_:
        parser.error("Must provide --to [email address] if --email is given.")
    
    return args

def send_email(subj,from_,to_,msg_body):
    """Send email to receiver
    
    Args:
        subj:      Email's subject
        from_:     Sender's email address
        to_:       Receiver's email address
        msg_body:  Email body in hmtl format
    Returns:
        
    """
    msg = MIMEMultipart('alternative')
    msg["From"] = from_
    msg["To"] = to_
    msg["Subject"] = subj
    HTML_BODY = MIMEText(msg_body, 'html')
    msg.attach(HTML_BODY)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    if (sys.version_info > (3, 0)):
        p.communicate(msg.as_bytes())
    else:
        p.communicate(msg.as_string())

user_name = os.environ["PG_USER"]
pgsql_conn_str = os.environ["PG_CONN_URL"]
jks_path = r'jceks://' + os.environ["PG_PWD_FILE"]
alias_name = os.environ["PG_PWD_ALIAS"]
pgsql_schema = os.environ['PG_PREPARED_SCHEMA']

# postgreSQL
pgsql_runtime_tbl_name  = 'dh_monitor_de_runtimes'

if '' in [user_name, pgsql_conn_str, jks_path, alias_name]:
    print('Error: PostgreSQL config is missing, check your ENV setting!')
    sys.exit(-1)

host = pgsql_conn_str.split(':')[2][2:]
port = pgsql_conn_str.split(':')[3].split('/')[0]
pg_db = pgsql_conn_str.split(':')[3].split('/')[1]

# to retrieve the passwd from jave keystore
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("yarn").appName(os.environ['USER'] + "_tm_pgsql_runtime_status").getOrCreate()

x = spark.sparkContext._jsc.hadoopConfiguration()
x.set("hadoop.security.credential.provider.path", jks_path)
a = x.getPassword(alias_name)

passwd = ""
for i in range(a.__len__()):
    passwd = passwd + str(a.__getitem__(i))

pd.set_option('display.max_colwidth', 100)
pd.set_option('display.max_rows', 999)
pd.set_option('display.width', 1000)

def convert_df_timedelta_to_str(df):
    for col in df.columns[3:]:
        df[col] = df[col].astype(str)
    return df

def write_df_to_pgsql(df):
    conn_str = "postgresql://{0}:{1}@{2}:{3}/{4}".format(user_name,passwd,host,port,pg_db)
    engine = sqlalchemy.create_engine(conn_str)
    df.to_sql(pgsql_runtime_tbl_name, engine, schema=pgsql_schema.lower(),if_exists='append',index=False)

def generate_header(user):
    header  = ["PostgreSQL Sanity Check Report for Data count"]
    header += ["<hr>"]
    header += [""]
    header += ["UTC Date and Time: " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
    header += ["User: " + user]
    header += [""]
    return "<br>".join(header)

def generate_footer():
    footer  = [""]
    footer += ["<hr>"]
    footer += ["Ending " + os.path.basename(__file__) + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d-%H.%M.%S")]
    footer += ["<hr>"]
    return "<br>".join(footer)

# this function will get max(last run) date from dh_monitor_de_runtimes table
def getMaxDate_FromDB():
    try:
        connection = psycopg2.connect(database=pg_db, user=user_name, password=passwd, host=host, port=port)
        connection.autocommit = True
        cursor = connection.cursor()
        stmt = "select date(coalesce((max("'"stats_date"'")+1),current_date-1)) from {}.dh_monitor_de_runtimes".format(pgsql_schema)
        cursor.execute(stmt)
        my_record = cursor.fetchone()
        maxDate_lastRun = my_record[0]
        cursor.close()
        connection.close()
    except Exception as err:
        print(err)
        if connection:
            connection.close()
    return maxDate_lastRun

# this function will return no of days between current date and other date
def daysDiff_From_CurrentDate(dbMaxDate):
    date_format = "%Y-%m-%d"
    dbDate = datetime.strptime(str(dbMaxDate), date_format)
    curDate = datetime.strptime(str(date.today()), date_format)
    daysDiff = curDate - dbDate
    return int(daysDiff.days)


if __name__ == '__main__':
    try:
        args = get_args()

        sample_DF_report=[]
        # fetch max stats date from runtime table
        recent_RunDate_getFromDB = getMaxDate_FromDB()       
        NumberOf_daysdiffFrom_LastRun  = daysDiff_From_CurrentDate(recent_RunDate_getFromDB)
        # execute the loop from last stats date to current date -1
        for runFromLastExeecution in range(0 , NumberOf_daysdiffFrom_LastRun+1 , 1):
            #print("runFromLastExeecution - Loop count",runFromLastExeecution+1)  
            conn = psycopg2.connect(database=pg_db, user=user_name, password=passwd, host=host, port=port)
            conn.autocommit = True
            stmt = "select * from {}.f_run_dh_runtime_monitoring();".format(pgsql_schema)
            df = pd.read_sql_query(stmt, conn)
            conn.close()
            df = convert_df_timedelta_to_str(df)
            stats_date = (recent_RunDate_getFromDB + timedelta(days=runFromLastExeecution))
            df["stats_date"]=str(stats_date)
            if args.db_insert and len(df)>0 and stats_date < date.today():
                
                # selecting recentdate records for email report
                sample_DF_report = df
                # Persist the monitoring result to postgreSQL
                write_df_to_pgsql(df)
                
    except Exception as e:
        print ("Execption",e.with_traceback)
        if conn:
            conn.close()
        exit(RC_ERROR)
    
    if args.send_email:
        
        # Email Report to display only recent date specfic manditory columns
            # updated some manditory columns only to display in email body
        if len(sample_DF_report)>=1:
            df=sample_DF_report[['table_name','sor_tpic_nm','stats_interval','exec_date','stats_date','avg_sor_raw','avg_wait_raw']]
        else:
            df=df[['table_name','sor_tpic_nm','stats_interval','exec_date','stats_date','avg_sor_raw','avg_wait_raw']]
            
        report  = generate_header(os.environ["USER"])
        report += "<br>"
        report += df.to_html()
        report += "<br>"
        report += generate_footer()
        
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        subj = "PostgreSQL RunTime Monitoring Checks ({ts})".format(ts=ts)
        from_ = os.getenv("USER") + '@CN.CA'
        to_ = args.to_
        send_email(subj,from_,to_,report)

    # clean-up
    if conn:
        conn.close()
    exit(RC_SUCCESS)