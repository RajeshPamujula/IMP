'''
  Author:   Brendan.McGarry@cn.ca / Jun.Dai@cn.ca
  Date:     Feb-21-2020
  Usage:    spark-submit tm_spark_monitoring.py -u <userId> [--db] [--email -t <target email address>]
            where either --db or --email -t must be provided.
'''

import argparse
import requests
from requests_kerberos import HTTPKerberosAuth, OPTIONAL
import os
import json
import re
import pandas as pd
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
import sqlalchemy
import dateutil.parser
import sys
import logging

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', action='store', dest='user_id',
                        help="The user ID to filter on for all Spark jobs", required=True)
    parser.add_argument('-t', '--to', action='store', dest='to_',
                        help="receiver's email address")
    parser.add_argument('-e', '--email', action='store_true', dest='send_email',
                        help="flag for whether to send an email")
    parser.add_argument('--db', action='store_true', dest='db_insert',
                        help="flag for whether to store in the database")
    
    args = parser.parse_args()
    
    # must provide at least one arg of --email or --db
    if not (args.send_email or args.db_insert):
        parser.error("Must provide at least one of the arguments: --db or --email")
    
    # must provide a recipient with -t if --email is specified
    if args.send_email and not args.to_:
        parser.error("Must provide --to [email address] if --email is given.")
    
    return args

def write_df_to_pgsql(df):
    conn_str = "postgresql://{0}:{1}@{2}:{3}/{4}".format(pg_user_name,passwd,host,port,pg_db)
    engine = sqlalchemy.create_engine(conn_str)
    result = df.to_sql(pgsql_target_tbl_name, engine, schema=pgsql_schema.lower(),if_exists='append',index=False)
    return result


def send_email(subj, from_, to_, msg_body):
    """Send email to receiver
    
    Args:
        subj:      Email's subject
        from_:     Sender's email address
        to_:       Receiver's email address
        msg_body:  Email body in hmtl format
    Returns: None  
    """
    msg = MIMEMultipart('alternative')
    msg["From"] = from_
    msg["To"] = to_
    msg["Subject"] = subj
    HTML_BODY = MIMEText(msg_body, 'html')
    msg.attach(HTML_BODY)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    if (sys.version_info > (3, 0)):
        p.communicate(msg.as_bytes())
    else:
        p.communicate(msg.as_string())


def get_spark_history(bundle, kerberos_auth, spark_history_url):
    r = requests.get('http://{}/api/v1/applications'.format(spark_history_url), verify=bundle, auth=kerberos_auth)
    spark_history_dict = json.loads(r.text)
    
    return spark_history_dict

def get_yarn_history(bundle, kerberos_auth, spark_history_url):
    r = requests.get('http://{}/ws/v1/cluster/apps?applicationTypes=SPARK'.format(spark_history_url), verify=bundle, auth=kerberos_auth)
    spark_history_dict = json.loads(r.text)    
    return spark_history_dict['apps']['app']


def get_prefixed_yarn_jobs(user_id, jobs, prefix=''):
    # get only jobs for given user id
    user_jobs = [job for job in jobs if job['user'] == user_id]
    
    # get jobs starting with the job name prefix (e.g. "dh_")
    prefixed_jobs = [job for job in user_jobs if any(job['name'].startswith(p) for p in prefix.split(','))]
    
    return prefixed_jobs


def get_most_recent_jobs(jobs):
    """
    From a list of spark jobs, generate a list the most recent jobs for each unique name.
    
    E.g. job1 (id 1): running,
         job1 (id 2): running,
         job2 (id 3): finished & started on June 11,
         job2 (id 4): finished & started on June 12
        =>
         job1 (id 1), job2 (id 4)
    """
    recent_jobs = {}
    
    for job in jobs:
        # if this job is the most recent of its name
        if not recent_jobs.get(job['name']) \
        or job['attempts'][0]['startTime'] > recent_jobs[job['name']]['attempts'][0]['startTime']:
            recent_jobs[job['name']] = job
        
    relevant_jobs = sorted(list(recent_jobs.values()),
                           key=lambda job: (not job['attempts'][0]['completed'], job['attempts'][0]['startTime']),
                           reverse=True)
    
    return relevant_jobs


def get_most_recent_yarn_jobs(jobs):
    recent_jobs = {}
    
    for job in jobs:
        # if this job is the most recent of its name
        if not recent_jobs.get(job['name']) \
        or job['startedTime'] > recent_jobs[job['name']]['startedTime']:
            recent_jobs[job['name']] = job
        
    relevant_jobs = sorted(list(recent_jobs.values()),
                           key=lambda job: (job['state'], job['startedTime']),
                           reverse=True)
    
    return relevant_jobs


def jobs_to_table(formatted_jobs):
    for job in formatted_jobs:
        for k in ['startedTime', 'finishedTime', 'elapsedTime']:
            job[k] = convert_epoch_ts(k,job[k])
    df = pd.DataFrame(formatted_jobs)
    df.index += 1  # starts job index at 1 instead of 0 for human readability
    return df.to_string()


def table_width(table_str):
    return max([len(line) for line in table_str.split('\n')])


fields_to_print = ['startedTime', 'finishedTime', 'elapsedTime', 'state', 'finalStatus']
def format_jobs(jobs, streaming_suffix=None):
    printable_jobs = [{
        **{'name': job['name']},
        **{key: job[key] for key in fields_to_print}
    } for job in jobs]
      
    return printable_jobs

   
def get_ts_from_epoch(epoch_time):
    return datetime.fromtimestamp(int(epoch_time)/1000.0)

def ms_to_dhms(millsec):
    day = 0
    sec,ms = divmod(int(millsec),1000)
    min,sec = divmod(sec,60)
    hr,min = divmod(min,60)
    if(hr > 23):
        day,hr = divmod(hr,24)
    ts_str = ''
    ts_str += str(day)+'D' if day else ''
    ts_str += str(hr)+'h' if hr else ''
    ts_str += str(min)+'m' if min else ''
    ts_str += str(sec)+'s' if sec else ''
    ts_str += str(ms)+'ms' if ms else ''
    return ts_str

def convert_epoch_ts(k,v):
    if k in ['startedTime']:
        return datetime.strftime(get_ts_from_epoch(v), "%Y-%m-%d %H:%M:%S")
    if k in ['finishedTime']:
        if int(v):
            return datetime.strftime(get_ts_from_epoch(v), "%Y-%m-%d %H:%M:%S")
        else:
            return ''        
    elif k in ['elapsedTime']:
        return ms_to_dhms(v)
    else:
        return v


def split_jobs_by_time(formatted_jobs, offset):
    # offset = 7 days
    new_jobs = []
    old_jobs = []
    now = datetime.utcnow()
    for job in formatted_jobs:
        try:
            startTime = get_ts_from_epoch(job['startedTime'])
            # if job has been running > offset (7 days)
            if (now - startTime) < offset:
                new_jobs.append(job)
            else:
                old_jobs.append(job)
            
        # if date parsing fails, include in main part of report
        except ValueError:
            new_jobs.append(job)
    
    return (new_jobs, old_jobs)


def generate_header(user):
    report_name = "Spark Monitoring Report"
    
    header  = [report_name]
    header += ["<hr>"]
    header += ["UTC Date and Time: " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
    header += ["User: " + user]
    header += [""]
    header += ["Spark Jobs:"]
    
    return "<br>".join(header)


def generate_old_jobs_header(cutoff):
    subheader  = ["Jobs older than {}:".format(cutoff)]
    
    return "<br>".join(subheader)


def generate_footer():
    footer  = [""]
    footer += ["Ending " + os.path.basename(__file__) + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")]
    
    return "<br>".join(footer)

def db_dataframe(jobs):
    exec_date = datetime.now()
    df = pd.DataFrame(jobs)
    df = df.rename(columns={'name': 'job_name', 'startedTime': 'start_time', 'finishedTime': 'end_time', 'elapsedTime': 'elapsed_time', 'finalStatus': 'final_status'})
    
    df['exec_date'] = pd.Series(exec_date, index=df.index)
    df['start_time'] = pd.to_datetime(df['start_time'], unit='ms')
    df['end_time'] = pd.to_datetime(df['end_time'], unit='ms')
    df['elapsed_time'] = pd.to_timedelta(df['elapsed_time'], unit='ms').astype(str)
    
    return df

if __name__ == "__main__":
    # configure logging
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    
    args = get_args()
    
    try:
        user = args.user_id
        pg_user_name          = os.environ["PG_USER"]
        pgsql_conn_str        = os.environ["PG_CONN_URL"]
        jks_path              = r'jceks://' + os.environ["PG_PWD_FILE"]
        alias_name            = os.environ["PG_PWD_ALIAS"]
        pgsql_schema          = os.environ["PG_PREPARED_SCHEMA"]
        pgsql_target_tbl_name = os.environ["DH_MONITOR_JOB_STATUS"]
        
        spark_history_host    = os.environ["SPARK_HISTORY_SERVER"]
        spark_history_port    = os.environ["SPARK_HISTORY_PORT"]
        job_prefix            = os.environ["SPARK_JOB_PREFIX"]
        stream_job_suffix     = os.environ.get("SPARK_JOB_STREAMING_SUFFIX")
        yarn_rm_host_url      = os.environ["YARN_RM_HOST_URL"]
        dir_path              = os.environ["CA_PATH"]
        pgsql_conn_str        = os.environ["PG_CONN_URL"]
    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        exit(RC_ERROR)
    
    default_ca_bundle = os.path.join(dir_path, 'CN.bundle.pem')
    kerberos_auth = HTTPKerberosAuth(mutual_authentication=OPTIONAL)
    spark_history_url = spark_history_host + ":" + spark_history_port
    old_cutoff = timedelta(days=7)
    
    all_jobs = get_yarn_history(default_ca_bundle, kerberos_auth, yarn_rm_host_url)
    prefixed_jobs = get_prefixed_yarn_jobs(user, all_jobs, job_prefix)
    recent_jobs = get_most_recent_yarn_jobs(prefixed_jobs)
    formatted_jobs = format_jobs(recent_jobs, stream_job_suffix)
    
    if args.db_insert:
        host = pgsql_conn_str.split(':')[2][2:]
        port = pgsql_conn_str.split(':')[3].split('/')[0]
        pg_db = pgsql_conn_str.split(':')[3].split('/')[1]
        
        if '' in [pg_user_name,pgsql_conn_str,jks_path,alias_name]:
            logging.error('Error: PostgreSQL config is missing, check your ENV setting!')
            sys.exit(-1)
        
        # to retrieve the passwd from jave keystore
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.master("yarn").appName(os.environ['USER'] + "_tm_spark_monitoring").getOrCreate()
        
        x = spark.sparkContext._jsc.hadoopConfiguration()
        x.set("hadoop.security.credential.provider.path", jks_path)
        a = x.getPassword(alias_name)
        
        passwd = ""
        for i in range(a.__len__()):
            passwd = passwd + str(a.__getitem__(i))
        
        df = db_dataframe(formatted_jobs)
        write_df_to_pgsql(df)
    
    if args.send_email:
        new_jobs, old_jobs = split_jobs_by_time(formatted_jobs, old_cutoff)
        new_jobs_table = pd.DataFrame(db_dataframe(new_jobs)).to_html() # jobs_to_table(new_jobs)
        old_jobs_table = pd.DataFrame(db_dataframe(new_jobs)).to_html() # jobs_to_table(old_jobs)
        
        report  = generate_header(user) + "<br>"
        report += new_jobs_table + "<br>"
        report += generate_old_jobs_header(old_cutoff) + "<br>"
        report += old_jobs_table + "<br>"
        report += generate_footer()
        
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        subj = "Spark Monitoring Checks ({ts})".format(ts=ts)
        from_ = os.getenv("USER") + '@CN.CA'
        to_ = args.to_
        send_email(subj,from_,to_,report)
    
    exit(RC_SUCCESS)
