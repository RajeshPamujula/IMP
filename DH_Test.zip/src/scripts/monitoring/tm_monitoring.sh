#!/bin/bash

# "**********************************************************************************"
# Usage          : sh tm_monitoring.sh <id>
# "**********************************************************************************"

export currentDirectory=`dirname $0`

# Setting kinit
export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;

USER=${1}

host=`hostname -s`
len=${#host}
env=${host:${len}-1 : 1}

# Sourcing Environment Variables from the SetEnv scripts

case ${env} in
  "d")
#         echo "Setting Environment variables for Datahub Dev env"
         kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
         klist > /dev/null 2>&1
         source ${currentDirectory}/../utilities/ENV_DEV.sh > /dev/null 2>&1
         ;;
  "p")
#         echo "Setting Environment variables for Datahub Prod env"
         kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
         klist > /dev/null 2>&1
         source ${currentDirectory}/../utilities/ENV_PROD.sh > /dev/null 2>&1
         ;;
 *)
         echo "Unknown Environment"
         exit 1
         ;;
esac

# Declaring Environment variable
export DH_TENANT=${DH_TENANT}
export DH_ENV=${DH_ENV}
export AMBARI_HOST=${AMBARI_HOST}
export hostEnv=`hostname`
export username=${USER}
export TARGET_EMAILS_LIST=${TARGET_EMAILS_LIST}
export EMAIL_TO=${TARGET_EMAILS_LIST}

# add Python3 path
export PATH=/opt/python3/bin:$PATH

# Log file
LOG_PATH=$SPARK_LOG
if [[ ! -e $LOG_PATH ]];then
    mkdir -p $LOG_PATH
fi
rm -f $LOG_PATH/tm_nifi_monitoring_*.txt >/dev/null 2>&1
LOGFILE=${LOG_PATH}/tm_nifi_monitoring_$$.txt
touch ${LOGFILE}
chmod 777 ${LOGFILE}

# Initiating the Monitoring Script

python -W ignore ${currentDirectory}/tm_monitoring.py -u ${USER} 1> ${LOGFILE} 2>/dev/null
RC=$?

function email_notify(){

       if [ $# -ne 3 ];then
         echo "Usage:"
         echo ""
         echo "$0 \"Subject\" \"To_adresses\" file_to_email"
         echo ""
         exit 8
       fi

       SUBJECT=$1
       TO=$2
       FILE=$3

       if [ ! -f ${LOGFILE} ]
       then
         echo "Error, file not found: ${FILE}"
         exit 8
       fi
(
cat <<EOF
From: ${USER}@`hostname --fqdn`
To: ${TO}
Subject: ${SUBJECT}
MIME-Version: 1.0
Content-Type: text/html
Content-Disposition: inline
<html>
<body>
<pre style="font: monospace">
EOF

cat ${FILE}

echo "</pre></body></html>"
) | /usr/sbin/sendmail -t

}

email_notify "${DH_ENV} Monitoring Checks (`date +%Y-%m-%d`)" "${EMAIL_TO}" ${LOGFILE}

exit $RC
