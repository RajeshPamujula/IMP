#!/opt/python3/bin/python
# coding: utf-8

'''
  Usage   :        spark-submit tm_failure_notification.py -h
  Author  :        Jun Dai (189485)
  Created :        2020-04-26
  Desc    :
      -t receiver's email address
      -d optional start date, format: yyyy-mm-dd, eg: 2020-04-25

  Example :
      spark-submit --master yarn --name "tm_failure_notification" --deploy-mode cluster --keytab /path/189485.keytab --principal 189485@CN.CA --files "/etc/krb5.conf,/path/189485.keytab.bak,/path/jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file /path/spark.conf --jars /hadoop/developers/189485/jars/spark-sql-kafka-0-10_2.11-2.3.2.jar,/hadoop/developers/189485/jars/kafka-clients-0.10.2.2.jar  ./tm_failure_notification.py -t 189485
'''
from pyspark.sql.types import StructType, StringType, StructField, TimestampType
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import time
from datetime import datetime,date,timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
import sys,os
import argparse
import logging

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', action='store', dest='to_',
                        help="receiver's email address", required=True)
    parser.add_argument('-d', action='store', dest='opt_date',
                        help="optional start date, format: yyyy-mm-dd", required=False)
    args = parser.parse_args()
    return args
    
def send_email(subj,from_,to_,msg_body):
    """Send email to receiver   

    Args:
        subj:      Email's subject
        from_:     Sender's email address
        to_:       Receiver's email address
        msg_body:  Email body in hmtl format
    Returns:
        
    """
    msg = MIMEMultipart('alternative')
    msg["From"] = from_
    msg["To"] = to_
    msg["Subject"] = subj
    HTML_BODY = MIMEText(msg_body, 'html')
    msg.attach(HTML_BODY)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    if (sys.version_info > (3, 0)):
        p.communicate(msg.as_bytes())
    else:
        p.communicate(msg.as_string())
        
def define_schema():
    return StructType([StructField(
                           "LogHeader",
                           StructType([StructField("ERROR_TO_DE",StringType(),True),
                                       StructField("RAW_KAFKA_QUEUE_NAME",StringType(),True),
                                       StructField("SPARK_JOB_NAME",StringType(),True),
                                       StructField("ERROR_TS",TimestampType(),True)
                                     ]),
                           True)])

def add_date_range(args):
    """create or modify the date range 
       The default date range is from yesterday to today, today is not included.
       If the argument "opt_date" is present, 
       first check if "opt_date" is valid,
       if valid, use it as start date otherwise use yesterday.
       
    Args:
        args: a Namespace object containing the arguments to the command.
    Returns:
        
    """
    # calculate date range
    today = date.today()
    yesterday = today - timedelta(days = 1)
    args.ts_from = yesterday
    args.ts_to = today    
    if args.opt_date and args.opt_date.strip() != "":
        try:
            ts_from = datetime.strptime(args.opt_date, "%Y-%m-%d").date()
            if ts_from > yesterday:
                logging.warning("Invalid date is given {}, query the date from yesterday instead.".format(ts_from))
            else:
                args.ts_from = ts_from
        except Exception as e:
            logging.error(e)
            sys.exit(-1)
            
        
class FailreNotificaitonService(object):
    """A class to read failure message from Kafka topics,
       using default date range [Yesterday, Today),
       where Today is not included,
       generate report then send out by email.
       Kafka batch query is used.
       
    Attributes:
        config: combines both application arguments and environmental variables
        schema: spark dataframe schema, it's a subset of JSON schema
    """
    
    def __init__(self,schema,**configs):
        self.config = configs
        self.schema = schema           
        self.spark = SparkSession.builder.master("yarn").appName("tm_flr_notif_script").getOrCreate() 
        
    def run(self):
        raw_df = self.readStream()
        transformed_df = self.transform(raw_df)
        self.sink(transformed_df)    
    
    def readStream(self):
        df = self.spark \
          .read \
          .format("kafka") \
          .option("kafka.bootstrap.servers", self.config["kafka_brokers"]) \
          .option("kafka.security.protocol", "SASL_PLAINTEXT") \
          .option("subscribe", self.config["topic"]) \
          .option("startingOffsets", "earliest") \
          .option("kafka.request.timeout.ms","150000") \
          .load().selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")          
        return df.select(F.from_json(F.col("value").cast(StringType()), self.schema).alias("message")).select("message.*")
        
    def transform(self,raw_df):
        # Transformation 
        # Omit the details, "Detail:.*"    
        # group by "SPARK_JOB_NAME","ERROR_TO_DE" and order by "Count"
        kafkaDF = raw_df.select(raw_df.LogHeader.ERROR_TS.alias("ERROR_TS"),raw_df.LogHeader.SPARK_JOB_NAME.alias("SPARK_JOB_NAME"),F.regexp_replace(raw_df.LogHeader.ERROR_TO_DE,"Detail:.*","").alias("ERROR_TO_DE"))
        
        kafkaDF = kafkaDF.filter((kafkaDF.ERROR_TS >= F.to_date(F.lit(self.config["ts_from"]))) & (kafkaDF.ERROR_TS < F.to_date(F.lit(self.config["ts_to"]))))
        return kafkaDF.groupBy(["SPARK_JOB_NAME","ERROR_TO_DE"]).count().alias("Count").orderBy("Count",ascending=False).select(["SPARK_JOB_NAME","Count","ERROR_TO_DE"])

    def sink(self,transformed_df):
        # generate report
        pdf = transformed_df.toPandas()
        email_content = pdf.to_html(index=False)
        from_ = os.getenv("USER") + '@CN.CA'
        
        # send by email
        #if not self.config["to_"].endswith('@CN.CA'):
        #    self.config["to_"] += '@CN.CA'
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        from_ts = self.config["ts_from"].strftime("%Y-%m-%d")
        to_ts = self.config["ts_to"].strftime("%Y-%m-%d")
        subj = "Failure Notification Report [{} to {}] on {}".format(from_ts,to_ts,ts)
        send_email(subj,from_,self.config["to_"],email_content)
            
if __name__ == '__main__':
    # config logging
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(level=logging.INFO, format=FORMAT)
    
    # arguments + env vars
    args = get_args()
    add_date_range(args)            
    envDict = {}
    try:
        envDict["kafka_brokers"]        = os.environ["KAFKA_BROKER_HOST"]
        topic_trans_rte_err_prepared    = os.environ["TRANSPORTATION_RTE_ERR_PREPARED"]
        topic_trans_dh_pglogs_prepared  = os.environ["TRANSPORTATION_DH_PGLOGS_PREPARED"]
        envDict["topic"] = ','.join([topic_trans_rte_err_prepared,topic_trans_dh_pglogs_prepared])
    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))    
    # Python3 only     
    configs = {**vars(args),**envDict}
    
    schema = define_schema()
    flr_notif_service = FailreNotificaitonService(schema,**configs)
    flr_notif_service.run() 
    
    
