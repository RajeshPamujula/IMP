#!/bin/env python
# "**********************************************************************************"
# Usage          : python tm_monitoring.py <userId>
# "**********************************************************************************"

import requests
import os
from datetime import datetime,timedelta
import sys
import traceback
import json
import re
import subprocess
import kerberos
from requests_kerberos import HTTPKerberosAuth, OPTIONAL
import urllib3
import time
import math
import smtplib
import argparse
import warnings

#warnings.filterwarnings("ignore")
warnings.filterwarnings("ignore", category=FutureWarning)

# To supress nifi REST API warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Return codes
RC_SUCCESS = 0
RC_WARNING = 4
RC_ERROR = 8

# Maximum RC
max_rc = RC_SUCCESS

# Initializing variables

# define arguments parser
# user's PIN is mandatory
parser = argparse.ArgumentParser()
parser.add_argument('-u', action='store', dest='user_id',
                help="user's PIN",required=True)    
args = parser.parse_args()


try:

    # Global Servers Variables from the SetEnv File
    curr_env = os.environ["DH_ENV"]
    ambari_host = os.environ["AMBARI_HOST"]
    #user = sys.argv[1]
    user = args.user_id
    tenant = os.environ["DH_TENANT"]
    ca_path = os.environ['CA_PATH']
    nifi_host=os.environ["NIFI_HOST"]
    nifi_process_groups_to_monitor=os.environ["NIFI_PROCESS_GROUPS_TO_MONITOR"]
    nifi_process_groups_to_monitor=nifi_process_groups_to_monitor.split(",")

except KeyError:
    print("")
    print("ERROR: Variables from the file setEnv cannot be resolved.")
    print("")
    exit(RC_ERROR)

# Kerberos Authentication for HTTP GET Requests
kerberos_auth = HTTPKerberosAuth(mutual_authentication=OPTIONAL)
# Point to CN PEM file
DEFAULT_CA_BUNDLE = os.path.join(ca_path, 'CN.bundle.pem')

# Common Variables
now = datetime.now()
prev = datetime.now() - timedelta(days=1)
sys_date = now.strftime("%Y%m%d")
prev_date = prev.strftime("%Y%m%d")

# Log Files for all subprocesses
summary_output = list()
nifi_output = list()
nifi_summary = list()

# Format
nifi_format = '{:<35}   {:<35}   {:<15}   {:<10}   {:<10}   {:<10}'

# Function to get json from url
def get_nifi_token():
    r = requests.post(nifi_host + '/nifi-api/access/kerberos',verify=DEFAULT_CA_BUNDLE, auth=kerberos_auth)
    assert r.status_code == 201, "(POST) HTTP Error: " + str(r.status_code)
    return r.text

# Function to get json from NiFi url
def get_nifi_json(url, token, json_data=None, method="GET"):
    if json_data is None:
        r = requests.request(method, url, headers={'Authorization': 'Bearer ' + token}, verify=False)
    else:
        r = requests.request(method, url, headers={'Content-Type': 'application/json',
                                                   'Authorization': 'Bearer ' + token,
                                                   'Accept': '*/*'}, json=json_data, verify=False)
    assert r.status_code in (200, 201), "(" + method + ") HTTP Error: " + str(r.status_code)
    return r.json()

# Function to get Processor's Status
def display_nifi_connections():

    summary_output.append("")
    summary_output.append("NIFI Flows:")
    summary_output.append("-" * 11)

    try:
        local_rc = RC_SUCCESS
        root_process = "root"
        queue_count = 0
        stop_count = 0
        stopped_list = list()
        p_sts = 0
        q_sts = 0

        # Get NiFi Token
        token = get_nifi_token()

        # Getting Root ID
        json_data = get_nifi_json(nifi_host + '/nifi-api/process-groups/root/process-groups', token=token)
        if curr_env == "DEV":
            for item in json_data['processGroups']:
                if item['status']['name'] == "INTEGRATION":
                    root_process = item['status']['id']
        else:
            root_process = "root"

        nifi_output.append("")
        nifi_output.append(nifi_format.format("Component Name","Component ID", "Stopped Processors", "Queue Count", "Queue Size", "Time Checked"))
        nifi_output.append('-' * 132)
        # Get List of Processors for the current Tenant
        json_data = get_nifi_json(nifi_host + '/nifi-api/process-groups/' + root_process + '/process-groups',token=token)

        for item in json_data['processGroups']:
            if item['status']['name'] in nifi_process_groups_to_monitor:
                name = item["status"]["name"]
                id = item["status"]['id']
                stoppedCount = item["stoppedCount"]
                queueCount = item["status"]["aggregateSnapshot"]["flowFilesQueued"]
                queueSize = item["status"]["aggregateSnapshot"]["queuedSize"]
                queuebytes = item["status"]["aggregateSnapshot"]["bytesQueued"]
                checkTime = item["status"]["statsLastRefreshed"]

                if queuebytes != 0:
                    q_sts = RC_WARNING
                    queue_count = queue_count + queuebytes

                if stoppedCount != 0:
                    stop_count = stop_count + stoppedCount
                    p_sts = RC_ERROR
                    stopped_list.append(name)

                nifi_output.append(nifi_format.format(name,id,stoppedCount,queueCount,queueSize,checkTime))

        # Converting Bytes to MB
        qc = str(queue_count/1048576.0)[0:5]
        summary_output.append("There are "+ qc + " flow files queued up and "+ str(stop_count) +" stopped processors")
        if ((q_sts == RC_WARNING and p_sts == RC_ERROR) or (q_sts == RC_WARNING and p_sts != RC_ERROR) or (q_sts != RC_WARNING and p_sts == RC_ERROR)):
            local_rc = RC_ERROR
        else:
            #summary_output.append("SUCCESS: All processors are running and No flowfiles are queued at present")
            local_rc = RC_SUCCESS

    except (KeyboardInterrupt, Exception) as err:
        msgerr = "Exception encountered (" + sys.exc_info()[0].__name__ + "): " + str(err)
        nifi_output.append(msgerr)
        local_rc = RC_ERROR
    nifi_output.append("-" * 132)
    return local_rc

def status_display():

    # Display Summary
    for line in summary_output:
        print(line)
    print("")
    print("")
    print("Brief Data Stats:")
    print("-" * 132)

    for line in nifi_output:
        print(line)


if __name__ == "__main__":

    print('-' * 132)
    print("                         ************************ DataHub Monitoring Report **********************                 ")
    print('-' * 132)
    print("")
    print("UTC Date and Time : " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S"))
    print("User              : " + user )
    print("")

    try:

        # Check Nifi for stopped processors
        rc = display_nifi_connections()
        if rc > max_rc:
            max_rc = rc

        status_display()

    except (KeyboardInterrupt, Exception) as err:

        # Set ERROR as max_rc
        if RC_ERROR > max_rc:
            max_rc = RC_ERROR

        # Get the exception
        msgerr = "Exception encountered (" + sys.exc_info()[0].__name__ + "): " + str(err)
        print(msgerr)

        # Print the traceback
        print("")
        print("Traceback:")
        indent = ""
        last_item = ""
        for item in traceback.extract_tb(sys.exc_info()[2]):
            if item[2] != "debug_decorator":
                print(indent + "|")
                print(indent + "+--> File: " + item[0])
                print(indent + "     Line: " + str(item[1]))
                print(indent + "     Fnc : " + item[2])
                print(indent + "     Cmd : " + item[3])
                indent += "     "
                last_item = item
        print()

    finally:
        print("")
        if max_rc == RC_SUCCESS:
            print("Run Success. No action required.")
        else:
            print("Abnormalities detected, please investigate.")
        print("")
        print('-' * 132)
        print("Ending " + __file__ + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d-%H.%M.%S"))
        print('-' * 132)

        exit(max_rc)

