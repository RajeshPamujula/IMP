#!/bin/bash

# "**********************************************************************************"
# Usage          : bash tm_pgsql_monitoring.sh -u PIN -e INT
# "**********************************************************************************"

export currentDirectory=`dirname $0`

# Setting kinit
export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;
USER=${USER}

usage()
{
    echo "usage: bash tm_pgsql_monitoring.sh -u PIN -e INT"
}

if [ $# -eq 0 ]; then
    echo "No arguments supplied"
	usage
	exit 1
fi

while [ "$1" != "" ]; do
    case $1 in
        -u | --username )       shift
	                            USER=$1
				                ;;
        -e | --env)             shift
                                env=$1
                                ;;							
        -h | --help )           usage
                                exit
                                ;;
        * )                     usage
                                exit 1
    esac
    shift
done


# setup env
if [ "$env" != "" ]; then
    case $env in
        "SB"|"QA"|"INT"|"PROD" )
            kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
            klist > /dev/null 2>&1
            source ${currentDirectory}/../utilities/ENV_${env}.sh > /dev/null 2>&1
            ;;
        * )         
            echo "ERROR: Invalid ENV option: "$env
            usage
            exit -1
            ;;
    esac
else
    usage
    exit -1
fi

# Declaring Environment variable
export DH_ENV=${DH_ENV}
export hostEnv=`hostname`
export EMAIL_TO=${TARGET_EMAILS_LIST}

# add Python3 path
export PATH=/opt/python3/bin:$PATH
export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client

# Log file
LOG_PATH=$SPARK_LOG
if [[ ! -e $LOG_PATH ]]; then
    mkdir -p $LOG_PATH
fi
rm -f $LOG_PATH/tm_pg_monitoring_*.txt >/dev/null 2>&1
LOGFILE=${LOG_PATH}/tm_pg_monitoring_$$.txt
touch ${LOGFILE}
chmod 777 ${LOGFILE}

# Initiating the Monitoring Script
spark-submit ${currentDirectory}/tm_pgsql_monitoring.py 1> ${LOGFILE} 2>/dev/null
#RC=$?

#if (( $RC == 0 ))
#then
#	spark-submit ${currentDirectory}/tm_pgsql_monitoring_queries.py 1>> ${LOGFILE} 2>/dev/null
#	RC=$?
#fi

function email_notify(){

       if [ $# -ne 3 ];then
         echo "Usage:"
         echo ""
         echo "$0 \"Subject\" \"To_adresses\" file_to_email"
         echo ""
         exit 8
       fi

       SUBJECT=$1
       TO=$2
       FILE=$3

       if [ ! -f ${LOGFILE} ]
       then
         echo "Error, file not found: ${FILE}"
         exit 8
       fi
(
cat <<EOF
From: ${USER}@`hostname --fqdn`
To: ${TO}
Subject: ${SUBJECT}
MIME-Version: 1.0
Content-Type: text/html
Content-Disposition: inline
<html>
<body>
<pre style="font: monospace">
EOF

cat ${FILE}

echo "</pre></body></html>"
) | /usr/sbin/sendmail -t

}

email_notify "${DH_ENV} PostgreSQL Monitoring Checks (`date +%Y-%m-%d`)" "${EMAIL_TO}" ${LOGFILE}

exit $RC