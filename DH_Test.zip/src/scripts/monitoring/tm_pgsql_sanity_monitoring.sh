#!/bin/bash

# "**********************************************************************************"
# Usage          : sh tm_pgsql_sanity_monitoring.sh <id> <ENV>
# "**********************************************************************************"

export currentDirectory=`dirname $0`

# Setting kinit
export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;

USER=${1}
env=$2 #[SB|QA|REG|INT|PROD]

# Sourcing Environment Variables from the SetEnv scripts
if [ "$env" != "" ]; then
    case $env in
        "SB"|"QA"|"REG"|"INT"|"PROD" )
            kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
            klist > /dev/null 2>&1
            source ${currentDirectory}/../utilities/ENV_${env}.sh > /dev/null 2>&1
            ;;

        * )         
            echo "Invalid ENV option: "$env
            usage
            exit -1
            ;;
    esac
else
    usage
    exit -1
fi

# Declaring Environment variable
export DH_ENV=${DH_ENV}
export hostEnv=`hostname`
export EMAIL_TO=${TARGET_EMAILS_LIST}

# add Python3 path
export PATH=/opt/python3/bin:$PATH
export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client

# Log file
rm ${SPARK_LOG}/TM_Sanity_Monitoring.log >/dev/null 2>&1 
LOGFILE=${SPARK_LOG}/TM_Sanity_Monitoring.log
touch ${LOGFILE}
chmod 777 ${LOGFILE}

# Initiating the Monitoring Script
spark-submit ${currentDirectory}/tm_pgsql_sanity_monitoring.py 1> ${LOGFILE} 2>/dev/null
RC=$?

function email_notify(){

       if [ $# -ne 3 ];then
         echo "Usage:"
         echo ""
         echo "$0 \"Subject\" \"To_adresses\" file_to_email"
         echo ""
         exit 8
       fi

       SUBJECT=$1
       TO=$2
       FILE=$3

       if [ ! -f ${LOGFILE} ]
       then
         echo "Error, file not found: ${FILE}"
         exit 8
       fi
(
cat <<EOF
From: ${USER}@`hostname --fqdn`
To: ${TO}
Subject: ${SUBJECT}
MIME-Version: 1.0
Content-Type: text/html
Content-Disposition: inline
<html>
<body>
<pre style="font: monospace">
EOF

cat ${FILE}

echo "</pre></body></html>"
) | /usr/sbin/sendmail -t

}

email_notify "${DH_ENV} PostgreSQL Sanity Monitoring Checks (`date +%Y-%m-%d`)" "${EMAIL_TO}" ${LOGFILE}

exit $RC
