#!/bin/bash

# "**********************************************************************************"
# Usage          : bash deploy_spark_job.sh -h
#                  -b non-blocking mode (optional):  
#                     1: Non-blocking (default) - The script doesn't wait and return instantly
#                     0: blocking - The script is blocked until it's completed
#                  -m deploy mode (optional): client or cluster mode, default is cluster mode 
#                  -k kill only (optional)
# Example: 
# E.1   Env setup is ENV_SB.sh, no-blocking, cluster mode
#    sh deploy_spark_job.sh -e SB -c ContainerCarFeedPGLoad,CarDestinationFeedPGLoad,CarInventoryFeedPGLoad,TrainScheduleFeedPGLoad,CarDestinationFeed,ContainerCarFeed,CarInventoryFeed,ActiveTrainScheduleFeed,ETAETDFeed,TrainReportingFeed -o "--num-executors 2  --driver-memory 2g --executor-memory 2g --executor-cores 1" 
# E.2   Env setup is ENV_DEV.sh, blocking, cluster mode
#    sh deploy_spark_job.sh -e DEV -c  Container,Car,RailStation,YardTrack -b 0 -o "--num-executors 1  --driver-memory 2g --executor-memory 5g --executor-cores 1" 
# E.3   Env setup is ENV_SB.sh, no-blocking, cluster mode, use default spark conf setup "--num-executors 1  --driver-memory 2g --executor-memory 5g --executor-cores 1"
#    sh deploy_spark_job.sh -e SB -c ContainerCarFeedPGLoad,CarDestinationFeedPGLoad,CarInventoryFeedPGLoad,TrainScheduleFeedPGLoad,CarDestinationFeed,ContainerCarFeed,CarInventoryFeed,ActiveTrainScheduleFeed,ETAETDFeed,TrainReportingFeed
# E.4   Env setup is ENV_SB.sh, kill the applicatoins with regex pattern '^PIN_.*_ClassName" 
#    sh deploy_spark_job.sh -e SB -c ContainerCarFeedPGLoad,CarDestinationFeedPGLoad -k
# 
# condition      : 1. <CA_PATH>/CN.bundle.pem
#                : 2. ../utilities/ENV_*.sh
# Comments       : When using this script to deploy spark jobs
#                  it checks if the given job is still running 
#                  if yes the script will kill the running one before deploy the new one
#                  The script is running in non-blocking mode
#                  If set as blocking mode, the script will be blocking until it returns 
# "**********************************************************************************"

export currentDirectory=`dirname $0`

export PATH=/opt/python3/bin:$PATH

export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;

if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
fi

USER=${USER}
mode=deployment

usage()
{
    echo "usage: deploy_spark_job.sh -e [SB|QA|INT|PROD] -c [sparkClassName1,sparkClassName2] [-b] [0|1] [-m] [client|cluster] [-k kill] -o \"other options\" "
}

while [ "$1" != "" ]; do
    case $1 in
        -u | --username )       shift
	                        USER=$1
				;;
        -c | --classNames )       shift
                                classNames=$1
                                ;;
        -e | --env)             shift
                                env=$1
                                ;;
        -b | --non-blocking )   shift
                                noblock=$1
                                ;;
        -m | --mode )           shift
                                run_mode=$1
                                ;;
        -k | --kill )           shift
                                kill_only='-k'
                                ;;
        -o | --opts )           shift
                                opts=$1
                                ;;								
        -h | --help )           usage
                                exit
                                ;;
        -a | --args )
                                shift
                                args=$1
                                ;;
        * )                     usage
                                exit 1
    esac
    shift
done

# setup env
if [ "$env" != "" ]; then
    case $env in
        "SB"|"QA"|"INT"|"PROD" )
            kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
            klist > /dev/null 2>&1
            source ${currentDirectory}/../utilities/ENV_${env}.sh > /dev/null 2>&1
            ;;

        * )         
            echo "Invalid ENV option: "$env
            usage
            exit -1
            ;;
    esac
else
    usage
    exit -1
fi

# read config from ENV_*.sh
keytab='-kt '$USER_KEYTAB
principal='-pr '${SPARK_USER_NAME}@CN.CA 
kt_copy='-kc '$USER_KEYTAB_BKUP
jaas='-j '$JAAS_CONFIG
yarn_queue='-q '$YARN_QUEUE
spark_conf="-sc "${SPARK_CONF_DIR}/spark.conf

# parse args (default: 'cluster')
run_mode="-m ${run_mode:-"cluster"}"

if [ "$kill_only" != "" ];then
    kill_only="-k"
fi

if [ "$noblock" != "" ]; then
    case $noblock in
        "1" )       noblock="-b 1"
                    ;;
        "0" )       noblock="-b 0"
                    ;;
        * )         usage
                    ;;
    esac
else
    noblock="-b 1"
fi

# Declaring Environment variables
export DH_TENANT=${DH_TENANT}
export DH_ENV=${DH_ENV}
export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client
export SPARK_HISTORY_SERVER=${SPARK_HISTORY_SERVER}
export SPARK_HISTORY_PORT=${SPARK_HISTORY_PORT}
export SPARK_JOB_PREFIX=${SPARK_JOB_PREFIX}
export hostEnv=`hostname`
export EMAIL_TO=${USER}  #datahub_support@cn.ca

# add Python3 path
export PATH=/opt/python3/bin:$PATH

ts=`date "+%Y_%m_%d_%H_%M_%S"`

# Log file
LOGFILE=${SPARK_LOG}/deploy_spark_job_${ts}.txt
touch ${LOGFILE}
chmod 777 ${LOGFILE}

if [ "$args" != "" ]; then
    args="-a "${args}
fi

if [ "$opts" != "" ];then
    opts="-o "${opts}
    python -W ignore ${currentDirectory}/deploy_spark_job.py -u ${USER} -c ${classNames} ${keytab} ${principal} ${kt_copy} ${jaas} ${noblock} ${run_mode} ${kill_only} ${yarn_queue} ${spark_conf} "${opts}" ${args} 1> ${LOGFILE} 2>/dev/null
else
    python -W ignore ${currentDirectory}/deploy_spark_job.py -u ${USER} -c ${classNames} ${keytab} ${principal} ${kt_copy} ${jaas} ${noblock} ${run_mode} ${kill_only} ${yarn_queue} ${spark_conf} ${args} 1> ${LOGFILE} 2>/dev/null
fi    

RC=$?

function email_notify(){

       if [ $# -ne 3 ]; then
         echo "Usage:"
         echo ""
         echo "$0 \"Subject\" \"To_adresses\" file_to_email"
         echo ""
         exit 8
       fi

       SUBJECT=$1
       TO=$2
       FILE=$3

       if [ ! -f ${LOGFILE} ]
       then
         echo "Error, file not found: ${FILE}"
         exit 8
       fi
(
cat <<EOF
From: ${USER}@`hostname --fqdn`
To: ${TO}
Subject: ${SUBJECT}
MIME-Version: 1.0
Content-Type: text/html
Content-Disposition: inline
<html>
<body>
<pre style="font: monospace">
EOF

cat ${FILE}

echo "</pre></body></html>"
) | /usr/sbin/sendmail -t

}

email_notify "${DH_ENV} Spark Job Deployment (`date +%Y-%m-%d`)" "${EMAIL_TO}" ${LOGFILE}

exit $RC
