'''
  Author:   jun.dai@cn.ca
  Date:     2020-01-15
  Usage:    python deploy_spark_job.py -u PIN -c [sparkJobName1,sparkJobName2] [-b] [0|1] [-m] [client|cluster] [-k]
            python deploy_spark_job.py -u 189485 -c Car,Container -m cluster
'''

import argparse
import requests
from requests_kerberos import HTTPKerberosAuth, OPTIONAL
import os,sys,re
import json
from datetime import datetime


RC_SUCCESS = 0
RC_WARNING = 4
RC_ERROR = 8


def main():
    args = get_args()
    try:
        user = args.user_id
        classNames = args.classNames.split(',')
        spark_history_host = os.environ["SPARK_HISTORY_SERVER"]
        spark_history_port = os.environ["SPARK_HISTORY_PORT"]
        job_prefix         = os.environ["SPARK_JOB_PREFIX"]
        yarn_rm_http_url   = os.environ["YARN_RM_HOST_URL"]
        jaas_config        = os.environ["JAAS_CONFIG"]
        spark_jar_loc      = os.environ["SPARK_JAR_LOC"]
        spark_scratch_dir  = os.environ["SPARK_SCRATCH_DIR"]
        ca_path            = os.environ["CA_PATH"]
    except KeyError:
        print("")
        print("ERROR: Variables from the file setEnv cannot be resolved.")
        print("")
        exit(RC_ERROR)
    
    default_ca_bundle = os.path.join(ca_path, 'CN.bundle.pem')
    kerberos_auth = HTTPKerberosAuth(mutual_authentication=OPTIONAL)

    print(generate_header(user))
    running_jobs = get_spark_history(default_ca_bundle, kerberos_auth, yarn_rm_http_url)
    if(running_jobs):
        # search for the running job with name provided, if exists, kill them
        kill_spark_job(default_ca_bundle,kerberos_auth,yarn_rm_http_url, find_app_ids(running_jobs, classNames))

    # deploy the spark job
    if not get_args().kill_only:
        deploy_spark_jobs(classNames)
    
    print(generate_footer())

def get_appId(jobs_dict,app_name):
    for app_id, value in jobs_dict.items():
        if(value == app_name):
            return app_id
    return None


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', action='store', dest='user_id',
                        help="The user ID to filter on for all Spark jobs", required=True)                   
    parser.add_argument('-c', action='store', dest='classNames',
                        help="Job names to be handled.", required=True)
    parser.add_argument('-kt', action='store', dest='keytab',
                        help="kerberos keytab abs path")
    parser.add_argument('-pr', action='store', dest='principal',
                        help="kerberos principal")
    parser.add_argument('-kc', action='store', dest='kt_copy',
                        help="keytab copy")                    
    parser.add_argument('-j', action='store', dest='jaas',
                        help="jaas conf")
    parser.add_argument('-b', action='store', dest='no_block',
                        help="1: non-blocking, 0: blocking mode", default=1, type=int)
    parser.add_argument('-m', action='store', dest='cluster_mode',
                        help="cluster|client", default='client', type=str)
    parser.add_argument('-q', action='store', dest='yarn_queue',
                        help="yarn queue", default='default', type=str)
    parser.add_argument('-k', dest='kill_only',
                        help="kill only", default=False, action='store_true')
    parser.add_argument('-o', dest='opts',
                        help="options", default="--num-executors 1 --driver-memory 2g --executor-memory 2g --executor-cores 1", type=str)
    parser.add_argument('-a', dest='job_args', nargs='*',
                        help="job arguments", default="", type=str)
    parser.add_argument('-sc', dest='spark_conf',
                        help="spark conf file path", type=str)                    
    args = parser.parse_args()
    return args


def find_app_ids(jobs_dict, classNames):
    # iterate the classNames, if there is running job, return the app Id
    # spark job naming rule: USERNAME_className, eg. 189485_Car  
    # jobs_dict: {'application_id': '189485_tm_load_Car'}
    # classNames: ['Car','ActiveTrainScheduleFeed']
    # pattern:  ^189485.*Car$
    user = os.getenv("USER")
    className_patterns = [ '^'+user+'.*'+className+'$' for className in classNames if className ]
    if jobs_dict:
        rt = []
        for app_id, app_name in jobs_dict.items():
            for pattern in className_patterns:
                if re.match(pattern, app_name):
                    rt.append((app_id,app_name))
        # In theory, app name should be unique
        return rt
    return None


def get_spark_history(bundle, kerberos_auth, yarn_rm_http_url, status='running'):
    r = requests.get('http://{}/ws/v1/cluster/apps?states={}'.format(yarn_rm_http_url,status), verify=bundle, auth=kerberos_auth)
    spark_history_dict = json.loads(r.text)
    running_jobs = {}
    for d in spark_history_dict["apps"]["app"]:
        running_jobs[d['id']]=d['name']
    if running_jobs:
        return running_jobs
    else:
        return None

def get_spark_full_history(bundle, kerberos_auth, yarn_rm_http_url):
    r = requests.get('http://{}/ws/v1/cluster/apps'.format(yarn_rm_http_url), verify=bundle, auth=kerberos_auth)
    spark_history_dict = json.loads(r.text)
    spark_jobs = {}
    for d in spark_history_dict["apps"]["app"]:
        spark_jobs[d['id']]=d['name']
    if spark_jobs:
        return spark_jobs
    else:
        return None



def kill_spark_job(bundle,kerberos_auth,yarn_rm_http_url, app_ids):
    header = {
        "Content-Type" : "application/json"
    }
    payload = {
        "state" : "KILLED"
    }

    if app_ids:
        for app_id in app_ids:
            print("WARN: {}:'{}' is still running, it has to be killed before we can deploy new one.".format(app_id[0],app_id[1]))
            r = requests.put('http://{}/ws/v1/cluster/apps/{}/state'.format(yarn_rm_http_url,app_id[0]), headers=header, data=json.dumps(payload),verify=bundle, auth=kerberos_auth)
            assert r.status_code in (200, 202), "(PUT) HTTP Error: " + str(r.status_code)
            print("WARN: {} has been killed successfully.".format(app_id[0]))


def get_spark_job_state(bundle,kerberos_auth,yarn_rm_http_url,app_id):
    
    r = requests.get('http://{}/ws/v1/cluster/apps/{}/state'.format(yarn_rm_http_url,app_id), verify=bundle, auth=kerberos_auth)
    assert r.status_code in (200,), "(GET) HTTP Error: " + str(r.status_code)
    # {'state': 'RUNNING'}
    return json.loads(r.text) 
    

def deploy_spark_jobs(classNames):
    for className in classNames:
        if className:
            spark_submit_proc(className)


def spark_submit_proc(className):
    # call spark-submit
    appName = os.getenv("USER")+'_tm_prepared_'+className
    kt_fname = os.path.basename(get_args().keytab)
    kt_fname = kt_fname if kt_fname[0] != '.' else kt_fname[1:]
    # s1 if s1[0] != '.' else s1[1:]
    app_conf = os.environ["SPARK_JAR_LOC"]+'/'+ className + '/classes/application.conf'
    class_name = '--class ' + className 
    mode = '--master yarn --deploy-mode ' + get_args().cluster_mode.lower()
    #config = '--conf "spark.local.dir='+os.environ["SPARK_SCRATCH_DIR"]+'" ' 
    yarn_queue = '--queue '+get_args().yarn_queue
    config = '--conf "spark.executor.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" '
    config += '--conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" '
    config += '--conf "spark.yarn.historyServer.address=http:'+os.environ["SPARK_HISTORY_SERVER"]+':'+os.environ["SPARK_HISTORY_PORT"]+'/" '
    config += '--conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" '
    config += '--conf "spark.yarn.submit.waitAppCompletion=false"'
    driver = '--driver-java-options "-Djava.security.auth.login.config=jaas.conf -Dconfig.file.name=application.conf"'
    jar_file = os.environ["SPARK_JAR_LOC"]+'/'+ className + '/*.jar'
    opts = get_args().opts
    job_args = get_args().job_args
    spark_conf = '--properties-file ' + get_args().spark_conf
    keytab = '--keytab=' + get_args().kt_copy + ' ' + '--principal='+ get_args().principal
    files = '--files "/etc/krb5.conf#krb5.conf,' + get_args().keytab+'#'+kt_fname+','+get_args().jaas+'#jaas.conf,'+app_conf+'#application.conf"'
    f_log = os.environ["SPARK_LOG"]+'/' + className + '.log'
    cmd = 'spark-submit ' + ' '.join(['--name '+appName,mode,class_name,opts,keytab,files,config,driver,yarn_queue,spark_conf,jar_file,*job_args])
    print('-'*100)
    print("INFO: Start deploying {}".format(appName))
    print(cmd)
    print(f_log)
    import subprocess
    with open(f_log,"w") as out:
        print("Spark job '{}' is deployed.".format(appName))
        # 1: non-blocking (default), 0: blocking mode 
        if get_args().no_block:
            subprocess.Popen(cmd, shell=True, stdin=None, stdout=out, stderr=out)
        else:
            subprocess.call(cmd, shell=True, stdin=None, stdout=out, stderr=out)

def generate_header(user, width=120):
    report_name = "INFO: Spark Job Deployment"
    num_spaces = int(width / 4)
    num_stars = int(width / 4) - int((len(report_name) + 2) / 2)

    header  = ["-" * width]
    header += [(" " * num_spaces) + ("*" * num_stars) + " " + report_name + " " + ("*" * num_spaces) + (" " * num_stars)]
    header += ["-" * width]
    header += [""]
    header += ["UTC Date and Time : " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
    header += ["User              : " + user]
    header += [""]
    header += ["Spark Jobs:"]
    return "\n".join(header)

def generate_footer(width=120):
    footer  = [""]
    footer += ["-" * width]
    footer += ["Ending " + __file__ + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")]
    footer += ["-" * width]
    return "\n".join(footer)

if __name__ == "__main__":
    main()
    exit(RC_SUCCESS)
