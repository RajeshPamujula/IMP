#!/bin/bash

# "**********************************************************************************"
# Usage          : sh deploy_spark_all.sh <SB|INT|QA|PROD>
# Purpose 		 : To source environment files and to deploy all the spark jobs with corresponding executor/memory/core configs
# "**********************************************************************************"
export currentDirectory="$( cd "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"

# Setting kinit
export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;

ENV=${1}

# Sourcing Environment Variables from the SetEnv scripts
# setup env
usage()
{
    echo "usage: sh deploy_spark_all.sh <SB|INT|QA|PROD>"
}
if [ "$ENV" != "" ]; then
    case $ENV in
        "SB"|"QA"|"INT"|"PROD" )
            kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
            klist > /dev/null 2>&1
			cd ../utilities
			dos2unix *
			chmod 755 *.sh
			. ./ENV_${ENV}.sh 
            source ${currentDirectory}/../utilities/ENV_${ENV}.sh 
            ;;

        * )
            echo "Invalid ENV option: "$ENV
            usage
            exit -1
            ;;
    esac
else
    usage
    exit -1
fi

# Prep work in deployment folder for permissions and os compatibility
cd ../deployment
chmod 755 *.sh
dos2unix *
# To launch the spark env variable script
sh deploy_spark_env.sh ${USER} $ENV

# To launch spark jobs
############Reference Data Load#################
sh deploy_spark_job.sh -e $ENV -c ReferenceDataLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  

############Active Train Schedule#################
sh deploy_spark_job.sh -e $ENV -c ActiveTrainScheduleDomainFeed -o "--num-executors 3  --executor-memory 6g --executor-cores 2" 
sh deploy_spark_job.sh -e $ENV -c ConveyorAssociatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ConveyorCreateLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ConveyorDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  
sh deploy_spark_job.sh -e $ENV -c ConveyorRemovedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  
sh deploy_spark_job.sh -e $ENV -c RouteCancelledLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  
sh deploy_spark_job.sh -e $ENV -c RoutePlannedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c RouteDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  

############Train Reporting#################
sh deploy_spark_job.sh -e $ENV -c TrainReportingDomainFeed -o "--num-executors 3  --driver-memory 5g  --executor-memory 6g --executor-cores 2" 
sh deploy_spark_job.sh -e $ENV -c TransportationReportedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  
sh deploy_spark_job.sh -e $ENV -c TransportationEventAssociatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ConveyorAssociateDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 3"  
sh deploy_spark_job.sh -e $ENV -c AssetAssociationLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  
sh deploy_spark_job.sh -e $ENV -c AssetAssociationDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c AssetCreatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c AssetDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"

############Car Inventory#################
sh deploy_spark_job.sh -e $ENV -c CarInventoryDomainFeed -o "--num-executors 3  --driver-memory 5g --executor-memory 6g --executor-cores 2" 
sh deploy_spark_job.sh -e $ENV -c TransportationEventAssociationDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  
#sh deploy_spark_job.sh -e $ENV -c TripAssociatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  
#sh deploy_spark_job.sh -e $ENV -c TripCreateLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"  
#sh deploy_spark_job.sh -e $ENV -c TripDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1" 
sh deploy_spark_job.sh -e $ENV -c LocationAssociatedDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ConveyorConditionCreatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ConveyorConditionChangedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c TransportationEventDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ShipmentAssociationDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"

############Train Consist#################
sh deploy_spark_job.sh -e $ENV -c TrainConsistDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"
sh deploy_spark_job.sh -e $ENV -c PlannedEventAssociationLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c PlannedEventReportedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c LocationAssociationLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"

############Industrial Instruction/Reason#################
sh deploy_spark_job.sh -e $ENV -c IndustrialReasonDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"
sh deploy_spark_job.sh -e $ENV -c ConveyorDisassociatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c PlannedEventDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c PlannedEventRemovedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c PlannedEventDescriptionChangedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"

############Terminal Event#################
sh deploy_spark_job.sh -e $ENV -c TerminalEventDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############Waybill#################
sh deploy_spark_job.sh -e $ENV -c WaybillDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"
sh deploy_spark_job.sh -e $ENV -c ShipmentCreateLoad -o "--num-executors 1 --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ShipmentAssociationLoad -o "--num-executors 1 --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ShipmentDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c ShipmentConditionCreatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"

############Waybill Reference#################
sh deploy_spark_job.sh -e $ENV -c WaybillReferenceDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############Gate Event#################
sh deploy_spark_job.sh -e $ENV -c GateEventDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"
sh deploy_spark_job.sh -e $ENV -c TransportationEventRemovedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"

############ETAETD#################
sh deploy_spark_job.sh -e $ENV -c ETAETDDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############IntermodalCarContainer#################
sh deploy_spark_job.sh -e $ENV -c IntermodalCarContainerDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############Car Inventory Intermodal#################
sh deploy_spark_job.sh -e $ENV -c CarInventoryIntermodalDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############Voyage#################
sh deploy_spark_job.sh -e $ENV -c VoyageDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############Intermodal Bad Order#################
sh deploy_spark_job.sh -e $ENV -c IntermodalBadOrderDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############MotorCarrier################
sh deploy_spark_job.sh -e $ENV -c MotorCarrierDomainFeed -o "--num-executors 1  --executor-memory 6g --executor-cores 2"
sh deploy_spark_job.sh -e $ENV -c BusinessPartnerCreatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c BusinessPartnerConditionCreatedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c BusinessPartnerDescribedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"
sh deploy_spark_job.sh -e $ENV -c BusinessPartnerRemovedLoad -o "--num-executors 1  --executor-memory 2g --executor-cores 1"

############Vessel#################
sh deploy_spark_job.sh -e $ENV -c VesselDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############PortStationInformationDomainFeed#################
sh deploy_spark_job.sh -e $ENV -c PortStationInformationDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############Voyage Segment#################
sh deploy_spark_job.sh -e $ENV -c VoyageSegmentDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

############Kafka Backup Event Feed#################
sh deploy_spark_job.sh -e $ENV -c KafkaBackupEventFeed -o "--num-executors 2 --executor-memory 6g --executor-cores 2" -a "$TRANSPORTATION_KAFKA_BACKUP_EVENT_FEED_TOPICS_RAW $TM_ARCHIVING_RAW_PATH $TM_ARCHIVING_RAW_CHKPT"

##########Track Reference & Rail Station############
#sh deploy_spark_job.sh -e $ENV -c RailStation,TrackReference -b 0 -o "--num-executors 1  --executor-memory 6g --executor-cores 1"

##########Car Reference############
#sh deploy_spark_job.sh -e $ENV -c CarReference -o "--num-executors 1  --executor-memory 6g --executor-cores 1"

############Rail Station and Track Reference################
sh deploy_spark_job.sh -e $ENV -c RailStationReferenceLoad,TrackReferenceLoad -b 0 -o "--num-executors 1  --executor-memory 2g --executor-cores 1"

############Car Reference#################
sh deploy_spark_job.sh -e $ENV -c CarReferenceLoad -o "--num-executors 1  --executor-memory 4g --executor-cores 2"

############Intermodal Storage#################
sh deploy_spark_job.sh -e $ENV -c IntermodalStorageDomainFeed -o "--num-executors 2  --executor-memory 6g --executor-cores 2"

