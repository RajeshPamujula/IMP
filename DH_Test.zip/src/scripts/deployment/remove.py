'''
  Author:   jun.dai@cn.ca
  Date:     2019-10-31
  Usage:    python remove.py --help

'''
import nipyapi
import requests
import os
from datetime import datetime,timedelta
import sys
import subprocess
import kerberos
from requests_kerberos import HTTPKerberosAuth, OPTIONAL
import argparse
import logging,six
import json
import xml.etree.ElementTree as ET

def check_template(path_to_template):
    # retrieve template name from the xml file
    template_name = get_pg_name_from_template(path_to_template)['template_name']
    logger.debug(template_name)
    ret = nipyapi.templates.get_template_by_name(template_name)
    logger.debug(ret)
    if(ret):
        if(type(ret) is list):
            for t in ret:
                logger.info('Template: '+t.template.name+' exists.')
                nipyapi.templates.delete_template(t.id)
                logger.info('Template: '+t.template.name+ ' is deleted.')
        else:
            logger.info('Template: '+ret.template.name+ ' exists.')
            nipyapi.templates.delete_template(ret.id)
            logger.info('Template: '+ret.template.name+ ' is deleted.')
    
def handle_controller(pg_id):
    ctrls = nipyapi.canvas.list_all_controllers(pg_id)
    if(ctrls):
        if(type(ctrls) is list):
            for ctrl in ctrls:
                nipyapi.canvas.schedule_controller(nipyapi.canvas.get_controller(ctrl.id,'id'),True)
        else:
            nipyapi.canvas.schedule_controller(nipyapi.canvas.get_controller(ctrls.id,'id'),True)
            

def deploy_template(parent_pgid, path_to_template):

    # check if the template already exists
    # if so, delete it first
    # Note: the template file name must have the same name as the template name.
    check_template(path_to_template)
    
    # upload template
    template_uploaded = nipyapi.templates.upload_template(nipyapi.canvas.get_root_pg_id(),path_to_template)
    if template_uploaded:
        logger.info("template is uploaded to NiFi with success!")
        # deploy the template to PG
        '''
        # Disabled the deployment temporarily
        ret = nipyapi.templates.deploy_template(parent_pgid, template_uploaded.id)
        logger.debug('deploy_template: return value of deployment')
        logger.debug(ret)
        if ret:
            try:
                deployed_pg = ret.flow.process_groups[0].component
                logger.info("template is deployed to NiFi with success!")
                return (deployed_pg.id,deployed_pg.name)
            except IndexError as e:
                logger.error('Your template is deployed but with error, you have to start the flow manually.')
                sys.exit(-1)
            finally:
                nipyapi.templates.delete_template(template_uploaded.id)
        else:
            logger.error('Failed to deploy template to NiFi! Start clean-up ...')
            # delete the uploaded template to keep the deck clean
            nipyapi.templates.delete_template(template_uploaded.id)
            sys.exit(-1)
        '''
    else:
        logger.error('Error: Failed to deploy template to NiFi!')
        sys.exit(-1)
        
        
def start_pg(deployed_pg_id):
    # scheduled: True/False -> Start/Stop
    # return True/False -> Succ/Fail
    return nipyapi.canvas.schedule_process_group(deployed_pg_id, scheduled=True)
    
def is_init_deploy(full_path,root_pid):
    # check if it's the initial deployment
    pid = get_deploy_pgid(full_path,root_pid)
    if pid:
        # Not the first time deployment
        logger.info("Not the first time deployment, process group: "+pid+" exists!")
        return pid
    else:
        # First time deployment
        logger.info("Start the initial deployment of process group: "+full_path)
        return False

def get_pg_status(pid):
    pg = nipyapi.canvas.get_process_group(pid,'id')
    status = {'name':pg.component.name}
    logger.debug(pg)
    if(type(pg) is list):
        pg = pg[0]
    if(pg):
        status['id'] = pg.id    
        status['running_count'] = pg.component.running_count
        status['ff_queued'] = pg.status.aggregate_snapshot.flow_files_queued
        status['running'] = True if (pg.component.running_count + pg.status.aggregate_snapshot.flow_files_queued) > 0 else False
    else:
        status['id'] = None
    return status

def stop_running_pg(pids):
    # only stop the FIRST component of the flow
    # the first component could be processor or PG
    for pid in pids:
        pg = nipyapi.canvas.get_processor(pid,'id')
        if pg:
            ret = nipyapi.canvas.schedule_processor(pg, False, refresh=True)
        else:
            ret = nipyapi.canvas.schedule_process_group(pid, False)
        if ret:
            logger.info('The root component: '+ pid +' is stopped with success!')
        else:
            logger.debug('Error: Failed to stop the root component: '+ pid)  
        
def rename_pg(pid,postfix='_OBSOLETE'):
    # change name and position
    # by default, the PG will be changed to upper case then padded by '_OBSOLETE'
    logger.info('renaming the old PG ...')
    ts = datetime.now().strftime("%m_%d_%Y_%H_%M_%S")
    process_group = nipyapi.canvas.get_process_group(pid,'id')
    new_pos = process_group.component.position
    new_pos.x += 30
    new_pos.y += 30
    new_name = process_group.component.name.upper() + '_' + ts + postfix
    nipyapi.canvas.update_process_group(process_group, {'position': new_pos, 'name': new_name})
    logger.info('renaming is done.')
    logger.info('The process group is renamed to: ' + new_name)

def get_src_dest_pid(pid):
    pg_flow = nipyapi.canvas.get_flow(pid)
    logger.debug(pg_flow)
    connections = pg_flow.process_group_flow.flow.connections
    logger.debug(connections)
    src_list = []
    dest_list = []
    for connection in connections:
        src_list.append(connection.source_id)
        dest_list.append(connection.destination_id)
    return (src_list, dest_list)

def get_first_pids(pid):
    pg_list = []
    for elem in nipyapi.canvas.list_all_process_groups(pid):
        pg_list.append(elem.component.id)
    logger.debug(pg_list)
    src_list = []
    dest_list = []
    for pg in pg_list:
        src_list.extend(get_src_dest_pid(pg)[0])
        dest_list.extend(get_src_dest_pid(pg)[1])
    
    #logger.debug(src_list, dest_list)
    src_list = list(set(src_list) - (set(src_list) & set(dest_list)))
    if(len(src_list)):
         return src_list
    else:
         return -1
        
''' 
# Only for exceptional user       
def nifi_auth(nifi_host,uid,passwd,ca_path):
    nipyapi.config.nifi_config.host = nifi_host
    nifiToken = subprocess.check_output(['curl',nifi_host+'/access/token','-H','Accept-Encoding: gzip, deflate, br','-H','Content-Type: application/x-www-form-urlencoded; charset=UTF-8','-H','Accept: */*','--data','username='+uid+'&password='+passwd,'--compressed']).decode()
    nipyapi.security.set_service_ssl_context(service='nifi', ca_file=ca_path, client_cert_file=None, client_key_file=None, client_key_password=None)
    logger.debug(nifiToken)
    nipyapi.security.set_service_auth_token(token=nifiToken, token_name='tokenAuth', service='nifi')
'''
   
def get_nifi_token(nifi_host,ca_path):
    kerberos_auth = HTTPKerberosAuth(mutual_authentication=OPTIONAL) 
    r = requests.post(nifi_host + '/access/kerberos',verify=ca_path, auth=kerberos_auth)
    logger.debug(r.text)
    assert r.status_code == 201, "(POST) HTTP Error: " + str(r.status_code)
    return r.text

def nifi_auth_ca(nifi_host,ca_path):
    nipyapi.config.nifi_config.host = nifi_host
    nifiToken = get_nifi_token(nifi_host,ca_path)
    nipyapi.security.set_service_ssl_context(service='nifi', ca_file=ca_path, client_cert_file=None, client_key_file=None, client_key_password=None)
    return nipyapi.security.set_service_auth_token(token=nifiToken, token_name='tokenAuth', service='nifi')  

# customized
def get_process_group(identifier, identifier_type='name',greedy=True):
    assert isinstance(identifier, six.string_types)
    assert identifier_type in ['name', 'id']
    with nipyapi.utils.rest_exceptions():
        if identifier_type == 'id':
            # assuming unique fetch of pg id
            # implementing separately to avoid recursing entire canvas
            out = nipyapi.nifi.ProcessGroupsApi().get_process_group(identifier)
        else:
            obj = nipyapi.canvas.list_all_process_groups()
            out = nipyapi.utils.filter_obj(obj, identifier, identifier_type,greedy) 
    return out

def get_deploy_pgid(deploy_path,root_pid):
    # create dict of {'pg_path_name':'pg_id'}
    pg_path_mapping = get_pg_path_mapping(deploy_path,root_pid)
    if(not pg_path_mapping):
        return None
    else:
        if(deploy_path in pg_path_mapping):
            logger.debug(pg_path_mapping)
            return pg_path_mapping[deploy_path]
        else:
            return None

def get_pg_path_mapping(pg_path,root_pid):
    parent_pg_name = os.path.basename(pg_path)
    pg_list = get_process_group(parent_pg_name,greedy=False)
    if(pg_list):
        pg_mapping = {}
        if(isinstance(pg_list,list)):
            for pg in pg_list:
               pid = pg.id
               pg_path = get_pg_path(pid,root_pid)
               pg_path = '/'+'/'.join(list(filter(None, reversed(pg_path.split('/')))))
               pg_mapping[pg_path] = pid
        else:
            pid = pg_list.id
            pg_path = get_pg_path(pid,root_pid)
            pg_path = '/'+'/'.join(list(filter(None, reversed(pg_path.split('/')))))
            pg_mapping[pg_path] = pid
        return pg_mapping
    else:
        return None

def get_pg_name_from_template(path):
    tree = ET.parse(path)
    root = tree.getroot()
    name_list = []
    ret = {}
    for elem in root.findall('.//name'):
        if(elem.text):
            name_list.append(elem.text)
    # template_name, process_group_name
    ret['template_name'] = name_list[0]
    ret['pg_name'] = name_list[-1]
    return(ret)

    
def get_pg_path(pid,stop_pid, path='/'):
    if(pid != None) :
        parent_group_id = get_process_group(pid,'id',False).component.parent_group_id
        pg_name = get_process_group(pid,'id',False).component.name       
        path = os.path.join(path, get_pg_path(parent_group_id,stop_pid,pg_name))
    return path
    
if __name__ == '__main__':
    # define arguments parser
    parser = argparse.ArgumentParser()

    parser.add_argument('-p', action='store', dest='path',
                    help='where the template locates',required=True)

    parser.add_argument('-pg', action='store', dest='deploy_path',
                    help='the full deploy path ',required=True)
    
    args = parser.parse_args()
    user = os.environ['USER']
    
    # create logs folder if not exists
    if not os.path.exists('./logs'):
        os.makedirs('logs')    
    # Gets or creates a logger
    logger = logging.getLogger(user+':Deployment')    
    # set log level
    logger.setLevel(logging.INFO)    
    # define file handler and set formatter
    file_handler = logging.FileHandler('./logs/logfile.log')
    formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
    file_handler.setFormatter(formatter)    
    # add file handler to logger
    logger.addHandler(file_handler)

    # get NiFi hostname
    try:  
       nifi_host = os.environ["NIFI_HOST"] + '/nifi-api'
    except KeyError: 
       nifi_host = 'https://mtl-emp08d.cn.ca:9091/nifi-api'
       
    
    path = args.path
    deploy_path = args.deploy_path
    dir_path = '/hadoop/developers/'+user+'/deployment'
    ca_path = os.path.join(dir_path, 'CN.bundle.pem')
        
    if(nifi_auth_ca(nifi_host,ca_path)):
        # retrieve process group name from the xml file
        deploy_pg_name = get_pg_name_from_template(path)['pg_name']

        root_pid = nipyapi.canvas.get_root_pg_id()    
        parent_pid = get_deploy_pgid(deploy_path,root_pid)
        
        if(not parent_pid):
            logger.error('Deploy path: '+ deploy_path + ' is not found.')
            assert parent_pid, 'Deploy path: '+ deploy_path + ' is not found.'
        
        deploy_pg_path = os.path.join(deploy_path,deploy_pg_name)
        logger.info('deploy path = '+deploy_path)
        logger.info('target path = '+deploy_pg_path)
    
    
        pid = is_init_deploy(deploy_pg_path,root_pid)
        if(pid):
            status = get_pg_status(pid)
            logger.debug(status)
            if(status['running']):
                logger.info('The PG is running. Stop the running one first!')                      
                logger.debug(get_first_pids(pid))
                stop_running_pg(get_first_pids(pid))
            else:
                # if not running, do nothing
                logger.info('The existing PG is not running. Deploy directly!')        
            rename_pg(pid)
    
        # deploy the pg template 
        #deployed_pg_id,deployed_pg_name = deploy_template(parent_pid, path)
        deploy_template(parent_pid, path)
        # start controller service if available
        # handle_controller(deployed_pg_id)
        
        # start the deployed pg
        #start_pg(deployed_pg_id)
        #logger.info('Process Group: ' + json.dumps(nipyapi.canvas.get_process_group_status(deployed_pg_id)) + ' is up and running.')        
        
    else:
        logger.error('Authenticaiton Failed!')
