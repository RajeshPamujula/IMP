#@IgnoreInspection BashAddShebang
    # User Prefix
    export DH_TENANT=dh
    export ROOT_PATH=/dev/${USER}/
    export HDFS_SERVER='hdfs:/'
    export HDFS_NAMENODE=${HDFS_SERVER}/hubdevnn:8020
    export RL_PATH=/hadoop/developers/build/TM_DAAS/Current/cnrail-dh-transportation-daas-1.14.0-SNAPSHOT
    export BUILD_PATH=/hadoop/developers/build
    export USER_KEYTAB=/home/${USER}/.${USER}.keytab
    export USER_KEYTAB_BKUP=/home/${USER}/.${USER}.keytab.bak
	export HADOOP_CONF_DIR=/etc/hadoop/conf
	export YARN_QUEUE="integration"

    # Zookeeper
    export ZK_HOST_1=mtl-hub02d.cn.ca
    export ZK_HOST_2=mtl-hub03d.cn.ca
    export ZK_HOST_3=mtl-hub04d.cn.ca
    export ZK_HOST_PORT=2181
    export ZK_HOSTS=${ZK_HOST_1}:${ZK_HOST_PORT},${ZK_HOST_2}:${ZK_HOST_PORT},${ZK_HOST_3}:${ZK_HOST_PORT}
    export ZK_HOSTS_NO_PORTS=${ZK_HOST_1},${ZK_HOST_2},${ZK_HOST_3}
    export HDF_ZK_HOST_1=mtl-emp11d.cn.ca:2181
    export HDF_ZK_HOST_2=mtl-emp12d.cn.ca:2181
    export HDF_ZK_HOST_3=mtl-emp13d.cn.ca:2181
    export HDF_ZK_HOST_4=mtl-emp14d.cn.ca:2181
    export HDF_ZK_HOST_5=mtl-emp15d.cn.ca:2181
    export HDF_ZK_HOSTS=${HDF_ZK_HOST_1},${HDF_ZK_HOST_2},${HDF_ZK_HOST_3},${HDF_ZK_HOST_4},${HDF_ZK_HOST_5}
	export ZOOKEEPER_PARAM=${HDF_ZK_HOSTS}

    # Spark
    export JAAS_CONFIG="/home/${USER}/jaas.conf"
    export SPARK_JAR_LOC="${RL_PATH}/spark-jars"
    export SPARK_USER_NAME=${USER}
    export SPARK_LOG="/hadoop/developers/build/logs"
    export SPARK_SCRATCH_DIR="/hadoop/developers/build/spark"
    export SPARK_CHKPT_DIR="/integration/spark/checkpoint/tm_daas"  #this is hdfs directory
    export SPARK_REFERENCE_DATA_DIR="/integration/referenceData"
    export YARN_RM_HOST_URL="mtl-hub03d.cn.ca:8088"
    export SPARK_CONF_DIR="${RL_PATH}/scripts/utilities"

    # Kafka
	export REPLICATIONFACTOR_PARAM=3
	export PARTITIONS_PARAM=3
    export KAFKA_BROKER_HOST="mtl-emp02d.cn.ca:6667,mtl-emp03d.cn.ca:6667,mtl-emp04d.cn.ca:6667,mtl-emp05d.cn.ca:6667,mtl-emp06d.cn.ca:6667,mtl-emp07d.cn.ca:6667"
    ############## Raw and domain queues for Act Train Schedule
    export TRANSPORTATION_ACT_TRN_SCH_RAW_SRSYIT="qa.tm.raw.srs.trnScheduleActive.v2"
    export TRANSPORTATION_CNVY_CRT_PREPARED="stg.tm.prepared.cnvyCrt.v1"
    export TRANSPORTATION_CNVY_DSC_PREPARED="stg.tm.prepared.cnvyDsc.v1"
    export TRANSPORTATION_RTE_PLAN_PREPARED="stg.tm.prepared.rtePlan.v1"
    export TRANSPORTATION_CNVY_RMV_PREPARED="stg.tm.prepared.cnvyRmv.v1"
    export TRANSPORTATION_RTE_CANC_PREPARED="stg.tm.prepared.rteCanc.v1"
	export TRANSPORTATION_RTE_DSC_PREPARED="stg.tm.prepared.rteDsc.v1"
    ############## Error queue for publish messages
    export TRANSPORTATION_RTE_ERR_PREPARED="stg.tm.prepared.rteErr.v1"
    ############## Raw and domain queues for Train Reporting
    export TRANSPORTATION_TRN_RPTG_RAW_SRSYIT="qa.tm.raw.srs.trnReporting.v3"
    export TRANSPORTATION_TRAN_EVT_RPTD_PREPARED="stg.tm.prepared.trspEvtRpt.v1"
    export TRANSPORTATION_TRAN_EVT_ASCT_PREPARED="stg.tm.prepared.trspEvtAsct.v1"
    export TRANSPORTATION_CONV_ASCT_PREPARED="stg.tm.prepared.cnvyAsct.v1"
    export TRANSPORTATION_CONV_ASCT_DESC_PREPARED="stg.tm.prepared.cnvyAsctDsc.v1"
    export TRANSPORTATION_AST_ASCT_PREPARED="stg.tm.prepared.asetAsct.v1"
    export TRANSPORTATION_AST_ASCT_DESC_PREPARED="stg.tm.prepared.asetAsctDsc.v1"
	export TRANSPORTATION_AST_CRT_PREPARED="stg.tm.prepared.asetCrt.v1"
	export TRANSPORTATION_AST_DESC_PREPARED="stg.tm.prepared.asetDsc.v1"	
	############## Raw and domain queues for Car Inventory
    export TRANSPORTATION_CAR_INVE_RAW_SRSYIT="stg.tm.raw.srs.carInventory.v2"	
	export TRANSPORTATION_CNVY_COND_CRT_PREPARED="stg.tm.prepared.cnvyCondCrt.v1"
	export TRANSPORTATION_CNVY_COND_CHG_PREPARED="stg.tm.prepared.cnvyCondChg.v1"
	export TRANSPORTATION_EVT_ASSOC_DESC_PREPARED="stg.tm.prepared.trspEvtAsctDsc.v1"
	export TRANSPORTATION_TRIP_CRT_PREPARED="stg.tm.prepared.tripCrt.v1"
	export TRANSPORTATION_TRIP_DESC_PREPARED="stg.tm.prepared.tripDsc.v1"
	export TRANSPORTATION_LOC_ASSOC_PREPARED="stg.tm.prepared.locAsct.v1"
	export TRANSPORTATION_LOC_ASSOC_DESC_PREPARED="stg.tm.prepared.locAsctDsc.v1"
	export TRANSPORTATION_TRIP_ASSOC_PREPARED="stg.tm.prepared.tripAsct.v1"
	export TRANSPORTATION_SHP_ASSOC_DESC_PREPARED="stg.tm.prepared.shipAsctDsc.v1"
    ############## Error queue for implement messages
    export TRANSPORTATION_DH_PGLOGS_PREPARED="stg.tm.prepared.dhPGLogs.v1"
    ############## Raw and domain queues for Train Consist
	export TRANSPORTATION_TRN_CONSIST_RAW_SRSYIT="qa.tm.raw.srs.trnConsist.v2"
	export TRANSPORTATION_PLAN_EVT_RPT_PREPARED="stg.tm.prepared.planEvtRpt.v1"
    export TRANSPORTATION_PLAN_EVT_ASCT_PREPARED="stg.tm.prepared.planEvtAsct.v1"
	export TRANSPORTATION_EVT_DSC_PREPARED="stg.tm.prepared.trspEvtDsc.v1"
    ############## Raw Kafka queues for Terminal Event
	export TRANSPORTATION_TER_EVT_RAW_SRSIM="qa.tm.raw.srs.yardEvent.v3"
	############## Raw Kafka queues for Industrial Instruction/Reason
    export TRANSPORTATION_INDS_INSN_RAW_SRSYIT="qa.tm.raw.indsInsn.v1"
    export TRANSPORTATION_PLAN_EVT_DSC_PREPARED="stg.tm.prepared.planEvtDsc.v1"
    export TRANSPORTATION_PLAN_EVT_RMV_PREPARED="stg.tm.prepared.planEvtRmv.v1"
	export TRANSPORTATION_PLAN_EVT_DSC_CHG_PREPARED="stg.tm.prepared.planEvtDscChg.v1"
    export TRANSPORTATION_CONV_DASCT_PREPARED="stg.tm.prepared.cnvyDasc.v1"
	############ Raw and domain queues for Waybill
   	export TRANSPORTATION_WAYBILL_RAW_SRSYIT="stg.tm.raw.srs.wayBill.v3"
   	export TRANSPORTATION_SHP_DESC_PREPARED="stg.tm.prepared.shipDsc.v1"
   	export TRANSPORTATION_SHP_CRTD_PREPARED="stg.tm.prepared.shipCrt.v1"
	export TRANSPORTATION_SHP_ASSOC_PREPARED="stg.tm.prepared.shipAsct.v1"
	export TRANSPORTATION_SHP_COND_CRT_PREPARED="stg.tm.prepared.shipCondCrt.v1"
	############ Raw queue for Waybill Reference
	export TRANSPORTATION_WAYBILLREFERENCE_RAW_SRSYIT="qa.tm.raw.waybill-reference.v1"
	############ Raw and domain queues for GATE EVENT
	export TRANSPORTATION_GTE_EVT_RAW_SRSYIT="qa.tm.raw.srs.gateEvts.v2"
	export TRANSPORTATION_TRAN_EVT_RMV_PREPARED="stg.tm.prepared.trspEvtRmv.v1"
	############ Raw and domain queues for ETAETD
   	export TRANSPORTATION_ETA_ETD_UPDATE_RAW_SRSYIT="qa.tm.raw.srs.trnETAETD.v2"
	############ Raw and domain queues for IntermodalCarContainer
   	export TRANSPORTATION_IMDL_CAR_CTNR_RAW_SRSYIT="qa.tm.raw.carCtnr.v1"
	############ Raw queue for Car Inventory Intermodal
   	export TRANSPORTATION_CAR_INV_IMDL_RAW_SRSIM="qa.tm.raw.carInvImdl.v1"
	############ Raw queue for Voyage
    export TRANSPORTATION_VYG_RAW_SRSYIT="qa.tm.raw.voyage.v1"
    ############ Raw and domain queue for Intermodal Bad Order
    export TRANSPORTATION_IBO_RAW_SRSYIT="qa.tm.raw.imBadOrder.v1"
    export TRANSPORTATION_CNVY_COND_CHG_PREPARED="stg.tm.prepared.cnvyCondChg.v1"
	############ Raw queue for Motor Carrier
	export TRANSPORTATION_MTR_CARR_RAW_SRSYIT="qa.tm.raw.imMtrCarr.v1"
	export TRANSPORTATION_BUS_PRTR_CRT_PREPARED="stg.tm.prepared.busPrtrCrt.v1"
	export TRANSPORTATION_BUS_PRTR_COND_CRT_PREPARED="stg.tm.prepared.busPrtrCondCrt.v1"
	export TRANSPORTATION_BUS_PRTR_DSC_PREPARED="stg.tm.prepared.busPrtrDsc.v1"
	export TRANSPORTATION_BUS_PRTR_RMV_PREPARED="stg.tm.prepared.busPrtrRmv.v1"
	############ Raw queue for Vessel
    export TRANSPORTATION_VSL_RAW_SRSYIT="qa.tm.raw.vessel.v1"
	############ Raw queue for Port Station Info
	export TRANSPORTATION_PORT_STN_INFO_RAW_SRSYIT="qa.tm.raw.portStnInfo.v1"
    ############ Raw queue for Voyage Segment
    export TRANSPORTATION_VYG_SEG_RAW_SRSYIT="qa.tm.raw.voyageSeg.v1"
	############ Raw queue for Rail Station Reference
    export TRANSPORTATION_RAILSTATION_REFERENCE="stg.tm.raw.commonStn.v1"
	############ Car Reference
    export TRANSPORTATION_CAR_REFERENCE="stg.tm.raw.commonUmler.v1"
    ############ Raw queue for Track Reference
    export TRANSPORTATION_TRACK_REFERENCE="stg.tm.raw.commonYrdTrk.v1"
    ############ Raw queue for Intermodal Storage
    export TRANSPORTATION_IS_RAW_SRSYIT="qa.supply-chain.intermodal-storage.raw.v1"
	
    ############ Kafka Backup Topics
    export TRANSPORTATION_KAFKA_BACKUP_EVENT_FEED_TOPICS_RAW="$TRANSPORTATION_ACT_TRN_SCH_RAW_SRSYIT,$TRANSPORTATION_TRN_RPTG_RAW_SRSYIT,$TRANSPORTATION_CAR_INVE_RAW_SRSYIT,$TRANSPORTATION_TRN_CONSIST_RAW_SRSYIT,$TRANSPORTATION_TER_EVT_RAW_SRSIM,$TRANSPORTATION_INDS_INSN_RAW_SRSYIT,$TRANSPORTATION_WAYBILL_RAW_SRSYIT,$TRANSPORTATION_GTE_EVT_RAW_SRSYIT,$TRANSPORTATION_ETA_ETD_UPDATE_RAW_SRSYIT,$TRANSPORTATION_IMDL_CAR_CTNR_RAW_SRSYIT,$TRANSPORTATION_CAR_INV_IMDL_RAW_SRSIM,$TRANSPORTATION_VYG_RAW_SRSYIT,$TRANSPORTATION_IBO_RAW_SRSYIT,$TRANSPORTATION_MTR_CARR_RAW_SRSYIT,$TRANSPORTATION_VSL_RAW_SRSYIT,$TRANSPORTATION_WAYBILLREFERENCE_RAW_SRSYIT,$TRANSPORTATION_VYG_SEG_RAW_SRSYIT,$TRANSPORTATION_PORT_STN_INFO_RAW_SRSYIT,$TRANSPORTATION_IS_RAW_SRSYIT"
    export TM_ARCHIVING_RAW_PATH="/integration/raw/SRS/intl"
    export TM_ARCHIVING_RAW_CHKPT="kafkaBackupEventCheckpointRaw"
    
	# Postgres
    export PG_CONN_URL="jdbc:postgresql://mtl-onedatadv.cn.ca:5491/datahubuat"
    export PG_USER="datahub-db-apimgmt-dev"
    export PG_PWD_ALIAS="postgres.password.alias"
    export PG_PWD_FILE="/integration/jceks/postgres.password.jceks"
    export PG_PREPARED_SCHEMA="DAAS_TM_PREPARED"
    export PG_RAW_SCHEMA="DAAS_TM_RAW"
    export PG_TBL_USER=""
    export PG_PREPARED_TBL_PREFIX=${PG_PREPARED_SCHEMA} #this is used in application.conf for TM_PREPARED tables
    export PG_RAW_TBL_PREFIX=${PG_RAW_SCHEMA} #this is used in application.conf for TM_RAW tables
    export PG_RAW_TBL_PREFIX_STATION="TM_RAW"
    export PG_DRIVER="org.postgresql.Driver"
	export PG_SCHEMA_LIST="tm_raw,tm_prepared,tm_trusted,daas_tm_prepared"

    # Hive
    export SRS_RAW_DB=srs_raw
    export SRS_RAW_DB_PATH=/integration/raw/SRS/intl
    export TM_PREPARED_DB=tm_prepared
    export TM_PREPARED_DB_PATH=/integration/prepared/tm/intl
    export hive_dbs="${SRS_RAW_DB},${TM_PREPARED_DB}"

    # Monitoring
    export DH_ENV=DEV
    export AMBARI_HOST="https://mtl-hubmgmt01d.cn.ca:8443"
    export NIFI_HOST="https://mtl-emp08d.cn.ca:9091"
    export TARGET_EMAILS_LIST="dh_support@cn.ca" #Change email at the time of testing
    export CA_PATH=/hadoop/developers/build
    export nifi_root_id=''
    export NIFI_PROCESS_GROUPS_TO_MONITOR='INTEGRATION_SRS' #process groups to monitor need to be determined at the time of deployment
    export SPARK_HISTORY_SERVER=mtl-hub04d.cn.ca
    export SPARK_HISTORY_PORT=18081
    export SPARK_JOB_PREFIX=${SPARK_USER_NAME}_
    export SPARK_JOB_STREAMING_SUFFIX=Load,Feed
    export PREDEPLOY_EMAIL_LIST='dh_support@cn.ca'
    export POSTDEPLOY_EMAIL_LIST='dh_support@cn.ca'
    export SUBJECT='DEPLOYMENT'
    export DH_MONITOR_JOB_STATUS=dh_monitor_job_status

    # Print the values of the variables
    echo "JAAS_CONFIG:"${JAAS_CONFIG}
    echo "SPARK_JAR_LOC:"${SPARK_JAR_LOC}
    echo "SPARK_USER_NAME:"${SPARK_USER_NAME}
    echo "SPARK_LOG:"${SPARK_LOG}
    echo "SPARK_SCRATCH_DIR:"${SPARK_SCRATCH_DIR}
    echo "SPARK_CHKPT_DIR:"${SPARK_CHKPT_DIR}
    echo "KAFKA_TOPIC_NM_ACTTRNSCD:"${KAFKA_TOPIC_NM_ACTTRNSCD}
    echo "KAFKA_TOPIC_NM_ETAETD:"${KAFKA_TOPIC_NM_ETAETD}
    echo "KAFKA_TOPIC_NM_TRNREEP:"${KAFKA_TOPIC_NM_TRNREEP}
    echo "KAFKA_TOPIC_NM_YARDEVT:"${KAFKA_TOPIC_NM_YARDEVT}
    echo "KAFKA_TOPIC_NM_WAYBILL:"${KAFKA_TOPIC_NM_WAYBILL}
    echo "KAFKA_TOPIC_NM_CARINV:"${KAFKA_TOPIC_NM_CARINV}
    echo "KAFKA_TOPIC_NM_PREPARED_TRNSCDEVT:"${KAFKA_TOPIC_NM_PREPARED_TRNSCDEVT}
    echo "KAFKA_TOPIC_NM_PREPARED_CARSTNEVT:"${KAFKA_TOPIC_NM_PREPARED_CARSTNEVT}
    echo "KAFKA_TOPIC_NM_PREPARED_CARDESTEVT:"${KAFKA_TOPIC_NM_PREPARED_CARDESTEVT}
    echo "KAFKA_TOPIC_NM_PREPARED_CTNRCAREVT:"${KAFKA_TOPIC_NM_PREPARED_CTNRCAREVT}
    echo "KAFKA_TOPIC_NM_PREPARED_CTNREVT:"${KAFKA_TOPIC_NM_PREPARED_CTNREVT}
    echo "KAFKA_TOPIC_NM_PREPARED_SHIPMTEVT:"${KAFKA_TOPIC_NM_PREPARED_SHIPMTEVT}
    echo "KAFKA_TOPIC_NM_PREPARED_SHIPMTCNVYEVT:"${KAFKA_TOPIC_NM_PREPARED_SHIPMTCNVYEVT}
    echo "TRANSPORTATION_ACT_TRN_SCH_RAW_SRSYIT:"${TRANSPORTATION_ACT_TRN_SCH_RAW_SRSYIT}
    echo "TRANSPORTATION_CNVY_CRT_PREPARED:"${TRANSPORTATION_CNVY_CRT_PREPARED}
    echo "TRANSPORTATION_CNVY_DSC_PREPARED:"${TRANSPORTATION_CNVY_DSC_PREPARED}
    echo "TRANSPORTATION_RTE_PLAN_PREPARED:"${TRANSPORTATION_RTE_PLAN_PREPARED}
    echo "TRANSPORTATION_CNVY_RMV_PREPARED:"${TRANSPORTATION_CNVY_RMV_PREPARED}
    echo "TRANSPORTATION_RTE_CANC_PREPARED:"${TRANSPORTATION_RTE_CANC_PREPARED}
    echo "TRANSPORTATION_RTE_ERR_PREPARED:"${TRANSPORTATION_RTE_ERR_PREPARED}
    echo "PG_CONN_URL:"${PG_CONN_URL}
    echo "PG_USER:"${PG_USER}
    echo "PG_PWD_FILE:"${PG_PWD_FILE}
    echo "PG_PREPARED_TBL_PREFIX:"${PG_PREPARED_TBL_PREFIX}
    echo "PG_RAW_TBL_PREFIX:"${PG_RAW_TBL_PREFIX}
    echo "TARGET_EMAILS_LIST:"${TARGET_EMAILS_LIST}
    echo "PREDEPLOY_EMAIL_LIST:"${PREDEPLOY_EMAIL_LIST}
    echo "POSTDEPLOY_EMAIL_LIST:"${POSTDEPLOY_EMAIL_LIST}
    echo "SUBJECT:${SUBJECT}"
    echo "BUILD_PATH:"${BUILD_PATH}
