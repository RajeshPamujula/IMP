#!/opt/python3/bin/python
# coding: utf-8

'''
  Author  :        Jun Dai (189485)
  Created :        2020-03-30
  Usage   :        python regression_notification.py -t <PIN>
'''

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
import sys,os
import sqlite3
from datetime import datetime
import argparse
import pandas as pd

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def send_email(subj,from_,to_,msg_body):
    msg = MIMEMultipart('alternative')
    msg["From"] = from_
    msg["To"] = to_
    msg["Subject"] = subj
    HTML_BODY = MIMEText(msg_body, 'html')
    msg.attach(HTML_BODY)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    if (sys.version_info > (3, 0)):
        p.communicate(msg.as_bytes())
    else:
        p.communicate(msg.as_string())
        
def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', action='store', dest='to_',
                        help="email receiver", required=True)
    args = parser.parse_args()
    return args 

def add_test_status(row):
        cols = list(df.columns)[2:10]
        sum_cols = 0
        # https://github.com/pandas-dev/pandas/issues/2656
        row['Status'] = 'NULL' # 
        for col in cols:
            if row[col] == 1:
                row[col] = 'Success'
                sum_cols += 1
            elif row[col] == 0:
                row[col] = 'Failure'
            else:
                continue
      
        if sum_cols == len(cols):
            row['Status'] = 'Success'
        else:
            row['Status'] = 'Failure'
        return row

def highlight_vals(val, color='red'):
        if val == 'Failure':
            return 'background-color: %s' % color
        else:
            return ''

def df_to_html(df):
    newCols = list(df.columns)
    newCols[1] = "sparkClassName"
    df.columns = newCols

    df = df[['id', 'sparkClassName', 'Status','prepare', 'loadInput', 'sparkRun',
       'loadOutput', 'test_count', 'test_schema', 'test_value', 'cleanUp',
       'exec_time','expect_value', 'actual_value']].reset_index(drop=True)

    # DataFrame.style requires jinja2
    '''
    html = df.style.set_table_styles(
        [{'selector': '.row_heading',
          'props': [('display', 'none')]},
         {'selector': '.blank.level0',
          'props': [('display', 'none')]}]).set_table_attributes('border="1" class="dataframe table table-hover table-bordered"').applymap(highlight_vals, subset=['Status']).render()
    '''
    html = df.to_html(index=False)
    return html

    
if __name__ == "__main__":

    args = get_args()
    to_ = args.to_
    
    # Read sqlite query results into a pandas DataFrame
    conn = sqlite3.connect("output/test_result.db")
    df = pd.read_sql_query("SELECT * from test_result", conn)
    
    # close DB connection
    conn.close()
    
    # add col 'Status'
    df = df.apply(add_test_status,axis=1)
    fail_cnt = len(df[(df['Status'] != 'Success')])  
    if  fail_cnt > 0:
        pass_rate = str(round((df.shape[0]-fail_cnt)*100.0/df.shape[0], 2)) + '%'
    else:
        pass_rate = '100%'

    # generate html body
    email_content = df_to_html(df)
    
    # send test report by email
    user = os.getenv("USER") + '@CN.CA'
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    subj = "Regression Checks " + ts + " <Pass Rate: " + pass_rate + ">"
    send_email(subj,user,to_,email_content)
    
    # return 0 if all pass
    if fail_cnt > 0:
        exit(RC_ERROR)
    else:
        exit(RC_SUCCESS)