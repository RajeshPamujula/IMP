#!/bin/bash

# "**********************************************************************************"
#  Author:  jun.dai@cn.ca
#  Created: 2020-03-17
#
# "**********************************************************************************"

export cwd="$( cd "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"

usage()
{
    echo "Usage: bash regression_wrapper.sh -u <PIN> [-m ALL|SparkClassName] [-n 1] [-k]"
	# if '-k' is present, auto clean-up is disabled
	# user has to clean up the test environment manually if the test fails.
}

if [ $# -eq 0 ] ;then
    echo "No arguments supplied"
    usage
	exit 1
fi

TS="date +%Y-%m-%d-%H-%M-%S"
TS_FORMAT=`eval $TS`
USER=${USER}
CLS_NAME="ALL"

while [ "$1" != "" ]; do
    case $1 in
        -u )            shift
                        USER=$1
                        ;;
        -m )            shift
                        CLS_NAME=$1
                        ;;
        -n )            shift
                        JOB_NR=$1
                        ;;
        -k )            CLEAN_UP='-k'
                        ;;						
        -h | --help )   usage
                        exit
                        ;;
        * )             usage
                        exit 1
    esac
    shift
done

# Color Scheme
red=$'\e[1;31m'
grn=$'\e[1;32m'
yel=$'\e[1;33m'
blu=$'\e[1;34m'
mag=$'\e[1;35m'
cyn=$'\e[1;36m'
end=$'\e[0m'

printf "%s\n" ==============================================================================
printf "%s\t%s\t%s\n" "[${yel}INFO${end}]" $TS_FORMAT: "TM Regression Test is started ..."
printf "%s\n"  ==============================================================================


# ------------------------------------------------
# Kerberose 
# ------------------------------------------------
KT_FILE=/home/${USER}/.${USER}.keytab
if [ -f "$KT_FILE" ]; then
    kinit ${USER}@CN.CA -kt ${KT_FILE} > /dev/null 2>&1
    klist > /dev/null 2>&1
else
    printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "$KT_FILE is not found!"
    exit -1
fi

# ------------------------------------------------
# Sourcing Environment Variables from the regression test
# ENV_REG.sh holds the env variables for regression test environment
# - PATH_TEST_PLAN
# - PATH_INPUT
# - PATH_OUTPUT
# - PATH_SPARK_CLASS
# - PATH_KAFKA_BIN
# - PATH_COMPARE
# - etc
# ------------------------------------------------
ENV_FILE=${cwd}/../utilities/ENV_REG.sh

if [ -f "$ENV_FILE" ]; then
    printf "%s\t%s\t%s\n" "[${yel}INFO${end}]" $TS_FORMAT: "Setting Up the regression test environment ..."
    source ${ENV_FILE} > /dev/null 2>&1
else 
    printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "$ENV_FILE is not found!"
    exit -1
fi

# ------------------------------------------------
# Declaring Additional Environment variables
# ------------------------------------------------
if [[ -z "$JOB_NR" ]] || [[ "$JOB_NR" == "" ]];then
    if [[ -z "$REG_JOB_NR" ]];then
        JOB_NR=1  # default: No parallelism
    else
        JOB_NR=${REG_JOB_NR}
    fi
fi

#-------------------------------------------------
# Enable auto clean up
#-------------------------------------------------
if [ "$CLEAN_UP" != "" ];then
    CLEAN_UP="-k"
fi

export PATH=/opt/python3/bin:$PATH
LOG_PATH=$REG_LOG

if [[ ! -e $LOG_PATH ]]; then
    mkdir -p $LOG_PATH
fi
# Logging Definition
rm -f ${LOG_PATH}/regression_test_* >/dev/null 2>&1 


# Clean reg test result DB
if [[ -e ${cwd}/output/test_result.db ]]; then
    rm -f ${cwd}/output/test_result.db
fi

# Reg test run-mode, ALL or SparkClassName
IFS=',' read -r -a CLS_NAME_LIST <<< "$CLS_NAME"

# ------------------------------------------------
# Define work path
# ------------------------------------------------ 
PATH_DEP_CSV=${cwd}/regression_dependency.csv
PATH_SCRIPTS=${cwd}/../../scripts
PATH_INPUT=${cwd}/input
PATH_OUTPUT=${cwd}/output
PATH_REF_DATA=${cwd}/../../postgresql/ref_data

export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client

# ------------------------------------------------
# Check if dependency csv exists
# Check input/output folders
# ------------------------------------------------
if [[ ! -e $PATH_DEP_CSV ]]; then
    printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "$PATH_DEP_CSV is not found!"
    exit -1
fi

if [[ ! -e $PATH_INPUT ]]; then
    printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "$PATH_INPUT is not found!"
    #mkdir -p $PATH_INPUT
    exit -1
fi

if [[ ! -e $PATH_OUTPUT ]]; then
    printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "$PATH_OUTPUT is not found!"
    #mkdir -p $PATH_OUTPUT
    exit -1
fi

if [[ ! "$(ls -A $PATH_REF_DATA)" ]];then
    printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "$PATH_REF_DATA is empty!"
    exit -1
else
    hadoop fs -put -f ${PATH_REF_DATA}/* $SPARK_REFERENCE_DATA_DIR
fi

# ------------------------------------------------
# 1. Prepare 
# - Create Regression Source Kafka Queue (regression prefix)
# - Create Regression Target Kafak Queue or Postgres table (regression prefix)
# - etc
# ------------------------------------------------
function prepare(){
    # RC = 0: PASS, otherwise FAIL

    if [[ -z "$1" ]] || [[ "$1" == "" ]] || [[ "${1^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "Prepare: Spark Class Name is missing!"
        return 1
    fi
    if [[ -z "$2" ]] || [[ "$2" == "" ]] || [[ "${2^^}" == "NONE" ]];then
        kaf_topics=""
    else
        kaf_topics="-tp $(echo $2 | sed "s/\"//g")"
    fi
    if [[ -z "$3" ]] || [[ "$3" == "" ]] || [[ "${3^^}" == "NONE" ]];then
        pg_tables=""
    else
        pg_tables="-pg $(echo $3 | sed "s/\"//g")"
    fi
    echo spark-submit ${cwd}/regression_prepare.py -c $1 $kaf_topics $pg_tables
    spark-submit ${cwd}/regression_prepare.py -c $1 $kaf_topics $pg_tables
    local _ret=$?
    return $_ret
}

# ------------------------------------------------
# 2. Load Input Test Data
# - Load the Input Test file data to Source Kafka
# ------------------------------------------------
function load_input(){
    # RC = 0: PASS, otherwise FAIL
            
    if [[ -z "$1" ]] || [[ "$1" == "" ]] || [[ "${1^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "LoadInput: Spark Class Name is missing!"
        return 1
    fi
    if [[ -z "$2" ]] || [[ "$2" == "" ]] || [[ "${2^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "LoadInput: Topic name is missing!"
        return 1
    else
        kaf_topics="-t $(echo $2 | sed "s/\"//g")"
    fi
    if [[ -z "$3" ]] || [[ "$3" == "" ]] || [[ "${3^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "LoadInput: JSON file is missing!"
        return 1
    else
        json_file="-f $(echo $3 | sed "s/\"//g")"
    fi
    if [[ -z "$4" ]] || [[ "$4" == "" ]] || [[ "${4^^}" == "NONE" ]];then
        ref_data=""
    else
        ref_data="-r $(echo $4 | sed "s/\"//g")"
    fi
    echo python ${cwd}/regression_loadInput.py -c $1 $kaf_topics $json_file
    python ${cwd}/regression_loadInput.py -c $1 $kaf_topics $json_file
    local _ret=$?
    return $_ret
}

# ------------------------------------------------
# 3. Run
# - Run the spark job in Regression mode (prefix of the job will determine this) 
# ------------------------------------------------
function run_spark(){
    # Run the spark job in Regression mode
    # RC = 0: PASS, otherwise FAIL

    dos2unix -f -q ${cwd}/../deployment/deploy_spark_env.sh
    bash ${cwd}/../deployment/deploy_spark_env.sh ${USER} REG
    if [ ! -f ${SPARK_CONF_DIR}/spark.conf ]; then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "Run: ${SPARK_CONF_DIR}/spark.conf is not found!"
        return 1
    fi
    if [[ -z "$1" ]] || [[ "$1" == "" ]] || [[ "${1^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "Run: Spark Class Name is missing!"
        return 1
    fi
    
	# generate a temp spark.conf for each test case
	spark_conf_file=/tmp/${TC_ID}_spark.conf
	sed "s/reg.tm./${TC_ID}.${USER}.reg.tm./g" ${SPARK_CONF_DIR}/spark.conf  > $spark_conf_file
	
	echo python ${cwd}/regression_run.py -u ${USER} -c ${1} -kt $USER_KEYTAB -pr ${SPARK_USER_NAME}@CN.CA -kc $USER_KEYTAB_BKUP -j $JAAS_CONFIG -q $YARN_QUEUE -sc $spark_conf_file -m cluster
	
	python ${cwd}/regression_run.py -u ${USER} -c ${1} -kt $USER_KEYTAB -pr ${SPARK_USER_NAME}@CN.CA -kc $USER_KEYTAB_BKUP -j $JAAS_CONFIG -q $YARN_QUEUE -sc $spark_conf_file -m cluster
	
    local _ret=$?
    return $_ret
}

# ------------------------------------------------
# 4. Load Output Test Data
# - Consume output from Kafka or Postgres and store it in a file
# ------------------------------------------------
function load_output(){
    # Consume output from Kafka/Postgres
    # RC = 0: PASS, otherwise FAIL
                        
    if [[ "${1^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "LoadOutput: Spark Class Name is missing!"
        return 1
    fi
    if [[ "${2^^}" == "NONE" ]];then
        kaf_topics=""
    else
        kaf_topics="-t $(echo $2 | sed "s/\"//g")"
    fi
    if [[ "${3^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "LoadOutput: Output json file is missing!"
        return 1
    else
        json_file="-f $(echo $3 | sed "s/\"//g")"
    fi
    if [[ "${4^^}" == "NONE" ]];then
        pg_tbls=""
    else
        pg_tbls="-s $(echo $4 | sed "s/\"//g")"
    fi    
    if [[ "${5^^}" == "NONE" ]];then
        pg_fltr=""
    else
        pg_fltr="-x $(echo $5 | sed "s/\"//g")"
    fi
    if [[ "${6^^}" == "NONE" ]];then
        kaf_fltr=""
    else
        kaf_fltr="-y $(echo $6 | sed "s/\"//g")"
    fi
    echo spark-submit ${cwd}/regression_loadOutput.py -c $1 $kaf_topics $json_file $pg_tbls $pg_fltr $kaf_fltr
    spark-submit ${cwd}/regression_loadOutput.py -c $1 $kaf_topics $json_file $pg_tbls $pg_fltr $kaf_fltr
    local _ret=$?
    return $_ret
}

# ------------------------------------------------
# 5. Outputs Validation
# - Compare generated output(s) from step 4 with the expected output Json file(s)
# - Some fields may be different, especially timestamp fields; these fields will be treated in a different way to avoid incorrect results
# ------------------------------------------------
function Compare(){
    # Compare $TC_INPUT and $TC_OUTPUT
    # RC = 0: PASS, otherwise FAIL
                    
    if [[ -z "$1" ]] || [[ "$1" == "" ]] || [[ "${1^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "Compare: Spark Class Name is missing!"
        return 1
    fi
    if [[ -z "$2" ]] || [[ "$2" == "" ]] || [[ "${2^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "Compare: Expected json file is missing!"
        return 1
    else
        file_exp="-s $(echo $2 | sed "s/\"//g")"
    fi
    if [[ -z "$3" ]] || [[ "$3" == "" ]] || [[ "${3^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "Compare: Actual json file is missing!"
        return 1
    else
        file_act="-t $(echo $3 | sed "s/\"//g")"
    fi
    if [[ "${4^^}" == "NONE" ]];then
        pg_fltr=""
    else
        pg_fltr="-x $(echo $4 | sed "s/\"//g")"
    fi
    if [[ "${5^^}" == "NONE" ]];then
        kaf_fltr=""
    else
        kaf_fltr="-y $(echo $5 | sed "s/\"//g")"
    fi
    
    echo python ${cwd}/regression_compare.py -c $1 $file_exp $file_act $pg_fltr $kaf_fltr
    python ${cwd}/regression_compare.py -c $1 $file_exp $file_act $pg_fltr $kaf_fltr
    local _ret=$?
    return $_ret                        
}

# ------------------------------------------------
# 6. Environment Cleanup
# - Cleanup if the requirement for comparison is met (delete Kafka Queues and PostgreSQL tables created in step 1)
# - Ask for a manual intervention for cleanup if the comparison fails
#   - To be set up in the Azure pipeline
#   - Once approved by individual this can be cleaned up and the cycle will be repeated after the issue is fixed from step 1
# - Email to be sent out irrespective (to be scheduled in azure pipeline)
# ------------------------------------------------
function clean_up(){
    # RC = 0: PASS, otherwise FAIL
    # exec clean up script

    if [[ -z "$1" ]] || [[ "$1" == "" ]] || [[ "${1^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "CleanUp: Spark Class Name is missing!"
        return 1
    fi
    # if [[ -z "$2" ]] || [[ "$2" == "" ]] || [[ "${2^^}" == "NONE" ]];then
        # kaf_topics=""
    # else
        # kaf_topics="-t $(echo $2 | sed "s/\"//g")"
    # fi
    if [[ -z "$3" ]] || [[ "$3" == "" ]] || [[ "${3^^}" == "NONE" ]];then
        pg_tbls=""
    else
        pg_tbls="-s $(echo $3 | sed "s/\"//g")"
    fi
    echo spark-submit ${cwd}/regression_cleanUp.py -c $1 $pg_tbls
    spark-submit ${cwd}/regression_cleanUp.py -c $1 $pg_tbls
    local _ret=$?
    return $_ret                        
}

# ------------------------------------------------
# 7. Send Notifications & Results
# - Email notification will be sent out on the report
# ------------------------------------------------
function notification(){
    # RC = 0: PASS, otherwise FAIL
    if [[ -z "$1" ]] || [[ "$1" == "" ]] || [[ "${1^^}" == "NONE" ]];then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "Notification: Email receiver is missing!"
        return 1
    fi
    
    python ${cwd}/regression_notification.py -t $1
    local _ret=$?
    return $_ret                        
}

# ------------------------------------------------
#  Util functions
# ------------------------------------------------
function addPrefix() {
  if [[ "${1^^}" == "NONE" ]];then
      echo $1
      return 0
  fi
  prefix=$2
  IFS=',' read -r -a myarray <<< `echo "$1" | sed -r 's/^"|"$//g'`
  for i in "${!myarray[@]}";do
      myarray[$i]=${prefix}${myarray[$i]}
  done
  echo $( IFS=$','; echo "${myarray[*]}" )
}

# Statistics
PASS=0
FAIL=0
TOTAL=0

# ------------------------------------------------
# Directory Structure:
# regression
#   |-- regression_wrapper.sh
#   |-- regression_dependency.csv
#   |-- regression_*.py
#   |-- input
#   |-- output
#   |-- logs
# 
# Regression dependency CSV File Format:
# JobClassName, SourceKafkaQueue, "List<TargetKafkaQueues>",JobClassName_InputKafkaMsgFile.json,"List<TargetPgTables>","List<PG_Table_Col_Filter>"
#


# Start Test Suite
printf "\n"
printf "%s\n"  "------------------------------------------------------------------------------------"

# ================================================
# read test plan and store in an array
# ================================================
IFS=$'\n' read -d '' -r -a tc_lines <${PATH_DEP_CSV}
printf "\n"

function run_all(){
    tc=$1	
    TC_ID="$(awk -vFPAT='([^,]*)|("[^"]+")' -vOFS=, '{print $1}' <<<${tc})"
    SPARK_CLS_NAME="$(awk -vFPAT='([^,]*)|("[^"]+")' -vOFS=, '{print $2}' <<<${tc})"		
	printf "%s\t%s\t%-60s%s\t\n"  "[${yel}INFO${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME}" "| ${yel}Scheduled${yel} |"		
    
	# Run all or ad-hoc
    if [[ $CLS_NAME != "ALL" ]] && [[ ! " ${CLS_NAME_LIST[@]} " =~ " ${SPARK_CLS_NAME} " ]]; then
        printf "%s\t%s\t%s\n" "[${red}ERROR${end}]" $TS_FORMAT: "'$SPARK_CLS_NAME' does not match the given list [$( IFS=$','; echo "${CLS_NAME_LIST[*]}" )]!"
        continue
    fi

    ((TOTAL+=1))
    SRC_KAF_TOPICS="$(awk -vFPAT='([^,]*)|("[^"]+")' -vOFS=, '{print $3}' <<<${tc})"
    TGT_KAF_TOPICS="$(awk -vFPAT='([^,]*)|("[^"]+")' -vOFS=, '{print $4}' <<<${tc})"
    # add prefix
    prefix=${TC_ID}.${USER}.
    SRC_KAF_TOPICS=$(addPrefix $SRC_KAF_TOPICS $prefix)
    TGT_KAF_TOPICS=$(addPrefix $TGT_KAF_TOPICS $prefix)
    KAF_FLTR="$(awk -vFPAT='([^,]*)|("[^"]+")' -vOFS=, '{print $5}' <<<${tc})"
    TC_INPUT="$(awk -vFPAT='([^,]*)|("[^"]+")' -vOFS=, '{print $6}' <<<${tc})"
    PG_TBLS="$(awk -vFPAT='([^,]*)|("[^"]+")' -vOFS=, '{print $7}' <<<${tc})"
    PG_FLTR="$(awk -vFPAT='([^,]*)|("[^"]+")' -vOFS=, '{print $8}' <<<${tc})"
    TC_OUTPUT_EXPECT="${SPARK_CLS_NAME}_Expect.json"
    TC_OUTPUT_ACTUAL="${SPARK_CLS_NAME}_Actual.json"
	SPARK_CLS_NAME=$TC_ID:$SPARK_CLS_NAME
	
	# define log file
    LOGFILE=${LOG_PATH}/regression_test_${TC_ID}_`date +%Y_%m_%d_%H_%M_%S`.log
    touch ${LOGFILE}
    chmod 777 ${LOGFILE}
	
    echo TC_ID=$TC_ID                           >> $LOGFILE  2>&1
    echo SPARK_CLS_NAME=$SPARK_CLS_NAME         >> $LOGFILE  2>&1
    echo SRC_KAF_TOPICS=$SRC_KAF_TOPICS         >> $LOGFILE  2>&1
    echo TGT_KAF_TOPICS=$TGT_KAF_TOPICS         >> $LOGFILE  2>&1
    echo KAF_FLTR=$KAF_FLTR                     >> $LOGFILE  2>&1
    echo TC_INPUT=$TC_INPUT                     >> $LOGFILE  2>&1
    echo TC_OUTPUT_EXPECT=$TC_OUTPUT_EXPECT     >> $LOGFILE  2>&1
    echo TC_OUTPUT_ACTUAL=$TC_OUTPUT_ACTUAL     >> $LOGFILE  2>&1
    echo PG_TBLS=$PG_TBLS                       >> $LOGFILE  2>&1
    echo PG_FLTR=$PG_FLTR                       >> $LOGFILE  2>&1
    #echo REG_LOG=$REG_LOG                      >> $LOGFILE  2>&1
    #echo REG_SCRATCH_DIR=$REG_SCRATCH_DIR      >> $LOGFILE  2>&1
    #echo REG_CHKPT_DIR=$REG_CHKPT_DIR          >> $LOGFILE  2>&1
    #echo REG_REFERENCE_DATA_DIR=$REG_REFERENCE_DATA_DIR  >> $LOGFILE  2>&1
    # Note: SRC_KAF_TOPICS cannot be empty

#   Step 1
    if [[ -z "$TGT_KAF_TOPICS" ]] || [[ "$TGT_KAF_TOPICS" == "" ]] || [[ "${TGT_KAF_TOPICS^^}" == "NONE" ]];then
        KAF_TOPICS=$SRC_KAF_TOPICS
    else
        KAF_TOPICS=$SRC_KAF_TOPICS,$TGT_KAF_TOPICS
    fi    
    prepare $SPARK_CLS_NAME $KAF_TOPICS $PG_TBLS >> $LOGFILE 2>&1
    RC=$?
    if test $RC != 0;then
        ((FAIL+=1))
        printf "%s\t%s\t%-60s%s\t\n"  "[${red}ERROR${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - Prepare" "| ${red}FAIL${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
		if [ "$CLEAN_UP" != "-k" ];then
            clean_up $SPARK_CLS_NAME $KAF_TOPICS $PG_TBLS >> $LOGFILE 2>&1
	    else
		    echo "Error: Test case $TC_ID is failed." >> $LOGFILE 2>&1 
			echo "To clean up the test environment, use command:" >> $LOGFILE 2>&1
			echo "spark-submit ${cwd}/regression_cleanUp.py -c $SPARK_CLS_NAME -s $PG_TBLS" >> $LOGFILE 2>&1
		fi
        continue
    else
        printf "%s\t%s\t%-60s%s\t\n"  "[${yel}INFO${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - Prepare" "| ${grn}PASS${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
    fi

#   Step 2
	load_input $SPARK_CLS_NAME $SRC_KAF_TOPICS ${PATH_INPUT}/${TC_INPUT}  >> $LOGFILE 2>&1
    RC=$?
    if test $RC != 0;then
        ((FAIL+=1))
        printf "%s\t%s\t%-60s%s\t\n"  "[${red}ERROR${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - LoadInput" "| ${red}FAIL${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
        if [ "$CLEAN_UP" != "-k" ];then
            clean_up $SPARK_CLS_NAME $KAF_TOPICS $PG_TBLS >> $LOGFILE 2>&1
	    else
		    echo "Error: Test case $TC_ID is failed." >> $LOGFILE 2>&1 
			echo "To clean up the test environment, use command:" >> $LOGFILE 2>&1
			echo "spark-submit ${cwd}/regression_cleanUp.py -c $SPARK_CLS_NAME -s $PG_TBLS" >> $LOGFILE 2>&1
		fi
        continue
    else
        printf "%s\t%s\t%-60s%s\t\n"  "[${yel}INFO${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - LoadInput" "| ${grn}PASS${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
    fi

#   Step 3    
    run_spark $SPARK_CLS_NAME >> $LOGFILE 2>&1
    RC=$?
    if test $RC != 0;then
        ((FAIL+=1))
        printf "%s\t%s\t%-60s%s\t\n"  "[${red}ERROR${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - Run     " "| ${red}FAIL${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
        if [ "$CLEAN_UP" != "-k" ];then
            clean_up $SPARK_CLS_NAME $KAF_TOPICS $PG_TBLS >> $LOGFILE 2>&1
	    else
		    echo "Error: Test case $TC_ID is failed." >> $LOGFILE 2>&1 
			echo "To clean up the test environment, use command:" >> $LOGFILE 2>&1
			echo "spark-submit ${cwd}/regression_cleanUp.py -c $SPARK_CLS_NAME -s $PG_TBLS" >> $LOGFILE 2>&1
		fi
        continue
    else
        printf "%s\t%s\t%-60s%s\t\n"  "[${yel}INFO${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - Run      " "| ${grn}PASS${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
    fi
    
    
#   Step 4 
    if [[ -z "$TGT_KAF_TOPICS" ]] || [[ "$TGT_KAF_TOPICS" == "" ]] || [[ "${TGT_KAF_TOPICS^^}" == "NONE" ]];then
        TGT_KAF_TOPICS='NONE'
    fi
    if [[ -z "$PG_TBLS" ]] || [[ "$PG_TBLS" == "" ]] || [[ "${PG_TBLS^^}" == "NONE" ]];then
        PG_TBLS='NONE'
    fi
    if [[ -z "$PG_FLTR" ]] || [[ "$PG_FLTR" == "" ]] || [[ "${PG_FLTR^^}" == "NONE" ]];then
        PG_FLTR='NONE'
    fi
    if [[ -z "$KAF_FLTR" ]] || [[ "$KAF_FLTR" == "" ]] || [[ "${KAF_FLTR^^}" == "NONE" ]];then
        KAF_FLTR='NONE'
    fi
    load_output $SPARK_CLS_NAME $TGT_KAF_TOPICS ${PATH_OUTPUT}/${TC_OUTPUT_ACTUAL} $PG_TBLS $PG_FLTR $KAF_FLTR >> $LOGFILE 2>&1
    RC=$?
    if test $RC != 0;then
        ((FAIL+=1))
        printf "%s\t%s\t%-60s%s\t\n"  "[${red}ERROR${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - LoadOutput" "| ${red}FAIL${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
        if [ "$CLEAN_UP" != "-k" ];then
            clean_up $SPARK_CLS_NAME $KAF_TOPICS $PG_TBLS >> $LOGFILE 2>&1
	    else
		    echo "Error: Test case $TC_ID is failed." >> $LOGFILE 2>&1 
			echo "To clean up the test environment, use command:" >> $LOGFILE 2>&1
			echo "spark-submit ${cwd}/regression_cleanUp.py -c $SPARK_CLS_NAME -s $PG_TBLS" >> $LOGFILE 2>&1
		fi
        continue
    else
        printf "%s\t%s\t%-60s%s\t\n"  "[${yel}INFO${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - LoadOutput" "| ${grn}PASS${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
    fi

#   Step 5
    if [[ -z "$PG_FLTR" ]] || [[ "$PG_FLTR" == "" ]] || [[ "${PG_FLTR^^}" == "NONE" ]];then
        PG_FLTR='NONE'
    fi
    if [[ -z "$KAF_FLTR" ]] || [[ "$KAF_FLTR" == "" ]] || [[ "${KAF_FLTR^^}" == "NONE" ]];then
        KAF_FLTR='NONE'
    fi
    Compare $SPARK_CLS_NAME ${PATH_OUTPUT}/${TC_OUTPUT_EXPECT} ${PATH_OUTPUT}/${TC_OUTPUT_ACTUAL} $PG_FLTR $KAF_FLTR >> $LOGFILE 2>&1
    RC=$?
    if test $RC != 0;then
        ((FAIL+=1))
        printf "%s\t%s\t%-60s%s\t\n"  "[${red}ERROR${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - Compare" "| ${red}FAIL${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
        if [ "$CLEAN_UP" != "-k" ];then
            clean_up $SPARK_CLS_NAME $KAF_TOPICS $PG_TBLS >> $LOGFILE 2>&1
	    else
		    echo "Error: Test case $TC_ID is failed." >> $LOGFILE 2>&1 
			echo "To clean up the test environment, use command:" >> $LOGFILE 2>&1
			echo "spark-submit ${cwd}/regression_cleanUp.py -c $SPARK_CLS_NAME -s $PG_TBLS" >> $LOGFILE 2>&1
		fi
        continue
    else
        printf "%s\t%s\t%-60s%s\t\n"  "[${yel}INFO${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - Compare" "| ${grn}PASS${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
    fi
    
#   Step 6    
    # clean up the test environment
    clean_up $SPARK_CLS_NAME $KAF_TOPICS $PG_TBLS >> $LOGFILE 2>&1
    RC=$?
    if test $RC != 0;then
        ((FAIL+=1))
        printf "%s\t%s\t%-60s%s\t\n"  "[${red}ERROR${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - CleanUp" "| ${red}FAIL${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
        continue
    else
        printf "%s\t%s\t%-60s%s\t\n"  "[${yel}INFO${end}]" $TS_FORMAT: "Test Case: ${SPARK_CLS_NAME} - CleanUp" "| ${grn}PASS${end} |"
        printf "%s\n"  ------------------------------------------------------------------------------------
    fi

}
	
pid_idx=0
ppid=$$  # parent PID
for tc_line in "${tc_lines[@]}"
do
    case "$tc_line" in \#*) continue ;; esac
    # Run in parallel
    ((i=i%JOB_NR)); ((i++==0)) && wait
    run_all $tc_line &
	pids[$((pid_idx++))]=$!  # store the PID of each bg job
done

# wait for all pids
for pid in "${pids[@]}"; do
    pArray=$( pgrep -P $ppid)
	if [[ ${pArray[*]} =~ ${pid} ]]; then
        wait $pid
    fi
done

# send report by email
# return non-zero if at least one TC fails
notification $TARGET_EMAILS_LIST
RC=$?
exit $RC
