#!/opt/python3/bin/python
# coding: utf-8

'''
  Author  :        Jun Dai (189485)
  Desc    :        auxiliary functions 
'''

import sqlite3
import logging

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def getDBConn(db_path=r"output/test_result.db"):
    try:
        sqliteConnection = sqlite3.connect(db_path)
        return sqliteConnection
    except sqlite3.Error as error:
        logging.error("Error while working with SQLite", error)
 
            
def createTestResultTable():
    try:
        sqliteConnection = getDBConn()
        cursor = sqliteConnection.cursor()
        logging.debug("Connected to SQLite")

        sqlite_create_table_query = '''CREATE TABLE IF NOT EXISTS test_result
             (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
             kw_id text,
             prepare int,
             loadInput int,
             sparkRun int,
             loadOutput int,
             test_count int,
             test_schema int,
             test_value int,
             cleanUp int,
             expect_value text,
             actual_value text,
             exec_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL);'''

        cursor = sqliteConnection.cursor()
        cursor.execute(sqlite_create_table_query)
        sqliteConnection.commit()
        cursor.close()

    except sqlite3.Error as error:
        logging.error("Error while working with SQLite", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            logging.debug("sqlite connection is closed")
 
def addTestResultRow(**kwargs):
    try:
        sqliteConnection = getDBConn()
        cursor = sqliteConnection.cursor()
        logging.debug("Connected to SQLite")        
        
        if 'kw_id' in kwargs:
            kw_id = kwargs['kw_id']
        else:
            logging.error("Error to get the kw_id")
            exit(RC_ERROR)
            
        data_tuple = (kw_id,0,0,0,0,0,0,0,0,'','')               
        cursor.execute("SELECT * FROM test_result WHERE kw_id = ?", (kw_id,)) 
        data=cursor.fetchone()
        if data is None:
            sqlite_stmt = """INSERT INTO 'test_result' ('kw_id','prepare','loadInput','sparkRun','loadOutput','test_count','test_schema','test_value','cleanUp','expect_value','actual_value') VALUES (?,?,?,?,?,?,?,?,?,?,?);"""
            logging.debug(sqlite_stmt)
            cursor.execute(sqlite_stmt, data_tuple)
        
        # update the table
        kwargs.pop('kw_id')
        data_dict = kwargs
        for key in data_dict:
            sqlite_stmt = """UPDATE 'test_result'
                          SET {} = {} where kw_id = '{}'""".format(key,data_dict[key],kw_id)

            logging.debug(sqlite_stmt)
            cursor.execute(sqlite_stmt)
       
        sqliteConnection.commit()
        logging.info('Test result is saved to test result database.')
        cursor.close()

    except sqlite3.Error as error:
        logging.error("Error while working with SQLite", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            logging.debug("sqlite connection is closed")

def udf_exit(exit_code,**kwargs):
    keyw_id = kwargs['kw_id']
    kwargs.pop('kw_id')
    for k,v in kwargs.items():
        addTestResultRow(**{k:v},kw_id=keyw_id)
    exit(exit_code)

# recursive deletion of dict keys
def rmDictKey(obj,toFilter):
    if isinstance(obj, list):
        for i in reversed(range(len(list(obj)))):
            rmDictKey(obj[i],toFilter)           
    if isinstance(obj, dict):
        # copy(): avoid runtime error - dict changed size
        for k, v in obj.copy().items():
            if isinstance(v, dict) or isinstance(v, list):
                rmDictKey(v,toFilter)
            else:  
                if toFilter and k.upper() in [ x.upper() for x in toFilter if x]:
                    del obj[k]
                    logging.debug("dict key: '{}' is deleted.".format(k))

