#!/usr/bin/bash
# "**********************************************************************************"
# Created        : 2020-08-07
# Author         : Brendan.McGarry@cn.ca
# Preconditions  : Provide the environment variables:
#                      - TM_ARCHIVING_RAW_PATH
#                      - SPARK_LOG
# Usage          : ./run_compress_archive.sh
# Description    : Will run the pyspark script to move and compress the data in
#                  new_data/ for each kafka topic partition for every process_date
#                  older than today.
# Result         : <path>/new_data/topic=<topic_name>/process_date=<process_date>
#                      will become
#                  <path>/historical_data/topic=<topic_name>/process_date=<process_date>
#                      if <process_date> is older than today's date.
# "**********************************************************************************"

# add Python3 path
export PATH=/opt/python3/bin:$PATH
export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client

# compress and archive $TM_ARCHIVING_RAW_PATH/new_data into $TM_ARCHIVING_RAW_PATH/historical_data
spark-submit compress_archive.py -p "$TM_ARCHIVING_RAW_PATH" -x "$HDFS_NAMENODE" >> ${SPARK_LOG}/${USER}_tm_compress_archive_`date "+%Y_%m_%d_%H_%M_%S"`.txt 2>&1
