#!/usr/bin/env python

"""
  Author:      Brendan.McGarry@cn.ca
  Date:        2020-04-18
  Description: Compresses all of the files within a 
  Usage:       spark-submit compress_archive.py -p <path>
"""

from __future__ import print_function

import argparse
import os
import datetime
from pyspark import SparkContext


sc = SparkContext("local")

def main():
    args = get_args()
    compress_path = args.path
    hadoop_prefix = args.hadoop_prefix

    hdfs_conn = HDFS(sc, hadoop_prefix)
    forall_topics(compress_path, hdfs_conn)


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', action='store', dest='path',
                        help="The HDFS path containing partitions with files to compress", required=True)
    parser.add_argument('-x', action='store', dest='hadoop_prefix',
                        help="The HDFS server prefix", default='hdfs://hubdevnn')
    args = parser.parse_args()
    return args


def forall_topics(path, hdfs_conn):
    new_data_path = os.path.join(path, 'new_data')
    topic_dirs = hdfs_conn.ls(new_data_path)
    for topic_dir in topic_dirs:
        historical_topic_dir = topic_dir.replace('/new_data/', '/historical_data/')
        compress_copy_dir(topic_dir, historical_topic_dir, hdfs_conn)


def compress_dir(path, hdfs_conn):
    partitions = hdfs_conn.ls(path)
    for partition in partitions:
        hdfs_files = hdfs_conn.ls(partition)
        for hdfs_file in hdfs_files:
            hdfs_conn.atomic_compress(hdfs_file)


def compress_copy_dir(path, dest_path, hdfs_conn):
    partitions = hdfs_conn.ls(path)
    for partition in partitions:
        if filter_compress_dirs(partition):
            sub_path = '/'.join(partition.split('/')[-1:])
            partition_dest = os.path.join(dest_path, sub_path)
            print('Copying ' + partition + ' to ' + partition_dest)
            hdfs_conn.copy_compress(partition, partition_dest)


def filter_compress_dirs(path, date_partition='date='):
    # if the partition date is older than today's date
    if not date_partition in path:
        return False
        
    now = datetime.datetime.now()
    year, month, day = now.year, now.month, now.day
    today = datetime.datetime(year, month, day)
    
    date_path_part = [part for part in path.split('/') if date_partition in part][0]
    p_year, p_month, p_day = [int(p) for p in date_path_part.split('=')[1].split('-')]
    partition_date = datetime.datetime(p_year, p_month, p_day)
    
    return partition_date < today


class HDFS:
    def __init__(self, spark_context, hadoop_prefix=None):
        if not isinstance(spark_context, SparkContext):
            raise ValueError("Class HDFS must be initialized with a valid SparkContext object.")
            
        self.sc         = spark_context
        self.URI        = spark_context._gateway.jvm.java.net.URI
        self.Path       = spark_context._gateway.jvm.org.apache.hadoop.fs.Path
        self.FileSystem = spark_context._gateway.jvm.org.apache.hadoop.fs.FileSystem
        
        if hadoop_prefix is not None:
            self.set_hadoop_prefix(hadoop_prefix)
            
    def set_hadoop_prefix(self, hadoop_prefix):
        self.hadoop_prefix = hadoop_prefix
        self.fs = self.FileSystem.get(self.URI(hadoop_prefix), self.sc._jsc.hadoopConfiguration())
        
    def ls(self, pathname):
        return [str(p.getPath()).replace(self.hadoop_prefix, '') for p in self.fs.listStatus(self.Path(pathname))]
        
    def rename(self, src, dest):
        return self.fs.rename(self.Path(src), self.Path(dest))
        
    def delete(self, pathname, recursive=False):
        return self.fs.delete(self.Path(pathname), recursive)
        
    def atomic_compress(self, filepath):
        basename = os.path.basename(filepath)
        dirname = os.path.dirname(filepath)
        tmpname = os.path.join(dirname, "tmp_" + basename)
        try:
            print('Performing hdfs_atomic_compress for ' + filepath)
            sf = self.sc.textFile(filepath)
            # save the compressed version as tmp_filename
            sf.saveAsTextFile(tmpname,
                compressionCodecClass="org.apache.hadoop.io.compress.GzipCodec")
            
            # delete the original and rename the new file to the original name
            self.delete(filepath, True)
            self.rename(tmpname, filepath)
            
        except Exception as e:
            print('Exception: Failure to do atomic compress:')
            print(e)
            self.delete(tmpname, True)
            return False
            
        return True
        
    def copy_compress(self, source_path, target_path, delete_orig=True):
        try:
            sf = self.sc.textFile(source_path)
            # save the compression version to target_path
            sf.saveAsTextFile(target_path, compressionCodecClass="org.apache.hadoop.io.compress.GzipCodec")
            
            if delete_orig:
                self.delete(source_path, True)
                
        except Exception as e:
            print('Exception: Failure to do copy compress:')
            print(e)
            try:
                self.delete(target_path, True)
            except Exception as e2:
                print('Failed to clean up while handling exception:')
                print(e2)
            return False
            
        return True


if __name__ == "__main__":
    main()


