#!/usr/bin/bash

# "**********************************************************************************"
# Usage          : ./hdfs_archive.sh <target directory> [sub_dir=new_data
#                  [archive_dir=historical_data]]
# Preconditions  : The format of <target directory> is "path/<sub_dir>/<partitions>"
#                  The user:
#                      - has access to the executables "hdfs dfs" and "hadoop archive"
#                      - initd its Kerberos authentication e.g. via keytab with kinit
#                      - has write authorization for the target dir
# Author         : brendan.mcgarry@cn.ca
# Date           : 2019-12-13
# "**********************************************************************************"

# script argument handling
target_dirname=${1}
sub_dir=${2:-new_data}  # default value: "new_data"
archive_dir=${3:-historical_data}  # default value: "historical_data"

orig_IFS="$IFS"
IFS=$'\n'

hdfs_lines=$(hdfs dfs -ls ${target_dirname}/*/* | tail -n +2 | grep -v "^Found ")

is_today() {
    partition_date="$1"
    
    # put current date as yyyymmdd
    printf -v date '%(%Y%m%d)T' -1
    
    if [ "$partition_date" == "$date" ]
    then
        return 0  # true
    fi
    
    return 1  # false
}

for line in ${hdfs_lines[@]}
do
    curr_path=$(awk '{print $NF}' <(echo "${line}"))  # full HDFS path
    table_path=$(dirname $(dirname "$curr_path"))
    
    # the name of the Hive table in HDFS
    tablename_dir=$(basename $(dirname $(dirname "$curr_path")))
    retention_dir=$(basename $(dirname "$curr_path"))
    partition_dir=$(basename "$curr_path")
    partition_date=$(awk -F "=" '{printf $NF}' <(echo "$partition_dir"))
    
    # if this option is a directory with the correct name
    if [ "${line:0:1}" == "d" ] \
        && [ "${retention_dir:0:${#sub_dir}}" == "${sub_dir}" ] \
        && [[ "$partition_date" =~ ^[0-9]{8}$ ]]
    then
        if is_today "$partition_date"
        then
            continue  # don't archive data for today
        fi
        
        # drop root slash to accomodate -p flag of the hadoop archive command
        curr_path_relative=${curr_path:1:$((${#curr_path} - 1))}
        target_historical_path="$table_path"/"$archive_dir"/"$partition_dir"
        
        hadoop archive -archiveName archive.har -p / "$curr_path_relative" "$target_historical_path"
        archiving_success=$?
        
        if [ $archiving_success ]
        then
            echo "Successfully archived $curr_path to $target_historical_path"
            hdfs dfs -rm -r -f "$curr_path"
        else
            echo "Failed to archive $curr_path"
        fi
    fi
done
