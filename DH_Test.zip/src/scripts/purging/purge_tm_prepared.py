#!/usr/bin/env python
# coding: utf-8

'''
  Usage   :        Use the script to execute stored procedure and perform vacuum on tables
                   spark-submit purge_tm_prepared.py --procName dbo_prc_dh_car_station_evt --chunkSize 1000000 --schemaName tm_prepared --tableName dbo_dh_car_station_evt
  Author  :        Vijay Dubey (xt26727)
  Created :        2019-12-11
  Changed :        Uma/Yonghua
  Last Changed :   2019-12-17 by Vijay Dubey
'''

import psycopg2
import collections
import pandas as pd
from datetime import datetime
import argparse
import os,sys,getopt
import psycopg2.extensions


# java keystore
# cmd to create jceks:    "hadoop credential create postgres.password.alias -provider jceks:/path/to/postgres.password.jceks"
# jks_path = "jceks://path/to/postgres.password.jceks"
# alias_name = "postgres.password.alias"

user_name = os.environ["PG_USER"]
pgsql_conn_str = os.environ["PG_CONN_URL"]
jks_path = os.environ["PG_PWD_FILE"]
alias_name = os.environ["PG_PWD_ALIAS"]
if '' in [user_name,pgsql_conn_str,jks_path,alias_name]:
    print('Error: PostgreSQL config is missing, check your ENV setting!')
    sys.exit(-1)

jks_path = r'jceks://'+jks_path
host = pgsql_conn_str.split(':')[2][2:]
port = pgsql_conn_str.split(':')[3].split('/')[0]
database = pgsql_conn_str.split(':')[3].split('/')[1]


# reading parameters
parser = argparse.ArgumentParser(description='')
parser.add_argument("--procName",  help="Procedure Name")
parser.add_argument("--chunkSize", help="Chunk Size for delete")
parser.add_argument("--tableName", help="Event table Name")
parser.add_argument("--schemaName", help="Event table Schema ame")
args = parser.parse_args()

procName = args.procName
chunkSize = args.chunkSize
tableName = args.tableName
schemaName = args.schemaName


# to retrieve the passwd from jave keystore
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("yarn").appName(user_name+"_"+schemaName+"_Purge_"+tableName).getOrCreate()

x = spark.sparkContext._jsc.hadoopConfiguration()
x.set("hadoop.security.credential.provider.path", jks_path)
a = x.getPassword(alias_name)

passwd = ""
for i in range(a.__len__()):
    passwd = passwd + str(a.__getitem__(i))

# function to execute stored procedure and perform vacuum on table
def execute_sql_stmt(conn,procName,tableName,schemaName):
    #opening cursor connection
    conn.autocommit = True
    cur = conn.cursor()

    try:
        print("Starting the execution for procedure:- "+procName)
        cur.execute('CALL '+schemaName+'.'+procName+'('+chunkSize+')'+';')

        print("Starting the vacuum")
        #setting the isolation level to autocommit for performing vacuum
        #conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
        cur.execute('VACUUM '+schemaName+'.'+tableName)

        print("Task completed Successfully")
    except Exception as e:
        print(e)
    finally:
        #conn.commit()
        conn.close()


if __name__ == '__main__':

    # connect to PostgreSQL DB
    print("Getting Connection")
    conn = psycopg2.connect(database=database, user=user_name, password=passwd, host=host, port=port)
    print("{0} INFO: Connected to: {1}/{2}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), host,database))


   # calling the execute procedure funtion
    try:
        execute_sql_stmt(conn,procName,tableName,schemaName)
    except Exception as e:
        print(e)

    if(conn):
        conn.close()
        