#!/bin/bash

# "**********************************************************************************************************************"
# Usage          : sh purge_tm_prepared.sh <id> <procName> <tableName> <schemaName> <chunkSize>
# "**********************************************************************************************************************"

export currentDirectory=`dirname $0`

# Setting kinit
export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;

USER=${1}

host=`hostname -s`
len=${#host}
env=${host:${len}-1 : 1}

# Sourcing Environment Variables from the SetEnv scripts

case ${env} in
  "d")
#         echo "Setting Environment variables for Datahub Dev env"
         kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
         klist > /dev/null 2>&1
         source ${currentDirectory}/../utilities/ENV_DEV.sh > /dev/null 2>&1
         ;;
  "p")
#         echo "Setting Environment variables for Datahub Prod env"
         kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
         klist > /dev/null 2>&1
         source ${currentDirectory}/../utilities/ENV_PROD.sh > /dev/null 2>&1
         ;;
 *)
         echo "Unknown Environment"
         exit 1
         ;;
esac

# Declaring Environment variable
export DH_ENV=${DH_ENV}
export hostEnv=`hostname`
export EMAIL_TO=${TARGET_EMAILS_LIST}

# add Python3 path
export PATH=/opt/python3/bin:$PATH
export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client

# Log file
rm ${SPARK_LOG}/purge_tm_prepared.log >/dev/null 2>&1 
LOGFILE=${SPARK_LOG}/purge_tm_prepared.log
touch ${LOGFILE}
chmod 777 ${LOGFILE}

# Initiating the Purging Script
spark-submit ${currentDirectory}/purge_tm_prepared.py --procName ${2} --tableName ${3} --schemaName ${4} --chunkSize ${5} 1> ${LOGFILE} 2>/dev/null
RC=$?

exit $RC
