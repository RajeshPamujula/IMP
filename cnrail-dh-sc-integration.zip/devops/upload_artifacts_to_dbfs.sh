#!/bin/bash

HOST=$1
TOKEN=$2
PIPELINE_WORKSPACE=$3
DBFS_LOCATION=$4
FILE_LOCATION=$5
VERSION=$6
if [[ -z $HOST || -z $TOKEN ]]
then
    echo 'The Databricks host URL and secret access token must be passed from job VM'
    exit 1
fi

#python -m pip install databricks-cli
echo $HOME
echo -e "[DEFAULT]\nhost: $HOST\ntoken: $TOKEN" > $HOME/.databrickscfg
echo -e "Testing the conncection  - removing dbfs:/scdh/deploy"
dbfs rm -r dbfs:/scdh/deploy
echo -e "Testing the conncection - create directory dbfs:/$4"
dbfs mkdirs dbfs:/scdh/deploy
echo -e "from ${FILE_LOCATION} - uploading dbfs:/"
dbfs ls
dbfs cp -r ${PIPELINE_WORKSPACE}/app/cnrail-dh-sc-integration-${VERSION}-SNAPSHOT-archive/cnrail-dh-sc-integration-${VERSION}-SNAPSHOT dbfs:/scdh/deploy
#dbfs cp -r ${PIPELINE_WORKSPACE}/app/cnrail-dh-sc-integration-1.35.0-SNAPSHOT-archive/cnrail-dh-sc-integration-1.35.0-SNAPSHOT/spark-jars/TripPlanDomainFeed dbfs:/scdh/deploy/spark-jars/TripPlanDomainFeed

