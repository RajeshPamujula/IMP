import os, uuid, sys
from azure.core._match_conditions import MatchConditions
from azure.identity import ClientSecretCredential
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, __version__
'''
#rg_name = 'TOR-DATAHUBTM-DEV-RGcode'
client_id= '05bc7696-f1d4-4535-9c46-8ca09e0fe297'
tenant_id= "fd753b92-f3b7-49fa-95cf-aed075c0f21c"
subscription_id = 'fe9234c3-74d4-416e-902d-4940ddbf29e2'
secret_key= 'mnjY4Z.V9A~U6aYgfCY.kjRs72089kl0hS'
storage_account_name= 'zcc1dhtmsta01dcode'
container_name = 'scdh'
blob_name = 'test/test2/'
path = '$(Pipeline.Workspace)/cnrail-dh-sc-integration-1.35.0-SNAPSHOT-archive/cnrail-dh-sc-integration-1.35.0-SNAPSHOT/postgresql/ref_data/'
'''
storage_account_name=sys.argv[1]
container_name=sys.argv[2]
client_id=sys.argv[3]
tenant_id=sys.argv[4]
subscription_id=sys.argv[5]
secret_key=sys.argv[6]
pipeline_workspace=sys.argv[7]
version=sys.argv[8]

path='{}/app/cnrail-dh-sc-integration-{}-SNAPSHOT-archive/cnrail-dh-sc-integration-{}-SNAPSHOT/postgresql/ref_data/'.format(pipeline_workspace,version,version)
blob_name = 'deploy/reference_data/'
#path = os.path.join(pipeline_workspace, file_path)

credentials = ClientSecretCredential(client_id=client_id, client_secret=secret_key, tenant_id=tenant_id)
ContainerClient = ContainerClient(account_url="{}://{}.blob.core.windows.net/".format("https", storage_account_name),container_name=container_name, credential=credentials)

for file in os.listdir(path):
    upload_file_path = os.path.join(path, file)
    blob = os.path.join(blob_name, file)
    #print(file)
    #print(upload_file_path)
    #print(blob) 
    Blob=BlobClient(account_url="{}://{}.blob.core.windows.net/".format("https", storage_account_name),container_name=container_name,blob_name=blob,credential=credentials)
    with open(upload_file_path, "rb") as data:
        Blob.upload_blob(data, blob_type="BlockBlob", overwrite=True)
        print(f'Upload succeeded: {file}')
    
print("\nListing blobs...")
blob_list = ContainerClient.list_blobs(name_starts_with="deploy/reference_data/")
for blob in blob_list:
    print(blob)