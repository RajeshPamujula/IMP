
# COMMAND ----------

from azure.identity import ClientSecretCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.datafactory import DataFactoryManagementClient  # v1.1.0
from azure.mgmt.datafactory.models import *
from datetime import datetime, timedelta,timezone
import time
import sys
# Parameters ----------


rg_name=sys.argv[1]
df_name=sys.argv[2]
client_id=sys.argv[3]
tenant_id=sys.argv[4]
subscription_id=sys.argv[5]
secret_key=sys.argv[6]
pipeline_namesP=sys.argv[7]
pipeline_namesI=sys.argv[8]
'''
rg_name = 'TOR-DATAHUBTM-DEV-RGcode'
df_name = 'zcc1dhtmadf01dcode'
client_id='05bc7696-f1d4-4535-9c46-8ca09e0fe297'
tenant_id= 'fd753b92-f3b7-49fa-95cf-aed075c0f21c'
subscription_id = 'fe9234c3-74d4-416e-902d-4940ddbf29e2'
pipeline_names= 'PLKSSC00_ConveyorAssociateDescribedLoad,PLKSSC00_GateEventDomainFeed'
secret_key= 'mnjY4Z.V9A~U6aYgfCY.kjRs72089kl0hS'
'''
# auth
credentials = ClientSecretCredential(client_id=client_id, client_secret=secret_key, tenant_id=tenant_id) 
resource_client = ResourceManagementClient(credentials, subscription_id)
adf_client = DataFactoryManagementClient(credentials, subscription_id)

# COMMAND ----------

# Status values: 
'''
Queued
InProgress
Succeeded
Failed
Canceling
Cancelled
'''
#https://docs.microsoft.com/en-us/azure/data-factory/monitor-programmatically#pipeline-run-information

# COMMAND ----------

# MAGIC %md
# MAGIC API doc https://azuresdkdocs.blob.core.windows.net/$web/python/azure-mgmt-datafactory/1.1.0/index.html

# COMMAND ----------

# get pipelineRuns list
start_time = datetime(2000, 1, 1, 12, 0, 0,tzinfo=timezone.utc)
end_time = datetime.now(timezone.utc)

'''
if not start_time:  
  start_time = datetime(2000, 1, 1, 12, 0, 0,tzinfo=timezone.utc)
if not end_time:
  end_time = datetime.now(timezone.utc)
'''  

# define pipeline name based filter
pl_name_list = [x.strip() for x in pipeline_namesP.split(',') if "pipeline_namesP".strip()]
if pipeline_namesI:
  pl_name_list.extend(x.strip() for x in pipeline_namesI.split(',') if "pipeline_namesI".strip())

print(pl_name_list)


filters = []
if pl_name_list:  
  filters.append(RunQueryFilter(operand='PipelineName',operator='In',values=pl_name_list))
filters.append(RunQueryFilter(operand='Status',operator='In',values=['InProgress','Queued']))
filters.append(RunQueryFilter(operand='RunEnd',operator='In',values=[None]))

plrunfilter = RunFilterParameters(last_updated_after=start_time,last_updated_before=end_time,filters=filters)
pipeline_runs = adf_client.pipeline_runs.query_by_factory(rg_name,df_name,plrunfilter)
values = pipeline_runs.value

# handle pagination response
while pipeline_runs.continuation_token :
  filter = RunFilterParameters(continuation_token=pipeline_runs.continuation_token,last_updated_after=start_time,last_updated_before=end_time,filters=filters)
  pipeline_runs = adf_client.pipeline_runs.query_by_factory(rg_name,df_name,filter)
  if pipeline_runs.value:
    values.extend(pipeline_runs.value)
    
# query result is stored in 'values'

# COMMAND ----------

'''
# An overview of fetch result
print(f"Length of values: {len(values)}")
for pl in values:
  print(pl.run_id, pl.pipeline_name, pl.status)
'''

# COMMAND ----------

# If the pipeline is still in progress, cancel the pipeline run.
success_list = []
failed_list = []
for pl in values:
  try:
    adf_client.pipeline_runs.cancel(rg_name,df_name,run_id=pl.run_id)
    success_list.append({'run_id':pl.run_id, 'pipeline_name':pl.pipeline_name, 'status':'Cancelled'})
  except:
    failed_list.append({'run_id':pl.run_id, 'pipeline_name':pl.pipeline_name, 'status':'Failed_to_cancel'})

if failed_list:
  status = False
else:
  status = True
# COMMAND ----------
input_count = len(pl_name_list)
success_count = len(success_list)
failure_count = len(failed_list)

import json
exit(json.dumps({
  "status": status,
  "input_count": input_count,
  "success_count": success_count,
  "failure_count": failure_count,
  "success_list": success_list,
  "failed_list": failed_list}))
