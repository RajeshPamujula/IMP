from azure.identity import ClientSecretCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.datafactory import DataFactoryManagementClient  # v1.1.0
from azure.mgmt.datafactory.models import *
from datetime import datetime, timedelta,timezone
import time
import sys
import json
# Parameters ----------
'''
rg_name = 'TOR-DATAHUBTM-DEV-RGcode'
df_name = 'zcc1dhtmadf01dcode'
client_id= '05bc7696-f1d4-4535-9c46-8ca09e0fe297'
tenant_id= "fd753b92-f3b7-49fa-95cf-aed075c0f21c"
subscription_id = 'fe9234c3-74d4-416e-902d-4940ddbf29e2'
pipeline_names= 'test,PLKSSC00_GateEventDomainFeed'
secret_key= 'mnjY4Z.V9A~U6aYgfCY.kjRs72089kl0hS'
'''
rg_name=sys.argv[1]
df_name=sys.argv[2]
client_id=sys.argv[3]
tenant_id=sys.argv[4]
subscription_id=sys.argv[5]
secret_key=sys.argv[6]
pipeline_namesP=sys.argv[7]
pipeline_namesI=sys.argv[8]

# auth
credentials = ClientSecretCredential(client_id=client_id, client_secret=secret_key, tenant_id=tenant_id) 
resource_client = ResourceManagementClient(credentials, subscription_id)
adf_client = DataFactoryManagementClient(credentials, subscription_id)

# COMMAND ----------

pl_name_list = [x.strip() for x in pipeline_namesP.split(',') if "pipeline_namesP".strip()]
if pipeline_namesI:
  pl_name_list.extend(x.strip() for x in pipeline_namesI.split(',') if "pipeline_namesI".strip())
print(pl_name_list)

success_list = []
failed_list = []
for pl in pl_name_list:
    try:
        run_response=adf_client.pipelines.create_run(rg_name, df_name, pl, parameters={})
        success_list.append({'pipeline_name': pl, 'status':'Succeeded'})
    except:
        failed_list.append({'pipeline_name':pl, 'status':'Failed_to_cancel'})


#Check pipeline in progress
time.sleep(30)
start_time = datetime(2000, 1, 1, 12, 0, 0,tzinfo=timezone.utc)
end_time = datetime.now(timezone.utc)

statusfilters = []
statusfilters.append(RunQueryFilter(operand='Status',operator='In',values=['InProgress']))

inprogressrunfilter = RunFilterParameters(last_updated_after=start_time,last_updated_before=end_time,filters=statusfilters)
pipeline_runs = adf_client.pipeline_runs.query_by_factory(rg_name,df_name,inprogressrunfilter)
inprogress = pipeline_runs.value

# handle pagination response
while pipeline_runs.continuation_token :
  pagingfilter = RunFilterParameters(continuation_token=pipeline_runs.continuation_token,last_updated_after=start_time,last_updated_before=end_time,filters=statusfilters)
  pipeline_runs = adf_client.pipeline_runs.query_by_factory(rg_name,df_name,pagingfilter)
  if pipeline_runs.value:
    inprogress.extend(pipeline_runs.value)
#Output

if failed_list:
  status = False
else:
  status = True

input_count = len(pl_name_list)
success_count = len(success_list)
failure_count = len(failed_list)
inprogress_count = len(inprogress)

exit(json.dumps({
  "status": status,
  "input_count": input_count,
  "success_count": success_count,
  "failure_count": failure_count,
  "inprogress_count": inprogress_count,
  "success_list": success_list,
  "failed_list": failed_list}))