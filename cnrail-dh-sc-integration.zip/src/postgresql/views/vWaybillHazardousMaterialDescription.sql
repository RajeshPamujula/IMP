DROP VIEW IF EXISTS daas_tm_trusted."vWaybillHazardousMaterialDescription" cascade;

create view daas_tm_trusted."vWaybillHazardousMaterialDescription" as 
SELECT 
a.ship_key as "shipmentKey" ,
b.id_val as "waybillIdentification",
a.data_hub_crt_ts as "dataHubCreationTimestamp",
a.haz_seq as "hazardousSequence",
ship_char1.char_val as "lastStccNumber",
ship_char2.char_val as "standardTransportationCommodityCode",
a.haz_stcc 	as "hazardousCommodityDescriptionAbbreviation",
a.inh_tox_haz_zn 	as "inhalationToxicityHazardZone",
a.pois_cd  	as "poisonCode",
pc.trsp_cd_dsc_eng as "poisonCodeEnglishDescription", 
pc.trsp_cd_dsc_fr  as "poisonCodeFrenchDescription",  
a.cdn_pois_matl_cd   as "canadianPoisonCode",  
cpc.trsp_cd_dsc_eng as "canadianPoisonCodeEnglishDescription", 
cpc.trsp_cd_dsc_fr  as "canadianPoisonCodeFrenchDescription",  
a.haz_mpc_dsc  	as "hazardousMarinePollutantCodeDescription",
a.cdn_mpc  	as "canadianMarinePollutantCode",
a.cdn_haz_mpc_dsc 	as "canadianHazardousMarinePollutantCodeDescription",
a.ram_dsc 	as "radioactiveMaterialDescription",
a.ract_curi_id    as  "radioactivityCuriesIdentifier",
a.ract_uom    as  "radioactivityUom",
a.dww_cd    as  "dangerousWhenWetCode",
a.haz_ltd_qty    as  "hazardousLimitedQuantity",
a.cdn_net_xpld    as  "canadianNetExplosive",
a.net_xpld_uom    as  "canadianNetExplosiveUom",
a.cnvy_eqp_dsc    as  "conveyorEquipmentDescription",
a.cdn_haz_xmpt_ind    as  "canadianHazardousExemptIndicator",
a.haz_matl_prof_4  as "hazardousMaterialProfileIndicator4",  
a.ship_nm    as  "shipperName",
a.ship_addr    as  "shipperAddress",
a.ship_city    as  "shipperCityName",
a.ship_st    as  "shipperProvinceState",
a.ship_zip    as  "shipperPostalCode",
a.cons_nm    as  "consigneeName",
a.cons_addr    as  "consigneeAddress",
a.cons_city    as  "consigneeCityName",
a.cons_st    as  "consigneeProvinceState",
a.cons_zip    as  "consigneePostalCode",
a.artl_qty    as  "articleQuantity",
a.pack_typ_cd    as  "packageTypeCode",
ptc.trsp_cd_dsc_eng as  "packageTypeEnglishDescription",  
ptc.trsp_cd_dsc_fr  as  "packageTypeFrenchDescription",   
a.tank_cmpt_cd    as  "tankCompartment",
a.haz_ship_vol_meas    as  "hazardShipmentVom",
a.haz_ship_cert    as  "hazardShipperCertification",
a.unit_meas_cd    as  "unitMeasurementCode",
				
a.pack_grp_cd    as  "packageGroupCode",
a.prop_nm    as  "properName",
a.cdn_spcl_cmdy_cd    as  "canadianSpecialCommodityCode",
a.cmdy_dsc_abr    as  "commodityDescriptionAbbreviation",
a.cdn_prop_nm    as  "canadianProperName",
a.haz_cmdy_clss_cd    as  "hazardousCommodityClassificationCode",
a.cdn_haz_clss_cd    as  "canadianHazardousCommodityClassificationCode",
a.cdn_sbsd_clss_cd_1    as  "canadianSubsidiaryClassificationCode1",
a.cdn_sbsd_clss_cd_2    as  "canadianSubsidiaryClassificationCode2",
a.cdn_sbsd_clss_cd_3    as  "canadianSubsidiaryClassificationCode3",
a.haz_unna_cmdy_nbr    as  "hazardousUnnaCommodityNumber",
a.cdn_haz_unna_cmdy_nbr    as  "canadianHazardousUnnaCommodityNumber",
a.cdn_sbsd_risk    as  "canadianSubsidiaryRisk",
a.trsp_indx_id    as  "transportationIndexIdentifier",
a.fsl_trsp_clss    as  "fissileTransportationClassification",
a.fsl_matl_dsc    as  "fissileMaterialDescription",
a.epa_wast_nbr	    as  "epaWasteNumber",
a.epa_wast_nbr_2	    as  "epaWasteNumber2",
a.epa_wast_nbr_3	    as  "epaWasteNumber3",
a.epa_wast_char_cd	    as  "epaWasteCharacteristicCode",
a.epa_wast_char_cd_2	    as  "epaWasteCharacteristicCode2",
a.epa_wast_char_cd_3	    as  "epaWasteCharacteristicCode3",
epa1.trsp_cd_dsc_eng  as "epaWasteCharacteristicCode1EnglishDescription",  
epa2.trsp_cd_dsc_eng  as "epaWasteCharacteristicCode2EnglishDescription",  
epa3.trsp_cd_dsc_eng  as "epaWasteCharacteristicCode3EnglishDescription",  
epa1.trsp_cd_dsc_fr   as "epaWasteCharacteristicCode1FrenchDescription",   
epa2.trsp_cd_dsc_fr   as "epaWasteCharacteristicCode2FrenchDescription",   
epa3.trsp_cd_dsc_fr   as "epaWasteCharacteristicCode3FrenchDescription",   
a.haz_cmdy_rpt_qty    as  "hazardousCommodityReportableQuantity",
a.hot_cd    as  "hotIndicator",
a.flsh_tmpr    as  "flashpointTemperature",
a.flsh_cd    as  "flashpointTemperatureUom",
a.cntl_tmpr    as  "controlTemperature",
a.cntl_emgy_cd    as  "controlTemperatureUom", 
a.emgy_tmpr    as  "emergencyTemperature",
a.cntl_emgy_cd  as  "emergencyTemperatureUom" ,  
a.els_prmt_nbr    as  "elsPermitNumber",
a.peles_exp_dt     as  "elsPermitExpirationDate",
a.dot_xmpt_nbr    as  "dotExemptionNumber",
a.dot_204_ind    as  "dot204Indicator",
a.dot_113_ind    as  "dot113Indicator",
a.class_7_nbr    as  "class7Number",
a.dot_spcl_aprv_nbr    as  "dotSpecialApproval",
a.dot_sec_haz_clss    as  "dotSecondaryHazardousClassification",
a.dot_sec_haz_clss_2    as  "dotSecondaryHazardousClassification2",
a.cdn_erap_cd    as  "canadianEmergencyResponseCode",  --cdn_emgy_rsps_cd
a.emgy_tel_nbr_1    as  "emergencyTelephoneNumber1",
a.emgy_tel_nbr_2    as  "emergencyTelephoneNumber2",
a.emgy_tel_nbr_3    as  "emergencyTelephoneNumber3",
a.emgy_cntc_nm_us    as  "emergencyContactNameUs",
a.emgy_cntc_nm    as  "emergencyContactName",
a.emgy_cntc_nm_intl    as  "emergencyContactNameInternational",
a.cdn_erap_nbr as "canadianEmergencyResponsePlanNumber",   
a.cdn_erap_tel_nbr as "canadianEmergencyResponsePlanTelephoneNumber",  
a.cdn_erap_nbr_2 as "canadianEmergencyResponsePlanNumber2",   
a.cdn_erap_tel_nbr_2 as "canadianEmergencyResponsePlanTelephoneNumber2"  

FROM daas_tm_prepared.dh_wb_haz_mat_dsc as a
inner join daas_tm_prepared.dh_ship as b on a.ship_key=b.ship_key and b.act_stus_ind=1
left join daas_tm_prepared.dh_ship_char as ship_char1 on a.ship_key=ship_char1.ship_key and ship_char1.act_stus_ind=1
and ship_char1.char_type_key='d8f5282211bd312bc615b46bc39a2221f95e1821de91e5a4c55a451258fd5aff'  -- Last STCC Number
left join daas_tm_prepared.dh_ship_char as ship_char2 on a.ship_key=ship_char2.ship_key and ship_char2.act_stus_ind=1
and ship_char2.char_type_key='897396de662fb7e14d0996db576e4a27eda9cb72f6db19414204cda5ab9bf3bd'  -- Standard Transportation Commodity Code

--lookup poisonCode
left join daas_tm_prepared.dh_trsp_cd_ref pc on a.pois_cd = pc.trsp_cd and pc.act_stus_ind=1 and pc.trsp_cd_type='Poisons Material Indicator Code'
--lookip canadianPoisonCode
left join daas_tm_prepared.dh_trsp_cd_ref cpc on a.cdn_pois_matl_cd = cpc.trsp_cd and cpc.act_stus_ind=1 and cpc.trsp_cd_type='Canadian Poisons Material Indicator Code'
--lookup packageTypeCode 
left join daas_tm_prepared.dh_trsp_cd_ref ptc on a.pack_typ_cd = ptc.trsp_cd and ptc.act_stus_ind=1 and ptc.trsp_cd_type='Package Type Code'
--lookup epaWasteCharacteristicCode 
left join daas_tm_prepared.dh_trsp_cd_ref epa1 on a.epa_wast_char_cd   = epa1.trsp_cd and epa1.act_stus_ind=1 and epa1.trsp_cd_type='EPA Waste Characteristics Code'
left join daas_tm_prepared.dh_trsp_cd_ref epa2 on a.epa_wast_char_cd_2 = epa2.trsp_cd and epa2.act_stus_ind=1 and epa2.trsp_cd_type='EPA Waste Characteristics Code'
left join daas_tm_prepared.dh_trsp_cd_ref epa3 on a.epa_wast_char_cd_3 = epa3.trsp_cd and epa3.act_stus_ind=1 and epa3.trsp_cd_type='EPA Waste Characteristics Code'
where a.act_stus_ind=1
;

