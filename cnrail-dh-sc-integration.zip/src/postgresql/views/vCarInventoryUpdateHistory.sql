DROP VIEW IF EXISTS daas_tm_trusted."vCarInventoryUpdateHistory" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vCarInventoryUpdateHistory"
AS
SELECT 
 te.data_hub_crt_ts AS "dataHubCreationTimestamp"
, cnvy.id_val AS "railcarId"
, cast(cc1.char_val as varchar(4)) AS "equipmentInitial"
, cast(cc2.char_val as varchar(10)) AS "equipmentNumber"
, cast('NA' as bytea)  AS "transportationEventKey"
, te.rpt_sor_proc_ts as "transportationProcessTimestamp"
, cast('NA' as bytea) as "transportationEventAssociateKey"
, COALESCE(SUBSTRING(tec.event, 1, 2), '') AS "eventCode"
, COALESCE(SUBSTRING(tec.event, 3, 2), '') AS "eventStatusCode"
, COALESCE(CONCAT(tec.Event_Date, ' ', tec.Event_Time), '') AS "eventTimestamp"
, COALESCE(SUBSTRING(a."event", 1, 2), '') AS "previousEventCode"  
, COALESCE(SUBSTRING(a."event", 3, 2), '') AS "previousEventStatusCode"  
, COALESCE(CONCAT(a."eventDate", ' ', a."eventTime"), '')  as "previousEventTimestamp"

, stn."scac"
, stn."fsac"

, cast('NA' as bytea) as "conveyorKey"
, 'NA'  as "conveyorConditionProcessTimestamp"
, 'NA' as "conveyorCharacterProcessTimestamp"
, 'NA' as "conveyorProcessTimestamp"
, teac.Track_Number AS "trackNumber" 
, COALESCE(b."trackNumber", '') AS "previousTrackNumber"
, teac.Current_Spot AS "currentSpot"
, teac.Track_Sequence_Number  AS "trackSequenceNumber"

, COALESCE(b."trackSequenceNumber", '') AS "previousTrackSequenceNumber" 
, 'NA' AS "currentAssignment"
, 'NA' AS "loadEmptyStatusCode"  
, ccond."carLocationCode"
, ccond."operatingZoneTrackSpot" AS "opZts"
, ccond."badOrderCode"

, ccond."mechanicalStatusCode1"
, ccond."mechanicalStatusCode2"
, ccond."mechanicalStatusCode3"
, COALESCE(c."mechanicalStatusCode1", '') AS "previousMechanicalStatusCode1"
, COALESCE(c."mechanicalStatusCode2", '') AS "previousMechanicalStatusCode2"
, COALESCE(c."mechanicalStatusCode3", '') AS "previousMechanicalStatusCode3"
, ccond."customerCarOrderNumber" 
, COALESCE(c."customerCarOrderNumber", '') AS "previousCustomerCarOrderNumber" 
, ccond."yardBlock"
, cc.CN_Pool_Id AS "cnPoolId"    
, 'NA' AS "previousCNPoolID" 
, cc.Car_Kind AS "carKind"
, ccond."customerSwitchCode"
--, sa.ship_key
, 'NA' as "shipmentConditionProcessTimestamp"
, 'NA' AS "specialConditionCode1"
, 'NA' AS "specialConditionCode2"
, 'NA' AS "specialConditionCode3"
, 'NA' AS "specialConditionCode4"
, 'NA' AS "specialConditionCode5"
, 'NA' AS "specialConditionCode6"
, 'NA' AS "previousSpecialConditionCode1"
, 'NA' AS "previousSpecialConditionCode2"
, 'NA' AS "previousSpecialConditionCode3"
, 'NA' AS "previousSpecialConditionCode4"
, 'NA' AS "previousSpecialConditionCode5"
, 'NA' AS "previousSpecialConditionCode6"
FROM daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_char cc1 on cc1.cnvy_key=cnvy.cnvy_key and cc1.act_stus_ind=1 
and cc1.char_type_key='53223cc5252d3111a784717f660a45a277a813430ed44561fc46bd7028fc6836'  --Equipment Initial
inner join daas_tm_prepared.dh_cnvy_char cc2 on cc2.cnvy_key=cnvy.cnvy_key and cc2.act_stus_ind=1 
and cc2.char_type_key='4b784c8ef416376b15dcc4a491e6fefe7f994d1da63a1729d18e793799de3b86'  --Equipment Number
INNER JOIN daas_tm_prepared.dh_trsp_evt te ON te.act_stus_ind = 1 AND cnvy.cnvy_key = te.trsp_evt_key AND te.trsp_evt_type_key = '\x66366235333062306561303063323737343735343365623935306438313465623061656463653265646664633561633439333133323936666232323338663032' -- Railcar Event
LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_char_equipment_by_trsp_evt_key (te.trsp_evt_key) AS tec on true 

LEFT JOIN daas_tm_prepared.dh_ship_asct sa ON sa.act_stus_ind = 1 AND sa.asct_obj_key = cnvy.cnvy_key
--LEFT JOIN daas_tm_prepared.dh_ship_asct_char sac1 ON sac1.act_stus_ind = 1 AND sa.asct_key = sac1.asct_key AND sac1.char_type_key = '\x30363333363733303538363532376533316435663966313238373164353035333634343537353930393736666338336433323635316130363836396433616131' -- Current Assignment
--LEFT JOIN daas_tm_prepared.dh_ship_char sc1 ON sc1.act_stus_ind = 1 AND sc1.ship_key = sa.ship_key AND sc1.char_type_key = '\x32356230383237303063366131346564653864333637656165303936643465336130653063626434613964666565653635323634353935383833346139313263' -- Load Empty Status Code

LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key(cnvy.cnvy_key) ccond on true 

LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON 
--tea.act_stus_ind = 1 AND 
tea.trsp_evt_key = cnvy.cnvy_key 
LEFT JOIN daas_tm_prepared.dh_rail_station stn ON (stn.stn_333_key = tea.asct_obj_key or stn.stn_333_cn_key = tea.asct_obj_key  or stn.stn_333_cn_key_conv = tea.asct_obj_key)

LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_asct_char_equipment_by_asct_key(tea.asct_key ) AS teac ON TRUE 

LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key(cnvy.cnvy_key) AS cc on true -- revert logic

--LEFT JOIN daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(sa.ship_key) as scond on true 

left join daas_tm_trusted.f_get_dh_trsp_evt_char_domn_evt_by_car_trsp_key( te.trsp_evt_key,te.rpt_sor_proc_ts)  as a on true 
left join daas_tm_trusted.f_get_dh_trsp_evt_asct_char_domn_evt_by_car_trsp_key(tea.asct_key,te.rpt_sor_proc_ts)  as b on true 
left join daas_tm_trusted.f_get_dh_cnvy_cond_domn_evt_by_cnvy_key(cnvy.cnvy_key, ccond."ProcessTimestamp" ) as c on true
--left join daas_tm_trusted.f_get_dh_cnvy_char_domn_evt_equipment_by_cnvy_key(cnvy.cnvy_key, cc.rpt_sor_proc_ts ) as d on true
--left join daas_tm_trusted.f_get_dh_ship_cond_domn_evt_by_ship_key(sa.ship_key, scond."ProcessTimestamp" ) as e on true
where cnvy.act_stus_ind=1
--te.data_hub_crt_ts > (now() - interval '1 days' )
--and cnvy.id_val='DTTX885023'
;

--select * from daas_tm_trusted."vCarInventoryUpdateHistory"
--where "railcarId"='DTTX885023';