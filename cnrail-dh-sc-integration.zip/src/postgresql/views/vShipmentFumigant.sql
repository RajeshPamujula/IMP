drop view if exists daas_tm_trusted."vShipmentFumigant" cascade;

CREATE OR REPLACE VIEW daas_tm_trusted."vShipmentFumigant" as 
select 
a.id_val as "waybillIdentification"
,a.ship_key as "shipmentKey" 
,ship_char1.char_val as "fumigationVolume"
,ship_char2.char_val as "fumigationUom"
,ship_char3.char_val as "fumigationDate"
,ship_char4.char_val as "disposalOfResidueInstruction"

from  daas_tm_prepared.dh_ship a 
inner join daas_tm_prepared.dh_ship_char as ship_char1 on a.ship_key=ship_char1.ship_key and ship_char1.act_stus_ind=1
and ship_char1.char_type_key='a5df0d45b73551f001ab2e03a3518f944f7e2594c7375da521e6e4851d851095'  -- Fumigation Volume
inner join daas_tm_prepared.dh_ship_char as ship_char2 on a.ship_key=ship_char2.ship_key and ship_char2.act_stus_ind=1
and ship_char2.char_type_key='6fb80e0f8f1edae306d055b33ec45c2b087cbd92dd1e0dbf46a5c0a7bc4f7fd6'  -- Fumigation UOM
inner join daas_tm_prepared.dh_ship_char as ship_char3 on a.ship_key=ship_char3.ship_key and ship_char3.act_stus_ind=1
and ship_char3.char_type_key='9e06ee5063a704cae25a51110da1cfdabc44e721e96c0b97983ca0ae1408c79e'  -- Fumigation Date
inner join daas_tm_prepared.dh_ship_char as ship_char4 on a.ship_key=ship_char4.ship_key and ship_char4.act_stus_ind=1
and ship_char4.char_type_key='0ddbe18a113340da9e9c980fb314088fd18b726800aecca8e40c2a0ada703446'  -- Disposal of Residue Instruction
where a.act_stus_ind=1;