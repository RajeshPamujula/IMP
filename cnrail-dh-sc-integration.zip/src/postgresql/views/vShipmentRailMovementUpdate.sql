drop view if exists daas_tm_trusted."vShipmentRailMovementUpdate" cascade;


CREATE OR REPLACE VIEW daas_tm_trusted."vShipmentRailMovementUpdate" as 
WITH shipChange as (
select ship.ship_key, ship.data_hub_crt_ts
from daas_tm_prepared.dh_ship ship
where ship.data_hub_crt_ts>(now() - interval '0.25 hours')
union
select ship_cond.ship_key, ship_cond.data_hub_crt_ts
from daas_tm_prepared.dh_ship_cond ship_cond
where ship_cond.data_hub_crt_ts>(now() - interval '0.25 hours')
)
, dtm as (select ship_key, max(data_hub_crt_ts) as "dataHubCreationTimestamp"
from shipChange
group by ship_key)
select 
 cnvy.id_val as "equipmentIdentification"
,cnvy_char.Equipment_Initial as "equipmentInitial"
,cnvy_char.Equipment_Number  as "equipmentNumber"
,cnvy_char.Car_Kind   as "carKind"
--,substring (cnvy_char.Car_Kind,1,1)
,ship_cond."specialConditionCode1"
,ship_cond."specialConditionCode2"
,ship_cond."specialConditionCode3"
,ship_cond."specialConditionCode4"
,ship_cond."specialConditionCode5"
,ship_cond."specialConditionCode6"
,ship_char.Operating_Railroad_At_Junction_Point as "operatingRailroadAtJunctionPoint"
,ship_char.Speed_Restriction  as "speedRestriction"
,ship_char.Speed_Restriction_Unit_of_Measure as "speedRestrictionUom"
,b.char_val as "waybillNumber"
,a.id_val as "waybillIdentification"
,ship_cond."waybillStatusCode"
,dtm."dataHubCreationTimestamp"
--select count(1)
from dtm
inner join daas_tm_prepared.dh_ship a on dtm.ship_key=a.ship_key
inner join daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(a.ship_key) ship_char on true
inner join daas_tm_prepared.dh_ship_char b on a.ship_key=b.ship_key and b.act_stus_ind=1
and b.char_type_key='8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0' --Waybill Number
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(a.ship_key) ship_cond on true
left join daas_tm_prepared.dh_cnvy cnvy on (ship_char.equipment_id = cnvy.id_val  and cnvy.act_stus_ind = 1)
left join daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key(cnvy.cnvy_key ) cnvy_char on true
where 1=1
--a.data_hub_crt_ts >=(now() - interval '200 hours')
and a.act_stus_ind=1
--and cnvy_char.Car_Kind not in ('V','K','U')
--and ship_cond."waybillStatusCode" in ('A','U')
;

