DROP VIEW IF EXISTS daas_tm_trusted."vRelContainerRailcarAll" CASCADE;
CREATE OR REPLACE VIEW daas_tm_trusted."vRelContainerRailcarAll"
AS
with RelContainerRailcar as (
select     distinct cont_car.cnvy_key as container_cnvy_key, 
    cont_car.asct_obj_key as railcar_cnvy_key,
	b.eqp_init || b.eqp_nbr as "equipmentIdentification"

from daas_tm_prepared.dh_cnvy_asct cont_car
inner join daas_tm_prepared.dh_rcar_ref  b on b.rcar_key=cont_car.asct_obj_key
where 1=1
  and cont_car.cnvy_type_key = '8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a'    ---   container
  and cont_car.asct_type_key = '0ba452470ff9f23b1d2e999f5afea823e1d7bab4913da2dc17aba3c6e784f011'    ---   Intra-BCD Container-Railcar
  and cont_car.asct_obj_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9'    ---   Railcar
  and cont_car.act_stus_ind = 1
  )
  select  
cnvy_cont.char_val as "containerIdentification",
cnvy_cont_2.char_val as "containerInitial",
cnvy_cont_3.char_val as "containerNumber",
cnvy_cond_cont_2.char_val as "firstStorageChargeDate",
cnvy_cond_cont.char_val as "storageChargeStatusCode",
m."equipmentIdentification",
coalesce(cnvy_cond.char_val, '') as "badOrderCode", -- New container bad order
coalesce(ship_char.char_val,'')as "ppsiTemperature",
coalesce(ship_char1.char_val,'') as "ppsiTemperatureUnitOfMeasure"
from daas_tm_prepared.dh_cnvy_char cnvy_cont
inner join daas_TM_prepared.dh_cnvy_char cnvy_cont_2 on (cnvy_cont.cnvy_key = cnvy_cont_2.cnvy_key and cnvy_cont_2.act_stus_ind = 1 and cnvy_cont_2.char_type_key = 'd878d5fd0d09bf69a1809f0d3dc148d78e3565660d33770ce7ba04c7bfde0938') -- container initial
inner join daas_TM_prepared.dh_cnvy_char cnvy_cont_3 on (cnvy_cont.cnvy_key = cnvy_cont_3.cnvy_key and cnvy_cont_3.act_stus_ind = 1 and cnvy_cont_3.char_type_key = '863b5cd8179cfd5b3590ffad9c482cf53e79935d1a8ed30f5a73e2719613b520') -- container number
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_cont on (cnvy_cont.cnvy_key = cnvy_cond_cont.cnvy_key and cnvy_cond_cont.act_stus_ind = 1 and cnvy_cond_cont.char_type_key = '37930ca551ed5baf224d861f86395b2a32e1bbac69406d2f47e29d4273583131') -- Storage Charge Status Code
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_cont_2 on (cnvy_cont.cnvy_key = cnvy_cond_cont_2.cnvy_key and cnvy_cond_cont_2.act_stus_ind = 1 and cnvy_cond_cont_2.char_type_key = 'd9fb9ddc0f66f8f86633f9eafc57a87e40c6d21e75b1f97c1997c6b96e835d85') -- First Storage Charge Date
left join RelContainerRailcar m on cnvy_cont.cnvy_key=m.container_cnvy_key
-- New container bad order
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond on (cnvy_cont.cnvy_key = cnvy_cond.cnvy_key and cnvy_cond.act_stus_ind = 1 and cnvy_cond.char_type_key = '07ed1078042c7692da1672e604d7b8cca3f42fad6fc79385ab9c57c9a23a2ce2') -- bad order code
--find PPSI Temperature
left join daas_tm_prepared.dh_ship_asct ship_asct on ship_asct.asct_obj_key = cnvy_cont.cnvy_key -- cnvy_key is container
and ship_asct.asct_type_key='3de22246a9c11b9fa0fae553613839d4fa5e077ff8bbbf7ee43eef0725c434c2'
left join daas_tm_prepared.dh_ship_char ship_char  on ship_char.ship_key=ship_asct.ship_key and ship_char.act_stus_ind=1 
 and ship_char.char_type_key='f3fef2a5ac0433e51523fb2902015d19093325ef4b3a5e1a35919fe0cf341899' --ppsiTemperature
 
left join daas_tm_prepared.dh_ship_char ship_char1  on ship_char1.ship_key=ship_asct.ship_key and ship_char1.act_stus_ind=1 
and ship_char1.char_type_key='e0a28b0e542009e081cd942ae2e075ac8b2e01116e686f7aed688b4e0de72ceb' --ppsiTemperatureUnitOfMeasure
where cnvy_cont.char_type_key = '223ef438ed2fc0f96ac98b04cf85175502707e90ec1c87b643471983519b95e8' -- container id 
and cnvy_cont.act_stus_ind = 1;