/*
https://jira.cn.ca:8443/browse/TDH-6297 (Specs: Smart Terminal - Train Schedule stn (View))

https://kb.cn.ca/display/DHTPE/Train+Schedule
*/

drop view if exists daas_tm_trusted."vTrainScheduleStation";

create view daas_tm_trusted."vTrainScheduleStation"
as
select cnvy.id_val as "trainIdentification",-- trn_id
trnod."originStationFsac",
trnod."originStationScac" ,
trnod."destinationStationFsac",
trnod."destinationStationScac",
trndtl."stationSequenceNumber",
trndtl."stationScac",
trndtl."stationFsac",
trndtl."stationSequenceTimestamp",
trndtl."estimatedArrivalUtc",
trndtl."estimatedArrivalTimezoneLabel",
trndtl."estimatedArrivalUtcOffsetValueHours",

trndtl."estimatedDepartureUtc",
trndtl."estimatedDepartureTimezoneLabel",
trndtl."estimatedDepartureUtcOffsetValueHours",

trndtl."topcEstimatedArrivalUtc",
trndtl."topcEstimatedArrivalTimezoneLabel",
trndtl."topcEstimatedArrivalUtcOffsetValueHours",

trndtl."topcEstimatedDepartureUtc",
trndtl."topcEstimatedDepartureTimezoneLabel",
trndtl."topcEstimatedDepartureUtcOffsetValueHours"

from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_trusted.f_run_dh_get_train_schedule_origin_detination_by_trainid( cnvy.id_val ) trnod on  cnvy.act_stus_ind = 1 
left  join daas_tm_trusted.f_run_dh_get_train_station_detail_by_trainid(cnvy.id_val ) trndtl on true
where 1=1
--and cnvy.id_val='Q1203120201205'
--and cnvy.id_val= 'A4213220201205'
;