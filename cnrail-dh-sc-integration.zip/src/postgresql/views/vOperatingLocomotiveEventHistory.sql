--vOperatingLocomotiveEventHistoryBystationCountry
DROP VIEW IF EXISTS daas_tm_trusted."vOperatingLocomotiveEventHistory" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vOperatingLocomotiveEventHistory"
AS
select cnvy.id_val as "trainIdentification",
tec3.char_val as "stationSequenceNumber",
COALESCE(SUBSTRING(tec4.char_val, 1, 2), '') AS "eventCode",
COALESCE(SUBSTRING(tec4.char_val, 3, 2), '') AS "eventStatusCode",
CASE WHEN tec5.char_val = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else (to_timestamp(tec5.char_val, 'YYYY-MM-DD HH24:MI:SS')) end  AS  "trainEventTimestamp",
tec.char_val as "stationSequenceTimestamp", 
tec1.char_val as "stationScac",
tec2.char_val as "stationFsac",
stn.stn_333 as "station333",
stn.stn_st as "stationProvinceState",
stn.stn_ctry as "stationCountry",
aset.id_val as "locomotiveIdentifier",
aac.char_val as "trainSequenceNumber"
--,first_value(cnvy.id_val) OVER (PARTITION BY aset.id_val ORDER BY ca.asct_sor_proc_ts DESC) as "latestTraintrainIdentification"
from daas_tm_prepared.dh_trsp_evt trsp
inner join daas_tm_prepared.dh_cnvy_asct ca on ca.act_stus_ind=1 and trsp.prim_obj_key=ca.asct_obj_key 
and ca.cnvy_type_key ='c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698' --Train
and ca.asct_obj_type_key='62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a'  --'Train Event'
inner join daas_tm_prepared.dh_cnvy cnvy on ca.cnvy_key = cnvy.cnvy_key 
and ca.act_stus_ind=1
and cnvy.act_stus_ind=1 and cnvy.cnvy_type_key='c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'  --train 
inner join daas_tm_prepared.dh_trsp_evt_char tec on (trsp.trsp_evt_key = tec.trsp_evt_key and tec.act_stus_ind = 1 and tec.char_type_key = 'a4a7f99206741fbff8e56a0d3d32b2881ce75a59728c8aaa64c36918d0e40609' )  -- station sequence timestamp
inner join daas_tm_prepared.dh_trsp_evt_char tec1 on (trsp.trsp_evt_key = tec1.trsp_evt_key and tec1.act_stus_ind = 1 and tec1.char_type_key = '2b77baf8b844500829fffd11357d1e243ee020adec77ea2cdc4b2934d8577d2a')  -- station scac
inner join daas_tm_prepared.dh_trsp_evt_char tec2 on (trsp.trsp_evt_key = tec2.trsp_evt_key and tec2.act_stus_ind = 1 and tec2.char_type_key = '61d9f08af8e5f9cc63abd8d3d1b42f2e3d4933e41449815f3574673e10cfe1fa')  -- station fsac
inner join daas_tm_prepared.dh_trsp_evt_char tec3 on (trsp.trsp_evt_key = tec3.trsp_evt_key and tec3.act_stus_ind = 1 and tec3.char_type_key = '2cb5b0e9672838ba34acfd341a4d3e8f6e8e95c42fd7bfbe215fe72f2b3904e9')  -- Station Sequence Number
left join daas_tm_prepared.dh_trsp_evt_char tec4 on tec4.trsp_evt_key = trsp.trsp_evt_key and tec4.act_stus_ind=1
and tec4.char_type_key='07814f276206869eb5b8e6777b5f06a1597ee49b2957f04b609d3c99093d11d7'  -- train Event Code
left join daas_tm_prepared.dh_trsp_evt_char tec5 on tec5.trsp_evt_key = trsp.trsp_evt_key and tec5.act_stus_ind=1
and tec5.char_type_key='47315209be802f75a9e4e3f07baf68f4c82f572b32d5dcea9eda9fbc91a92f32'  -- train Event Date Time UTC
inner join daas_tm_prepared.dh_rail_station stn on stn.fsac=tec2.char_val and stn.scac=tec1.char_val
INNER JOIN daas_tm_prepared.dh_aset_asct as aa ON trsp.prim_obj_key = aa.prim_obj_key AND aa.act_stus_ind = 1
INNER JOIN daas_tm_prepared.dh_aset_asct_char as aac on aac.act_stus_ind=1
and aac.asct_key = aa.asct_key
and aac.char_type_key='ab2627489c16d13421c9d286b39d1f1c138c93988c14f4ac3235b04fb50ee9d0' --Train Sequence Number
and aac.char_val='001'
INNER JOIN daas_tm_prepared.dh_aset as aset ON aset.aset_key = aa.aset_key AND aset.act_stus_ind = 1 
and aset.aset_type_key='08e8d3db4a88f4048af2d4afa8e241965560177eeaa88d8f5eab57e9641c2249' -- aset type:Locomotive 
where 1=1
--and stn.stn_ctry='CANADA'
and trsp.data_hub_crt_ts >= now()- interval '2 days'
AND trsp.trsp_evt_type_key = '62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a' --- Train Event Transportation Event
--order by cnvy.id_val, --"trainIdentification"
--tec3.char_val,  --"stationSequenceNumber"
--trsp.trsp_evt_val   --"trainArrivalDeparture" desc
-- order by stationSequenceNumber,trainArrivalDeparture 
;
/*
test case
select *
from daas_tm_trusted."vOperatingLocomotiveEventHistory"
where "stationCountry"='CANADA'
*/