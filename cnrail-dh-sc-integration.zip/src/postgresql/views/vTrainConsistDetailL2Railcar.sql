DROP VIEW IF EXISTS daas_tm_trusted."vTrainConsistDetailL2Railcar" CASCADE;
CREATE OR REPLACE VIEW daas_tm_trusted."vTrainConsistDetailL2Railcar"
AS
select ca2.cnvy_key  
, rcar.eqp_init || rcar.eqp_nbr AS "railcarIdentification"
, rcar.car_kind AS "carKind"
,cnvy_asct_char_flat.trn_seq_nbr AS "trainSequenceNumber"
,cnvy_asct_char_flat.sout_stn_seq_nbr AS "setOutStationSequenceNumber"
,cnvy_asct_char_flat.sout_trk AS "setOutTrackNumber"
,cnvy_asct_char_flat.sout_stn_seq_ts AS "setOutStationSequenceTimestamp"
,cnvy_asct_char_flat.sout_trk_seq_nbr AS "setoutTrackSequenceNumber"
,cnvy_asct_char.Platform_Code AS "platformCode"
,cnvy_asct_char.Platform_Position_Code AS "platformPositionCode"
, ship_char.rail_destination_333 AS "arrivalStation333"
, ship_char.rail_destination_333_province_state_code AS "arrivalStationProvinceState"
, stn2.scac AS "arrivalStationScac"
, stn2.fsac AS "arrivalStationFsac"
, c2.id_val AS "containerIdentification"
, CASE WHEN SUBSTRING(rcar.car_kind,1,1) IN ('Q', 'P') THEN 1 ELSE 0 END AS "intermodalTrainIndicator"
, ca2.asct_obj_key -- technical field filtered by L1.trsp_evt_key

, cnvy_asct_char_flat.sout_scac as "setOutStationScac"
, case when cast(case when cnvy_asct_char_flat.sout_fsac='' then '0' else cnvy_asct_char_flat.sout_fsac end as int)=0 then '' else 
cast(cast(case when cnvy_asct_char_flat.sout_fsac='' then '0' else cnvy_asct_char_flat.sout_fsac end as int) as varchar(5)) end  as "setOutStationFsac"
, stn3.stn_333 as "setOutStation333"
, stn3.stn_st as "setOutStationProvinceState"
from daas_tm_prepared.dh_cnvy_asct ca2 
inner join daas_tm_prepared.dh_rcar_ref rcar on rcar.rcar_key = ca2.cnvy_key 
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_asct_char_train_by_asct_key (ca2.asct_key) cnvy_asct_char ON 1= 1   --- still need this for the platform code & platform position code
left join daas_tm_prepared.dh_cnvy_asct_char_flat cnvy_asct_char_flat on (ca2.asct_key = cnvy_asct_char_flat.asct_key)
LEFT JOIN daas_tm_prepared.dh_rail_station stn3  ON LPAD(stn3.fsac, 6, '0') = cnvy_asct_char_flat.sout_fsac AND stn3.scac = cnvy_asct_char_flat.sout_scac

LEFT JOIN daas_tm_prepared.dh_ship_asct sa       ON  rcar.rcar_key = sa.asct_obj_key and sa.act_stus_ind = 1  --AND SA.ship_type_key = '\x64376239313433376666373461336266643730626133656265386431366238623563323635386362353839633765356661396438663637643335346533623830' -- Waybill
left join daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key  (sa.ship_key)   ship_char On 1= 1
LEFT JOIN daas_tm_prepared.dh_rail_station stn2  ON stn2.stn_333 = ship_char.rail_destination_333 AND stn2.stn_st = ship_char.rail_destination_333_province_state_code
LEFT JOIN daas_tm_prepared.dh_cnvy_asct ca3 ON ca3.act_stus_ind = 1 AND ca3.asct_obj_key = rcar.rcar_key
AND ca3.cnvy_type_key = '\x38643865333337333939373830393263666337313964643039393634393863316231666233333463336237356439386665366337336538666237363761393161' -- Container
AND ca3.asct_obj_type_key = '\x33393464623062666463323165653030306133613164366661336230356539396138643736333031383632613963396338363663393330353133363234366439' -- Railcar
LEFT JOIN daas_tm_prepared.dh_cnvy c2 ON c2.act_stus_ind = 1 AND c2.cnvy_key = ca3.cnvy_key
where ca2.act_stus_ind = 1 
AND ca2.cnvy_type_key = '\x33393464623062666463323165653030306133613164366661336230356539396138643736333031383632613963396338363663393330353133363234366439' -- Railcar
--and ca2.cnvy_key = '9003ede80cb3a0f68956b4a2e433473fc685669c78de9910d55ce5e95b60e47e'
;

/* test case  
select * from daas_tm_trusted."vTrainConsistDetailL2Railcar" 
where asct_obj_key='e34b55213045746d0f8d97a760e7913c68ab3180ecbd61868eb4a9e0ab036283';
*/