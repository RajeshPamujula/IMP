SET search_path TO daas_tm_trusted;
SET ROLE = daas_tm_trusted_admin;