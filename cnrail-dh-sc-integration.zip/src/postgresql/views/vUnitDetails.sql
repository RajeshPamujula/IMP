DROP VIEW IF EXISTS daas_tm_trusted."vUnitDetails" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vUnitDetails"
AS
SELECT
cnvy.id_val as "equipmentIdentifier"
,cnvy_char.Equipment_Initial as "equipmentInitial"
,cast(cast(cnvy_char.Equipment_Number  as integer) as text) as "equipmentNumber"
,WaybillInfo.WaybillNumber as "waybillNumber"
,WaybillInfo.WaybillId as "waybillIdentifier"
,cnvy_char.Outside_Length as "outsideLength"
,cnvy_char.Outside_Length_uom as "outsideLengthUnitOfMeasure"
,cnvy_char.Rail_Control_Code as "railControlCode"
,cnvy_char.equipment_lessee_abbreviation as "leaseeCode"
,cnvy_char.Outside_Height as "outsideHeight"
,cnvy_char.Outside_Height_uom as "outsideHeightUnitOfMeasure"
,cnvy_char.Outside_Width as "outsideWidth"
,cnvy_char.outside_width_uom as "outsideWidthUnitOfMeasure"
,cnvy_char.AAR_Car_Kind as "aarCarKind"
,cnvy_char.Car_Kind as "carKind"
,cnvy_cond."mechanicalStatusCode1" as "mechanicalStatusCode1"
,cnvy_cond."mechanicalStatusCode2" as "mechanicalStatusCode2"
,cnvy_cond."mechanicalStatusCode3" as "mechanicalStatusCode3"
,cnvy_char.Equipment_Tare as "equipmentTareWeight"
,cnvy_char.Equipment_Tare_UOM as "equipmentTareWeightUnitOfMeasure"
,cnvy_char.Equipment_Owner_Abbreviation as "equipmentOwnerAbbreviation"
,cnvy_cond."badOrderCode"
,cnvy_cond."eventAccountCode"
,'waterCarrierFlag' as "waterCarrierFlag"
,cnvy_char.Rail_Private_Code  as "railPrivateCode"
,cnvy_cond."balanceOwedIndicator"
,cc1.char_val as "lastResponsibleRoadAbbreviation"
,trim(mc1.trsp_cd_dsc_eng) as "mechanicalStatusCode1EnglishDescription"
,trim(mc1.trsp_cd_dsc_fr)  as "mechanicalStatusCode1FrenchDescription"
,trim(mc2.trsp_cd_dsc_eng) as "mechanicalStatusCode2EnglishDescription"
,trim(mc2.trsp_cd_dsc_fr)  as "mechanicalStatusCode2FrenchDescription"
,trim(mc3.trsp_cd_dsc_eng) as "mechanicalStatusCode3EnglishDescription"
,trim(mc3.trsp_cd_dsc_fr)  as "mechanicalStatusCode3FrenchDescription"
FROM daas_tm_prepared.dh_cnvy cnvy
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key (cnvy.cnvy_key) cnvy_char ON 1= 1
left join daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key (cnvy.cnvy_key) cnvy_cond on 1= 1
left join daas_tm_prepared.dh_cnvy_cond cc1 on cc1.cnvy_key=cnvy.cnvy_key and cc1.act_stus_ind=1
and cc1.char_type_key='7cb27be3630145de8dcd9e5d36667fc8a65ca120e884532e891d6b3ce4fc3e00' --Last Responsible Road Abbreviation
left outer join
(SELECT id_val AS WaybillId
,c.char_val AS EquipmentID
,d.char_val AS WaybillNumber
,g.char_val as waybillstatus -- debug propose
,c.data_hub_crt_ts as EquipmentIDts  --debug propose
FROM daas_tm_prepared.dh_ship main
inner join daas_tm_prepared.dh_ship_char c
on main.ship_key = c.ship_key and c.act_stus_ind = 1
AND c.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
inner join daas_tm_prepared.dh_ship_char d
on main.ship_key = d.ship_key and d.act_stus_ind = 1
AND d.char_type_key = '8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0' --Waybill Number
inner join daas_tm_prepared.dh_ship_cond g on main.ship_key=g.ship_key 
and g.char_val in ('A','S','O' ) -- to keep active waybill association only
and g.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083'  -- waybill status
and g.act_stus_ind=1
) as WaybillInfo
on id_val = WaybillInfo.EquipmentID
left join daas_tm_prepared.dh_trsp_cd_ref  mc1 on mc1.trsp_cd=cnvy_cond."mechanicalStatusCode1" and mc1.trsp_cd_type='Mechanical Status Code'
left join daas_tm_prepared.dh_trsp_cd_ref  mc2 on mc2.trsp_cd=cnvy_cond."mechanicalStatusCode2" and mc2.trsp_cd_type='Mechanical Status Code'
left join daas_tm_prepared.dh_trsp_cd_ref  mc3 on mc3.trsp_cd=cnvy_cond."mechanicalStatusCode3" and mc3.trsp_cd_type='Mechanical Status Code'
--WHERE cnvy_type_key = 'e91b3bb060fea6f9d741db9db19e3328be5f64f34429ff2e66aa176cdcf24133' --Intermodal Unit
--where cnvy.id_val='DTTX751390'
;

-- select * from daas_tm_trusted."vUnitDetails" where "equipmentIdentifier"='DTTX751390';
