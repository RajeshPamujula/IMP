DROP VIEW IF EXISTS daas_tm_trusted."vCarloadInformationAll" cascade
;
CREATE OR REPLACE VIEW daas_tm_trusted."vCarloadInformationAll"
AS
with carinfo as ( select 
rcar.eqp_init || rcar.eqp_nbr as "equipmentIdentification",
RCAR.eqp_init as "equipmentInitial",
RCAR.eqp_nbr as "equipmentNumber",
rcar.rcar_key,
cnvy_cond.char_val as "badOrderCode",
cnvy_cond_2.char_val as "holdCode",
tac.char_val as "trackNumber",
case when tac_2.char_val = '0' then '' else tac_2.char_val end as "trackSequenceNumber",
sa_char.char_val as "trainIdentification",
sa_char.char_val,
Rail_stat.scac ,
rail_stat.fsac,
Rail_STAT.stn_333,
rail_stat.stn_st,
tde.trsp_evt_val,
--substr(tde.trsp_evt_val,1,2),
--substr(tde.trsp_evt_val,3,2),
rail_stat.splc ,
rail_stat.stn_nm  ,
tde.sor_evt_ts,
event_tz_ci.tz_lbl as event_tz_ci_tz_lbl,
event_tz_ci.utc_ofst_val_hr as event_tz_ci_utc_ofst_val_hr,
tde.rpt_sor_proc_ts ,
proc_tz_ci.tz_lbl as proc_tz_ci_tz_lbl,
proc_tz_ci.utc_ofst_val_hr as proc_tz_ci_utc_ofst_val_hr
from DAAS_TM_PREPARED.DH_TRSP_EVT TDE
inner join daas_tm_prepared.dh_rcar_ref RCAR on (TDE.TRSP_EVT_KEY = rcar.rcar_key)
inner join daas_tm_prepared.dh_cnvy_cond cnvy_cond on (rcar.rcar_key = cnvy_cond.cnvy_key and cnvy_cond.act_stus_ind = 1 and cnvy_cond.char_type_key = '07ed1078042c7692da1672e604d7b8cca3f42fad6fc79385ab9c57c9a23a2ce2')-- bad order code
inner join daas_tm_prepared.dh_cnvy_cond cnvy_cond_2 on (rcar.rcar_key = cnvy_cond_2.cnvy_key and cnvy_cond_2.act_stus_ind = 1 and cnvy_cond_2.char_type_key = '665ce7a009722311c22f1e1011f1fc80fdc720870d1b70499485d5d9a766a538')-- mechanical status code
inner join DAAS_TM_PREPARED.dh_trsp_evt_asct TEA on (rcar.rcar_key = tea.trsp_evt_key and tea.act_stus_ind = 1)
inner join daas_tm_prepared.dh_rail_station Rail_STAT on (TEA.asct_obj_key = Rail_STAT.stn_333_key or TEA.asct_obj_key = Rail_STAT.stn_333_cn_key or TEA.asct_obj_key = Rail_STAT.stn_333_cn_key_conv)
inner join daas_tm_prepared.dh_trsp_evt_asct_char TAC on (TEA.asct_key = TAC.asct_key and tac.act_stus_ind = 1 and tac.char_type_key = '22fba95bb00160a504606f34b153dbd889ed746cc7d7f794472aa48b7bdbb41a') -- track number
inner join daas_tm_prepared.dh_trsp_evt_asct_char TAC_2 on (TEA.asct_key = TAC_2.asct_key and tac_2.act_stus_ind = 1 and tac_2.char_type_key = 'a83fa7f14d9937952df568bcfb79fb3516b4f847ecb90799dd431c0c25215af9')   -- track sequence number
inner join daas_tm_prepared.dh_ship_asct ship_asct on (rcar.rcar_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
inner join daas_tm_prepared.dh_ship_asct_char sa_char on (ship_asct.asct_key = sa_char.asct_key and sa_char.act_stus_ind =1 and sa_char.char_type_key = '06336730586527e31d5f9f12871d505364457590976fc83d32651a06869d3aa1')
inner join daas_tm_prepared.dh_tz_dst_ref event_tz_ci on (tde.sor_evt_ts_tz_dst_cd = event_tz_ci.tz_dst_cd)
inner join daas_tm_prepared.dh_tz_dst_ref proc_tz_ci on (tde.sor_proc_ts_tz_dst_cd = proc_tz_ci.tz_dst_cd)
and TDE.act_stus_ind = 1
)
, trainkey as (select RCAR.rcar_key,
train.trsp_evt_key,
train.sor_evt_ts,
train.sor_evt_ts_tz_dst_cd,
train.rpt_sor_proc_ts,  
train.sor_proc_ts_tz_dst_cd,
train_char_2.char_val as "stationScac",  
train_char_3.char_val as "stationFsac",
substr(train_char_5.char_val,1,2) as "eventCode",
substr(train_char_5.char_val,3,2) as "eventStatusCode",
train_char_4.char_val as "stationSequenceTimestamp",
ROW_NUMBER() OVER (PARTITION BY RCAR.rcar_key ORDER BY train.sor_evt_ts DESC) rk
from 
carinfo RCAR 
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (rcar.rcar_key = cnvy_asct.cnvy_key and cnvy_asct.act_stus_ind = 1)
inner join daas_tm_prepared.dh_trsp_evt train on (cnvy_asct.asct_obj_key = train.trsp_evt_key and train.act_stus_ind = 1)
inner join daas_tm_prepared.dh_trsp_evt_char train_char_2 on (train.trsp_evt_key = train_char_2.trsp_evt_key and train_char_2.act_stus_ind = 1 and train_char_2.char_type_key = '2b77baf8b844500829fffd11357d1e243ee020adec77ea2cdc4b2934d8577d2a' ) -- scac event station carrier abbreviation 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_3 on (train.trsp_evt_key = train_char_3.trsp_evt_key and train_char_3.act_stus_ind = 1 and train_char_3.char_type_key = '61d9f08af8e5f9cc63abd8d3d1b42f2e3d4933e41449815f3574673e10cfe1fa' ) -- fsac event station FSAC 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_4 on (train.trsp_evt_key = train_char_4.trsp_evt_key and train_char_4.act_stus_ind = 1 and train_char_4.char_type_key = 'a4a7f99206741fbff8e56a0d3d32b2881ce75a59728c8aaa64c36918d0e40609' ) -- sequence timestamp 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_5 on (train.trsp_evt_key = train_char_5.trsp_evt_key and train_char_5.act_stus_ind = 1 and train_char_5.char_type_key = '07814f276206869eb5b8e6777b5f06a1597ee49b2957f04b609d3c99093d11d7' ) -- event code 
where 1=1
and cnvy_asct.cnvy_type_Key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' --  'Railcar'   --
and cnvy_asct.asct_obj_type_key = '62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a' -- 'Train Event'   --
)
select
a."equipmentIdentification",
a."equipmentInitial",
a."equipmentNumber",
a."badOrderCode",
a."holdCode",
a."trackNumber",
a."trackSequenceNumber",
a."trainIdentification",
case when COALESCE(a.char_val, '') = '' then a.scac  else b."stationScac" end as "stationScac",
case when COALESCE(a.char_val, '') = '' then a.fsac else b."stationFsac" end as "stationFsac",
case when COALESCE(a.char_val, '') = '' then a.stn_333 else stn.stn_333 end as "station333", 
case when COALESCE(a.char_val, '') =  '' then case when a.stn_st = 'PQ' then 'QC' else a.stn_st end    
else case when stn.stn_st = 'PQ' then 'QC' else stn.stn_st end end as "stationProvinceState",
case when COALESCE(a.char_val, '') = '' then case when a.stn_st in ('PQ', 'ON', 'BC', 'AB', 'NF', 'NB', 'PE', 'NS', 'SK', 'MB') then 'CA' else 'US' end 
else case when stn.stn_st in ('PQ', 'ON', 'BC', 'AB', 'NF', 'NB', 'PE', 'NS', 'SK', 'MB') then 'CA' else 'US' end end as "countryCode",
case when COALESCE(a.char_val, '') = '' then substr(a.trsp_evt_val,1,2) else b."eventCode" end as "eventCode",
case when COALESCE(a.char_val, '') = '' then case when  substr(a.trsp_evt_val,3,2) = '' then null else substr(a.trsp_evt_val,3,2) end 
else case when  b."eventStatusCode" = '' then null else  b."eventStatusCode" end end as "eventStatusCode",
case when COALESCE(a.char_val, '') = '' then a.splc else stn.splc end as "splc",
case when COALESCE(a.char_val, '') = '' then a.stn_nm  else stn.stn_nm end as "stationName",  
case when COALESCE(a.char_val, '') = '' then a.sor_evt_ts else b.sor_evt_ts end as "eventTimestampUtc", 
case when COALESCE(a.char_val, '') = '' then a.event_tz_ci_tz_lbl else event_tz.tz_lbl end as "eventTimezoneLabel", 
case when COALESCE(a.char_val, '') = '' then a.event_tz_ci_utc_ofst_val_hr else event_tz.utc_ofst_val_hr end as "eventOffsetHours",
case when COALESCE(a.char_val, '') = '' then a.rpt_sor_proc_ts  else b.rpt_sor_proc_ts end as "processTimestampUtc",  
case when COALESCE(a.char_val, '') = '' then a.proc_tz_ci_tz_lbl  else proc_tz.tz_lbl end as "processTimezoneLabel", 
case when COALESCE(a.char_val, '') = '' then a.proc_tz_ci_utc_ofst_val_hr else proc_tz.utc_ofst_val_hr end as "processOffsetHours"
from carinfo a
left join trainkey b on a.rcar_key=b.rcar_key and b.rk=1
left join daas_tm_prepared.dh_rail_station stn on (b."stationFsac" = stn.fsac and b."stationScac" = stn.scac)
left join daas_tm_prepared.dh_tz_dst_ref event_tz on (b.sor_evt_ts_tz_dst_cd = event_tz.tz_dst_cd)
left join daas_tm_prepared.dh_tz_dst_ref proc_tz on (b.sor_proc_ts_tz_dst_cd = proc_tz.tz_dst_cd)
--where a."equipmentIdentification"='CN135324'
;