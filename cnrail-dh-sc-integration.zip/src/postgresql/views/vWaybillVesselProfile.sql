DROP VIEW IF EXISTS daas_tm_trusted."vWaybillVesselProfile" CASCADE;
CREATE OR REPLACE VIEW daas_tm_trusted."vWaybillVesselProfile"
AS

SELECT
cnvy.id_val as "containerIdentifier"
,ship.id_val as "waybillIdentifier"
,voyage.vessel_id as "vesselIdentifier"
,dh_ship_cmp_char_vessel.Vessel_Name as "vesselName"
,voyage."voyageNumber"
,voyage."portOperator633"
,voyage."originalArrivalUTC"
,voyage."originalArrivalOffsetValueHours"
,voyage."originalArrivalTimeZoneLabel"
,voyage."scheduledSailUTC"
,voyage."scheduledSailOffsetValueHours"
,voyage."scheduledSailTimeZoneLabel"
,voyage."scheduledCutOffUTC"
,voyage."scheduledCutOffOffsetValueHours"
,voyage."scheduledCutOffTimeZoneLabel"
,voyage."scheduledArrivalUTC"
,voyage."scheduledArrivalOffsetValueHours"
,voyage."scheduledArrivalTimeZoneLabel"
, dh_ship_cmp_by_ship."oceanBillOfLading"
, dh_ship_char_waybill_by_ship.Waybill_Number as "waybillNumber"
, dh_ship_char_waybill_by_ship.Load_Empty_Status_Code as "loadEmptyStatusCode"
, dh_ship_cmp_char_vessel.Inbound_Outbound_Code as "inboundOutboundCode"
FROM daas_tm_prepared.dh_cnvy cnvy /****** to get container with vessel on Waybill Vessel SOR *********/
--INNER JOIN daas_tm_prepared.dh_ship_asct ship_asct  ON ship_asct.asct_obj_key = cnvy.cnvy_key AND ship_asct.act_stus_ind = 1
--and cnvy.cnvy_type_key='8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a' -- container
INNER JOIN daas_tm_prepared.dh_ship_char sce on sce.act_stus_ind=1 and sce.char_val=cnvy.id_val
and sce.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296'  --Equipment ID
INNER JOIN daas_tm_prepared.dh_ship ship  ON sce.ship_key = ship.ship_key AND ship.act_stus_ind = 1

LEFT JOIN daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(ship.ship_key) dh_ship_char_waybill_by_ship ON 1=1 -- to get waybill number, waybill status, Origin and destination

INNER JOIN daas_tm_prepared.dh_ship_cmp ship_cmp on ship.ship_key = ship_cmp.ship_key AND ship_cmp.act_stus_ind = 1 

AND ship_cmp_type_key = 'af82909b34df99ece8af4b140307841a3a899bac846f096ff2a3efcbed32f44c' --Intra-Domain Shipment-Shipment-Voyage-Segment
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_vessel_by_ship_cmp_key (ship_cmp.ship_cmp_key) dh_ship_cmp_char_vessel ON 1=1 -- to get vessel name, vessel id and Inbound code
--- obtain Ocean Bill of Lading
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_by_ship_key(ship.ship_key) dh_ship_cmp_by_ship  ON 1=1

INNER JOIN daas_tm_trusted.f_get_dh_ship_cmp_voyage_number_by_ship_key(ship.ship_key) v on 1=1
/********* To get the details in Voyage Segment SOR ************/
LEFT JOIN (
SELECT vessel_id
,voyage_number
,vessel_name
,Voyage_Number as "voyageNumber"
,bus_prtr_char.char_val as "portOperator633"
,CASE
WHEN plan_char.char_val = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else (to_timestamp(plan_char.char_val, 'YYYY-MM-DD HH24:MI:SS'))
END as "originalArrivalUTC",
tz_original.utc_ofst_val_hr as "originalArrivalOffsetValueHours",
tz_original.tz_lbl as "originalArrivalTimeZoneLabel"
,CASE
WHEN plan_char_4.char_val = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else (to_timestamp(plan_char_4.char_val, 'YYYY-MM-DD HH24:MI:SS'))
END as "scheduledSailUTC",
tz_sail.utc_ofst_val_hr as "scheduledSailOffsetValueHours",
tz_sail.tz_lbl as "scheduledSailTimeZoneLabel"
,CASE
WHEN plan_char_3.char_val = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else (to_timestamp(plan_char_3.char_val, 'YYYY-MM-DD HH24:MI:SS'))
END as "scheduledCutOffUTC",
tz_cutoff.utc_ofst_val_hr as "scheduledCutOffOffsetValueHours",
tz_cutoff.tz_lbl as "scheduledCutOffTimeZoneLabel"
,CASE
WHEN plan_char_2.char_val = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else (to_timestamp(plan_char_2.char_val, 'YYYY-MM-DD HH24:MI:SS'))
END as "scheduledArrivalUTC",
tz_schedule.utc_ofst_val_hr as "scheduledArrivalOffsetValueHours",
tz_schedule.tz_lbl as "scheduledArrivalTimeZoneLabel"
FROM DAAS_TM_PREPARED.DH_RTE RDE
INNER JOIN DAAS_TM_PREPARED.dh_rte_char R_CHAR  ON (RDE.Rte_KEY = R_CHAR.rte_KEY and r_char.act_stus_ind = 1 and r_char.char_type_key = '33b37227ce0b89435a341ef230a6d906a78656cf6d46f7342f24832157bae225') -- vessel Id
INNER JOIN DAAS_TM_PREPARED.dh_rte_char R_CHAR_2  ON (RDE.Rte_KEY = R_CHAR_2.rte_KEY and r_char_2.act_stus_ind = 1 and r_char_2.char_type_key = '9f228350a6eb570b6361ecbe10114e7cbbaa6562f5fe73d43e5d31a9a985cdcd') -- voyage number
INNER JOIN daas_tm_prepared.dh_plan_evt plan_evt  ON (RDE.rte_key = plan_evt.prim_obj_key and plan_evt.act_stus_ind = 1)
---- obtain the original ETA UTC and the time zone code
INNER JOIN DAAS_tm_prepared.dh_plan_evt_char plan_char  ON (plan_evt.plan_evt_key = plan_char.plan_evt_key and plan_char.act_stus_ind = 1 and plan_char.char_type_key = 'e99d6d455406089ad5c177896b3ccb98b650f5847a780b917605fdcddcb7c427') -- Original Arrival utc
INNER JOIN DAAS_tm_prepared.dh_plan_evt_char plan_char_TZ  ON (plan_evt.plan_evt_key = plan_char_TZ.plan_evt_key and plan_char_tz.act_stus_ind = 1 and plan_char_tz.char_type_key = '53fc5939064f70a426436f3525dfe7f9ac6145f9c0a2df5ea4eea017614ffcc5') -- Original Arrival Tz Dst Cd
INNER JOIN daas_tm_prepared.dh_tz_dst_ref tz_original  ON (tz_original.tz_dst_cd = cast(plan_char_tz.char_val as SMALLINT))
--- obtain the schedule sail utc and the time zone code
INNER JOIN DAAS_tm_prepared.dh_plan_evt_char plan_char_4  ON (plan_evt.plan_evt_key = plan_char_4.plan_evt_key and plan_char_4.act_stus_ind = 1 and plan_char_4.char_type_key = 'a2e6aed9aef136e5990dea7f0b7d407f8129e3956df3890de5eb7d9756039281') -- Scheduled Sail UTC
INNER JOIN DAAS_tm_prepared.dh_plan_evt_char plan_char_4_TZ  ON (plan_evt.plan_evt_key = plan_char_4_TZ.plan_evt_key and plan_char_4_TZ.act_stus_ind = 1 and plan_char_4_TZ.char_type_key = '209c4e9d6c2e8b9d639e7b797dd62a8867678b10095a97d71af36ef515972cd4') -- Scheduled Sailing Tz Dst Cd
INNER JOIN daas_tm_prepared.dh_tz_dst_ref tz_sail  ON (tz_sail.tz_dst_cd = cast(plan_char_4_tz.char_val  as smallint))
--- obtain the schedule cutoff utc and the time zone code
INNER JOIN DAAS_tm_prepared.dh_plan_evt_char plan_char_3  ON (plan_evt.plan_evt_key = plan_char_3.plan_evt_key and plan_char_3.act_stus_ind = 1 and plan_char_3.char_type_key = 'c5a5b88e0b7c38af442e9ba99062e840a492f19a7d4bbe34be4f42487995ad38') -- Scheduled Cut-Off UTC
INNER JOIN DAAS_tm_prepared.dh_plan_evt_char plan_char_3_TZ  ON (plan_evt.plan_evt_key = plan_char_3_TZ.plan_evt_key and plan_char_3_TZ.act_stus_ind = 1 and plan_char_3_TZ.char_type_key = 'b8bb9175aaa3ed07ca0fb7ad8b1574f451474c6544e5169c392ca5a915534ad6') -- Scheduled Cut Off Tz Dst Cd
INNER JOIN daas_tm_prepared.dh_tz_dst_ref tz_cutoff  ON (tz_cutoff.tz_dst_cd = cast(plan_char_3_tz.char_val  as smallint))
---- obtain the schedule ETA UTC and the time zone code
INNER JOIN DAAS_tm_prepared.dh_plan_evt_char plan_char_2  ON (plan_evt.plan_evt_key = plan_char_2.plan_evt_key and plan_char_2.act_stus_ind = 1 and plan_char_2.char_type_key = '547e657dbaed8f630e132742e5357373be4c5eebed7562d04c857233e44d6777') -- Scheduled Arrival UTC
INNER JOIN DAAS_tm_prepared.dh_plan_evt_char plan_char_2_TZ  ON (plan_evt.plan_evt_key = plan_char_2_TZ.plan_evt_key and plan_char_2_TZ.act_stus_ind = 1 and plan_char_2_TZ.char_type_key = '15a594806e61a09dd297b07aa435511175fd06ed908e6b70c3b5b01c969341a3') -- Scheduled Arrival Tz Dst Cd
INNER JOIN daas_tm_prepared.dh_tz_dst_ref tz_schedule  ON (tz_schedule.tz_dst_cd = cast(plan_char_2_tz.char_val  as smallint))

INNER JOIN daas_tm_prepared.dh_plan_evt_asct PADE  ON (plan_evt.plan_evt_key = PADE.plan_evt_key and pade.act_stus_ind = 1)
INNER JOIN daas_tm_prepared.dh_loc_asct LADE  ON (pade.asct_obj_key = LADE.asct_key and lade.act_stus_ind = 1 )
LEFT JOIN daas_tm_prepared.dh_rail_station rail_station  ON (LADE.loc_key = rail_station.stn_333_key_conv or LADE.loc_key = rail_station.stn_333_cn_key_conv)
--- obtain voyage number, vessel Id
LEFT JOIN daas_tm_trusted.f_get_dh_rte_char_vessel_by_rte_key (RDE.Rte_KEY) rte_char_vessel ON 1=1
LEFT JOIN daas_tm_prepared.dh_loc_asct loc_asct_2  ON (rail_station.stn_fsac_key = loc_asct_2.loc_key and loc_asct_2.act_stus_ind = 1 and loc_asct_2.asct_obj_type_key = '375cc4b1170cfc7ffcea1f62d157d8007f3738d6f375bdf13cd612b37cfbb3cd') --- for port operator (CUST_CITY_333)
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char bus_prtr_char  ON (loc_asct_2.asct_obj_key = bus_prtr_char.bus_prtr_key and bus_prtr_char.act_stus_ind = 1 and bus_prtr_char.char_type_key = '505f6bad7a9b81a7f7f211e95a6fa5c4ac303e1af8798d517141e9a2839b2ea2') -- port operator 633 (CUST_ST)
--- obtain vessel name from Conveyor (LLOYD_VES_ID)
INNER JOIN daas_tm_prepared.dh_cnvy_asct cnvy_asct  ON RDE.rte_key = cnvy_asct.prim_obj_key and cnvy_asct.act_stus_ind = 1
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_vessel_by_cnvy_key(cnvy_asct.cnvy_key) cnvy_char_vessel  ON 1= 1
WHERE RDE.rte_type_key = '2e7511ebde345fade6957c5d2a07e826e100c7f436832f1aa4f2045881709876' --Voyage Vessel
and RDE.act_stus_ind = '1'
) as voyage ON 
((trim(voyage.vessel_name) = trim(dh_ship_cmp_char_vessel.vessel_name)) 
OR (TRIM(voyage.vessel_id) = trim(dh_ship_cmp_char_vessel.vessel_id)))
and voyage."voyageNumber"=v."voyageNumber"
WHERE cnvy.act_stus_ind = 1
--AND cnvy.id_val = 'ZIMU130515'
;
