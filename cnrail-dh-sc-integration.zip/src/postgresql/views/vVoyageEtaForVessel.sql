DROP VIEW IF EXISTS "vVoyageEtaForVessel" CASCADE;

CREATE OR REPLACE VIEW "vVoyageEtaForVessel"
AS

select r_char.char_val as "vesselIdentification",
r_char_2.char_val as "voyageNumber",
CASE WHEN plan_char.char_val = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else (to_timestamp(plan_char.char_val, 'YYYY-MM-DD HH24:MI:SS')) END as "originalEtaUtc",
tz_original.utc_ofst_val_hr as "originalEtaOffsetValueHours",
tz_original.tz_lbl as "originalEtaTimeZoneLabel",
CASE WHEN plan_char.char_val = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else (to_timestamp(plan_char.char_val, 'YYYY-MM-DD HH24:MI:SS')) + + tz_original.utc_ofst_val_hr * interval '1 hour'--
END as "originalEtaLocal",
CASE WHEN plan_char_2.char_val = '' THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else(to_timestamp(plan_char_2.char_val, 'YYYY-MM-DD HH24:MI:SS')) END as "updatedEtaUtc",
tz_schedule.utc_ofst_val_hr as "updatedEtaOffsetValueHours",
tz_schedule.tz_lbl as "updatedEtaTimeZoneLabel",
rail_station.stn_333 as "customerCity333",rail_station.stn_st as "customerState",rail_station.fsac as "fsac", rail_station.scac as "scac"
----
from DAAS_TM_PREPARED.DH_RTE RDE
inner join DAAS_TM_PREPARED.dh_rte_char R_CHAR on(RDE.Rte_KEY = R_CHAR.rte_KEY and r_char.act_stus_ind = 1 and r_char.char_type_key ='33b37227ce0b89435a341ef230a6d906a78656cf6d46f7342f24832157bae225')  -- vessel Id
inner join DAAS_TM_PREPARED.dh_rte_char  R_CHAR_2 on(RDE.Rte_KEY = R_CHAR_2.rte_KEY and r_char_2.act_stus_ind = 1 and r_char_2.char_type_key ='9f228350a6eb570b6361ecbe10114e7cbbaa6562f5fe73d43e5d31a9a985cdcd')  -- voyage number 
inner join daas_tm_prepared.dh_plan_evt plan_evt on(RDE.rte_key = plan_evt.prim_obj_key and plan_evt.act_stus_ind = 1)
---- obtain the original ETA UTC and the time zone code
inner join DAAS_tm_prepared.dh_plan_evt_char plan_char on(plan_evt.plan_evt_key = plan_char.plan_evt_key and plan_char.act_stus_ind = 1 and plan_char.char_type_key ='e99d6d455406089ad5c177896b3ccb98b650f5847a780b917605fdcddcb7c427')  -- original eta utc
inner join DAAS_tm_prepared.dh_plan_evt_char plan_char_TZ on(plan_evt.plan_evt_key = plan_char_TZ.plan_evt_key and plan_char_tz.act_stus_ind = 1   and plan_char_tz.char_type_key   = '53fc5939064f70a426436f3525dfe7f9ac6145f9c0a2df5ea4eea017614ffcc5')  -- original eta utc
inner join daas_tm_prepared.dh_tz_dst_ref  tz_original On(tz_original.tz_dst_cd = cast(plan_char_tz.char_val as SMALLINT))
---- obtain the schedule ETA UTC and the time zone code
inner join DAAS_tm_prepared.dh_plan_evt_char plan_char_2 on(plan_evt.plan_evt_key = plan_char_2.plan_evt_key and plan_char_2.act_stus_ind = 1 and plan_char_2.char_type_key ='547e657dbaed8f630e132742e5357373be4c5eebed7562d04c857233e44d6777')  -- schedule eta utc
inner join DAAS_tm_prepared.dh_plan_evt_char plan_char_2_TZ on (plan_evt.plan_evt_key   = plan_char_2_TZ.plan_evt_key and plan_char_2_TZ.act_stus_ind = 1 and plan_char_2_TZ.char_type_key = '15a594806e61a09dd297b07aa435511175fd06ed908e6b70c3b5b01c969341a3')  -- schedule eta utc
inner join daas_tm_prepared.dh_tz_dst_ref  tz_schedule On (tz_schedule.tz_dst_cd = cast(plan_char_2_tz.char_val as smallint))
inner join  daas_tm_prepared.dh_plan_evt_asct PADE on (plan_evt.plan_evt_key = PADE.plan_evt_key and pade.act_stus_ind = 1)
---  join to location association key to obtain the rail station, did a left join for rail station in case it does not exist
inner join  daas_tm_prepared.dh_loc_asct LADE on(pade.asct_obj_key = LADE.asct_key and lade.act_stus_ind = 1)
left join  daas_tm_prepared.dh_rail_station rail_station On (LADE.loc_key = rail_station.stn_333_key_conv or LADE.loc_key = rail_station.stn_333_cn_key_conv)
where rde.rte_type_key = '2e7511ebde345fade6957c5d2a07e826e100c7f436832f1aa4f2045881709876'   --- voyage vessel
and  rde.act_stus_ind = '1'
;
