DROP VIEW IF EXISTS daas_tm_trusted."vCarCharacteristicsChange" CASCADE;


CREATE OR REPLACE VIEW daas_tm_trusted."vCarCharacteristicsChange"
AS
select a.cnvy_key, a.data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_char a
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.cnvy_key=a.cnvy_key
and  (cnvy.cnvy_type_key = 'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' -- Rail Car
or cnvy.cnvy_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' ) -- RailCar
and cnvy.act_stus_ind=1
union all
select b.cnvy_key, b.data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_cond b
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.cnvy_key=b.cnvy_key
and  (cnvy.cnvy_type_key = 'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' -- Rail Car
or cnvy.cnvy_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' ) -- RailCar
and cnvy.act_stus_ind=1
where b.char_type_key='0f0cfaff4acf325a3407b96a0ef90378f6831929d513dcf6943f68e2dec87a84'  --End of Service Date
;
