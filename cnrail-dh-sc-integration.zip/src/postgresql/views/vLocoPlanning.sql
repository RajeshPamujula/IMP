DROP VIEW IF EXISTS daas_tm_trusted."vLocoPlanning" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vLocoPlanning"
AS
select  distinct m.id_val as "locomotiveIdentifier"
,case when loco."locomotiveLocationCode" ='T' then trn."trainIdentification" else '' end as "trainIdentifier"
,loco."trainShortIdentifier"
,case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate"  then trn."eventCode" else loco."eventCode" end as "eventCode"
,case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate"  then trn."eventStatusCode" else loco."eventStatus" end as "eventStatus"
,case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate"  then trn."eventLocationStation333" else loco."eventLocationStation333" end as "eventLocationStation333"
,case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate"  then trn."eventLocationStationState" else loco."eventLocationStationState" end as "eventLocationStationState"
,case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate"  then trn."eventDateTime"  else loco."eventDateTime" end as "eventDateTime"
,case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate" then trn."eventTimezoneLabel"  else loco."eventTimezoneLabel" end as "eventTimezoneLabel"
,case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate"  then trn."eventOffsetHours"  else loco."eventOffsetHours" end as "eventOffsetHours"

,loco."latitude" 
,loco."longitude" 
,loco."locomotiveCurrentPositionTimestamp"
,stn.stn_333 as "locomotiveDestinationStation333"
,stn.stn_st  as "locomotiveDestinationStationState"
,e."estimatedArrivalUtc" AS "etalocomotiveDestinationUtc" 
,e."estimatedArrivalTimezoneLabel" AS "locomotiveDestinationTimezoneLabel"
,e."estimatedArrivalUtcOffsetValueHours" AS "locomotiveDestinationOffsetHours"
,loco."locomotiveStatus"
,b."destinationStation_333" as "trainDestinationStation333"
,b."destinationStationSt" as "trainDestinationStationState"
,b."destinationStationSequenceNumber"
,c."estimatedArrivalUtc" as "etaTrainDestinationUtc"
,c."estimatedArrivalTimezoneLabel" as "trainDestinationTimezoneLabel"
,c."estimatedArrivalUtcOffsetValueHours" as "trainDestinationOffsetHours"
,loco."locoArrivalSequence"
,loco."locomotiveLocationCode"
,stn2.rgn_cd as "regionCode"
,stn2.srgn_cd as "subRegionCode"
,stn2.div_cd as  "divisionCode"
,Greatest(loco."timestampUpdate" ,trn."timestampUpdate" ) as "timestampUpdate"
--,trn."trainIdentification" as "trainIdentifierReportedByTrain" 
,loco."eventCode" as "eventCodeReportedByLoco"
,trn."eventCode" as "eventCodeReportedByTrain"
,loco."eventStatus" as "eventStatusCodeReportedByLoco"
,trn."eventStatusCode" as "eventStatusCodeReportedByTrain"
,loco."eventLocationStation333"  as "eventLocationStation333ReportedByLoco"
,trn."eventLocationStation333"  as "eventLocationStation333ReportedByTrain"
,loco."eventLocationStationState" as "eventLocationStationStateReportedByLoco"
,trn."eventLocationStationState" as "eventLocationStationStateReportedByTrain"
,loco."eventDateTime" as "eventDateTimeReportedByLoco"
,trn."eventDateTime"   as "eventDateTimeReportedByTrain"
,loco."eventTimezoneLabel"  as  "eventTimezoneLabelReportedByLoco"
,trn."eventTimezoneLabel"  as  "eventTimezoneLabelReportedByTrain"
,loco."eventOffsetHours"  as  "eventOffsetHoursReportedByLoco"
,trn."eventOffsetHours"  as  "eventOffsetHoursReportedByTrain"
from daas_tm_prepared.dh_aset m 
left join daas_tm_trusted.f_get_loco_event_by_locoid(m.id_val) loco on true
left join daas_tm_trusted.f_get_dh_trainid_by_locoid(m.id_val) trn on true
left join daas_tm_trusted.f_run_dh_get_train_schedule_origin_detination_by_trainid(case when loco."locomotiveLocationCode" ='T' then trn."trainIdentification" else NULL end) b on true
left join daas_tm_trusted.f_run_dh_get_train_station_detail_by_trainid(case when loco."locomotiveLocationCode" ='T' then trn."trainIdentification" else NULL end) c on  c."stationSequenceNumber"=b."destinationStationSequenceNumber"
left join daas_tm_trusted.f_run_dh_get_train_station_detail_by_trainid(case when loco."locomotiveLocationCode" ='T' then trn."trainIdentification" else NULL end) e on  
cast(e."stationSequenceNumber" as integer)=cast(loco."locoArrivalSequence" as integer)
left join daas_tm_prepared.dh_rail_station stn on stn.scac=e."stationScac" and stn.fsac=e."stationFsac"
left join daas_tm_prepared.dh_rail_station stn2 on stn2.stn_333 = case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate"  then trn."eventLocationStation333" else loco."eventLocationStation333" end 
and stn2.stn_st = case when loco."locomotiveLocationCode" ='T' and trn."timestampUpdate" > loco."timestampUpdate"  then trn."eventLocationStationState" else loco."eventLocationStationState" end
where m.aset_type_key='08e8d3db4a88f4048af2d4afa8e241965560177eeaa88d8f5eab57e9641c2249'  --Locomotive
--and m.id_val='CN2025'
and m.act_stus_ind=1 ;


