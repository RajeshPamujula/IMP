DROP VIEW IF EXISTS daas_tm_trusted."vContainerDetail" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vContainerDetail"
AS
select
e.id_val as "containerIdentification"
,e.cnvy_key as container_cnvy_key
,f1.char_val as "containerInitial"
,f2.char_val as "containerNumber"
,stcc."standardTransportationCommodityCode"
,stcc."commodityDescriptionAbbreviation"
,stcc."commodity15Description"
,addstcc."additionalStcc" as "containerAdditionalStcc" -- this is arrary
,scond."specialConditionCode1" as "containerSpecialConditionCode1"
,spcl1.trsp_cd_dsc_eng as "containerSpecialConditionCode1EnglishDescription"
,spcl1.trsp_cd_dsc_fr as "containerSpecialConditionCode1FrenchDescription"
,scond."specialConditionCode2" as "containerSpecialConditionCode2"
,spcl2.trsp_cd_dsc_eng as "containerSpecialConditionCode2EnglishDescription"
,spcl2.trsp_cd_dsc_fr as "containerSpecialConditionCode2FrenchDescription"
,scond."specialConditionCode3" as "containerSpecialConditionCode3"
,spcl3.trsp_cd_dsc_eng as "containerSpecialConditionCode3EnglishDescription"
,spcl3.trsp_cd_dsc_fr as "containerSpecialConditionCode3FrenchDescription"
,scond."specialConditionCode4" as "containerSpecialConditionCode4"
,spcl4.trsp_cd_dsc_eng as "containerSpecialConditionCode4EnglishDescription"
,spcl4.trsp_cd_dsc_fr as "containerSpecialConditionCode4FrenchDescription"
,scond."specialConditionCode5" as "containerSpecialConditionCode5"
,spcl5.trsp_cd_dsc_eng as "containerSpecialConditionCode5EnglishDescription"
,spcl5.trsp_cd_dsc_fr as "containerSpecialConditionCode5FrenchDescription"
,scond."specialConditionCode6" as "containerSpecialConditionCode6"
,spcl6.trsp_cd_dsc_eng as "containerSpecialConditionCode6EnglishDescription"
,spcl6.trsp_cd_dsc_fr as "containerSpecialConditionCode6FrenchDescription"
FROM daas_tm_prepared.dh_cnvy e
left join daas_tm_prepared.dh_cnvy_char f1 on e.cnvy_key=f1.cnvy_key and f1.act_stus_ind=1
and f1.char_type_key='53223cc5252d3111a784717f660a45a277a813430ed44561fc46bd7028fc6836' --Equipment Initial, not use container initial
left join daas_tm_prepared.dh_cnvy_char f2 on e.cnvy_key=f2.cnvy_key and f2.act_stus_ind=1
and f2.char_type_key='4b784c8ef416376b15dcc4a491e6fefe7f994d1da63a1729d18e793799de3b86' --Equipment Number
left join daas_tm_prepared.dh_ship_asct c on c.asct_obj_key=e.cnvy_key -- e.cnvy_key is container
left join daas_tm_prepared.dh_ship_char d on d.ship_key=c.ship_key
and d.char_type_key='897396de662fb7e14d0996db576e4a27eda9cb72f6db19414204cda5ab9bf3bd' -- Standard Transportation Commodity Code
left join daas_tm_trusted.f_get_stcc_description_by_stcc (d.char_val) stcc on true
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key (c.ship_key) scond on true
------ to get the special condition descriptions
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl1 ON scond."specialConditionCode1" = spcl1.trsp_cd and trim(spcl1.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl2 ON scond."specialConditionCode2" = spcl2.trsp_cd and trim(spcl2.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl3 ON scond."specialConditionCode3" = spcl3.trsp_cd and trim(spcl3.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl4 ON scond."specialConditionCode4" = spcl4.trsp_cd and trim(spcl4.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl5 ON scond."specialConditionCode5" = spcl5.trsp_cd and trim(spcl5.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl6 ON scond."specialConditionCode6" = spcl6.trsp_cd and trim(spcl6.trsp_cd_type) = 'Special Car Handling Instruction'

left join daas_tm_trusted.f_get_additional_stcc_by_ship_key(c.ship_key) addstcc on true --c.ship_key
where 1=1
;