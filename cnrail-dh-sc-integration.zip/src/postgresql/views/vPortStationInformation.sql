DROP VIEW IF EXISTS "vPortStationInformation";

CREATE OR REPLACE VIEW "vPortStationInformation"
AS

select rail_station.scac as "scac",
rail_station.fsac as "fsac",
rail_station.stn_333 as "station333",
rail_station.stn_st as "stationState",
rail_station.stn_nm as "stationName",
case when rail_station.stn_st in('PQ','ON','BC','AB','NF','NB','PE','NS','SK','MB') then 'CA' else 'US' end as "countryCode",
bus_prtr_char_2.char_val as "portOperatorNumber",
bus_prtr_char_3.char_val as "portOperator633",
bus_prtr_char.char_val as "portOperatorName",
LA_char.char_val as "portCutOffHours",
bus_prtr_char_4.char_val as "etaThresholdHours",
trim(la_char_2.char_val) as "eeSeaPortCode"
from daas_tm_prepared.dh_bus_prtr bus_prtr
inner join daas_tm_prepared.dh_bus_prtr_char bus_prtr_char on (bus_prtr.bus_prtr_key = bus_prtr_char.bus_prtr_key and bus_prtr_char.act_stus_ind = 1 and bus_prtr_char.char_type_key = '0af01db1ec35b38b2871cf15c71a8bbbaa8e6d2b55c2f3e5608a76d399ba8699')--business partner name --> port Operator name
inner join DAAS_tm_prepared.dh_bus_prtr_char bus_prtr_char_2 on
(bus_prtr.bus_prtr_key = bus_prtr_char_2.bus_prtr_key and
bus_prtr_char_2.act_stus_ind = 1 and bus_prtr_char_2.char_type_key = '0b1821f40450113c8ce372b1cc14a2865520c66493a36d225a353a1f6bbbeb94')-- customer number --> port Operator Number
inner join DAAS_tm_prepared.dh_bus_prtr_char bus_prtr_char_3 on
(bus_prtr.bus_prtr_key = bus_prtr_char_3.bus_prtr_key and
bus_prtr_char_3.act_stus_ind = 1 and bus_prtr_char_3.char_type_key
=
'505f6bad7a9b81a7f7f211e95a6fa5c4ac303e1af8798d517141e9a2839b2ea2')-- business Partner Name 633 --> port Operator 633
inner join DAAS_tm_prepared.dh_bus_prtr_char bus_prtr_char_4 on
(bus_prtr.bus_prtr_key = bus_prtr_char_4.bus_prtr_key and bus_prtr_char_4.act_stus_ind = 1 and bus_prtr_char_4.char_type_key =
'af60c55e51d1695348df620787f57d64b0974dedb1161e8fdb8a53c164f593ae')-- ETA Threshold
inner join daas_tm_prepared.dh_ref_type bus_prtr_char_type on
(bus_prtr_char.char_type_key = bus_prtr_char_type.type_key)
inner join daas_tm_prepared.dh_loc_asct LADE on
(bus_prtr.bus_prtr_key = LADE.asct_obj_key)
inner join daas_tm_prepared.dh_loc_asct_char LA_char on (lade.asct_key = LA_char.asct_key and la_char.act_stus_ind =1          and la_char.char_type_key =
'1e0dc823d2f980724a3c0f6f8384725bf15d52371da2abc06df0bfb663be635b')-- Port Cut-off)
inner join daas_tm_prepared.dh_loc_asct_char LA_char_2 on (lade.asct_key = LA_char_2.asct_key and la_char_2.act_stus_ind = 1        and la_char_2.char_type_key =
'0ddf505f41f41b694e881313db1774aed8c0347e8315d85fe79548933c4a1a59')-- eeSea Terminal Id --> eeSea Port code
left join daas_tm_prepared.dh_rail_station rail_station On (LADE.loc_key = rail_station.stn_fsac_key)
where bus_prtr.bus_prtr_type_key = '375cc4b1170cfc7ffcea1f62d157d8007f3738d6f375bdf13cd612b37cfbb3cd' ---'Port Operator'
and bus_prtr.act_stus_ind = 1
;