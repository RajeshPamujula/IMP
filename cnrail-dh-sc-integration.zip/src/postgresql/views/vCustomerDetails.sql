DROP VIEW IF EXISTS "vCustomerDetails" CASCADE;

CREATE OR REPLACE VIEW "vCustomerDetails"
as
SELECT
id_val as "customerNumber"
,cond1.char_val as "customerStatus"
,char1.char_val as "customer633"
,char2.char_val as "customerName"
,char3.char_val AS "equipmentOwnertype"
,char4.char_val AS "equipmentOwnerAbbreviation"
FROM daas_tm_prepared.dh_bus_prtr
INNER JOIN daas_tm_prepared.dh_ref_type ref ON bus_prtr_type_key = ref.type_key AND ref.type_key = '9ee460d6271fa6d30ea34378302dda0b7f8c3e6524d9d00490dcbff4b270ceda' ---'Business Partner/Customer'
LEFT JOIN daas_tm_prepared.dh_bus_prtr_cond cond1 ON dh_bus_prtr.bus_prtr_key = cond1.bus_prtr_key AND cond1.char_type_key = 'b0dbb55054f31f2fe32f4b5d2d283ec890ed91aaa61a8b6413a6b70508c13c95' --Customer Status
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char char1 ON dh_bus_prtr.bus_prtr_key = char1.bus_prtr_key AND char1.char_type_key = 'bd9dae217a0a467e1d4ab7e34974038e2001b9361a106a8a088debd5c5430e14' --Customer 633
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char char2 ON dh_bus_prtr.bus_prtr_key = char2.bus_prtr_key AND char2.char_type_key = '28fa08b6d074f1abef54d8137ee775f0c86b5d3246929eb140b56e963c8263c6' --Customer Name
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char char3 ON dh_bus_prtr.bus_prtr_key = char3.bus_prtr_key AND char3.char_type_key = '109bf075b3c8df3bb31aeeab84bd20f95cfd27d177fdebab4581732024e93b54' --Equipment Owner Type
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char char4 ON dh_bus_prtr.bus_prtr_key = char4.bus_prtr_key AND char4.char_type_key = 'f49d12114258c1c62ec26c7d9be537d35935a60a6cbacea03ec85a7e9840d58c' --Equipment Owner Abbreviation
ORDER BY id_val;