DROP VIEW IF EXISTS daas_tm_trusted."vUnitShipmentDetailWaybill" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vUnitShipmentDetailWaybill"
AS
SELECT cnvy.id_val AS "unitIdentifier" 
     , ship.id_val AS "waybillIdentifier"
	 , ship.ship_key as "ship_key"
     , cc."shuttleEquipmentIndicator" AS "shuttleEquipmentIndicator" 
     , sac.Empty_Order_Number AS "emptyOrderNumber"
     , fcc1.true_kingpin AS "trueKingpin"      
     , fcc1.Refrigerator_Position_Code as "refrigeratorPositionCode" 
     , sac.Shuttle_Destination_333 AS "shuttleDestination333"
     , sac.Shuttle_Destination_333_Province_State_Code AS "shuttleDestination333ProvinceStateCode"
     , fsc1.Level_of_Service_Code AS "levelOfServiceCode" 
     , cc."yardBlock" AS "yardBlock" 
     , cc."nextAssignment" AS "nextAssignment" 
     , fsc1.Bill_of_Lading_Number AS "billOfLadingNumber" 
     , fsc1.Bill_of_Lading_Date AS "billOfLadingDate" 
     , fsc1.Carrier_Abbreviation_On AS "carrierAbbreviationOn" 
     
     , fsc1.Customer_Supplied_Net_Weight AS "customerSuppliedNetWeight" 
     , fsc1.Customer_Supplied_Weight_Code AS "customerSuppliedWeightCode" 
     , fsc1.Customer_Supplied_Weight_UOM AS "customerSuppliedWeightUOM" 
     , fsc1.Rail_Destination_333 AS "railDestination333" 
     , fsc1.Rail_Destination_333_Province_State_Code AS "railDestination333ProvinceStateCode" 
     , fsc1.Destination_Ramp_333 AS "destinationRamp333" 
     , fsc1.Destination_Ramp_333_Province_State_Code AS "destinationRamp333ProvinceStateCode"      
     , DATE(sc.sor_evt_ts) AS "eventDate" 
     , CAST(sc.sor_evt_ts AS TIME) AS "eventTime" 
     , sc.sor_evt_ts AS "eventTimestamp"      
     , fsc1.Gross_Scale_Weight AS "grossScaleWeight" 
     , fsc1.Standard_Transportation_Commodity_Code AS "standardTransportationCommodityCode" 
   
	 , scond."intermodalHandlingCode1"
	 , scond."intermodalHandlingCode2"
	 , scond."intermodalHandlingCode3"
     , fsc1.Load_Empty_Status_Code AS "loadEmptyStatusCode" 
     , fsc1.Net_Scale_Weight AS "netScaleWeight" 
     , fsc1.Operating_Railroad_At_Junction_Point AS "operatingRailroadAtJunctionPoint"      
     , fsc1.Operating_City AS "operatingCity" 
     , fsc1.Operating_City_Province_State_Code AS "operatingCityProvinceStateCode" 
     , shipchar.char_val AS "originRamp333" 
     , fsc1.Origin_Ramp_333_Province_State_Code AS "originRamp333ProvinceStateCode" 
     , fsc1.Rail_Origin_333 AS "railOrigin333" 
     , fsc1.Rail_Origin_333_Province_State_Code AS "railOrigin333ProvinceStateCode" 
     , fsc1.Intermodal_Plan_Number AS "intermodalPlanNumber" 
     , fcc1.Rail_Control_Code AS "railControlCode" 
     , cc."refrigeratorFuelLevel" AS "refrigeratorFuelLevel" 
     , cc."refrigeratorRunningTemperature" AS "refrigeratorRunningTemperature" 
     , fsc1.PPSI_Temparature AS "ppsiTemparature" 
     , fsc1.PPSI_Temperature_UOM AS "ppsiTemperatureUOM" 
	, scond."specialConditionCode1"
	, scond."specialConditionCode2"
	, scond."specialConditionCode3"
	, scond."specialConditionCode4"
	, scond."specialConditionCode5"
	, scond."specialConditionCode6"
     , fsc1.Total_Lading_Weight AS "totalLadingWeight" 
     , fsc1.Waybill_Date AS "waybillDate" 
     , scond."waybillErrorCode"
     , fsc1.Waybill_Number AS "waybillNumber"
     , fsc1.Waybill_Record_Type AS "waybillRecordType" 
      ,shipcond.char_val as "waybillStatusCode"
     , fsc1.Weight_Allowance_1 AS "weightAllowance1" 
     , fsc1.Weight_Allowance_2 AS "weightAllowance2" 
     , fsc1.Weight_Unit_Code AS "weightUnitCode" 
     , fsc1.Reservation_Number AS "reservationNumber" 

     , cc."balanceOwedIndicator"as "storageChargeIndicator" 
     ,cmc."commodityDescriptionAbbreviation" AS "commodityDescriptionAbbreviation"
     , cc."firstStorageChargeDate" AS "firstStorageChargeDate"
     , cc."storageChargeStatusCode" AS "storageChargeStatusCode"     
     , stn1.fsac AS "railDestinationFsac" 
     , stn1.scac AS "railDestinationScac" 
     , stn2.fsac AS "destinationRampFsac" 
     , stn2.scac AS "destinationRampScac" 
     , stn3.fsac AS "originRampFsac" 
     , stn3.scac AS "originRampScac" 
     , stn4.fsac AS "railOriginFsac" 
     , stn4.scac AS "railOriginScac" 
	 
     , fsc1.Ingate_Placard_Code AS "ingatePlacardCode"
	 , fsc1.Net_Scale_Weight_UOM AS "netScaleWeightUOM"
	 , sr."sealRange"
	 , fsc1.Pickup_Number as "pickupNumber"
	 , cc."loadSheetHoldCode" as "loadSheetBlockHold"
	 --, fsc1.Load_Sheet_Block_Hold as "loadSheetBlockHold"
	 , fsc1.Import_Export_Code as "importExportCode"
from daas_tm_prepared.dh_ship ship
inner join daas_tm_prepared.dh_ship_char shipchar on ship.ship_key = shipchar.ship_key 
and shipchar.act_stus_ind= 1
and shipchar.char_type_key = '418b49a8156170759c643aec85b4227271b81e33b2a4d2125d92231b2906bc90'  --Origin Ramp 333
inner join daas_tm_prepared.dh_ship_cond shipcond on shipcond.ship_key=ship.ship_key 
and shipcond.act_stus_ind=1
and shipcond.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083'  --waybill status code

inner join daas_tm_prepared.dh_ship_char sc ON sc.act_stus_ind = 1 AND ship.ship_key=sc.ship_key 
AND sc.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' -- Equipment ID

inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.id_val =sc.char_val 
and cnvy.act_stus_ind=1
and cnvy.cnvy_type_key in(
'e91b3bb060fea6f9d741db9db19e3328be5f64f34429ff2e66aa176cdcf24133',  --Intermodal Unit
'8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a',  --Container
'20ba3d6edbfbaab0653bd3314bf4ec3a1f6049daa8ab757fd2c8621944a3f4cf',   --Chassis
'011acac69fa2afa34a95160ed404f7366a1543e6ad88cb7e34c21be43ccc4f0f'    --Trailer

) 

LEFT JOIN daas_tm_prepared.dh_ship_asct sa ON sa.act_stus_ind = 1 AND ship.ship_key = sa.ship_key
and sa.asct_type_key='3de22246a9c11b9fa0fae553613839d4fa5e077ff8bbbf7ee43eef0725c434c2'  --Inter-BCD Shipment-Conveyor
left join daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key(cnvy.cnvy_key) cc on true
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(ship.ship_key) scond on true 
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key(cnvy.cnvy_key) fcc1 ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(ship.ship_key) fsc1 ON 1=1
-- scac/fsac can be added in the function
LEFT JOIN daas_tm_prepared.dh_rail_station stn1 ON stn1.stn_333 = fsc1.Rail_Destination_333 
AND stn1.stn_st = case when fsc1.Rail_Destination_333_Province_State_Code='QC' then 'PQ' else fsc1.Rail_Destination_333_Province_State_Code end 
LEFT JOIN daas_tm_prepared.dh_rail_station stn2 ON stn2.stn_333 = fsc1.Destination_Ramp_333 
AND stn2.stn_st = case when fsc1.Destination_Ramp_333_Province_State_Code='QC' then 'PQ' else fsc1.Destination_Ramp_333_Province_State_Code end 
LEFT JOIN daas_tm_prepared.dh_rail_station stn3 ON stn3.stn_333 = fsc1.Origin_Ramp_333 
AND stn3.stn_st = case when fsc1.Origin_Ramp_333_Province_State_Code='QC' then 'PQ' else fsc1.Origin_Ramp_333_Province_State_Code end 

LEFT JOIN daas_tm_prepared.dh_rail_station stn4 ON stn4.stn_333 = fsc1.Rail_Origin_333 
AND stn4.stn_st = case when fsc1.Rail_Origin_333_Province_State_Code='QC' then 'PQ' else fsc1.Rail_Origin_333_Province_State_Code end 



LEFT JOIN daas_tm_trusted.f_get_dh_ship_asct_char_equipment_by_asct_key(sa.asct_key) sac on true 
left join daas_tm_trusted.f_get_stcc_description_by_stcc(fsc1.Standard_Transportation_Commodity_Code) cmc on 1=1 																				  
left join daas_tm_trusted.f_get_seal_range_by_ship_key(ship.ship_key) sr on true
WHERE cnvy.act_stus_ind = 1 
-- and cnvy.id_val='GCNU472762'
;

