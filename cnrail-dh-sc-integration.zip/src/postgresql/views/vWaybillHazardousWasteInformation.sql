DROP VIEW IF EXISTS daas_tm_trusted."vWaybillHazardousWasteInformation" cascade;

create view daas_tm_trusted."vWaybillHazardousWasteInformation" as 
select 
a.ship_key  as "shipmentKey",
b.id_val  as "waybillIdentification",
a.data_hub_crt_ts  as "dataHubCreationTimestamp",
a.haz_seq   as  "hazardousSequence" ,
a.peles_line_nbr   as  "elsPermitLineNumber",
a.peles_ntc_nbr   as  "elsPermitNoticeNumber",
a.peles_sch_arr_dt   as  "elsPermitScheduledArrivalDate",
a.haz_wast_mfst_id   as  "hazardousWasteManifestIdentifier",
a.fclty_id   as  "facilityIdentifier",
a.haz_mfst_id   as  "hazardousManifestIdentifier",
a.haz_mfst_gen_nm   as  "hazardousManifestGeneratorName",
a.haz_mfst_gen_addr   as  "hazardousManifestGeneratorAddress",
a.haz_mfst_gen_city_nm   as  "hazardousManifestGeneratorCityName",
a.haz_mfst_gen_st   as  "hazardousManifestGeneratorProvinceState",
a.haz_mfst_gen_zip   as  "hazardousManifestGeneratorPostalCode",
a.haz_mfst_tel_nbr   as  "hazardousManifestTelephoneNumber",
a.fclty_nm   as  "facilityName",
a.fclty_addr   as  "facilityAddress",
a.fclty_city_nm   as  "facilityCityName",
a.fclty_st   as  "facilityProvinceState",
a.fclty_zip   as  "facilityPostalCode",
a.dest_fclty_tel_nbr   as  "destinationFacilityTelephoneNumber",
a.haz_mfst_hndl_insn   as  "hazardousManifestHandlingInstruction",
a.trsp_co_nm_1	   as  "transportationCompanyName1",
a.trsp_co_nm_2	   as  "transportationCompanyName2",
a.trsp_co_nm_3	   as  "transportationCompanyName3",
a.trsp_co_nm_4	   as  "transportationCompanyName4",
a.haz_trsp_id   as  "hazardousTransportationIdentifier",
a.haz_trsp_id_2   as  "hazardousTransportationIdentifier2",
a.haz_trsp_id_3   as  "hazardousTransportationIdentifier3",
a.haz_trsp_id_4   as  "hazardousTransportationIdentifier4",
a.haz_trsp_tel_nbr   as  "hazardousTransporterTelephoneNumber",
a.haz_trsp_tel_nbr_2   as  "hazardousTransporterTelephoneNumber2",
a.haz_trsp_tel_nbr_3   as  "hazardousTransporterTelephoneNumber3",
a.haz_trsp_tel_nbr_4   as  "hazardousTransporterTelephoneNumber4"
from daas_tm_prepared.dh_wb_haz_wast_info a
inner join daas_tm_prepared.dh_ship b on a.ship_key=b.ship_key and b.act_stus_ind=1
where a.act_stus_ind=1;