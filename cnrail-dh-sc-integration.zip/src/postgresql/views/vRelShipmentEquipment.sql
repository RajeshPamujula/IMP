drop view if exists daas_tm_trusted."vRelShipmentEquipment" cascade;
CREATE OR REPLACE VIEW daas_tm_trusted."vRelShipmentEquipment"
AS
select 
a.id_val as "waybillIdentification"
,a.ship_key as "shipmentKey"
,cnvy.id_val as "equipmentIdentification"
,cnvy.cnvy_key as "conveyorKey"
,cnvy_char.Equipment_Initial as "equipmentInitial"
,cnvy_char.Equipment_Number  as "equipmentNumber"
,cnvy_char.Car_Kind   as "carKind"
,ship_char1.char_val as "waybillNumber"
,ship_cond.char_val as "waybillStatusCode"
,ship_char3.char_val as "waybillTypeCode"
from  daas_tm_prepared.dh_ship a 
inner join daas_tm_prepared.dh_ship_char as ship_char1 on a.ship_key=ship_char1.ship_key and ship_char1.act_stus_ind=1
and ship_char1.char_type_key='8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0'  -- Waybill Number
inner join daas_tm_prepared.dh_ship_char as ship_char2 on a.ship_key=ship_char2.ship_key and ship_char2.act_stus_ind=1
and ship_char2.char_type_key='31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296'  -- Equipment ID
inner join daas_tm_prepared.dh_ship_char as ship_char3 on a.ship_key=ship_char3.ship_key and ship_char3.act_stus_ind=1
and ship_char3.char_type_key='c57d0d67f26f0d7450d1962621fa4f9748b11258159649ab23de0e5c4d1f860a'  -- Waybill Type Code
left join daas_tm_prepared.dh_cnvy cnvy on (ship_char2.char_val = cnvy.id_val  and cnvy.act_stus_ind = 1)
left join daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key(cnvy.cnvy_key ) cnvy_char on true
left join daas_tm_prepared.dh_ship_cond ship_cond on ship_cond.ship_key=a.ship_key and ship_cond.act_stus_ind=1
and ship_cond.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083'   --Waybill Status Code
where a.act_stus_ind=1
--and ship_char1.char_val ='654739'
--and a.ship_key='d366ed1dd6aef3fc1c472a1247ecec50c90f16df84fad6f6d16ba9376f6e3360'
;
