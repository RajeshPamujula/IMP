DROP VIEW IF EXISTS daas_tm_trusted."vCarCharacteristicsLastUpdateTimestamp" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vCarCharacteristicsLastUpdateTimestamp"
AS
SELECT
cnvy.id_val as "equipmentIdentifier"
,a.char_val as "equipmentInitial"
,b.char_val as "equipmentNumber"
,c.char_val as "loadLimit"
,c.data_hub_crt_ts as "loadLimitLastTimestamp"
,d.char_val as "equipmentTare"
,d.data_hub_crt_ts as "equipmentTareLastTimestamp"
--,c.sor_tpic_nm --technical field for debug
--,d.sor_tpic_nm --technical field for debug
FROM daas_tm_prepared.dh_cnvy cnvy
INNER JOIN daas_tm_prepared.dh_cnvy_char a on cnvy.cnvy_key = a.cnvy_key AND a.act_stus_ind=1
AND a.char_type_key ='53223cc5252d3111a784717f660a45a277a813430ed44561fc46bd7028fc6836' --Equipment Initial
INNER JOIN daas_tm_prepared.dh_cnvy_char b on cnvy.cnvy_key = b.cnvy_key and b.act_stus_ind=1
AND b.char_type_key ='4b784c8ef416376b15dcc4a491e6fefe7f994d1da63a1729d18e793799de3b86' --Equipment Number
INNER JOIN daas_tm_prepared.dh_cnvy_char c
ON cnvy.cnvy_key = c.cnvy_key AND cnvy.act_stus_ind = c.act_stus_ind AND c.char_type_key ='88e1c02ec20c72583b22209c290d71221b4a13ba15b98d0decd1fa382f0e5f24' --Load Limit
INNER JOIN daas_tm_prepared.dh_cnvy_char d
ON cnvy.cnvy_key = d.cnvy_key AND cnvy.act_stus_ind = d.act_stus_ind AND d.char_type_key ='cec6293fee578b4be058cbee8629c394891e36d5b6646732364d94f53c2fdb2c' --Equipment Tare
WHERE cnvy.act_stus_ind = 1
--and cnvy.id_val='CRDX3090'
;