DROP VIEW IF EXISTS daas_tm_trusted."vContainerVessel" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vContainerVessel"
AS
select 
--ship.ship_key, 
--ship_cmp.ship_cmp_key, 
scc1.char_val as "vesselIdentifier",
r_char_2.char_val AS "voyageNumber",
cnvyc2.char_val  AS "vesselOwner",
bus_prtr_char.char_val as "portOperator633",
scc4.char_val as "voyageBookingNumber",
scc3.char_val as "inboundOutboundCode",
scc2.char_val as "vesselName",
ship.id_val as "waybillIdentifier", 
a.Waybill_Number as "waybillNumber",
scond.char_val as "waybillStatusCode",										 
schar.char_val as "containerIdentifier"									 
,a.Load_Empty_Status_Code as "loadEmptyStatusCode"
,a.Rail_Origin_333 as "railOriginStation333"
,a.Rail_Origin_333_Province_State_Code as "railOrigin333StationState"
,a.Rail_Destination_333 as "railDestinationStation333"
,a.Rail_Destination_333_Province_State_Code as "railDestinationStationState"
,a.Check_Digit as "checkDigit"
from daas_tm_prepared.dh_ship ship
INNER JOIN daas_tm_prepared.dh_ship_cmp ship_cmp on ship.ship_key = ship_cmp.ship_key AND ship_cmp.act_stus_ind = 1 and ship.act_stus_ind=1
AND ship_cmp_type_key = 'af82909b34df99ece8af4b140307841a3a899bac846f096ff2a3efcbed32f44c' --Intra-Domain Shipment-Shipment-Voyage-Segment
INNER JOIN daas_tm_prepared.dh_ship_cmp_char scc1 on scc1.ship_cmp_key=ship_cmp.ship_cmp_key and scc1.act_stus_ind=1 
and scc1.char_type_key='33b37227ce0b89435a341ef230a6d906a78656cf6d46f7342f24832157bae225' -- Vessel ID
INNER JOIN daas_tm_prepared.dh_ship_cmp_char scc2 on scc2.ship_cmp_key=ship_cmp.ship_cmp_key and scc2.act_stus_ind=1 
and scc2.char_type_key='923bbadd3545994daaeaf56ca373c1e552e66b84231c596c67018ae3bed8a179' -- Vessel Name
INNER JOIN daas_tm_prepared.dh_ship_cmp_char scc3 on scc3.ship_cmp_key=ship_cmp.ship_cmp_key and scc3.act_stus_ind=1 
and scc3.char_type_key='5b8d28544f7cd40381850b85ef5d786c84a27299041e02a4b15073af09a7732f' -- Inbound Outbound Code
LEFT JOIN daas_tm_prepared.dh_ship_cmp_char scc4 on scc4.ship_cmp_key=ship_cmp.ship_cmp_key and scc4.act_stus_ind=1 
and scc4.char_type_key='333e160bbeb91b67cdd9c4418c0c0b7559fc8734e4fe3bd697a419bdc31cdb9d' -- Voyage Booking Number
INNER JOIN daas_tm_prepared.dh_ship_char schar on ship.ship_key = schar.ship_key and schar.act_stus_ind=1
and schar.char_type_key='31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
INNER JOIN daas_tm_prepared.dh_ship_cond scond ON scond.ship_key=ship.ship_key and scond.act_stus_ind=1
and scond.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083'  --Waybill Status Code
INNER JOIN daas_tm_prepared.dh_cnvy cnvy on cnvy.id_val =scc1.char_val and cnvy.act_stus_ind=1
--and  vessel type
INNER JOIN daas_tm_prepared.dh_cnvy_char cnvyc2 ON cnvy.cnvy_key=cnvyc2.cnvy_key and cnvyc2.act_stus_ind=1
and cnvyc2.char_type_key ='b305623ff70c43803f6a8b40ae84626a574ecd37c82937faff9f2c21e803889e'  --Vessel Owner

INNER JOIN daas_tm_prepared.dh_cnvy_asct cnvy_asct on cnvy_asct.cnvy_key=cnvy.cnvy_key and cnvy_asct.act_stus_ind=1
and cnvy_asct.asct_type_key='2f622aab0a0f2a08fd6cb40c3bfa69dde5df09839314279a42931010c75fc02b' --Inter-BCD Conveyor-Route  
-- lots of dup(VOYG_NBR + LLOYD_VES_ID), filtered by VOYG_NBR later
INNER JOIN daas_tm_prepared.dh_rte rde on rde.rte_key = cnvy_asct.prim_obj_key and rde.act_stus_ind=1
and rde.rte_type_key = '2e7511ebde345fade6957c5d2a07e826e100c7f436832f1aa4f2045881709876' --Voyage Vessel
INNER JOIN DAAS_TM_PREPARED.dh_rte_char r_char_2  ON (rde.Rte_KEY = r_char_2.rte_KEY and r_char_2.act_stus_ind = 1 
and r_char_2.char_type_key = '9f228350a6eb570b6361ecbe10114e7cbbaa6562f5fe73d43e5d31a9a985cdcd') -- voyage number
INNER JOIN daas_tm_trusted.f_get_dh_ship_cmp_voyage_number_by_ship_key(ship.ship_key) v on v."voyageNumber"=r_char_2.char_val
INNER JOIN daas_tm_prepared.dh_plan_evt plan_evt  ON (rde.rte_key = plan_evt.prim_obj_key and plan_evt.act_stus_ind = 1)

INNER JOIN daas_tm_prepared.dh_plan_evt_asct pade  ON (plan_evt.plan_evt_key = pade.plan_evt_key and pade.act_stus_ind = 1)
LEFT JOIN daas_tm_prepared.dh_loc_asct lade  ON (pade.asct_obj_key = lade.asct_key and lade.act_stus_ind = 1 )
LEFT JOIN daas_tm_prepared.dh_rail_station rail_station  ON (lade.loc_key = rail_station.stn_333_key_conv or lade.loc_key = rail_station.stn_333_cn_key_conv)

LEFT JOIN daas_tm_prepared.dh_loc_asct loc_asct_2  ON (rail_station.stn_fsac_key = loc_asct_2.loc_key and loc_asct_2.act_stus_ind = 1 
and loc_asct_2.asct_obj_type_key = '375cc4b1170cfc7ffcea1f62d157d8007f3738d6f375bdf13cd612b37cfbb3cd') --- for port operator (CUST_CITY_333)
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char bus_prtr_char  ON (loc_asct_2.asct_obj_key = bus_prtr_char.bus_prtr_key and bus_prtr_char.act_stus_ind = 1 
and bus_prtr_char.char_type_key = '505f6bad7a9b81a7f7f211e95a6fa5c4ac303e1af8798d517141e9a2839b2ea2') -- port operator 633 (CUST_ST)
LEFT JOIN daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(ship.ship_key) a ON 1=1 -- to get waybill number,  Origin and destination
--where scc1.char_val='9335173'
--and r_char_2.char_val='EES0000005'
;
