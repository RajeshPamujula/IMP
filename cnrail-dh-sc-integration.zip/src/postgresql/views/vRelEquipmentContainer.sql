DROP VIEW IF EXISTS daas_tm_trusted."vRelEquipmentContainer" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vRelEquipmentContainer"
AS
select 
a.cnvy_key
, a.id_val as "equipmentIdentification"
, e.id_val as "containerIdentification"
, e.cnvy_key as container_cnvy_key
, asctc.char_val  as "platformPositionCode"
FROM daas_tm_prepared.dh_cnvy a
inner join daas_tm_prepared.dh_cnvy_asct b on a.cnvy_key=b.asct_obj_key and b.act_stus_ind=1 
and b.asct_type_key='0ba452470ff9f23b1d2e999f5afea823e1d7bab4913da2dc17aba3c6e784f011' --Intra-BCD Container-Railcar
and b.cnvy_type_key='8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a' -- container
inner join daas_tm_prepared.dh_cnvy e on b.cnvy_key=e.cnvy_key --and e.act_stus_ind=1
left join daas_tm_prepared.dh_cnvy_asct_char asctc  on asctc.asct_key=b.asct_key and asctc.act_stus_ind=1 
and asctc.char_type_key='db442b26e87d44a5489f02aa88d7b42cacdc24f189585abbda3f6583b89e5397' --Platform Position Code
where 1=1
--and a.id_val='DTTX25146'
--and e.id_val='PLHU100324'
;