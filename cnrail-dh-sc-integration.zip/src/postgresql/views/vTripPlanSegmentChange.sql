DROP VIEW IF EXISTS daas_tm_trusted."vTripPlanSegmentChange" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vTripPlanSegmentChange"
AS
select tpln_seg_key, data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_tpln_seg_char
union all
select tpln_seg_key, data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_tpln_seg ;



