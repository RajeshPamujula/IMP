drop view if exists daas_tm_trusted."vTrainScheduleUpdate";

create view daas_tm_trusted."vTrainScheduleUpdate"
as
with rtechanges as (
select rte.rte_key, a.data_hub_crt_ts, 'dh_plan_evt_char' as source, a.sor_evt_ts
from daas_tm_prepared.dh_rte rte
inner join daas_tm_prepared.dh_plan_evt plan_evt on rte.rte_key = plan_evt.prim_obj_key and rte.act_stus_ind=1 and plan_evt.act_stus_ind=1
inner join daas_tm_prepared.dh_plan_evt_char a on a.plan_evt_key=plan_evt.plan_evt_key and a.act_stus_ind=1
where 1=1
and (a.sor_tpic_nm like '%tm.raw.srs.trnETAETD%' or a.sor_tpic_nm like '%tm.raw.srs.trnScheduleActive.v2%')
and a.data_hub_crt_ts >=(now() - interval '1 hours' )
union all
select rte_key, data_hub_crt_ts, 'dh_rte_char' as source, sor_evt_ts
from daas_tm_prepared.dh_rte_char
where act_stus_ind=1 and data_hub_crt_ts >(now() - interval '1 hours' )
union all
select rte_key, data_hub_crt_ts, 'dh_rte' as source, sor_evt_ts
from daas_tm_prepared.dh_rte
where act_stus_ind=1 and data_hub_crt_ts >(now() - interval '1 hours' )

)
, latestrtechange as (
select rte_key,
rank() over (partition by rte_key order by data_hub_crt_ts desc ) as rk,
data_hub_crt_ts,
sor_evt_ts,
source
from rtechanges a
)
select cnvy_char_sel.char_val as "trainIdentification",
a.data_hub_crt_ts as "dataHubCreationTimestamp",
a.sor_evt_ts as "eventTimestamp",
case when source ='dh_rte_char' or source ='dh_rte' or EXTRACT(EPOCH FROM (a.data_hub_crt_ts -c.data_hub_crt_ts )) <=1000 then c.char_val
else '' end
as "trainScheduleChangeReason"
--,source
--,a.rte_key
--,c.data_hub_crt_ts
--,EXTRACT(EPOCH FROM (a.data_hub_crt_ts -c.data_hub_crt_ts )) as diff_time_planevtchar_rtechar
from latestrtechange a
inner join daas_tm_prepared.dh_cnvy_char cnvy_char_sel on a.rte_key = cnvy_char_sel.cnvy_key
and cnvy_char_sel.char_type_key = '2de848fbf4f4a1b422a4ac69aca68604254d48919aa8015e71079ec8f69382fb' --Train Unique Id
left join daas_tm_prepared.dh_rte_char c on a.rte_key=c.rte_key
AND c.char_type_key = '34aa2605f8b2e052ebc41adb1c8f99b8607db4d5f0a7c6cd7966d669bffc51cf' -- Train Schedule Change Reason
and c.act_stus_ind=1
where a.rk=1;