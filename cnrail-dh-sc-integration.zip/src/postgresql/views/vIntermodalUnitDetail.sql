drop view if exists daas_tm_trusted."vIntermodalUnitDetail";

create or replace view daas_tm_trusted."vIntermodalUnitDetail"
as
select 
b.cnvy_key,
greatest( p."dataHubCreationTimestamp",ship_asct.data_hub_crt_ts, q1."dataHubCreationTimestamp", q2."dataHubCreationTimestamp") as "dataHubCreationTimestamp",
greatest( p."eventTimestamp",ship_asct.sor_evt_ts, q1."eventTimestamp", q2."eventTimestamp") as "eventTimestamp",
p."conveyorType",
p."equipmentInitial",
p."equipmentNumber",
b.id_val as "unitIdentification",
p."carKind",
q2."badOrderCode",
q2."loadSheetHoldCode",
q2."balanceOwedIndicator" as "storageChargeIndicator",  
q1."specialConditionCode1",
q1."specialConditionCode2",
q1."specialConditionCode3",
q1."specialConditionCode4",
q1."specialConditionCode5",
q1."specialConditionCode6",
q2."mechanicalStatusCode1",
q2."mechanicalStatusCode2",
q2."mechanicalStatusCode3",
q2."firstStorageChargeDate",  
q1."intermodalHandlingCode1",
q1."intermodalHandlingCode2",
q1."intermodalHandlingCode3",
p."outsideLength",
p."outsideLengthUnitOfMeasure",
p."outsideHeight",
p."outsideHeightUnitOfMeasure",
p."outsideWidth",
p."outsideWidthUnitOfMeasure",
p."trueKingpin",
p."equipmentTareWeight",
p."equipmentTareWeightUnitOfMeasure",
p."loadLimit",
p."equipmentOwnerAbbreviation",
p."equipmentLesseeAbbreviation" as "unitLeasee",
sa_char1.char_val as "emptyOrderNumber" 

/*,

q1.ship_key,
q1."ProcessTimestamp" as "shipmentConditionProcessTimestamp" , -- ship cond 
sa_char1.asct_key as ship_asct_key,
sa_char1.rpt_sor_proc_ts as "shipmentAssociatoinProcessTimestamp",
p."conveyorCharProcessTimestamp",
q2.cnvy_key as railcar_cnvy_key,
q2."ProcessTimestamp" as"conveyorConditionProcessTimestamp"
*/
from  daas_tm_prepared.dh_cnvy b 
inner join daas_tm_trusted.f_run_dh_get_cnvy_char_by_container(b.cnvy_key) p on true
left join daas_tm_prepared.dh_ship_asct ship_asct on ship_asct.asct_obj_key=b.cnvy_key and ship_asct.act_stus_ind=1
and ship_asct.asct_type_key  ='3de22246a9c11b9fa0fae553613839d4fa5e077ff8bbbf7ee43eef0725c434c2'  --Inter-BCD Shipment-Conveyor
left join daas_tm_prepared.dh_ship_asct_char sa_char1 on (ship_asct.asct_key = sa_char1.asct_key and sa_char1.act_stus_ind =1 and sa_char1.char_type_key = 'd9d99aec0ae95b5ffc046ffa2f1812bc215f3915ee2ca8f2b326c59c6b81e057')  -- Empty Order Number
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(ship_asct.ship_key) q1 on true
left join daas_tm_trusted.f_get_dh_cnvy_cond_non_unit_location_by_cnvy_key(b.cnvy_key ) q2 on true  -- rail car cnvy key
--left join daas_tm_trusted.f_run_dh_get_cnvy_cond_by_container(b.cnvy_key) m on true
;

/*
test case:
select distinct cnvy_key
from daas_tm_trusted."vIntermodalUnitChange"
where "dataHubCreationTimestamp" > now()- interval '12 minutes';


select * from daas_tm_trusted."vIntermodalUnitDetail"  
where cnvy_key in
--('64f81b1b3992be9ff061d2fc1f6570b9c9041ba13d3d4c84f0fa04f4c072722c');

(
'4322ade84fee9eb59865c1194a8ddf9ed80f846653fa20a1b21838adb1f07130',
'9c719283a70ffa051a69b6463bb9e333e28bd8f87b2ad00e8b1b6d4f5a065984',
'c66a088b34f22a23497bd010ec989859d2dcbeb7815b7404621f82b44c0a070b'
)
*/