DROP VIEW IF EXISTS daas_tm_trusted."vTripPlanGoalChange" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vTripPlanGoalChange"
AS
select tpln_key, data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_tpln_char
union all
select tpln_key, data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_tpln ;



