DROP VIEW IF EXISTS daas_tm_trusted."vTripPlanSegment" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vTripPlanSegment"
AS
select 
Greatest(d."dataHubCreationTimestamp", c.data_hub_crt_ts) as "dataHubCreationTimestamp"
,b.id_val as "waybillIdentification"
,cnvy.id_val as "equipmentIdentification"
,c.tpln_seg_val as "tripPlanSequence"
,cc.char_val as "carKind"
,d."tripTypeCode" 
,d."eventCode"
,d."eventStatusCode"
,stn.scac as "stationScac"
,stn.fsac as "stationFsac" 
,CASE WHEN d."scheduleEventTimestamp" = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d."scheduleEventTimestamp", 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "scheduleEventTimestamp"
,CASE WHEN d."estimatedEventTimestamp" = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d."estimatedEventTimestamp", 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "estimatedEventTimestamp"
,CASE WHEN d."actualEventTimestamp" = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d."actualEventTimestamp", 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "actualEventTimestamp"
,d."stationSequenceNumber"
,d."trainIdentification"
,d."trainBlock"
,d."yardBlock"
,d."jeopardyReasonCode"
,d."rescheduleReasonCode"
,d."associatedEquipmentInitial" || d."associatedEquipmentNumber" as "associatedEquipmentIdentification"
,d."operatingRailroadAtJunctionPoint"
,d."opZTS"
,c.tpln_seg_key -- technical field used with vTripPlanSegmentChange
from daas_tm_prepared.dh_tpln_asct a
inner join daas_tm_prepared.dh_ship b on a.asct_obj_key=b.ship_key and b.act_stus_ind=1
inner join daas_tm_prepared.dh_tpln_seg c on a.prim_obj_key = c.prim_obj_key and c.act_stus_ind=1
inner join daas_tm_prepared.dh_cnvy cnvy on a.prim_obj_key = cnvy.cnvy_key and cnvy.act_stus_ind=1
inner join daas_tm_prepared.dh_cnvy_char cc on cc.cnvy_key=cnvy.cnvy_key
and cc.char_type_key='dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8' --Car Kind
and cc.act_stus_ind=1
inner join daas_tm_trusted.f_get_dh_tpln_seg_char_by_tpln_seg_key(c.tpln_seg_key) d on true
left join daas_tm_prepared.dh_rail_station stn on stn.stn_333=d."station333" 
and stn.stn_st= case when d."stationProvinceStateCode"='QC' then 'PQ' else d."stationProvinceStateCode" end 
where  a.act_stus_ind=1
--and cnvy.id_val='SIMU400253' 
--and b.id_val='9684-12-04-15.05.15.022020'
order by b.id_val,cnvy.id_val,lpad(c.tpln_seg_val ,5,'0')
;