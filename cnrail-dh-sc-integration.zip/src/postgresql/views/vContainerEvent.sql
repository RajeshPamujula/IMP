DROP VIEW IF EXISTS daas_tm_trusted."vContainerEvent" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vContainerEvent"
AS
SELECT
cnvy.id_val as "containerIdentifier"
,cc1.char_val as "containerInitial"
,cc2.char_val as "containerNumber"
,trsp_evt_char.Event_Code as "eventCode"
,trsp_evt_char.Event_Status as "eventStatus"
,CAST(case when trsp_evt_char.event_date is null or trsp_evt_char.event_date =''  then '1900-01-01' else trsp_evt_char.event_date end  as DATE) AS "eventDate"
,CAST(replace (case when trsp_evt_char.event_time ='' or trsp_evt_char.event_time is null then '00:00:00' else trsp_evt_char.event_time end ,'.',':') as TIME) AS "eventTime"
,CAST(case when trsp_evt_char.event_date is null or trsp_evt_char.event_date =''  then '1900-01-01' else trsp_evt_char.event_date end  as DATE) + 
CAST(replace (case when trsp_evt_char.event_time ='' or trsp_evt_char.event_time is null then '00:00:00' else trsp_evt_char.event_time end ,'.',':') as TIME)
as "eventDateTime"
,cast( case when trsp_evt_char.Event_Date_Time_UTC is null or trsp_evt_char.Event_Date_Time_UTC ='' then '1900-01-01' else trsp_evt_char.Event_Date_Time_UTC end  as timestamp) as "eventDateTimeUTC"
,dh_tz_dst_ref.tz_lbl AS "eventDateTimeZoneLabel"
,dh_tz_dst_ref.utc_ofst_val_hr AS "eventDateTimeOffsetValueHours" 
,trsp_evt_char.Action as "actionCode"
,trsp_evt_char.Equipment_Cycle_Id as "cycleIdentifier"
,tea.sor_tpic_nm  -- make sure all topic works
-- use dh_trsp_evt_asct to connect to dh_rail_station
,stn.scac as "scac"
,stn.fsac as "fsac"
,stn.stn_333 as "station333"
,stn.stn_st as "stationProvinceStateCode"
,trsp_evt_char."notation"
,greatest(te.sor_evt_ts, trsp_evt_char.sor_evt_ts,tea.sor_evt_ts) as "processDateTime"
,greatest(te.data_hub_crt_ts, trsp_evt_char."dataHubCreationTimestamp",tea.data_hub_crt_ts) as "dataHubCreationTimestamp"

, case when ccond."stripPlacement" ='' or ccond."stripPlacement" is null then 'N' else 'Y' end as "stripPlacementFlag"
, ccond."equipmentLocationCode"
, ccond."statusIndicator"
, ccond."operatingCity333"
, ccond."platformCode"
, ccond."planNumber"
, ccond."voyageBookingNumber"
from daas_tm_prepared.dh_trsp_evt te
INNER JOIN daas_tm_prepared.dh_cnvy cnvy ON cnvy.cnvy_key = te.prim_obj_key and cnvy.act_stus_ind=1
INNER JOIN daas_tm_prepared.dh_cnvy_char cc1 on cc1.cnvy_key=cnvy.cnvy_key and cc1.act_stus_ind=1
and cc1.char_type_key='53223cc5252d3111a784717f660a45a277a813430ed44561fc46bd7028fc6836' --Equipment Initial
INNER JOIN daas_tm_prepared.dh_cnvy_char cc2 on cc2.cnvy_key=cnvy.cnvy_key and cc2.act_stus_ind=1
and cc2.char_type_key='4b784c8ef416376b15dcc4a491e6fefe7f994d1da63a1729d18e793799de3b86' --Equipment Number
LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_char_container_event_by_trsp_evt_key(te.trsp_evt_key) trsp_evt_char ON 1=1
left JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON te.prim_obj_key = tea.prim_obj_key and tea.act_stus_ind=1
left join daas_tm_prepared.dh_rail_station stn on (stn.stn_333_key = tea.asct_obj_key or stn.stn_333_cn_key = tea.asct_obj_key
or stn.stn_fsac_key = tea.asct_obj_key) 
LEFT JOIN daas_tm_prepared.dh_tz_dst_ref ON cast(Event_Timestamp_Time_Zone_Daylight_Savings_Code as integer) = tz_dst_cd
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key(cnvy.cnvy_key) ccond  on true 
WHERE cnvy.cnvy_type_key IN ('8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a' --Container
, 'e91b3bb060fea6f9d741db9db19e3328be5f64f34429ff2e66aa176cdcf24133' --Intermodal Unit
)
AND te.act_stus_ind=1
--AND te.data_hub_crt_ts >= '2021-07-07'
--AND id_val like 'PTVU%'
;