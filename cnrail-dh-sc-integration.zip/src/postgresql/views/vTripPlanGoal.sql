DROP VIEW IF EXISTS daas_tm_trusted."vTripPlanGoal" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vTripPlanGoal"
AS
select
b.id_val as "waybillIdentification"
,c.tpln_val as "equipmentIdentification"
,d."jeopardyReasonCode"
,d."customerGoalType"
,d."customerGoalNumber"
,CASE WHEN d."goalCutOffTimestamp" = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d."goalCutOffTimestamp", 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "goalCutOffTimestamp"

,CASE WHEN d."goalTimestamp" = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d."goalTimestamp", 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "goalTimestamp"
,d."goalTotalHours"
,greatest(d."dataHubCreationTimestamp", c.data_hub_crt_ts) as "dataHubCreationTimestamp"
,c.tpln_key
from daas_tm_prepared.dh_tpln_asct a
inner join daas_tm_prepared.dh_ship b on a.asct_obj_key=b.ship_key and b.act_stus_ind=1
inner join daas_tm_prepared.dh_tpln c on a.prim_obj_key = c.tpln_key and c.act_stus_ind=1
inner join daas_tm_trusted.f_get_dh_tpln_char_by_tpln_key(c.tpln_key) d on true
where a.act_stus_ind=1
--and c.tpln_val='HRTU715529'
--and b.id_val='9684-12-04-15.05.15.022020'
;

