DROP VIEW IF EXISTS daas_tm_trusted."vTrainConsistDetailL1Train" CASCADE;
CREATE OR REPLACE VIEW daas_tm_trusted."vTrainConsistDetailL1Train"
AS
--explain analyze
SELECT c.id_val AS "trainIdentification"
--,sa.ship_key
, te.trsp_evt_key
, te1.rpt_sor_proc_ts AS "processTimestamp"
, te1.sor_evt_ts AS "eventTimestamp"
, tec1.char_val AS "eventStationScac"
, tec2.char_val AS "eventStationFsac"
, tec3.char_val AS "keyTrainIndicator"
FROM daas_tm_prepared.dh_cnvy c
JOIN daas_tm_trusted.f_get_latest_transportation_event_by_train_id(c.id_val) te ON te.rk = 1
JOIN daas_tm_prepared.dh_trsp_evt te1 ON te1.act_stus_ind = 1 AND te.trsp_evt_key = te1.trsp_evt_key
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec1 ON tec1.act_stus_ind = 1 AND te.trsp_evt_key = tec1.trsp_evt_key AND tec1.char_type_key = '\x32623737626166386238343435303038323966666664313133353764316532343365653032306164656337376561326364633462323933346438353737643261' -- Event Station Carrier Abbreviation
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec2 ON tec2.act_stus_ind = 1 AND te.trsp_evt_key = tec2.trsp_evt_key AND tec2.char_type_key = '\x36316439663038616638653566396363363361626438643364316234326632653364343933336534313434393831356633353734363733653130636665316661' -- Event Station FSAC
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec3 ON tec3.act_stus_ind = 1 AND te.trsp_evt_key = tec3.trsp_evt_key AND tec3.char_type_key = '\x38386233316637343739663534353262646335353933386236616661306262333335313938303136363864343461643633656465396662633239393039383766' -- Key Train indicator
--where c.id_val = 'Q1165120210712'
;
/*test case 

select * from daas_tm_trusted."vTrainConsistDetailL1Train"
where "trainIdentification"='Q1165120210712'
*/