DROP VIEW IF EXISTS daas_tm_trusted."vTripPlanSegmentFlat" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vTripPlanSegmentFlat"
AS
select 
Greatest(d.data_hub_crt_ts, c.data_hub_crt_ts) as "dataHubCreationTimestamp"
,b.id_val as "waybillIdentification"
,cnvy.id_val as "equipmentIdentification"
,c.tpln_seg_val as "tripPlanSequence"
,cc.char_val as "carKind"
,d.trip_type_cd as "tripTypeCode"
,d.evt_cd as "eventCode"
,d.evst_cd as "eventStatusCode"
,stn.scac as "stationScac" 
,stn.fsac as "stationFsac" 
,CASE WHEN d.sch_evt_ts  = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d.sch_evt_ts, 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "scheduleEventTimestamp"
,CASE WHEN d.est_evt_ts = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d.est_evt_ts, 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "estimatedEventTimestamp"
,CASE WHEN d.actl_evt_ts = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d.actl_evt_ts, 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "actualEventTimestamp"
,d.stn_seq_nbr as "stationSequenceNumber"
,d.trn_id as "trainIdentification"
,d.tblk as "trainBlock"
,d.yblk as "yardBlock"
,d.jpdy_rsn_cd as "jeopardyReasonCode"
,d.resch_rsn_cd as "rescheduleReasonCode"
,d.asct_eqp_init || d.asct_eqp_nbr  as "associatedEquipmentIdentification"
,d.oper_rr_at_jct as "operatingRailroadAtJunctionPoint"
,d.op_zts as "opZTS"
,c.tpln_seg_key -- technical field used with vTripPlanSegmentChange
from daas_tm_prepared.dh_tpln_asct a
inner join daas_tm_prepared.dh_ship b on a.asct_obj_key=b.ship_key and b.act_stus_ind=1
inner join daas_tm_prepared.dh_tpln_seg c on a.prim_obj_key = c.prim_obj_key and c.act_stus_ind=1
inner join daas_tm_prepared.dh_cnvy cnvy on a.prim_obj_key = cnvy.cnvy_key and cnvy.act_stus_ind=1
inner join daas_tm_prepared.dh_cnvy_char cc on cc.cnvy_key=cnvy.cnvy_key
and cc.char_type_key='dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8' --Car Kind
and cc.act_stus_ind=1
inner join daas_tm_prepared.dh_tpln_seg_char_flatten d on (c.tpln_seg_key = d.tpln_seg_key)  -- and d.act_stus_ind = 1) 
left join daas_tm_prepared.dh_rail_station stn on stn.stn_333=d.stn_333 
and stn.stn_st= case when d.stn_prov_st_cd='QC' then 'PQ' else d.stn_prov_st_cd end 
where  a.act_stus_ind=1
--and cnvy.id_val='TGCU510259' 
--and b.id_val='9684-12-04-15.05.15.022020'
--and  c.tpln_seg_key in ('8fa68514f96a6304f16dfe792a6556b284da70625625d9c4dee68b05bb3b79a0', '0ecef5dbaec8645d83ca8dba93c03916121008b93ab95416c3c2e0b180bedd51', '24ca540cf6a1a342f9af85c1cc524244453e1813a7e865954b3a7867bf8222da')

order by b.id_val,cnvy.id_val,lpad(c.tpln_seg_val ,5,'0')
;
