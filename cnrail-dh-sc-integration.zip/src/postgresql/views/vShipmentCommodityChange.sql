DROP VIEW IF EXISTS daas_tm_trusted."vShipmentCommodityChange";

create view daas_tm_trusted."vShipmentCommodityChange" as 
select 
a.data_hub_crt_ts as "dataHubCreationTimestamp",  -- change to b for testing purpose
a.ship_key as "shipmentKey",
b.char_val as "waybillNumber"
from daas_tm_prepared.dh_wb_haz_mat_dsc a
inner join daas_tm_prepared.dh_ship_char b  
on a.ship_key=b.ship_key 
and b.act_stus_ind=1
and a.act_stus_ind=1
and b.char_type_key = '8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0'  --Waybill Number
union
select 
a.data_hub_crt_ts as "dataHubCreationTimestamp",
a.ship_key as "shipmentKey",
b.char_val as "waybillNumber"
from daas_tm_prepared.dh_wb_haz_mat_note a
inner join daas_tm_prepared.dh_ship_char b  
on a.ship_key=b.ship_key 
and b.act_stus_ind=1
and a.act_stus_ind=1
and b.char_type_key = '8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0'  --Waybill Number
union
select 
a.data_hub_crt_ts as "dataHubCreationTimestamp",
a.ship_key as "shipmentKey",
b.char_val as "waybillNumber"
from daas_tm_prepared.dh_wb_haz_wast_info a
inner join daas_tm_prepared.dh_ship_char b  
on a.ship_key=b.ship_key 
and b.act_stus_ind=1
and a.act_stus_ind=1
and b.char_type_key = '8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0'  --Waybill Number
;





