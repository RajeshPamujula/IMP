DROP VIEW IF EXISTS daas_tm_trusted."vWaybillHazardousMaterialNote" cascade;

create view daas_tm_trusted."vWaybillHazardousMaterialNote" as 
select 
a.ship_key  as "shipmentKey",
b.id_val  as "waybillIdentification",
a.data_hub_crt_ts  as "dataHubCreationTimestamp",
a.haz_seq	 as "hazardousSequence",
a.haz_note_seq   as "hazardousNoteSequence", 
a.haz_note  as "hazardousNote"
from daas_tm_prepared.dh_wb_haz_mat_note as a
inner join daas_tm_prepared.dh_ship as b on a.ship_key=b.ship_key and b.act_stus_ind=1
where a.act_stus_ind=1;

