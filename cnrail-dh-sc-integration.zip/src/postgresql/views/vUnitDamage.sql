DROP VIEW IF EXISTS daas_tm_trusted."vUnitDamage" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vUnitDamage"
AS
select a.id_val as "equipmentIdentifier"
,damageinfo."damageIteration"
,damageinfo."damageWhatCode"
,damageinfo."damageWhereCode"
,damageinfo."damageWhyCode"
,damageinfo."damageResponsibility"
,damageinfo."damageText"
from daas_tm_prepared.dh_cnvy a
inner join daas_tm_trusted.f_get_damage_info_by_cnvy_key(a.cnvy_key) damageinfo on true
--where a.id_val in ('PLHU680131','abc')
;
