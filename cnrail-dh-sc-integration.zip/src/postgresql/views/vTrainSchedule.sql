DROP VIEW IF EXISTS daas_tm_trusted."vTrainSchedule" CASCADE;


CREATE OR REPLACE VIEW daas_tm_trusted."vTrainSchedule"
AS
select 
 a.id_val as "trainIdentification"
,p.train_type as "trainType"
,p.train_symbol as "trainSymbol"
,p.train_section as "trainSection"
,p.train_departure_Date as "trainDepartureDate"
,right(p.train_departure_Date ,2) as "trainDay"
,o.maximum_mph as "maximumMilePerHour" 
,o.train_reporting_group   as "trainReportingGroupCode"
,n.station_sequence_number as "stationSequenceNumber"
,n.station_type_code as "stationTypeCode"
,n.crew_change_indicator as "crewChangeIndicator"
,n.tjs_inclusive_flag as "tjsInclusiveFlag"
,'' as "maximumLengthFeet"
,'' as "maximumWeightTon"
,'' as "maximumEquipmentCount"
,'' as "makeTrainIndicator"
,'' as "alternateIndicator"
, rail.stn_333 as "station333"
, rail.fsac as "stationFsac"
, rail.scac as "stationScac"
, rail.stn_st as "stationProvinceState"
,max(m.estimated_arrival_utc) as "estimatedArrivalUtc"
,max(m.estimated_departure_utc) as "estimatedDepartureUtc"
,max(m.topc_estimated_arrival_utc) as "topcEstimatedArrivalUtc"
,max(m.topc_estimated_departure_utc) as "topcEstimatedDepartureUtc"
,max(NULL)as "inboundLineUpDirectionCode"
,max(NULL) as "outboundLineUpDirectionCode"
,max(NULL) as "departureDirectionCode"
,max(NULL) as "arrivalDirectionCode"
from daas_tm_prepared.dh_cnvy a
--inner join daas_tm_prepared.dh_cnvy_char cnvy_char_sel on a.cnvy_key=cnvy_char_sel.cnvy_key
--and cnvy_char_sel.act_stus_ind= 1 
--and cnvy_char_sel.char_type_key = '2de848fbf4f4a1b422a4ac69aca68604254d48919aa8015e71079ec8f69382fb' --'unique train ID'
inner join daas_tm_prepared.dh_plan_evt_asct pade_sel on  pade_sel.prim_obj_key = a.cnvy_key and  pade_sel.act_stus_ind = 1
inner join daas_tm_prepared.dh_loc_asct la_sel on la_sel.asct_key = pade_sel.asct_obj_key and la_sel.act_stus_ind=1

inner join daas_tm_prepared.dh_plan_evt plan_evt on plan_evt.plan_evt_key = pade_sel.plan_evt_key and plan_evt.act_stus_ind=1
inner join daas_tm_prepared.dh_rte rte on rte.rte_key = plan_evt.prim_obj_key and rte.act_stus_ind=1
left join daas_tm_trusted.f_get_dh_plan_evt_char_train_by_plan_evt_key(pade_sel.plan_evt_key) as m on true
left join daas_tm_trusted.f_get_dh_loc_asct_char_train_by_asct_key(la_sel.asct_key) as n on true
left join daas_tm_trusted.f_get_dh_rte_char_train_by_rte_key(rte.rte_key) as o on true
inner join daas_tm_trusted.f_get_dh_cnvy_char_train_by_cnvy_key(a.cnvy_key) as p on true
inner join daas_tm_prepared.dh_rail_station rail on rail.stn_fsac_key=la_sel.loc_key
where a.act_stus_ind= 1 
and a.cnvy_type_key = 'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698' --'Train'
and to_date(p.train_departure_Date, 'YYYY-MM-DD') >(now() - interval '15 days ')
--and a.id_val='L5812120210211'
Group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21;