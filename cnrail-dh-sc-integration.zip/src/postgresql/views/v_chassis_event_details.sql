DROP VIEW IF EXISTS v_chassis_event_details CASCADE;

CREATE OR REPLACE VIEW v_chassis_event_details
AS
SELECT
te.trsp_evt_key
,tec.char_val AS gate_event_code
,c.id_val AS chassis_id
,cc.char_val AS chassis_initial
,stn.stn_333
,stn.stn_st
,trsp_char.cn_tractor_indicator AS cn_tractor_indicator
,te.data_hub_crt_ts AS data_hub_crt_ts
,te.SOR_evt_TS AS event_ts_utc
,r_tz.utc_ofst_val_hr AS tz_utc_ofst_val_hr
,r_tz.tz_lbl AS tz_lbl
,te.act_stus_ind AS active_gate_event
,COALESCE(cc2.char_val, '') AS chassis_number
,COALESCE(cc_cntr_1.char_val, '') AS container_initial
,COALESCE(cc_cntr_2.char_val, '') AS container_number
,COALESCE(trsp_char.carter_scac, '') AS carter_scac
,COALESCE(trsp_char.carter_customer_number, '') AS carter_Customer_number
,COALESCE(trsp_char.event_status, '') AS gate_event_status
,COALESCE(trsp_char.tractor_license, '') AS tractor_license
,c_cond.char_val AS bad_order_status
--- obtain the chassis
FROM daas_tm_prepared.dh_cnvy c
--- obtain the chassis characteristics (chassis initial and chassis number)
INNER JOIN daas_tm_prepared.dh_cnvy_char cc ON c.cnvy_key = cc.cnvy_key AND cc.act_stus_ind = 1 AND cc.char_type_key = '8f35d2683255a33a2cce4e00402379bf1d802e7f32b75c4094f936adc28fa5c6' -- 'Chassis Initial'
inner JOIN daas_tm_prepared.dh_cnvy_char cc2 ON c.cnvy_key = cc2.cnvy_key AND cc2.act_stus_ind = 1 AND cc2.char_type_key = '91715e8f8b4ef1dbcb598132968fd5038314440b34e506a5ba4d91abf33020ca' -- 'Chassis Number')
--- associated the chassis with the gate event
inner join daas_tm_prepared.dh_cnvy_asct ca on (c.cnvy_key = ca.cnvy_key and ca.act_stus_ind = 1 and ca.cnvy_type_key = '20ba3d6edbfbaab0653bd3314bf4ec3a1f6049daa8ab757fd2c8621944a3f4cf' -- 'Chassis'
and ca.asct_obj_type_key = '34bd4d29aed55b4527d08b0e4b1249a8812a8678ec9c254e35724fe68594c18d')
--- obtain the gate event and the gate event characteristcs
INNER JOIN daas_tm_prepared.dh_trsp_evt te ON ca.asct_obj_key = te.trsp_evt_key and te.act_stus_ind = 1 and trsp_evt_type_key = '34bd4d29aed55b4527d08b0e4b1249a8812a8678ec9c254e35724fe68594c18d' -- chassis gate event
INNER JOIN daas_tm_prepared.dh_trsp_evt_char tec ON tec.trsp_evt_key = te.trsp_evt_key and tec.act_stus_ind = 1
AND tec.char_type_key = '4ad95d606bc09078d5afe687ceeed40922882091d5217ca5ad6db6830ab0ffd5' --(select type_key from daas_tm_prepared.dh_ref_type where type_cd = 'Event Code')
AND tec.act_stus_ind = 1
--- associate the gate event with the location (get info from rail station and daylight saving reference tables)
INNER JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON te.trsp_evt_key = tea.trsp_evt_key AND tea.act_stus_ind = 1
INNER JOIN daas_tm_prepared.dh_rail_station stn ON (tea.asct_obj_key = stn.stn_333_key or tea.asct_obj_key = stn.stn_333_cn_key or stn.stn_333_cn_key_conv=tea.asct_obj_key)
INNER JOIN daas_tm_prepared.dh_tz_dst_ref r_tz ON te.sor_evt_ts_tz_dst_cd = r_tz.tz_dst_cd
-- associate the chassis gate event to the tractor gate event and obtain characteristics for the tractor gate event
inner join daas_tm_prepared.dh_cnvy_asct ca_tractor on (te.trsp_evt_key = ca_tractor.asct_obj_key and ca_tractor.act_stus_ind = 1 and ca_tractor.cnvy_type_key = 'd6663f4bdac4e24ddee5b7e3f8ebafbc903c50890d331ece54b7225f9b9a1a79' -- Tractor
and te.sor_crlt_id = ca_tractor.sor_crlt_id)
LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_char_gate_by_trsp_evt_key(ca_tractor.cnvy_key) trsp_char ON 1=1
--- associate the chassis gate event to the containers
LEFT JOIN daas_tm_prepared.dh_cnvy_asct ca_cntr ON te.trsp_evt_key = ca_cntr.asct_obj_key AND te.sor_evt_ts = ca_cntr.sor_evt_ts
AND ca_cntr.asct_obj_type_key = '34bd4d29aed55b4527d08b0e4b1249a8812a8678ec9c254e35724fe68594c18d' -- 'Chassis Gate Event'
AND ca_cntr.cnvy_type_key='8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a' -- 'Container'
AND ca_cntr.act_stus_ind = 1
LEFT JOIN daas_tm_prepared.dh_cnvy_char cc_cntr_1
ON ca_cntr.cnvy_key = cc_cntr_1.cnvy_key
AND cc_cntr_1.char_type_key = 'd878d5fd0d09bf69a1809f0d3dc148d78e3565660d33770ce7ba04c7bfde0938' --in (select type_key from daas_tm_prepared.dh_ref_type where type_cd = 'Container Initial')
AND cc_cntr_1.act_stus_ind = 1
LEFT JOIN daas_tm_prepared.dh_cnvy_char cc_cntr_2
ON ca_cntr.cnvy_key = cc_cntr_2.cnvy_key
AND cc_cntr_2.char_type_key = '863b5cd8179cfd5b3590ffad9c482cf53e79935d1a8ed30f5a73e2719613b520' --in (select type_key from daas_tm_prepared.dh_ref_type where type_cd = 'Container Number')
AND cc_cntr_2.act_stus_ind = 1
LEFT JOIN daas_tm_prepared.dh_cnvy_cond c_cond
ON c.cnvy_key = c_cond.cnvy_key
AND c_cond.char_type_key = '07ed1078042c7692da1672e604d7b8cca3f42fad6fc79385ab9c57c9a23a2ce2' ----in (select type_key from daas_tm_prepared.dh_ref_type where type_cd = 'Bad Order Code')
AND c_cond.act_stus_ind = 1
WHERE c.cnvy_type_key = '20ba3d6edbfbaab0653bd3314bf4ec3a1f6049daa8ab757fd2c8621944a3f4cf' --in (select type_key from daas_tm_prepared.dh_ref_type where type_cd = 'Chassis')
AND c.act_stus_ind = 1
;
