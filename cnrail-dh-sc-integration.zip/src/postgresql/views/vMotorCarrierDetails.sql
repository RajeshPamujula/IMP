DROP VIEW IF EXISTS daas_tm_trusted."vMotorCarrierDetails" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vMotorCarrierDetails"
AS

SELECT
TRIM(id_val) AS "trucker633"
,cond1.char_val AS "agreementEffectiveDate"
,CAST(daas_tm_trusted.f_is_date(cond1.char_val) AS INTEGER) as "isValidAgreementEffectiveDateIndicator"
,case WHEN daas_tm_trusted.f_is_date(cond1.char_val) = '0' then to_date('19000101','YYYYMMDD') ELSE TO_DATE(cond1.char_val,'YYYYMMDD') END AS "reviewedAgreementEffectiveDate"
,cond2.char_val as "agreementExpiryDate"
,CAST(daas_tm_trusted.f_is_date(cond2.char_val) AS INTEGER) as "isValidAgreementExpiryDateIndicator"
,case WHEN daas_tm_trusted.f_is_date(cond2.char_val) = '0' then to_date('20991231','YYYYMMDD') ELSE TO_DATE(cond2.char_val,'YYYYMMDD') END AS "reviewedAgreementExpiryDate"
,TRIM(char2.char_val) AS "carterSCAC"
,SUBSTRING(char2.char_val,1,2) AS "carterSCACFirst2Characters"
,char3.char_val AS "customerNumber"
FROM daas_tm_prepared.dh_bus_prtr
INNER JOIN daas_tm_prepared.dh_ref_type ref ON bus_prtr_type_key = ref.type_key AND ref.type_key = '225bd7dbabceb5d1adc471b2e9fd51841d156994cbb5e75d4d0142665b07a117' ---Motor Carrier
inner JOIN daas_tm_prepared.dh_bus_prtr_cond cond1 ON dh_bus_prtr.bus_prtr_key = cond1.bus_prtr_key  and cond1.act_stus_ind=1
AND cond1.char_type_key = '55821f53a1d132182bec83869f96c8837749609bc4976a3fa0aab11e41b05bd3' --Agreement Effective Date
inner JOIN daas_tm_prepared.dh_bus_prtr_cond cond2 ON dh_bus_prtr.bus_prtr_key = cond2.bus_prtr_key and cond2.act_stus_ind=1
AND cond2.char_type_key = '42f6a2c985101108c42cc5750bd589f9aabd0f756267253a3d382d8da1d1cb9f' --Agreement Effective Date
inner JOIN daas_tm_prepared.dh_bus_prtr_char char2 ON dh_bus_prtr.bus_prtr_key = char2.bus_prtr_key  and char2.act_stus_ind=1
AND char2.char_type_key = '70fbcb21ab4331aea4015b6062e8df8949bc53b8d316e547fede0b14ebe234bd' --Carter SCAC
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char char3 ON dh_bus_prtr.bus_prtr_key = char3.bus_prtr_key AND char3.char_type_key = '0b1821f40450113c8ce372b1cc14a2865520c66493a36d225a353a1f6bbbeb94' --Customer Number
where dh_bus_prtr.act_stus_ind =1
ORDER BY id_val ASC;