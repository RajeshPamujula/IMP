drop view if exists daas_tm_trusted."vIntermodalUnitUpdate";

create or replace view daas_tm_trusted."vIntermodalUnitUpdate"
as
with intermodalunitchange as (
select a.cnvy_key, ship_asct.sor_evt_ts, ship_asct.data_hub_crt_ts
from daas_tm_prepared.dh_cnvy a 
inner join daas_tm_prepared.dh_ship_asct ship_asct on (a.cnvy_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
where a.act_stus_ind =1 and ship_asct.data_hub_crt_ts >(now() - interval '2 hours ')
union
select cnvy_char.cnvy_key, cnvy_char.sor_evt_ts, cnvy_char.data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_char cnvy_char
where  cnvy_char.act_stus_ind=1
and cnvy_char.data_hub_crt_ts >(now() - interval '2 hours ')
union
select cnvy_cond_3.cnvy_key, cnvy_cond_3.sor_evt_ts, cnvy_cond_3.data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_cond cnvy_cond_3
where cnvy_cond_3.act_stus_ind = 1 
and cnvy_cond_3.data_hub_crt_ts >(now() - interval '2 hours ')
),
intermodalunit as (
select a.cnvy_key, max(a.sor_evt_ts) as "eventTimestamp", max(a.data_hub_crt_ts) as "dataHubCreationTimestamp"
from intermodalunitchange a 
inner join daas_tm_prepared.dh_cnvy b on a.cnvy_key=b.cnvy_key 
where b.cnvy_type_key not in (
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
)
group by a.cnvy_key
)
select 
a.cnvy_key,
a."dataHubCreationTimestamp",
a."eventTimestamp",
p."conveyorType",
p."equipmentInitial",
p."equipmentNumber",
b.id_val as "unitIdentification",
p."carKind",
q2."badOrderCode",
q2."loadSheetHoldCode",
q2."balanceOwedIndicator" as "storageChargeIndicator",  
q1."specialConditionCode1",
q1."specialConditionCode2",
q1."specialConditionCode3",
q1."specialConditionCode4",
q1."specialConditionCode5",
q1."specialConditionCode6",
q2."mechanicalStatusCode1",
q2."mechanicalStatusCode2",
q2."mechanicalStatusCode3",
m."firstStorageChargeDate",
q1."intermodalHandlingCode1",
q1."intermodalHandlingCode2",
q1."intermodalHandlingCode3",
p."outsideLength",
p."outsideLengthUnitOfMeasure",
p."outsideHeight",
p."outsideHeightUnitOfMeasure",
p."outsideWidth",
p."outsideWidthUnitOfMeasure",
p."trueKingpin",
p."equipmentTareWeight",
p."equipmentTareWeightUnitOfMeasure",
p."loadLimit",
p."equipmentOwnerAbbreviation",
p."equipmentLesseeAbbreviation" as "unitLeasee",
sa_char1.char_val as "emptyOrderNumber" ,

q1.ship_key,
q1."ProcessTimestamp" as "shipmentConditionProcessTimestamp" , -- ship cond 
sa_char1.asct_key as ship_asct_key,
sa_char1.rpt_sor_proc_ts as "shipmentAssociatoinProcessTimestamp",
p."conveyorCharProcessTimestamp",
q2.cnvy_key as railcar_cnvy_key,
q2."ProcessTimestamp" as"conveyorConditionProcessTimestamp"
from intermodalunit a
inner join daas_tm_prepared.dh_cnvy b on a.cnvy_key=b.cnvy_key
inner join daas_tm_trusted.f_run_dh_get_cnvy_char_by_container(a.cnvy_key) p on true
left join daas_tm_prepared.dh_ship_asct ship_asct on ship_asct.asct_obj_key=b.cnvy_key and ship_asct.act_stus_ind=1
left join daas_tm_prepared.dh_ship_asct_char sa_char1 on (ship_asct.asct_key = sa_char1.asct_key and sa_char1.act_stus_ind =1 and sa_char1.char_type_key = 'd9d99aec0ae95b5ffc046ffa2f1812bc215f3915ee2ca8f2b326c59c6b81e057')  -- Empty Order Number
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(ship_asct.ship_key) q1 on true
left join daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key(a.cnvy_key ) q2 on true  -- rail car cnvy key
left join daas_tm_trusted.f_run_dh_get_cnvy_cond_by_container(a.cnvy_key) m on true
;