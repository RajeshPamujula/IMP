drop view if exists "vTrainReportingDetails" cascade
;
create or replace view "vTrainReportingDetails"
as
SELECT substr(all_trains.train_id,1,6) as "trainIdentification",
all_trains.train_id as "trainUniqueIdentification",
substr(all_trains.train_id,1,1) as "trainType",
substr(all_trains.train_id,2,4) as "trainSymbol",
substr(all_trains.train_id,6,1) as "trainSection",
substr(all_trains.train_id,7,4) ||'-'|| substr(all_trains.train_id,11,2) ||'-'|| substr(all_trains.train_id,13,2) as "trainDepartureDate",
all_stations."stationSequenceTimestamp",
all_stations.trsp_evt_val as "trainArrivalDeparture",
all_stations."stationScac",
all_stations."stationFsac",
all_stations."station333",
all_stations."stationProvinceState",
all_stations."stationName",
all_stations."subdivisionCode",
all_stations."divisionCode",
all_stations."subregionCode",
all_stations."regionCode",
all_stations."loadedCarCount",
all_stations."emptyCarCount",
all_stations."totalCarWeight",
all_stations."totalCarWeightUnitOfMeasure",
all_stations."totalCarLength",
all_stations."totalCarLengthUOM",
all_stations."totalLocomotiveWeight",
all_stations."totalLocomotiveWeightUOM",
all_stations."totalLocomotiveLength",
all_stations."totalLocomotiveLengthUOM",
cast(all_stations."totalCarLength" as integer) + cast(all_stations."totalLocomotiveLength" as integer) as "totalLength",
cast(all_stations."totalCarWeight" as integer) + cast(all_stations."totalLocomotiveWeight" as integer) as "totalWeight",
all_stations."horsepowerPerTon",
all_stations."totalAvailableHorsepower",
all_stations."distributedPowerIndicator",
all_stations."trainTimestampUtc",
all_stations."trainTimestampTimezoneLabel",
all_stations."trainTimestampOffsetValueHours",
rail_stat_sel.stn_333 as "finalDestination333",
rail_stat_sel.stn_st as "finalDestinationProvinceState"
FROM daas_tm_prepared.dh_rail_station rail_stat_sel
JOIN LATERAL daas_tm_trusted.f_run_dh_get_trains_by_stnkey(rail_stat_sel.stn_fsac_key) all_trains ON true
LEFT JOIN LATERAL daas_tm_trusted.f_run_dh_get_train_details_by_trainkey_stnSeqTS(all_trains.cnvy_key, all_trains.max_station_sequence_timestamp) all_stations ON true
where all_stations.trsp_evt_val is not null
;
