DROP VIEW IF EXISTS daas_tm_trusted."vUnitShipmentDetailCustomer" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vUnitShipmentDetailCustomer"
AS
SELECT ship.ship_key as "ship_key"
     , ship.id_val as "waybillIdentifier"
     , sc.char_val as "waybillNumber"
     -- ship from
     , f_s_cmp_sf.City_333 AS "shipFromCity333" 
     , f_s_cmp_sf.Province_State AS "shipFromProvinceState" 
     , f_s_cmp_sf.Customer_633 AS "shipFromCustomer633" 
     -- prior origin
     , f_s_cmp_pp.City_333 AS "priorOriginCity333" 
     , f_s_cmp_pp.Province_State AS "priorOriginProvinceState" 
     , f_s_cmp_pp.Customer_633 AS "priorOriginCustomer633" 
     -- FD
     , f_s_cmp_fd.City_333 AS "finalDestinationCity333" 
     , f_s_cmp_fd.Province_State AS "finalDestinationProvinceState" 
     , f_s_cmp_fd.Customer_633 AS "finalDestinationCustomer633"   
     -- CO
     , f_s_cmp_co.City_333 AS "careOfCity333" 
     , f_s_cmp_co.Province_State AS "careOfProvinceState" 
     , f_s_cmp_co.Customer_633 AS "careOfCustomer633"      
     -- CN
     , f_s_cmp_cn.City_333 AS "consigneeCity333" 
     , f_s_cmp_cn.Province_State AS "consigneeProvinceState" 
     , f_s_cmp_cn.Customer_633 AS "consigneeCustomer633"   
     -- SH
     , f_s_cmp_sh.City_333 AS "shipperCity333" 
     , f_s_cmp_sh.Province_State AS "shipperProvinceState" 
     , f_s_cmp_sh.Customer_633 AS "shipperCustomer633" 
      -- UC
     , f_s_cmp_uc.City_333 AS "ultimateConsigneeCity333" 
     , f_s_cmp_uc.Province_State AS "ultimateConsigneeProvinceState"
     , f_s_cmp_uc.Customer_633 AS "ultimateConsigneeCustomer333" 

     , f_s_cmp_igsn.In_gate_Seal_Number AS "inGateSealNumber"

 
     , f_s_cmp_ves.Inbound_Outbound_Code AS "inboundOutboundCode" 
     , f_s_cmp_ves.Manifest_Creation_Date AS "manifestCreationDate" 
     , f_s_cmp_ves.Sail_Date AS "sailDate" 
     , f_s_cmp_ves.Sail_Time AS "sailTime" 
     , f_s_cmp_ves.Vessel_Name AS "vesselName" 
     , f_s_cmp_ves.Voyage_Booking_Date AS "voyageBookingDate" 
     , f_s_cmp_ves.Flight_Voyage_Number AS "flightVoyageNumber" 
     , f_s_cmp_ves.Voyage_Booking_Number AS "voyageBookingNumber" 
     , f_s_cmp_ves.Voyage_Port_Name AS "voyagePortName" 
 
     , stn5.fsac AS "shipFromFsac" 
     , stn5.scac AS "shipFromScac" 
     , stn6.fsac AS "priorOriginFsac" 
     , stn6.scac AS "priorOriginScac"      
     , stn7.fsac AS "finalDestinationFsac" 
     , stn7.scac AS "finalDestinationScac" 
     , stn8.fsac AS "careOfFsac" 
     , stn8.scac AS "careOfScac" 
     , stn9.fsac AS "consigneeFsac" 
     , stn9.scac AS "consigneeScac"      
     , stn10.fsac AS "shipperFsac" 
     , stn10.scac AS "shipperScac"  
	 
	   -- UC 
     , f_s_cmp_uc.Appointment_Date AS "ultimateConsigneeAppointmentDate" 
     , f_s_cmp_uc.Appointment_Time AS "ultimateConsigneeAppointmentTime" 

      -- PC new
     , f_s_cmp_pc.City_333 AS "payingCustomerCity333" 
     , f_s_cmp_pc.Province_State AS "payingCustomerProvinceState"
     , f_s_cmp_pc.Customer_633 AS "payingCustomerCustomer633" 
FROM daas_tm_prepared.dh_ship ship
inner join daas_tm_prepared.dh_ship_char sc on ship.ship_key=sc.ship_key and sc.act_stus_ind=1
and sc.char_type_key='8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0' --Waybill Number
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_sf ON s_cmp_sf.act_stus_ind = 1 AND s_cmp_sf.ship_key = ship.ship_key AND s_cmp_sf.id_val = 'Ship From' AND s_cmp_sf.id_type_key = '0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' -- BP Role
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_pp ON s_cmp_pp.act_stus_ind = 1 AND s_cmp_pp.ship_key = ship.ship_key AND s_cmp_pp.id_val = 'Prior Origin' AND s_cmp_pp.id_type_key = '0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' -- BP Role
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_fd ON s_cmp_fd.act_stus_ind = 1 AND s_cmp_fd.ship_key = ship.ship_key AND s_cmp_fd.id_val = 'Final Destination' AND s_cmp_fd.id_type_key = '0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' -- BP Role
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_co ON s_cmp_co.act_stus_ind = 1 AND s_cmp_co.ship_key = ship.ship_key AND s_cmp_co.id_val = 'Care Of' AND s_cmp_co.id_type_key = '0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' -- BP Role
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_cn ON s_cmp_cn.act_stus_ind = 1 AND s_cmp_cn.ship_key = ship.ship_key AND s_cmp_cn.id_val = 'Consignee' AND s_cmp_cn.id_type_key = '0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' -- BP Role
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_sh ON s_cmp_sh.act_stus_ind = 1 AND s_cmp_sh.ship_key = ship.ship_key AND s_cmp_sh.id_val = 'Shipper' AND s_cmp_sh.id_type_key = '0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' -- BP Role
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_igsn ON s_cmp_igsn.act_stus_ind = 1 AND s_cmp_igsn.ship_key = ship.ship_key and s_cmp_igsn.id_type_key='3bfa86ca22b888ca146f9bdd7e628a81389ac6147a84f44fbf80ea27a1a1d769'  --In-gate Seal
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_uc ON s_cmp_uc.act_stus_ind = 1 AND s_cmp_uc.ship_key = ship.ship_key AND s_cmp_uc.id_val = 'Ultimate Consignee' AND s_cmp_uc.id_type_key = '0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' -- BP Role
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_pc ON s_cmp_pc.act_stus_ind = 1 AND s_cmp_pc.ship_key = ship.ship_key AND s_cmp_pc.id_val = 'Paying Customer' AND s_cmp_pc.id_type_key = '0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' -- BP Role


-- One shipment could have multiple composites (voyage segments)
LEFT JOIN daas_tm_prepared.dh_ship_cmp s_cmp_ves ON s_cmp_ves.act_stus_ind = 1 AND s_cmp_ves.ship_key = ship.ship_key AND s_cmp_ves.id_type_key = '0b57f6225be919ba8943b3f10cbff9067e865c01d5fb6e6d73846d67e3a0af3e' -- Shipment-Voyage-Segment Sequence Number


LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_sf.ship_cmp_key) f_s_cmp_sf ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_pp.ship_cmp_key) f_s_cmp_pp ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_fd.ship_cmp_key) f_s_cmp_fd ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_co.ship_cmp_key) f_s_cmp_co ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_cn.ship_cmp_key) f_s_cmp_cn ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_sh.ship_cmp_key) f_s_cmp_sh ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_vessel_by_ship_cmp_key(s_cmp_ves.ship_cmp_key) f_s_cmp_ves ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_igsn.ship_cmp_key) f_s_cmp_igsn ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_uc.ship_cmp_key) f_s_cmp_uc ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(s_cmp_pc.ship_cmp_key) f_s_cmp_pc ON 1=1


LEFT JOIN daas_tm_prepared.dh_rail_station stn5 ON stn5.stn_333 = f_s_cmp_sf.City_333 
AND stn5.stn_st = case when f_s_cmp_sf.Province_State='QC' then 'PQ' else f_s_cmp_sf.Province_State end 

LEFT JOIN daas_tm_prepared.dh_rail_station stn6 ON stn6.stn_333 = f_s_cmp_pp.City_333 
AND stn6.stn_st = case when f_s_cmp_pp.Province_State='QC' then 'PQ' else f_s_cmp_pp.Province_State end 

LEFT JOIN daas_tm_prepared.dh_rail_station stn7 ON stn7.stn_333 = f_s_cmp_fd.City_333 
AND stn7.stn_st = case when f_s_cmp_fd.Province_State='QC' then 'PQ' else f_s_cmp_fd.Province_State end 

LEFT JOIN daas_tm_prepared.dh_rail_station stn8 ON stn8.stn_333 = f_s_cmp_co.City_333 
AND stn8.stn_st = case when f_s_cmp_co.Province_State='QC' then 'PQ' else f_s_cmp_co.Province_State end 

LEFT JOIN daas_tm_prepared.dh_rail_station stn9 ON stn9.stn_333 = f_s_cmp_cn.City_333 
AND stn9.stn_st = case when f_s_cmp_cn.Province_State='QC' then 'PQ' else f_s_cmp_cn.Province_State end 

LEFT JOIN daas_tm_prepared.dh_rail_station stn10 ON stn10.stn_333 = f_s_cmp_sh.City_333 
AND stn10.stn_st = case when f_s_cmp_sh.Province_State='QC' then 'PQ' else f_s_cmp_sh.Province_State end 
--where ship.ship_key='5ef0f6808d1a4814189c889ab308d9ddacf2261873869c1c23797fcca1a8bb77'
--and sc.char_val='771787'

;