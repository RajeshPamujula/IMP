DROP VIEW IF EXISTS daas_tm_trusted."vLocoPlanningChange" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vLocoPlanningChange"
AS
-- train event by locoid
select aset.id_val as "locomotiveIdentifier", trsp.data_hub_crt_ts as "timestampUpdate" 
FROM daas_tm_prepared.dh_trsp_evt as trsp
INNER JOIN daas_tm_prepared.dh_cnvy_asct as b
	ON b.prim_obj_key = trsp.trsp_evt_key
	AND trsp_evt_type_key = '62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a' --- Train Event Transportation Event
	and b.cnvy_type_key='c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698' -- train 
	AND b.act_stus_ind = 1 
	AND trsp.act_stus_ind = 1
INNER JOIN daas_tm_prepared.dh_cnvy as cnvy 	on cnvy.cnvy_key = b.cnvy_key 	--AND cnvy.act_stus_ind = 1	
INNER JOIN daas_tm_prepared.dh_aset_asct as aa ON trsp.prim_obj_key = aa.prim_obj_key AND aa.act_stus_ind = 1
INNER JOIN daas_tm_prepared.dh_aset as aset ON aset.aset_key = aa.aset_key AND aset.act_stus_ind = 1 and aset.aset_type_key='08e8d3db4a88f4048af2d4afa8e241965560177eeaa88d8f5eab57e9641c2249' -- aset type:Locomotive 
union all
-- loco event by locoid
select aset.id_val as "locomotiveIdentifier", trsp.data_hub_crt_ts  as "timestampUpdate"
FROM daas_tm_prepared.dh_aset as aset
INNER JOIN daas_tm_prepared.dh_trsp_evt as trsp on trsp.trsp_evt_key = aset.aset_key AND trsp.act_stus_ind = 1 AND trsp.trsp_evt_type_key = 'fda02cd8241999c41cec8807dd74ffd911c1c59507adc3cebac0c140abb6f219'--- to get the loco event
;