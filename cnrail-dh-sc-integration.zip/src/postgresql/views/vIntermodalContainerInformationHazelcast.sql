DROP VIEW IF EXISTS daas_tm_trusted."vIntermodalContainerInformationHazelcast" CASCADE;
CREATE OR REPLACE VIEW daas_tm_trusted."vIntermodalContainerInformationHazelcast"
AS
select
cnvy_cont.char_val as "containerIdentification",
cnvy_cont_2.char_val as "containerInitial",
cnvy_cont_3.char_val as "containerNumber",
cnvy_cond_cont_2.char_val as "firstStorageChargeDate",
cnvy_cond_cont.char_val as "storageChargeStatusCode",
coalesce(a.eqp_init || a.eqp_nbr, '') as "equipmentIdentification",
coalesce(a.eqp_init, '') as "equipmentInitial",
coalesce(a.eqp_nbr, '') as "equipmentNumber",
--coalesce(a.badOrderCode, '') as "badOrderCode",
coalesce(a.holdCode, '') as "holdCode",
coalesce(a.trackNumber, '') as "trackNumber",
case when a.trackSequenceNumber = '0' then '' else coalesce(a.trackSequenceNumber, '') end as "trackSequenceNumber",
coalesce(a.trainIdentification,'') as "trainIdentification",
case when COALESCE(a.trainIdentification,'') = '' then coalesce(Rail_stat.scac,'') else coalesce(b.stationScac,'') end as "stationScac",
case when COALESCE(a.trainIdentification,'') = '' then coalesce(rail_stat.fsac,'') else coalesce(b.stationFsac ,'') end as "stationFsac",
case when COALESCE(a.trainIdentification,'') = '' then coalesce(Rail_STAT.stn_333,'') else coalesce(stn.stn_333,'') end as "station333",
case when COALESCE(a.trainIdentification,'') = '' then case when rail_stat.stn_st = 'PQ' then 'QC' else coalesce(Rail_STAT.stn_st,'') end
else case when stn.stn_st = 'PQ' then 'QC' else coalesce(stn.stn_st,'') end end as "stationProvinceState",
case when COALESCE(a.trainIdentification,'') = '' then case when rail_stat.stn_st in ('PQ', 'ON', 'BC', 'AB', 'NF', 'NB', 'PE', 'NS', 'SK', 'MB') then 'CA' else 'US' end else case when stn.stn_st in ('PQ', 'ON', 'BC', 'AB', 'NF', 'NB', 'PE', 'NS', 'SK', 'MB') then 'CA' else 'US' end end as "countryCode",
case when COALESCE(a.trainIdentification,'') = '' then substr(a.trsp_evt_val,1,2) else b.eventCode end as "eventCode",
case when COALESCE(a.trainIdentification,'') = '' then case when substr(a.trsp_evt_val,3,2) = '' then null else substr(a.trsp_evt_val,3,2) end
else case when b.eventStatusCode = '' then null else b.eventStatusCode end end as "eventStatusCode",
case when COALESCE(a.trainIdentification,'') = '' then rail_stat.splc else stn.splc end as "splc",
case when COALESCE(a.trainIdentification,'') = ''then rail_stat.stn_nm else stn.stn_nm end as "stationName",
case when COALESCE(a.trainIdentification,'') = '' then a.eventTimestampUtc else b.sor_evt_ts end as "eventTimestampUtc",
case when COALESCE(a.trainIdentification,'') = '' then event_tz_ci.tz_lbl else event_tz.tz_lbl end as "eventTimezoneLabel",
case when COALESCE(a.trainIdentification,'') = '' then event_tz_ci.utc_ofst_val_hr else event_tz.utc_ofst_val_hr end as "eventOffsetHours",
case when COALESCE(a.trainIdentification,'') = '' then a.processTimestampUtc else b.rpt_sor_proc_ts end as "processTimestampUtc",
case when COALESCE(a.trainIdentification,'') = '' then proc_tz_ci.tz_lbl else proc_tz.tz_lbl end as "processTimezoneLabel",
case when COALESCE(a.trainIdentification,'') = '' then proc_tz_ci.utc_ofst_val_hr else proc_tz.utc_ofst_val_hr end as "processOffsetHours",
coalesce(cnvy_cond.char_val, '') as "badOrderCode", -- New container bad order
coalesce(c.PPSI_Temparature,'')as "ppsiTemperature",
coalesce(c.PPSI_Temperature_UOM,'') as "ppsiTemperatureUnitOfMeasure",
--cnvy_cont.data_hub_crt_ts,
--cnvy_cond_cont.data_hub_crt_ts,
--a.max_data_hub_crt_ts,
(select max(x) from unnest(array[cnvy_cont.data_hub_crt_ts,cnvy_cond_cont.data_hub_crt_ts,a.max_data_hub_crt_ts  ]) as x ) as latestDataHubCreateTimestamp

from daas_tm_prepared.dh_cnvy_char cnvy_cont
inner join daas_TM_prepared.dh_cnvy_char cnvy_cont_2 on (cnvy_cont.cnvy_key = cnvy_cont_2.cnvy_key and cnvy_cont_2.act_stus_ind = 1 and cnvy_cont_2.char_type_key = 'd878d5fd0d09bf69a1809f0d3dc148d78e3565660d33770ce7ba04c7bfde0938') -- container initial
inner join daas_TM_prepared.dh_cnvy_char cnvy_cont_3 on (cnvy_cont.cnvy_key = cnvy_cont_3.cnvy_key and cnvy_cont_3.act_stus_ind = 1 and cnvy_cont_3.char_type_key = '863b5cd8179cfd5b3590ffad9c482cf53e79935d1a8ed30f5a73e2719613b520') -- container number
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_cont on (cnvy_cont.cnvy_key = cnvy_cond_cont.cnvy_key and cnvy_cond_cont.act_stus_ind = 1 and cnvy_cond_cont.char_type_key = '37930ca551ed5baf224d861f86395b2a32e1bbac69406d2f47e29d4273583131') -- Storage Charge Status Code
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_cont_2 on (cnvy_cont.cnvy_key = cnvy_cond_cont_2.cnvy_key and cnvy_cond_cont_2.act_stus_ind = 1 and cnvy_cond_cont_2.char_type_key = 'd9fb9ddc0f66f8f86633f9eafc57a87e40c6d21e75b1f97c1997c6b96e835d85') -- First Storage Charge Date
--find car
left join daas_tm_trusted.f_run_dh_get_car_details_by_container (cnvy_cont.cnvy_key) a on true
left join daas_tm_prepared.dh_rail_station Rail_STAT on (a.stn_333_key = Rail_STAT.stn_333_key or a.stn_333_key = Rail_STAT.stn_333_cn_key or a.stn_333_key = Rail_STAT.stn_333_cn_key_conv)
left join daas_tm_prepared.dh_tz_dst_ref event_tz_ci on (a.sor_evt_ts_tz_dst_cd = event_tz_ci.tz_dst_cd)
left join daas_tm_prepared.dh_tz_dst_ref proc_tz_ci on (a.sor_proc_ts_tz_dst_cd = proc_tz_ci.tz_dst_cd)
--find train
left join daas_tm_trusted.f_run_dh_get_train_details_by_car(a.eqp_init,a.eqp_nbr) b on COALESCE(a.trainIdentification, '') <> '' and rk = 1
left join daas_tm_prepared.dh_rail_station stn on (b.stationFsac = stn.fsac and b.stationScac = stn.scac)
left join daas_tm_prepared.dh_tz_dst_ref event_tz on (b.sor_evt_ts_tz_dst_cd = event_tz.tz_dst_cd)
left join daas_tm_prepared.dh_tz_dst_ref proc_tz on (b.sor_proc_ts_tz_dst_cd = proc_tz.tz_dst_cd)
-- New container bad order
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond on (cnvy_cont.cnvy_key = cnvy_cond.cnvy_key and cnvy_cond.act_stus_ind = 1 and cnvy_cond.char_type_key = '07ed1078042c7692da1672e604d7b8cca3f42fad6fc79385ab9c57c9a23a2ce2') -- bad order code
--find PPSI Temperature
left join daas_tm_prepared.dh_ship_asct ship_asct on ship_asct.asct_obj_key = cnvy_cont.cnvy_key -- cnvy_key is container
left join daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key (ship_asct.ship_key) c on true
where cnvy_cont.char_type_key = '223ef438ed2fc0f96ac98b04cf85175502707e90ec1c87b643471983519b95e8' 
and   cnvy_cont.act_stus_ind = 1
;