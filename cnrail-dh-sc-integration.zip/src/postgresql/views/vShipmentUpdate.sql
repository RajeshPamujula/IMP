drop view if exists daas_tm_trusted."vShipmentUpdate" cascade;


CREATE OR REPLACE VIEW daas_tm_trusted."vShipmentUpdate" as 
WITH shipChange as (
select ship.ship_key, ship.data_hub_crt_ts,ship.sor_evt_ts
from daas_tm_prepared.dh_ship ship
where ship.data_hub_crt_ts>(now() - interval '0.25 hours')
/*ship_asct*/
union
select a.ship_key, b.data_hub_crt_ts, b.sor_evt_ts
from daas_tm_prepared.dh_ship_asct a
inner join daas_tm_prepared.dh_ship_asct_char b on a.asct_key=b.asct_key
where b.data_hub_crt_ts>(now() - interval '0.25 hours')
union
select ship_cmp.ship_key, ship_cmp_char.data_hub_crt_ts,ship_cmp_char.sor_evt_ts
from daas_tm_prepared.dh_ship_cmp ship_cmp
inner join daas_tm_prepared.dh_ref_type b on ship_cmp.id_type_key = b.type_key
inner join daas_tm_prepared.dh_ship_cmp_char ship_cmp_char on ship_cmp_char.ship_cmp_key = ship_cmp.ship_cmp_key
--inner join daas_tm_prepared.dh_ref_type c on ship_cmp_char.char_type_key = c.type_key
where ship_cmp.act_stus_ind=1
--and ship_cmp.id_type_key='0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' --BP Role
and ship_cmp_char.data_hub_crt_ts>(now() - interval '0.25 hours')
)
, dtm as (select ship_key, max(data_hub_crt_ts) as "dataHubCreationTimestamp", max(sor_evt_ts) as "eventTimestamp"
from shipChange
group by ship_key)
select

  a."dataHubCreationTimestamp"
, a."eventTimestamp"
, ship_char.waybill_number as "waybillNumber"
, ship.id_val as "waybillIdentification"

, b."shipperCity333"
, b."shipperProvinceState"
, b."shipperStationNumber"
, b."shipperCustomer633"
, b."shipperCarrierAbbreviation"
, b."shipperCityName"
, b."shipperZip"
, b."shipperCustomerAddress"
, b."shipperCustomerName"
, b."shipperCustomerNumber"


, b."consigneeCity333"
, b."consigneeProvinceState"
, b."consigneeStationNumber"
, b."consigneeCustomer633"
, b."consigneeCarrierAbbreviation"
, b."consigneeCityName"
, b."consigneeZip"
, b."consigneeCustomerAddress"
, b."consigneeCustomerName"
, b."consigneeCustomerNumber"

, b."payingCustomerCity333"
, b."payingCustomerProvinceState"
, b."payingCustomerStationNumber"
, b."payingCustomerCustomer633"
, b."payingCustomerCarrierAbbreviation"
, b."payingCustomerCityName"
, b."payingCustomerZip"
, b."payingCustomerCustomerAddress"
, b."payingCustomerCustomerName"
, b."payingCustomerCustomerNumber"

, b."careOfCity333"
, b."careOfProvinceState"
, b."careOfStationNumber"
, b."careOfCustomer633"
, b."careOfCarrierAbbreviation"
, b."careOfCityName"
, b."careOfZip"
, b."careOfCustomerAddress"
, b."careOfCustomerName"
, b."careOfCustomerNumber"


, b."finalDestinationCity333"
, b."finalDestinationProvinceState"
, b."finalDestinationStationNumber"
, b."finalDestinationCustomer633"
, b."finalDestinationCarrierAbbreviation"
, b."finalDestinationCityName"
, b."finalDestinationZip"
, b."finalDestinationCustomerAddress"
, b."finalDestinationCustomerName"
, b."finalDestinationCustomerNumber"

, b."priorOriginCity333"
, b."priorOriginProvinceState"
, b."priorOriginStationNumber"
, b."priorOriginCustomer633"
, b."priorOriginCarrierAbbreviation"
, b."priorOriginCityName"
, b."priorOriginZip"
, b."priorOriginCustomerAddress"
, b."priorOriginCustomerName"
, b."priorOriginCustomerNumber"



, b."shipFromCity333"
, b."shipFromProvinceState"
, b."shipFromStationNumber"
, b."shipFromCustomer633"
, b."shipFromCarrierAbbreviation"
, b."shipFromCityName"
, b."shipFromZip"
, b."shipFromCustomerAddress"
, b."shipFromCustomerName"
, b."shipFromCustomerNumber"


,ship_char.bill_of_lading_number as "billOfLadingNumber"
,cnvy_char.char_val as "carKind"
,ship_char.customer_supplied_net_weight as "customerSuppliedNetWeight"
,ship_char.customer_supplied_weight_code as "customerSuppliedWeightCode"
,ship_char.Customer_Supplied_Weight_UOM as "customerSuppliedWeightUom"
,ship_char.destination_ramp_333 as "destinationRamp333"
,ship_char.destination_ramp_333_province_state_code as "destinationRamp333ProvinceStateCode"
,ship_char.equipment_id as "equipmentIdentification"
,ship_char.load_empty_status_code as "loadEmptyStatusCode"
,ship_char.operating_city as "operatingCity"
,ship_char.operating_city_province_state_code as "operatingCityProvinceStateCode"
,ship_char.operating_destination_fsac as "operatingDestinationFsac"
,ship_char.operating_destination_scac as "operatingDestinationScac"
,ship_char.rail_origin_333 as "railOrigin333"
,ship_char.origin_ramp_333 as "originRamp333"
,ship_char.origin_ramp_333_province_state_code as "originRamp333ProvinceStateCode"
,ship_char.rail_origin_333_province_state_code as "railOrigin333ProvinceStateCode"
,ship_char.standard_transportation_commodity_code as "standardTransportationCommodityCode"
,ship_char.Waybill_Record_Type as "waybillTypeCode"

,ship_cond."specialConditionCode1"
,ship_cond."specialConditionCode2"
,ship_cond."specialConditionCode3"
,ship_cond."specialConditionCode4"
,ship_cond."specialConditionCode5"
,ship_cond."specialConditionCode6"

,ship_cond."waybillStatusCode"
,cnvy_type.type_cd
,ship_char.Rail_Destination_333 as "railDestination333"
,ship_char.Rail_Destination_333_Province_State_Code as "railDestination333ProvinceStateCode"
,ship_char.Gross_Scale_Weight as "grossScaleWeight"
,ship_char.Gross_Scale_Weight_UOM as "grossScaleWeightUom"
,ship_char.Net_Scale_Weight as "netScaleWeight"
,ship_char.Net_Scale_Weight_UOM as "netScaleWeightUom"
,ship_char.Regulatory_Authority as "regulatoryAuthority"
--,ship_char.Standard_Transportation_Commodity_Code as "standardTransportationCommodityCode"
,ship_char.Waybill_Date as "waybillDate"
,ship_char.Waybill_EDI_Code as "waybillEdiCode"
,ship_char.First_CN_Origin_Carrier_Abbreviation as "firstCnOriginCarrierAbbreviation"
,ship_char.First_CN_Origin_Station_Number as "firstCnOriginStationNumber"
,ship_char.Last_CN_Origin_Carrier_Abbreviation as "lastCnOriginCarrierAbbreviation"
,ship_char.Last_CN_Origin_Station_Number as "lastCnOriginStationNumber"
,stn.stn_333 as "lastCnOriginStation333"
,stn.stn_st as "lastCnOriginStation333ProvinceStateCode"
--,ship_char.Operating_City as "operatingCity"
,ship_asct_cnvy_char.op_zts AS "operatingZoneTrackSpot"
,ship_asct_comm_char."articleQuantity"
,ship_asct_comm_char."packageType"

,'packageTypeDescriptionInEnglish' as "packageTypeDescriptionInEnglish"

,'packageTypeDescriptionInFrench' as "packageTypeDescriptionInFrench"

,scf1."referenceNumber"
,scf1."referenceNumberCode"

,scf2.Sail_Date as "sailDate"
,scf2.Sail_Time as "sailTime"
,scf2.Vessel_Name as "vesselName"

,cmdy_char.char_val as "additionalStcc"
from dtm a
inner join daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(a.ship_key) ship_char on true
left join daas_tm_trusted.f_get_dh_ship_cond_bp_role_char_waybill_by_ship_key(a.ship_key) b on true
inner join daas_tm_prepared.dh_ship ship on ship.ship_key=a.ship_key and ship.act_stus_ind=1
/*
left join daas_tm_prepared.dh_ship_cond ship_cond1 on a.ship_key=ship_cond1.ship_key
and ship_cond1.act_stus_ind =1 and ship_cond1.char_type_key = 'f3c0d6f82e7737e9e08d2180b7c1203f442a37ca40669441a61565b2d480b81a' --Special Condition Code
left join daas_tm_prepared.dh_ship_cond ship_cond2 on a.ship_key=ship_cond2.ship_key
and ship_cond2.act_stus_ind =1 and ship_cond2.char_type_key = '1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083' --Waybill Status Code;
*/
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(a.ship_key) as ship_cond on true
left join daas_tm_prepared.dh_cnvy cnvy on (ship_char.equipment_id = cnvy.id_val and cnvy.act_stus_ind = 1)
left join daas_tm_prepared.dh_cnvy_char cnvy_char on (cnvy.cnvy_key = cnvy_char.cnvy_key and cnvy_char.act_stus_ind = 1 and cnvy_char.char_type_key = 'dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8' )
left join daas_tm_prepared.dh_ref_type cnvy_type on cnvy_type.type_key=cnvy.cnvy_type_key
left join daas_tm_prepared.dh_rail_station stn on stn.scac=ship_char.Last_CN_Origin_Carrier_Abbreviation and LPAD(stn.fsac, 6, '0')=ship_char.Last_CN_Origin_Station_Number
-- ship asct and ship asct equipemnet char
left join daas_tm_prepared.dh_ship_asct sa1 on sa1.ship_key=ship.ship_key
and sa1.act_stus_ind=1
and sa1.ship_type_key = 'd7b91437ff74a3bfd70ba3ebe8d16b8b5c2658cb589c7e5fa9d8f67d354e3b80' -- Waybill
and sa1.asct_type_key='3de22246a9c11b9fa0fae553613839d4fa5e077ff8bbbf7ee43eef0725c434c2' --Inter-BCD Shipment-Conveyor
left join daas_tm_trusted.f_get_dh_ship_asct_char_equipment_by_asct_key (sa1.asct_key) ship_asct_cnvy_char on 1 = 1

-- ship asct and ship asct commodity char
left join daas_tm_prepared.dh_ship_asct sa2 on sa2.ship_key=ship.ship_key
and sa2.act_stus_ind=1
and sa2.ship_type_key = 'd7b91437ff74a3bfd70ba3ebe8d16b8b5c2658cb589c7e5fa9d8f67d354e3b80' -- Waybill
and sa2.asct_type_key='e5f3fd59caf7dc0eb131d6b81aed6a07bd1f6b04488e979cb19be3fdf9daff44' --Inter-BCD Shipment-Commodity
left join daas_tm_trusted.f_get_dh_ship_asct_char_commodity_by_asct_key (sa2.asct_key) ship_asct_comm_char on 1 = 1

--sh cmp and waybill reference
left join daas_tm_prepared.dh_ship_cmp sc1 on sc1.ship_key=ship.ship_key
and sc1.ship_cmp_type_key='4ba31249118427e3579be1407f8a067652b3d2327833b0066d8491a2ba5ad25e' --Intra-Domain Shipment-Reference
and sc1.act_stus_ind=1
left join daas_tm_trusted.f_get_dh_ship_asct_char_waybill_reference_by_asct_key(sc1.ship_cmp_key) scf1 on true

--sh cmp and vessel
left join daas_tm_prepared.dh_ship_cmp sc2 on sc2.ship_key=ship.ship_key
and sc2.ship_cmp_type_key='af82909b34df99ece8af4b140307841a3a899bac846f096ff2a3efcbed32f44c' --Intra-Domain Shipment-Shipment-Voyage-Segment
and sc2.act_stus_ind=1
left join daas_tm_trusted.f_get_dh_ship_cmp_char_vessel_by_ship_cmp_key(sc2.ship_cmp_key) scf2 on true

-- ship asct and lading/additional stcc
left join daas_tm_prepared.dh_ship_asct sa3 on sa3.ship_key=ship.ship_key
and sa3.act_stus_ind=1
and sa3.asct_obj_type_key='27d689b061a6dc690a7e43b2f63913fdb060b98c6c67ff6c3888e4bf64641359' --commodity
and sa3.asct_type_key='e5f3fd59caf7dc0eb131d6b81aed6a07bd1f6b04488e979cb19be3fdf9daff44' --Inter-BCD Shipment-Commodity
left join daas_tm_prepared.dh_cmdy cmdy on sa3.asct_obj_key=cmdy.cmdy_key
left join daas_tm_prepared.dh_cmdy_char cmdy_char on cmdy_char.cmdy_key=cmdy.cmdy_key and cmdy_char.act_stus_ind = 1
and cmdy_char.char_type_key = '384f5b7339b33adefe3edeee78962574f0d747f5c37222508e5ec2647294022a' --STCC
;
