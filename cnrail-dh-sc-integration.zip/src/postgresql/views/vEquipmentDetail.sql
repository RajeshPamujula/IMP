DROP VIEW IF EXISTS daas_tm_trusted."vEquipmentDetail" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vEquipmentDetail"
AS
SELECT
cnvy.id_val as "equipmentIdentification",
rcar2.equipment_initial as "equipmentInitial",
rcar2.equipment_number as "equipmentNumber",
cnvy_cond."badOrderCode",

ship_asct_char.customer_switch_code AS "customerSwitchCode",
COALESCE(SUBSTRING(tec1.char_val, 1, 2), '') AS "eventCode",
COALESCE(SUBSTRING(tec1.char_val, 3, 2), '') AS "eventStatusCode",
COALESCE(te.sor_evt_ts, '1900-01-01 000000') AS "eventTimestampUtc", -- timestamp when transportation event is reported (railcar)
Gross_Scale_Weight AS "grossScaleWeight",
Gross_Scale_Weight_UOM AS "grossScaleWeightUnitOfMeasure",
rcar2.car_kind AS "carKind",
rcar2.outside_length AS "outsideLength",
rcar2.outside_length_uom as "outsideLengthUnitOfMeasure",
Load_Empty_Status_Code AS "loadEmptyStatusCode",
Net_Scale_Weight AS "netScaleWeight",
Net_Scale_Weight_UOM AS "netScaleWeightUnitOfMeasure",
ship_asct_char.op_zts AS "operatingZoneTrackSpot",
rcar2.pool_id AS "poolIdentification",
rcar2.Equipment_Tare AS "equipmentTareWeight",
rcar2.Equipment_Tare_UOM AS "equipmentTareWeightUnitOfMeasure", -- will be replaced by cnvy_char when Umler is completed, fixed
ship_asct_char.yard_block AS "yardBlock",
cnvy_cond."carLocationCode" as "locationCode",
trsp_evt_asct_char.track_sequence_number as "locationSequenceNumber", --- track sequence number

trsp_evt_asct_char.current_spot AS "currentSpot",

teac.char_val as "trackIdentification",
COALESCE(stn.fsac, '') as"stationFsac",
COALESCE(stn.scac, '') as "stationScac",
COALESCE(stn.stn_333, '') AS "station333",
COALESCE(stn.stn_st, '') AS "stationState",
ship_asct_char.current_assignment as "trainIdentification",
substr(ship_asct_char.current_assignment,1,1) as "trainType",
substr(ship_asct_char.current_assignment,2,4) as "trainSymbol",
substr(ship_asct_char.current_assignment,6,1) as "trainSection",
substr(ship_asct_char.current_assignment,7,2) as "trainDay",

stcc."standardTransportationCommodityCode",
stcc."commodityDescriptionAbbreviation",
stcc."commodity15Description",
ici."industrialCarInstruction" as "industrialCarMessages" , -- this is array
a.char_val as "referenceNumber",
astcc."additionalStcc" , -- this is arrary
scond."specialConditionCode1",
spcl1.trsp_cd_dsc_eng as "specialConditionCode1EnglishDescription",
spcl1.trsp_cd_dsc_fr as "specialConditionCode1FrenchDescription",
scond."specialConditionCode2",
spcl2.trsp_cd_dsc_eng as "specialConditionCode2EnglishDescription",
spcl2.trsp_cd_dsc_fr as "specialConditionCode2FrenchDescription",
scond."specialConditionCode3",
spcl3.trsp_cd_dsc_eng as "specialConditionCode3EnglishDescription",
spcl3.trsp_cd_dsc_fr as "specialConditionCode3FrenchDescription",
scond."specialConditionCode4",
spcl4.trsp_cd_dsc_eng as "specialConditionCode4EnglishDescription",
spcl4.trsp_cd_dsc_fr as "specialConditionCode4FrenchDescription",
scond."specialConditionCode5",
spcl5.trsp_cd_dsc_eng as "specialConditionCode5EnglishDescription",
spcl5.trsp_cd_dsc_fr as "specialConditionCode5FrenchDescription",
scond."specialConditionCode6",
spcl6.trsp_cd_dsc_eng as "specialConditionCode6EnglishDescription",
spcl6.trsp_cd_dsc_fr as "specialConditionCode6FrenchDescription",
cnvy_cond."mechanicalStatusCode1",
mech1.trsp_cd_dsc_eng as "mechanicalStatusCode1EnglishDescription",
mech1.trsp_cd_dsc_fr as "mechanicalStatusCode1FrenchDescription",
cnvy_cond."mechanicalStatusCode2",
mech2.trsp_cd_dsc_eng as "mechanicalStatusCode2EnglishDescription",
mech2.trsp_cd_dsc_fr as "mechanicalStatusCode2FrenchDescription",
cnvy_cond."mechanicalStatusCode3",
mech3.trsp_cd_dsc_eng as "mechanicalStatusCode3EnglishDescription",
mech3.trsp_cd_dsc_fr as "mechanicalStatusCode3FrenchDescription"
FROM daas_tm_prepared.dh_cnvy cnvy
INNER JOIN daas_tm_prepared.dh_ship_asct sa ON sa.asct_obj_key = cnvy.cnvy_key AND sa.act_stus_ind = 1 AND sa.asct_obj_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' -- Railcar
INNER JOIN daas_tm_prepared.dh_trsp_evt te ON te.trsp_evt_key = sa.asct_obj_key AND te.act_stus_ind = 1
inner JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON te.trsp_evt_key = tea.trsp_evt_key --AND tea.act_stus_ind = 1
INNER JOIN daas_tm_prepared.dh_rail_station stn ON (tea.asct_obj_key = stn.stn_333_key or tea.asct_obj_key = stn.stn_333_cn_key or stn.stn_333_cn_key_conv=tea.asct_obj_key
)
inner join daas_tm_prepared.dh_trsp_evt_asct_char teac on teac.asct_key= tea.asct_key
and teac.char_type_key='22fba95bb00160a504606f34b153dbd889ed746cc7d7f794472aa48b7bdbb41a' -- Track Number
and teac.act_stus_ind=1
inner JOIN daas_tm_prepared.dh_trsp_evt_char tec1 ON tec1.trsp_evt_key = te.trsp_evt_key AND tec1.act_stus_ind = 1
AND tec1.char_type_key = '07814f276206869eb5b8e6777b5f06a1597ee49b2957f04b609d3c99093d11d7' -- Event
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key(cnvy.cnvy_key) rcar2 ON 1 = 1
left join daas_tm_trusted.f_get_dh_trsp_evt_asct_char_equipment_by_asct_key (tea.asct_key) trsp_evt_asct_char on 1 = 1
left join daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key (cnvy.cnvy_key) cnvy_cond on 1 = 1
LEFT JOIN daas_tm_prepared.dh_ship_asct sa1 ON sa1.act_stus_ind = 1 AND cnvy.cnvy_key = sa1.asct_obj_key
AND sa1.ship_type_key = '\x64376239313433376666373461336266643730626133656265386431366238623563323635386362353839633765356661396438663637643335346533623830' -- Waybill

left join daas_tm_trusted.f_get_dh_ship_asct_char_equipment_by_asct_key (sa1.asct_key) ship_asct_char on 1 = 1

LEFT JOIN daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(sa.ship_key) ship_char ON 1 = 1
left join daas_tm_trusted.f_get_stcc_description_by_stcc (ship_char.standard_transportation_commodity_code) stcc on true
left join daas_tm_trusted.f_get_industrial_car_instruction_by_cnvy_key(cnvy.cnvy_key) ici on true
left join daas_tm_trusted.f_get_additional_stcc_by_ship_key(sa.ship_key) astcc on true
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(sa.ship_key) scond on true
------ to get the special condition descriptions
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl1 ON scond."specialConditionCode1" = spcl1.trsp_cd and trim(spcl1.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl2 ON scond."specialConditionCode2" = spcl2.trsp_cd and trim(spcl2.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl3 ON scond."specialConditionCode3" = spcl3.trsp_cd and trim(spcl3.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl4 ON scond."specialConditionCode4" = spcl4.trsp_cd and trim(spcl4.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl5 ON scond."specialConditionCode5" = spcl5.trsp_cd and trim(spcl5.trsp_cd_type) = 'Special Car Handling Instruction'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref spcl6 ON scond."specialConditionCode6" = spcl6.trsp_cd and trim(spcl6.trsp_cd_type) = 'Special Car Handling Instruction'
------ to get the mechanical stattus descriptions
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref mech1 ON cnvy_cond."mechanicalStatusCode1" = mech1.trsp_cd and trim(mech1.trsp_cd_type) = 'Mechanical Status Code'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref mech2 ON cnvy_cond."mechanicalStatusCode2" = mech2.trsp_cd and trim(mech2.trsp_cd_type) = 'Mechanical Status Code'
LEFT JOIN daas_tm_prepared.dh_trsp_cd_ref mech3 ON cnvy_cond."mechanicalStatusCode3" = mech3.trsp_cd and trim(mech3.trsp_cd_type) = 'Mechanical Status Code'

left join daas_tm_prepared.dh_ship_cmp c on sa.ship_key=c.ship_key and c.act_stus_ind=1
and c.ship_type_key='d7b91437ff74a3bfd70ba3ebe8d16b8b5c2658cb589c7e5fa9d8f67d354e3b80' --Waybill
and c.ship_cmp_type_key='4ba31249118427e3579be1407f8a067652b3d2327833b0066d8491a2ba5ad25e' --Intra-Domain Shipment-Reference
left join daas_tm_prepared.dh_ship_cmp_char a on c.ship_cmp_key=a.ship_cmp_key and a.act_stus_ind=1
and a.char_type_key = 'd4f53dc6ab8256d581e1b5c2671de5860d6fd862889c99bc1a0b527c6e3aad0e' --'Reference Number'
;