DROP VIEW IF EXISTS daas_tm_trusted."vUnitStopOrder" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vUnitStopOrder"
AS
select a.id_val as "equipmentIdentifier",
(to_timestamp(b."stopTimestamp" , 'YYYY-MM-DD HH24:MI:SS')) as "stopTimestamp",
b."stopOrderIteration",
b."stopOrderAuthorization",
b."stopOrder",
b."eventCode",
b."eventCodeOverride",
b."stopOrderStation333"   ,
b."stopOrderStationProvinceState"
from daas_tm_prepared.dh_cnvy a
inner join daas_tm_trusted.f_get_stop_order_by_cnvy_key(a.cnvy_key) b on true
--where a.id_val='SIMU474121'
;

-- select * from daas_tm_trusted."vUnitStopOrder"  where "equipmentIdentifier"='SIMU474121';