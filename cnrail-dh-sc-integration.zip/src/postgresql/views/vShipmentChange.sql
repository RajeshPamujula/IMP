DROP VIEW IF EXISTS daas_tm_trusted."vShipmentChange" cascade;

CREATE OR REPLACE VIEW daas_tm_trusted."vShipmentChange"
as
select ship.ship_key, ship.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship ship
union 
select ship_char.ship_key, ship_char.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_char ship_char 
union 
select ship_cond.ship_key, ship_cond.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_cond ship_cond
union
select a.ship_key, b.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_asct a
inner join daas_tm_prepared.dh_ship_asct_char b on a.asct_key=b.asct_key
where b.sor_tpic_nm  like '%waybill%'
and b.act_stus_ind =1
union
select ship_cmp.ship_key, ship_cmp_char.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_cmp ship_cmp
inner join daas_tm_prepared.dh_ship_cmp_char ship_cmp_char on ship_cmp_char.ship_cmp_key = ship_cmp.ship_cmp_key
where ship_cmp.act_stus_ind=1
and ship_cmp_char.sor_tpic_nm not like '%reference%'
union 
select ship_key, cc.data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_char cc
inner join daas_tm_prepared.dh_cnvy cnvy on cc.cnvy_key = cnvy.cnvy_key
inner join daas_tm_prepared.dh_ship_char sc on sc.char_val =cnvy.id_val 
and sc.char_type_key='31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
where cc.sor_tpic_nm like '%wayBill%' and cc.act_stus_ind=1
;

/*
select * from daas_tm_trusted."vShipmentChange" 
where "dataHubCreationTimestamp" >= now()- interval '2 minutes';
*/
