drop view if exists daas_tm_trusted."vIntermodalUnitChange";

create or replace view daas_tm_trusted."vIntermodalUnitChange"
as
select a.id_val as "unitIdentification", a.cnvy_key,  ship_asct.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy a 
inner join daas_tm_prepared.dh_ship_asct ship_asct on (a.cnvy_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
where a.act_stus_ind =1 
and a.cnvy_type_key not in (
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
)
--and ship_asct.data_hub_crt_ts >(now() - interval '2 hours ')
union
-- new change capture
select a.id_val as "unitIdentification", a.cnvy_key,  ship_cond.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy a 
inner join daas_tm_prepared.dh_ship_asct ship_asct on (a.cnvy_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
inner join daas_tm_prepared.dh_ship_cond ship_cond on ship_asct.ship_key=ship_cond.ship_key and ship_cond.act_stus_ind=1
where a.act_stus_ind =1 
and a.cnvy_type_key not in (
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
)
--and ship_cond.data_hub_crt_ts >(now() - interval '2 hours ')
union
select a.id_val as "unitIdentification", cnvy_char.cnvy_key,  cnvy_char.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy_char cnvy_char
inner join daas_tm_prepared.dh_cnvy a  on a.cnvy_key=cnvy_char.cnvy_key
and a.cnvy_type_key not in (
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
) 
where  cnvy_char.act_stus_ind=1
--and cnvy_char.data_hub_crt_ts >(now() - interval '2 hours ')
union
select a.id_val as "unitIdentification",  cnvy_cond_3.cnvy_key,  cnvy_cond_3.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy_cond cnvy_cond_3
inner join daas_tm_prepared.dh_cnvy a  on a.cnvy_key=cnvy_cond_3.cnvy_key
and a.cnvy_type_key not in (
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
) 
where cnvy_cond_3.act_stus_ind = 1 and cnvy_cond_3.sor_tpic_nm  not like '%unit-location-updated%'
--and cnvy_cond_3.data_hub_crt_ts >(now() - interval '2 hours ')
;

/*
release note:
1. one conveyor may have multiple records, GQL team has to get unique cnvy_key;

select distinct cnvy_key
from daas_tm_trusted."vIntermodalUnitChange"
where "dataHubCreationTimestamp" > now()- interval '12 minutes'

*/
