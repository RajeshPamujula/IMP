DROP VIEW IF EXISTS daas_tm_trusted."vCarloadInformationHazelcast" cascade
;
CREATE OR REPLACE VIEW daas_tm_trusted."vCarloadInformationHazelcast"
AS
select
rcar.eqp_init || rcar.eqp_nbr as "equipmentIdentification",
RCAR.eqp_init as "equipmentInitial",
RCAR.eqp_nbr as "equipmentNumber",
cnvy_cond.char_val as "badOrderCode",
cnvy_cond_2.char_val as "holdCode",
tac.char_val as "trackNumber",
case when tac_2.char_val = '0' then '' else tac_2.char_val end as "trackSequenceNumber",
sa_char.char_val as "trainIdentification",
case when COALESCE(sa_char.char_val, '') = '' then Rail_stat.scac  else b.stationScac end as "stationScac",
case when COALESCE(sa_char.char_val, '') = '' then rail_stat.fsac else b.stationFsac end as "stationFsac",
case when COALESCE(sa_char.char_val, '') = '' then Rail_STAT.stn_333 else stn.stn_333 end as "station333", 
case when COALESCE(sa_char.char_val, '') =  '' then case when rail_stat.stn_st = 'PQ' then 'QC' else Rail_STAT.stn_st end    
else case when stn.stn_st = 'PQ' then 'QC' else stn.stn_st end end as "stationProvinceState",
case when COALESCE(sa_char.char_val, '') = '' then case when rail_stat.stn_st in ('PQ', 'ON', 'BC', 'AB', 'NF', 'NB', 'PE', 'NS', 'SK', 'MB') then 'CA' else 'US' end else case when stn.stn_st in ('PQ', 'ON', 'BC', 'AB', 'NF', 'NB', 'PE', 'NS', 'SK', 'MB') then 'CA' else 'US' end end as "countryCode",
case when COALESCE(sa_char.char_val, '') = '' then substr(tde.trsp_evt_val,1,2) else b.eventCode end as "eventCode",
case when COALESCE(sa_char.char_val, '') = '' then case when  substr(tde.trsp_evt_val,3,2) = '' then null else substr(tde.trsp_evt_val,3,2) end 
else case when  b.eventStatusCode = '' then null else  b.eventStatusCode end end as "eventStatusCode",
case when COALESCE(sa_char.char_val, '') = '' then rail_stat.splc else stn.splc end as "splc",
case when COALESCE(sa_char.char_val, '') = '' then rail_stat.stn_nm  else stn.stn_nm end as "stationName",  
case when COALESCE(sa_char.char_val, '') = '' then tde.sor_evt_ts else b.sor_evt_ts end as "eventTimestampUtc", 
case when COALESCE(sa_char.char_val, '') = '' then event_tz_ci.tz_lbl else event_tz.tz_lbl end as "eventTimezoneLabel", 
case when COALESCE(sa_char.char_val, '') = '' then event_tz_ci.utc_ofst_val_hr else event_tz.utc_ofst_val_hr end as "eventOffsetHours",
case when COALESCE(sa_char.char_val, '') = '' then tde.rpt_sor_proc_ts  else b.rpt_sor_proc_ts end as "processTimestampUtc",  
case when COALESCE(sa_char.char_val, '') = '' then proc_tz_ci.tz_lbl  else proc_tz.tz_lbl end as "processTimezoneLabel", 
case when COALESCE(sa_char.char_val, '') = '' then proc_tz_ci.utc_ofst_val_hr else proc_tz.utc_ofst_val_hr end as "processOffsetHours",

--RCAR.data_hub_crt_ts,
--TDE.data_hub_crt_ts,
--cnvy_cond.data_hub_crt_ts,
--TEA.data_hub_crt_ts,
--ship_asct.data_hub_crt_ts,
(select max(x) from unnest(array[RCAR.data_hub_crt_ts,TDE.data_hub_crt_ts,cnvy_cond.data_hub_crt_ts,TEA.data_hub_crt_ts,ship_asct.data_hub_crt_ts  ]) as x ) as "latestDataHubCreateTimestamp"


from DAAS_TM_PREPARED.DH_TRSP_EVT TDE
inner join daas_tm_prepared.dh_rcar_ref RCAR on (TDE.TRSP_EVT_KEY = rcar.rcar_key)
inner join daas_tm_prepared.dh_cnvy_cond cnvy_cond on (tde.trsp_evt_key = cnvy_cond.cnvy_key and cnvy_cond.act_stus_ind = 1 and cnvy_cond.char_type_key = '07ed1078042c7692da1672e604d7b8cca3f42fad6fc79385ab9c57c9a23a2ce2')-- bad order code
inner join daas_tm_prepared.dh_cnvy_cond cnvy_cond_2 on (tde.trsp_evt_key = cnvy_cond_2.cnvy_key and cnvy_cond_2.act_stus_ind = 1 and cnvy_cond_2.char_type_key = '665ce7a009722311c22f1e1011f1fc80fdc720870d1b70499485d5d9a766a538')-- mechanical status code
inner join DAAS_TM_PREPARED.dh_trsp_evt_asct TEA on (tde.trsp_evt_key = tea.trsp_evt_key and tea.act_stus_ind = 1)
inner join daas_tm_prepared.dh_rail_station Rail_STAT on (TEA.asct_obj_key = Rail_STAT.stn_333_key or TEA.asct_obj_key = Rail_STAT.stn_333_cn_key or TEA.asct_obj_key = Rail_STAT.stn_333_cn_key_conv)
inner join daas_tm_prepared.dh_trsp_evt_asct_char TAC on (TEA.asct_key = TAC.asct_key and tac.act_stus_ind = 1 and tac.char_type_key = '22fba95bb00160a504606f34b153dbd889ed746cc7d7f794472aa48b7bdbb41a') -- track number
inner join daas_tm_prepared.dh_trsp_evt_asct_char TAC_2 on (TEA.asct_key = TAC_2.asct_key and tac_2.act_stus_ind = 1 and tac_2.char_type_key = 'a83fa7f14d9937952df568bcfb79fb3516b4f847ecb90799dd431c0c25215af9')   -- track sequence number
inner join daas_tm_prepared.dh_ship_asct ship_asct on (TDE.trsp_evt_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
inner join daas_tm_prepared.dh_ship_asct_char sa_char on (ship_asct.asct_key = sa_char.asct_key and sa_char.act_stus_ind =1 and sa_char.char_type_key = '06336730586527e31d5f9f12871d505364457590976fc83d32651a06869d3aa1')
inner join daas_tm_prepared.dh_tz_dst_ref event_tz_ci on (tde.sor_evt_ts_tz_dst_cd = event_tz_ci.tz_dst_cd)
inner join daas_tm_prepared.dh_tz_dst_ref proc_tz_ci on (tde.sor_proc_ts_tz_dst_cd = proc_tz_ci.tz_dst_cd)
--find train
left join  daas_tm_trusted.f_run_dh_get_train_details_by_car(rcar.eqp_init,rcar.eqp_nbr) b on COALESCE(sa_char.char_val, '') <> '' and rk = 1
left join daas_tm_prepared.dh_rail_station stn on (b.stationFsac = stn.fsac and b.stationScac = stn.scac)
left join daas_tm_prepared.dh_tz_dst_ref event_tz on (b.sor_evt_ts_tz_dst_cd = event_tz.tz_dst_cd)
left join daas_tm_prepared.dh_tz_dst_ref proc_tz on (b.sor_proc_ts_tz_dst_cd = proc_tz.tz_dst_cd)
where TDE.TRSP_EVT_TYPE_KEY = 'f6b530b0ea00c27747543eb950d814eb0aedce2edfdc5ac49313296fb2238f02'-- for 'Railcar Event' from Car Inventory
and TDE.act_stus_ind = 1
;