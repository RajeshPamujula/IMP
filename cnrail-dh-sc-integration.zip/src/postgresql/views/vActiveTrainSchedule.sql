drop view if exists "vActiveTrainSchedule" cascade;

create or replace view  "vActiveTrainSchedule"
as
SELECT
substr(all_trains.train_id,1,6) || substr(all_trains.train_id,13,2) AS "trainIdentification",
all_trains.train_id AS "trainUniqueIdentification",
all_stations."stationSequenceNumber",
all_stations."stationSequenceTimestamp",
all_stations.scac as "stationScac",
all_stations.fsac as "stationFsac",
all_stations.stn_333 as "station333",
all_stations.stn_st as "stationProvinceState",
all_stations."estimatedDepartureUtc",
tz_dep.tz_lbl as "departureTimezoneLabel",
tz_dep.utc_ofst_val_hr as "departureUtcOffsetValueHours",
all_stations."estimatedArrivalUtc",
tz_arr.tz_lbl as "arrivalTimezoneLabel",
tz_arr.utc_ofst_val_hr as "arrivalUtcOffsetValueHours",
all_stations."topcEstimatedArrivalUtc",
all_stations."topcEstimatedDepartureUtc",
all_stations."plannedDepartureDayOffset",
all_stations."plannedDepartureTimeLocal",
all_stations."plannedArrivalDayOffset",
all_stations."plannedArrivalTimeLocal",
all_stations."crewChangeIndicator",
all_stations."refuelPoint",
all_stations."requiredInspection",
all_stations."rewheel",
all_stations."tjsFlag",
rail_stat_sel.stn_333 as "finalDestination333",
rail_stat_sel.stn_st as "finalDestinationProvinceState"
FROM daas_tm_prepared.dh_rail_station rail_stat_sel
JOIN LATERAL daas_tm_trusted.f_run_dh_get_trains_by_stnkey(rail_stat_sel.stn_fsac_key) all_trains ON true
LEFT JOIN LATERAL daas_tm_trusted.f_run_dh_get_train_details_by_trainkey_stnSeqNum(all_trains.cnvy_key, all_trains.max_station_sequence_nb) all_stations ON true
left join daas_tm_prepared.dh_tz_dst_ref tz_dep on (all_stations."estimatedDepartureTimezoneCode" = CAST(tz_dep.tz_dst_cd AS varchar))
left join daas_tm_prepared.dh_tz_dst_ref tz_arr on (all_stations."estimatedArrivalTimezoneCode" = CAST(tz_arr.tz_dst_cd AS varchar))
where all_stations."tjsFlag"='Y'
;