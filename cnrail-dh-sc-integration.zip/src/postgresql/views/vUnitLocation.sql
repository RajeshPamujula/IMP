DROP VIEW IF EXISTS daas_tm_trusted."vUnitLocation" CASCADE;
CREATE OR REPLACE VIEW daas_tm_trusted."vUnitLocation"
AS
SELECT c.id_val AS "equipmentIdentifier"
, cnvy_char.equipment_initial as "equipmentInitial"
, cnvy_char.equipment_number as "equipmentNumber"
, te.sor_evt_ts as "eventTimestamp"
, stn.scac AS "stationScac"
, stn.fsac AS "stationFsac"
, cc1.char_val AS "equipmentLocationCode"
, rcar.opZTS AS "opZts"
, rcar.trainidentification AS "currentAssignment"

, case when COALESCE(cnvy_cond."latestLotTrackIdTs" , '1900-01-01') >COALESCE(cnvy_cond."latestLotTs" , '1900-01-01')  then cnvy_cond."lotTrackId" else cnvy_cond."lot" end as "lot"

--, cnvy_cond."lotTrackId" as "lot"
, cnvy_cond."row" as "row"
, cnvy_cond."spot" as "spot"
, rcar.tracknumber as "trackNumber"
, trsp_evt_asct_char.track_area as "trackArea"
, trsp_evt_asct_char.lift_code as "liftCode"
, cnvy_cond."parkingTracksideIndicator" as "parkOrTrackCode"
, rcar.eqp_init || rcar.eqp_nbr as "railcarAssociation"
, rcar.tracksequencenumber as "trackSequenceNumber"
, d1.char_val as "platformCode"
, d2.char_val as "platformPosition"
, cnvy_char.Car_Kind as "carKind"
, r.type_cd as "equipmentType"
, cnvy_cond."tier" as "tier"
, cnvy_cond."statusIndicator" as "statusIndicator"
FROM daas_tm_prepared.dh_cnvy c

left JOIN daas_tm_prepared.dh_ref_type r on c.cnvy_type_key = r.type_key AND r.type_cd in ( 'Container' , 'Chassis' , 'Trailer')
left JOIN daas_tm_prepared.dh_trsp_evt te ON te.act_stus_ind = 1 AND c.cnvy_key = te.trsp_evt_key
left JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON tea.act_stus_ind = 1 AND te.trsp_evt_key = tea.trsp_evt_key
left JOIN daas_tm_prepared.dh_rail_station stn ON (stn.stn_333_key = tea.asct_obj_key or stn.stn_333_cn_key = tea.asct_obj_key
or stn.stn_fsac_key = tea.asct_obj_key) 
left join daas_tm_prepared.dh_cnvy_cond cc1 on cc1.cnvy_key = c.cnvy_key and cc1.act_stus_ind=1
and cc1.char_type_key='4ea81b8a03299ac5c6a2fd8a6821868bff1bf08eea4e810ba8373f574d33119f' --Equipment Location Code
LEFT JOIN daas_tm_trusted.f_run_dh_get_car_details_by_container(c.cnvy_key) rcar ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key (c.cnvy_key) cnvy_char ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key (c.cnvy_key) cnvy_cond ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_asct_char_yard_by_asct_key (tea.asct_key) trsp_evt_asct_char ON 1=1
LEFT JOIN daas_tm_prepared.dh_cnvy_asct b ON c.cnvy_key=b.cnvy_key and b.asct_type_key='0ba452470ff9f23b1d2e999f5afea823e1d7bab4913da2dc17aba3c6e784f011' and b.act_stus_ind=1-- Intra-BCD Container-Railcar
LEFT JOIN daas_tm_prepared.dh_cnvy_asct_char d1 ON b.asct_key=d1.asct_key and d1.char_type_key= '4d8db4222b8246af57f924cab221bf48a29077323041d2c57d4870aebef0fe17' --Platform Code
LEFT JOIN daas_tm_prepared.dh_cnvy_asct_char d2 ON b.asct_key=d2.asct_key and d2.char_type_key= 'db442b26e87d44a5489f02aa88d7b42cacdc24f189585abbda3f6583b89e5397' --Platform Position Code
WHERE c.act_stus_ind = 1
--and stn.fsac='42365'
--and stn.scac ='CN'
--and cc1.char_val in ('G','Y'); 
;

/*
select * from daas_tm_trusted."vUnitLocation"
where  "stationScac"='CN'
and  "stationFsac"='42365'
and "equipmentLocationCode" in ('G','Y');

*/




