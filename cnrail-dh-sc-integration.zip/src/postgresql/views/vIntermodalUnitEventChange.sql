DROP VIEW IF EXISTS daas_tm_trusted."vIntermodalUnitEventChange" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vIntermodalUnitEventChange"
AS

SELECT dh_trsp_evt.data_hub_crt_ts AS "dataHubCreationTimestamp", id_val as "containerIdentifier"
from daas_tm_prepared.dh_trsp_evt
INNER JOIN daas_tm_prepared.dh_cnvy ON cnvy_key = dh_trsp_evt.prim_obj_key and dh_cnvy.act_stus_ind=1
WHERE cnvy_type_key IN ('8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a' --Container
, 'e91b3bb060fea6f9d741db9db19e3328be5f64f34429ff2e66aa176cdcf24133' --Intermodal Unit
)
UNION
SELECT dh_trsp_evt_char.data_hub_crt_ts AS data_hub_crt_ts,  id_val
from daas_tm_prepared.dh_trsp_evt
INNER JOIN daas_tm_prepared.dh_cnvy ON cnvy_key = dh_trsp_evt.prim_obj_key and dh_cnvy.act_stus_ind=1
INNER JOIN daas_tm_prepared.dh_trsp_evt_char ON dh_trsp_evt_char.trsp_evt_key = dh_trsp_evt.trsp_evt_key AND dh_trsp_evt_char.act_stus_ind=1
AND dh_trsp_evt_char.char_type_key = '4ad95d606bc09078d5afe687ceeed40922882091d5217ca5ad6db6830ab0ffd5' --Event Code
INNER JOIN daas_tm_prepared.dh_ref_type ON dh_trsp_evt_char.char_type_key = type_key
WHERE cnvy_type_key IN ('8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a' --Container
, 'e91b3bb060fea6f9d741db9db19e3328be5f64f34429ff2e66aa176cdcf24133' --Intermodal Unit
);