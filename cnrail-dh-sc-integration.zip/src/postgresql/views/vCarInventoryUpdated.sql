DROP VIEW IF EXISTS daas_tm_trusted."vCarInventoryUpdated" CASCADE; 

CREATE OR REPLACE VIEW daas_tm_trusted."vCarInventoryUpdated"
AS 
SELECT te.data_hub_crt_ts AS "dataHubCreationTimestamp"
     , rcar.eqp_init || rcar.eqp_nbr AS "railcarId"
     , rcar.eqp_init AS "equipmentInitial"
     , rcar.eqp_nbr AS "equipmentNumber"
     , te.trsp_evt_key AS "transportationEventKey"
     , COALESCE(SUBSTRING(tec.event, 1, 2), '') AS "eventCode"
     , COALESCE(SUBSTRING(tec.event, 3, 2), '') AS "eventStatusCode"
     , COALESCE(CONCAT(tec.Event_Date, ' ', tec.Event_Time), '') AS "eventTimestamp"
     , stn."scac"
     , stn."fsac"     
     , teac.Track_Number AS "trackNumber"
     , teac.Current_Spot AS "currentSpot"
     , teac.Track_Sequence_Number  AS "trackSequenceNumber"     
     , COALESCE(sac1.char_val, '') AS "currentAssignment"
     , COALESCE(sc1.char_val, '') AS "loadEmptyStatusCode"     
     , ccond."carLocationCode"
     , ccond."operatingZoneTrackSpot" AS "opZts"
     , ccond."previousTrackNumber"
     , ccond."badOrderCode"
     , ccond."mechanicalStatusCode1"
     , ccond."mechanicalStatusCode2"
     , ccond."mechanicalStatusCode3"
     , ccond."customerCarOrderNumber"
     , ccond."yardBlock"
     , cc.CN_Pool_Id AS "cnPoolId"
     , cc.Car_Kind AS "carKind"
     , ccond."customerSwitchCode"
     , scond."specialConditionCode1"
     , scond."specialConditionCode2"
     , scond."specialConditionCode3"
     , scond."specialConditionCode4"
     , scond."specialConditionCode5"
     , scond."specialConditionCode6"	 
FROM daas_tm_prepared.dh_rcar_ref rcar
JOIN daas_tm_prepared.dh_trsp_evt te ON te.act_stus_ind = 1 AND rcar.rcar_key = te.trsp_evt_key AND te.trsp_evt_type_key = '\x66366235333062306561303063323737343735343365623935306438313465623061656463653265646664633561633439333133323936666232323338663032' -- Railcar Event
LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_char_equipment_by_trsp_evt_key (te.trsp_evt_key) AS tec on true 
/*
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec1 ON tec1.act_stus_ind = 1 AND te.trsp_evt_key = tec1.trsp_evt_key AND tec1.char_type_key = '\x30373831346632373632303638363965623562386536373737623566303661313539376565343962323935376630346236303964336339393039336431316437' -- Event
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec2 ON tec2.act_stus_ind = 1 AND te.trsp_evt_key = tec2.trsp_evt_key AND tec2.char_type_key = '\x61623030336662386438333862623030396132336531306239366664656135623564626161363931646436613635383134363835316466336637383031313330' -- Event Date
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec3 ON tec3.act_stus_ind = 1 AND te.trsp_evt_key = tec3.trsp_evt_key AND tec3.char_type_key = '\x66356233613364343339363761396434303530383632316233343966353439363666316261626338643863363233336566626366663537653431616564336665' -- Event Time
*/
LEFT JOIN daas_tm_prepared.dh_ship_asct sa ON sa.act_stus_ind = 1 AND sa.asct_obj_key = rcar.rcar_key
LEFT JOIN daas_tm_prepared.dh_ship_asct_char sac1 ON sac1.act_stus_ind = 1 AND sa.asct_key = sac1.asct_key AND sac1.char_type_key = '\x30363333363733303538363532376533316435663966313238373164353035333634343537353930393736666338336433323635316130363836396433616131' -- Current Assignment
LEFT JOIN daas_tm_prepared.dh_ship_char sc1 ON sc1.act_stus_ind = 1 AND sc1.ship_key = sa.ship_key AND sc1.char_type_key = '\x32356230383237303063366131346564653864333637656165303936643465336130653063626434613964666565653635323634353935383833346139313263' -- Load Empty Status Code

LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key(rcar.rcar_key) ccond on true 
/*
LEFT JOIN daas_tm_prepared.dh_cnvy_cond ccond1 ON ccond1.act_stus_ind = 1 AND rcar.rcar_key = ccond1.cnvy_key AND ccond1.char_type_key = '\x66323161333737333637346166396131356463333836656332376465643663356437313861656637333862346533346363326463616566633631313734653965' -- Car Location Code
LEFT JOIN daas_tm_prepared.dh_cnvy_cond ccond2 ON ccond2.act_stus_ind = 1 AND rcar.rcar_key = ccond2.cnvy_key AND ccond2.char_type_key = '\x33393036643564316365306465343763653432653837373737383863613865643536333439303964383734383436313535633166383965626631363032383362' -- Op ZTS
LEFT JOIN daas_tm_prepared.dh_cnvy_cond ccond3 ON ccond3.act_stus_ind = 1 AND rcar.rcar_key = ccond3.cnvy_key AND ccond3.char_type_key = '\x38633263613935343561666262613965333938383136363531353139316464366538383835333563616332306432633132333930303465323234313230323631' -- Previous Track Number
LEFT JOIN daas_tm_prepared.dh_cnvy_cond ccond4 ON ccond4.act_stus_ind = 1 AND rcar.rcar_key = ccond4.cnvy_key AND ccond4.char_type_key = '\x30376564313037383034326337363932646131363732653630346437623863636133663432666164366663373933383561623963353763396132336132636532' -- Bad Order Code
LEFT JOIN daas_tm_prepared.dh_cnvy_cond ccond5 ON ccond5.act_stus_ind = 1 AND rcar.rcar_key = ccond5.cnvy_key AND ccond5.char_type_key = '\x36363563653761303039373232333131633232663165313031316631666338306664633732303837306431623730343939343835643564396137363661353338' -- Mechanical Status Codes
LEFT JOIN daas_tm_prepared.dh_cnvy_cond ccond6 ON ccond6.act_stus_ind = 1 AND rcar.rcar_key = ccond6.cnvy_key AND ccond6.char_type_key = '' -- CCO Number !!! fill hash key when it becomes available
LEFT JOIN daas_tm_prepared.dh_cnvy_cond ccond7 ON ccond7.act_stus_ind = 1 AND rcar.rcar_key = ccond7.cnvy_key AND ccond7.char_type_key = '\x35613362346633356331346439643134323264323861633736623832636434626362633239646532633831623836616533376239323033313732616330343664' -- Yard Block
LEFT JOIN daas_tm_prepared.dh_cnvy_cond ccond8 ON ccond8.act_stus_ind = 1 AND rcar.rcar_key = ccond8.cnvy_key AND ccond8.char_type_key = '\x62313664376338623531353037616631383737346232316439346663313231373863356362333432333131663230336639336165623038376365356365646462' -- Customer Switch Code
*/
LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON 
--tea.act_stus_ind = 1 AND 
tea.trsp_evt_key = rcar.rcar_key 
LEFT JOIN daas_tm_prepared.dh_rail_station stn ON (stn.stn_333_key = tea.asct_obj_key or stn.stn_333_cn_key = tea.asct_obj_key or stn.stn_333_cn_key_conv = tea.asct_obj_key)

LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_asct_char_equipment_by_asct_key(tea.asct_key ) AS teac ON TRUE 
/*
LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac1 ON teac1.act_stus_ind = 1 AND teac1.asct_key = tea.asct_key AND teac1.char_type_key = '\x32326662613935626230303136306135303436303666333462313533646264383839656437343663633764376637393434373261613438623762646262343161' -- Track Number
LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac2 ON teac2.act_stus_ind = 1 AND teac2.asct_key = tea.asct_key AND teac2.char_type_key = '\x34643232613536376431303535393531303034663838386462326464323632643936363037386363616463326235363033353662643330656666613632346466' -- Current Spot
LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac3 ON teac3.act_stus_ind = 1 AND teac3.asct_key = tea.asct_key AND teac3.char_type_key = '\x61383366613766313464393933373935326466353638626366623739666233353136623466383437656362393037393964643433316330633235323135616639' -- Track Sequence Number
*/
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key(rcar.rcar_key) AS cc on true 
--LEFT JOIN daas_tm_prepared.dh_cnvy_char cc ON cc.act_stus_ind = 1 AND cc.cnvy_key = rcar.rcar_key AND cc.char_type_key = '\x35396265396539393933303037663539393130323738366466323830626366373366636362646233613937643366326234343833393334613236356434623864' -- CN Pool Id

LEFT JOIN daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(sa.ship_key) as scond on true 
--LEFT JOIN daas_tm_prepared.dh_ship_cond scond ON scond.act_stus_ind = 1 AND scond.ship_key = sa.ship_key AND scond.char_type_key = '\x66336330643666383265373733376539653038643231383062376331323033663434326133376361343036363934343161363135363562326434383062383161' -- Special Condition Code
where te.data_hub_crt_ts > (now() - interval '1 days' )
;


