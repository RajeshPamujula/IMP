DROP VIEW IF EXISTS "vLocationDetails" CASCADE;

CREATE OR REPLACE VIEW "vLocationDetails"
AS

SELECT
stn_333_key AS "locationKey"
,scac
,fsac
,stn_333 as "station333"
,stn_st as "stationProvince"
,stn_nm as "stationName"
,stn_abbr as "stationAbbreviation"
,ramp_cd as "rampCode"
,splc as "standardPointLocationCode"
,stn_abbr as "stationShortAbbreviation"
,yd_scale_cd as "yardScaleCode"
,tz_abbr as "timeZoneAbbreviation"
,stn_ctry as "stationCountry"
,sdiv_cd as "subDivisionNumber"
,div_cd as "divisionNumber"
,rgn_cd as "regionNumber"
,srgn_cd as "subRegionNumber"
FROM daas_tm_prepared.dh_rail_station;