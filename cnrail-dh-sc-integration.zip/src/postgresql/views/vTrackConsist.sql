DROP VIEW IF EXISTS daas_tm_trusted."vTrackConsist";
CREATE OR REPLACE VIEW daas_tm_trusted."vTrackConsist"
AS

SELECT
trk.trk_nbr as "trackNumber",
CAST(COALESCE(dh_trsp_evt_asct_char2.char_val, '') AS INTEGER) as "trackSequenceNumber",
trk.stn_333 as "station333",
trk.trk_key as "trackKey",
trk.stn_prst_cd as "stationState",
stn.scac as "scac",
stn.fsac as "fsac",
rcar.eqp_init||rcar.eqp_nbr as "equipmentIdentification",
rcar.eqp_init as "equipmentInitial",
rcar.eqp_nbr as "equipmentNumber",
trk.trk_dir AS "trackDirectionCode",
trk.trk_lgt_ft AS "trackLengthFeet",
trk.trk_type_cd AS "trackTypeCode",
trk.trk_nm AS "trackName"
FROM DAAS_TM_PREPARED.dh_trk_ref trk
INNER JOIN daas_tm_prepared.dh_trsp_evt_asct_char tc
ON (tc.char_val = trk.trk_nbr 
and tc.act_stus_ind = 1
and tc.char_type_key='22fba95bb00160a504606f34b153dbd889ed746cc7d7f794472aa48b7bdbb41a' -- Track Number  add new or not , uncertainty
)
INNER JOIN DAAS_TM_PREPARED.dh_trsp_evt_asct as ta
ON (ta.asct_key = tc.asct_key 

and ta.act_stus_ind = 1
)
INNER JOIN DAAS_TM_PREPARED.DH_TRSP_EVT te ON (te.trsp_evt_key = ta.trsp_evt_key and te.act_stus_ind = 1)
INNER JOIN daas_tm_prepared.dh_rcar_ref rcar on (te.TRSP_EVT_KEY = rcar.rcar_key and te.act_stus_ind = 1)
INNER JOIN daas_tm_prepared.dh_trsp_evt_asct_char dh_trsp_evt_asct_char2
ON (ta.asct_key = dh_trsp_evt_asct_char2.asct_key and dh_trsp_evt_asct_char2.act_stus_ind = 1 and dh_trsp_evt_asct_char2.char_type_key = 'a83fa7f14d9937952df568bcfb79fb3516b4f847ecb90799dd431c0c25215af9') -- track sequence number
INNER JOIN daas_tm_prepared.dh_rail_station stn on (ta.asct_obj_key = stn.stn_333_key or ta.asct_obj_key = stn.stn_333_cn_key or ta.asct_obj_key = stn.stn_333_cn_key_conv)
WHERE stn.stn_333 = trk.stn_333
AND stn.stn_st = trk.stn_prst_cd
AND SUBSTRING(rcar.car_kind,1,1) <> 'K' --- to exclude containers
--and trk.trk_nbr='GA56'
--and trk.stn_333='VIKING'
;