DROP VIEW IF EXISTS daas_tm_trusted."vTrainConsistDetail" CASCADE;

CREATE OR REPLACE VIEW daas_tm_trusted."vTrainConsistDetail"
AS
SELECT c.id_val AS "trainIdentification"
, te1.rpt_sor_proc_ts AS "processTimestamp"
, te1.sor_evt_ts AS "eventTimestamp"
, tec1.char_val AS "eventStationScac"
, tec2.char_val AS "eventStationFsac"
, tec3.char_val AS "keyTrainIndicator"
,Train_Sequence_Number AS "trainSequenceNumber"
,Set_Out_Station_Sequence_Number AS "setOutStationSequenceNumber"
,Set_Out_Track AS "setOutTrackNumber"
,Set_Out_Station_Sequence_Timestamp AS "setOutStationSequenceTimestamp"
, rcar.eqp_init || rcar.eqp_nbr AS "railcarIdentification"
, rcar.car_kind AS "carKind"
, ship_char.rail_destination_333 AS "arrivalStation333"
, ship_char.rail_destination_333_province_state_code AS "arrivalStationProvinceState"
, stn2.scac AS "arrivalStationScac"
, stn2.fsac AS "arrivalStationFsac"
, c2.id_val AS "containerIdentification"
,Setout_Track_Sequence_Number AS "setoutTrackSequenceNumber"
,Platform_Code AS "platformCode"
,Platform_Position_Code AS "platformPositionCode"
,CASE WHEN IMU2.IntermodalRailcarIndicator IS NULL THEN 0 ELSE IMU2.IntermodalRailcarIndicator END AS "intermodalTrainIndicator"
FROM daas_tm_prepared.dh_cnvy c
JOIN daas_tm_trusted.f_get_latest_transportation_event_by_train_id(c.id_val) te ON te.rk = 1
JOIN daas_tm_prepared.dh_trsp_evt te1 ON te1.act_stus_ind = 1 AND te.trsp_evt_key = te1.trsp_evt_key
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec1 ON tec1.act_stus_ind = 1 AND te.trsp_evt_key = tec1.trsp_evt_key AND tec1.char_type_key = '\x32623737626166386238343435303038323966666664313133353764316532343365653032306164656337376561326364633462323933346438353737643261' -- Event Station Carrier Abbreviation
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec2 ON tec2.act_stus_ind = 1 AND te.trsp_evt_key = tec2.trsp_evt_key AND tec2.char_type_key = '\x36316439663038616638653566396363363361626438643364316234326632653364343933336534313434393831356633353734363733653130636665316661' -- Event Station FSAC
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec3 ON tec3.act_stus_ind = 1 AND te.trsp_evt_key = tec3.trsp_evt_key AND tec3.char_type_key = '\x38386233316637343739663534353262646335353933386236616661306262333335313938303136363864343461643633656465396662633239393039383766' -- Key Train indicator
LEFT JOIN daas_tm_prepared.dh_cnvy_asct ca2 ON ca2.act_stus_ind = 1 AND te1.trsp_evt_key = ca2.asct_obj_key AND ca2.cnvy_type_key = '\x33393464623062666463323165653030306133613164366661336230356539396138643736333031383632613963396338363663393330353133363234366439' -- Railcar
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_asct_char_train_by_asct_key (ca2.asct_key) cnvy_asct_char ON 1= 1
LEFT JOIN daas_tm_prepared.dh_rcar_ref rcar ON ca2.cnvy_key = rcar.rcar_key
LEFT JOIN daas_tm_prepared.dh_ship_asct sa       ON sa.act_stus_ind = 1 AND ca2.cnvy_key = sa.asct_obj_key AND ship_type_key = '\x64376239313433376666373461336266643730626133656265386431366238623563323635386362353839633765356661396438663637643335346533623830' -- Waybill
left join daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key  (sa.ship_key)   ship_char On 1= 1

LEFT JOIN daas_tm_prepared.dh_rail_station stn2  ON stn2.stn_333 = ship_char.rail_destination_333 
AND stn2.stn_st = case when ship_char.rail_destination_333_province_state_code='QC' then 'PQ' else ship_char.rail_destination_333_province_state_code end 


LEFT JOIN daas_tm_prepared.dh_cnvy_asct ca3 ON ca3.act_stus_ind = 1 AND ca3.asct_obj_key = rcar.rcar_key
AND ca3.cnvy_type_key = '\x38643865333337333939373830393263666337313964643039393634393863316231666233333463336237356439386665366337336538666237363761393161' -- Container
AND ca3.asct_obj_type_key = '\x33393464623062666463323165653030306133613164366661336230356539396138643736333031383632613963396338363663393330353133363234366439' -- Railcar
LEFT JOIN daas_tm_prepared.dh_cnvy c2 ON c2.act_stus_ind = 1 AND c2.cnvy_key = ca3.cnvy_key
LEFT JOIN
(SELECT IMU.id_val, IMU.sor_evt_ts, IMU.IntermodalRailcarIndicator
FROM ( SELECT c.id_val, te1.sor_evt_ts, CASE WHEN SUBSTRING(rcar.car_kind,1,1) IN ('Q', 'P') THEN 1 ELSE 0 END AS IntermodalRailcarIndicator
FROM daas_tm_prepared.dh_cnvy c
JOIN daas_tm_trusted.f_get_latest_transportation_event_by_train_id(c.id_val) te ON te.rk = 1
JOIN daas_tm_prepared.dh_trsp_evt te1 ON te1.act_stus_ind = 1 AND te.trsp_evt_key = te1.trsp_evt_key
LEFT JOIN daas_tm_prepared.dh_cnvy_asct ca2 ON ca2.act_stus_ind = 1 AND te1.trsp_evt_key = ca2.asct_obj_key AND ca2.cnvy_type_key = '\x33393464623062666463323165653030306133613164366661336230356539396138643736333031383632613963396338363663393330353133363234366439' -- Railcar
LEFT JOIN daas_tm_prepared.dh_rcar_ref rcar ON ca2.cnvy_key = rcar.rcar_key
GROUP BY 1,2,3 ) AS IMU
WHERE IMU.IntermodalRailcarIndicator = 1) AS IMU2
ON IMU2.id_val = c.id_val AND IMU2.sor_evt_ts = te1.sor_evt_ts
;