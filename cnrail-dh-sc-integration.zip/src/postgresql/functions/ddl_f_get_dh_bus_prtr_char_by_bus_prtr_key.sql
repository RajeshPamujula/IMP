DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_bus_prtr_char_by_bus_prtr_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_bus_prtr_char_by_bus_prtr_key(p_bus_prtr_key bytea)
RETURNS TABLE
(
bus_prtr_key bytea,
"customer633" text,
"customerName" text,
"equipmentOwnertype" text,
"equipmentOwnerAbbreviation" text
)
AS $$
begin
return query

select
a.bus_prtr_key,
bus_prtr_char1.char_val as "customer633",
bus_prtr_char2.char_val as "customerName",
bus_prtr_char3.char_val as "equipmentOwnertype",
bus_prtr_char4.char_val as "equipmentOwnerAbbreviation"
from daas_tm_prepared.dh_bus_prtr a
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char bus_prtr_char1 ON (a.bus_prtr_key = bus_prtr_char1.bus_prtr_key AND bus_prtr_char1.act_stus_ind = 1 and bus_prtr_char1.char_type_key = 'bd9dae217a0a467e1d4ab7e34974038e2001b9361a106a8a088debd5c5430e14') --Customer 633
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char bus_prtr_char2 ON (a.bus_prtr_key = bus_prtr_char2.bus_prtr_key AND bus_prtr_char2.act_stus_ind = 1 and bus_prtr_char2.char_type_key = '28fa08b6d074f1abef54d8137ee775f0c86b5d3246929eb140b56e963c8263c6') --Customer Name
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char bus_prtr_char3 ON (a.bus_prtr_key = bus_prtr_char3.bus_prtr_key AND bus_prtr_char3.act_stus_ind = 1 and bus_prtr_char3.char_type_key = '109bf075b3c8df3bb31aeeab84bd20f95cfd27d177fdebab4581732024e93b54') --Equipment Owner Type
LEFT JOIN daas_tm_prepared.dh_bus_prtr_char bus_prtr_char4 ON (a.bus_prtr_key = bus_prtr_char4.bus_prtr_key AND bus_prtr_char4.act_stus_ind = 1 and bus_prtr_char4.char_type_key = 'f49d12114258c1c62ec26c7d9be537d35935a60a6cbacea03ec85a7e9840d58c') --Equipment Owner Abbreviation
where a.bus_prtr_key = p_bus_prtr_key
and a.act_stus_ind = 1;

end;
$$
LANGUAGE 'plpgsql';
