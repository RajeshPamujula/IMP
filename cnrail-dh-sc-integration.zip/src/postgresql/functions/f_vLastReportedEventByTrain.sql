DROP FUNCTION IF EXISTS daas_tm_trusted."f_vLastReportedEventByTrain"(timestamp , text) cascade; -- 

CREATE or replace FUNCTION daas_tm_trusted."f_vLastReportedEventByTrain"(p_data_hub_crt_ts timestamp , p_trainIdentification text )
RETURNS TABLE(

"trainIdentification"   text,
"stationSequenceNumber"    text,
"eventCode"    text,
"eventStatusCode"   text,
"dataHubCreationTimestamp"  timestamp,
"eventTimestamp"   timestamp,
sor_evt_ts_tz_dst_cd  int2,
"stationScac"     text,
"stationFsac"   text,
"station333"    varchar(9),
"statoinProvinceState"   bpchar(2),
"timezoneLabel"      VARCHAR(10),
"utcOffsetValueHours"   NUMERIC(5, 3),
"trainEventKey"   bytea,
"stationSequenceTimestamp"    text,
rk bigint

    )
AS $$
BEGIN




-- part 1: change capture and apply the optional filter , limit 1000 records

create temporary table tbl_changes 
ON COMMIT DROP 
as
select dh_cnvy.id_val as "trainIdentification",
train.data_hub_crt_ts as "dataHubCreationTimestamp",
train.sor_evt_ts as "eventTimestamp",
train.sor_evt_ts_tz_dst_cd,
train.trsp_evt_key  

FROM daas_tm_prepared.dh_trsp_evt train
inner JOIN daas_tm_prepared.dh_cnvy_asct ON (dh_cnvy_asct.asct_obj_key = train.trsp_evt_key and train.act_stus_ind = 1) and train.trsp_evt_type_key = '62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a' --- Train Event
inner JOIN daas_tm_prepared.dh_cnvy ON (dh_cnvy.cnvy_key = dh_cnvy_asct.cnvy_key and dh_cnvy.act_stus_ind = 1 and dh_cnvy.cnvy_type_key = 'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698')
where train.data_hub_crt_ts > 
COALESCE(p_data_hub_crt_ts, (now()::timestamp  - interval '2 days')) 
;
create index tbl_changes_i0 on tbl_changes(trsp_evt_key);


-- part 2: parse parameter string to temporay table 
if p_trainIdentification is not null 
then
create temporary table tbl_id ( id_val text)  on commit drop;
insert into tbl_id(id_val)
 select distinct m.id_val
 from (select trim(unnest(string_to_array(p_trainIdentification ,','))) as id_val ) as m 
 ;
delete from tbl_changes where not exists (Select 1 from tbl_id where tbl_id.id_val=tbl_changes."trainIdentification" );
end if ;


-- part 3: return details
RETURN QUERY 
with alltrain as(
select train."trainIdentification",
train_char_4.char_val as "stationSequenceNumber",
substr(train_char_5.char_val,1,2) as "eventCode",
substr(train_char_5.char_val,3,2) as "eventStatusCode",
train."dataHubCreationTimestamp",
train."eventTimestamp",
train.sor_evt_ts_tz_dst_cd,
train_char_2.char_val as "stationScac",
train_char_3.char_val as "stationFsac",
stn.stn_333 as "station333",
stn.stn_st as "statoinProvinceState",
tz.tz_ofst_lbl as "timezoneLabel",
tz.utc_ofst_val_hr as "utcOffsetValueHours",
train.trsp_evt_key  as "trainEventKey",
train_char_6.char_val as "stationSequenceTimestamp",
ROW_NUMBER() OVER (PARTITION BY train."trainIdentification" ORDER BY train_char_4.char_val DESC, substr(train_char_5.char_val,1,2) DESC, train."eventTimestamp" DESC) rk
FROM 
tbl_changes train

inner join daas_tm_prepared.dh_trsp_evt_char train_char_4 on (train.trsp_evt_key = train_char_4.trsp_evt_key and train_char_4.act_stus_ind = 1 and train_char_4.char_type_key = '2cb5b0e9672838ba34acfd341a4d3e8f6e8e95c42fd7bfbe215fe72f2b3904e9' ) -- Station Sequence Number
inner join daas_tm_prepared.dh_trsp_evt_char train_char_5 on (train.trsp_evt_key = train_char_5.trsp_evt_key and train_char_5.act_stus_ind = 1 and train_char_5.char_type_key = '07814f276206869eb5b8e6777b5f06a1597ee49b2957f04b609d3c99093d11d7' ) -- event code

inner join daas_tm_prepared.dh_trsp_evt_char train_char_2 on (train.trsp_evt_key = train_char_2.trsp_evt_key and train_char_2.act_stus_ind = 1 and train_char_2.char_type_key = '2b77baf8b844500829fffd11357d1e243ee020adec77ea2cdc4b2934d8577d2a' ) -- scac event station carrier abbreviation
inner join daas_tm_prepared.dh_trsp_evt_char train_char_3 on (train.trsp_evt_key = train_char_3.trsp_evt_key and train_char_3.act_stus_ind = 1 and train_char_3.char_type_key = '61d9f08af8e5f9cc63abd8d3d1b42f2e3d4933e41449815f3574673e10cfe1fa' ) -- fsac event station FSAC

inner join daas_tm_prepared.dh_trsp_evt_char train_char_6 on (train.trsp_evt_key = train_char_6.trsp_evt_key and train_char_6.act_stus_ind = 1 and train_char_6.char_type_key = 'a4a7f99206741fbff8e56a0d3d32b2881ce75a59728c8aaa64c36918d0e40609' ) -- sequence timestamp
left join daas_tm_prepared.dh_rail_station stn ON (train_char_2.char_val = stn.scac and train_char_3.char_val = stn.fsac)
left join daas_tm_prepared.dh_tz_dst_ref tz ON train.sor_evt_ts_tz_dst_cd = tz.tz_dst_cd
)
select *  
FROM alltrain
where alltrain.rk=1
;

END;$$ SECURITY DEFINER
LANGUAGE plpgsql;



/*
--GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vLastReportedEventByTrain"( timestamp , text) TO public;
select * from daas_tm_trusted."f_vLastReportedEventByTrain"(now()::timestamp - interval '95 days', NULL);

select * from daas_tm_trusted."f_vLastReportedEventByTrain"(NULL, 'Q9463820210803');

 select * from daas_tm_trusted."f_vLastReportedEventByTrain"(now()::timestamp - interval '95 days', 'Q9463820210803');

select * from daas_tm_trusted."f_vLastReportedEventByTrain"(now()::timestamp - interval '95 days', NULL);

*/
