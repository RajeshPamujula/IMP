DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_stop_order_by_cnvy_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_stop_order_by_cnvy_key(p_cnvy_key bytea)

RETURNS TABLE
(
cnvy_key bytea,
"stopOrderIteration" bigint,
"stopTimestamp" text,
"stopOrderAuthorization" text,
"stopOrder" text,
"eventCode" text,
"eventCodeOverride" text,
"stopOrderStation333" text,
"stopOrderStationProvinceState" text

)
AS $$
BEGIN
RETURN QUERY

with mydata as(
select c.cnvy_key,a.cnvy_cmp_key, b.type_cd, a.char_val, c.data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_cmp_char a
inner join daas_tm_prepared.dh_ref_type b on a.char_type_key = b.type_key
inner join daas_tm_prepared.dh_cnvy_cmp c on c.cnvy_cmp_key = a.cnvy_cmp_key
and c.cnvy_cmp_type_key='d7cd65078ac119c66041926ff2612b6612994a6a4d583ae8401b54ad0f71edfa'  --Intra-Domain Conveyor-Stop Order
where a.act_stus_ind=1 and c.act_stus_ind=1
and c.cnvy_key= p_cnvy_key --'81f00f8cd936ac0b829a1a13f3401645288bd095033cc6c51f36b55ec7fb74a0' -- p_cnvy_key
)
,mypivot as (select mydata.cnvy_key
,mydata.cnvy_cmp_key 
,mydata.data_hub_crt_ts
,min(case when type_cd='Stop Timestamp' then char_val else null end ) as "stopTimestamp"
,min(case when type_cd='Stop Order Authorization' then char_val else null end ) as "stopOrderAuthorization"
,min(case when type_cd='Stop Order' then char_val else null end ) as "stopOrder"  -- I think stop order is number in source 
,min(case when type_cd='Event Code' then char_val else null end ) as "eventCode"
,min(case when type_cd='Event Code Override' then char_val else null end ) as "eventCodeOverride"
,min(case when type_cd='Station 333' then char_val else null end ) as "stopOrderStation333"
,min(case when type_cd='Station Province State Code' then char_val else null end ) as "stopOrderStationProvinceState"

,min(case when type_cd='Program Date' then char_val else null end ) as "programDate"
,min(case when type_cd='Program Time' then char_val else null end ) as "programTime"
from mydata
group by 1,2,3
)
select mypivot.cnvy_key, rank() over( partition by mypivot.cnvy_key   order by mypivot."programDate" , mypivot."programTime" ,  mypivot.data_hub_crt_ts) as "stopOrderIteration", mypivot."stopTimestamp",
mypivot."stopOrderAuthorization",mypivot."stopOrder",mypivot."eventCode",mypivot."eventCodeOverride",
mypivot."stopOrderStation333",mypivot."stopOrderStationProvinceState"
from mypivot;

END;
$$ LANGUAGE plpgsql;