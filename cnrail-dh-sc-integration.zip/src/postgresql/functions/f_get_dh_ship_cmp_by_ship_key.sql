DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_cmp_by_ship_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_cmp_by_ship_key(p_ship_key bytea)
RETURNS TABLE
(ship_key bytea,
"referenceNumberCode" text,
"oceanBillOfLading" text []
)
AS $$
begin
return query
SELECT
a.ship_key
, a.id_val as "referenceNumberCode"
,array_agg(b1.char_val) as "oceanBillOfLading"
FROM daas_tm_prepared.dh_ship_cmp a
INNER JOIN daas_tm_prepared.dh_ship_cmp_char b ON a.ship_cmp_key = b.ship_cmp_key and b.act_stus_ind = 1
and b.char_type_key = '0dcc508d48be45adf14a84e5c72fd6bbedccefd8d1f7671fabbaad4ac55effe5' ---'Reference Number Code'
INNER JOIN daas_tm_prepared.dh_ship_cmp_char b1  ON a.ship_cmp_key = b1.ship_cmp_key and b1.act_stus_ind = 1
and b1.char_type_key='d4f53dc6ab8256d581e1b5c2671de5860d6fd862889c99bc1a0b527c6e3aad0e' ---'Reference Number'
where TRIM(a.id_val) = 'OB'
and a.ship_key = p_ship_key
group by
a.ship_key, a.id_val;
end;
$$
LANGUAGE 'plpgsql';