DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_industrial_car_instruction_by_cnvy_key(bytea);

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_industrial_car_instruction_by_cnvy_key(p_cnvy_key bytea)
RETURNS TABLE
(
  cnvy_key bytea,
  "industrialCarInstruction" text []
)
AS $$
BEGIN
RETURN QUERY
select a.cnvy_key,  array_agg(d.char_val)
from daas_tm_prepared.dh_cnvy a
inner join daas_tm_prepared.dh_cnvy_asct b on a.cnvy_key = b.cnvy_key 
and b.asct_type_key='8c0358f49994d9758d327daac28ae25ee98dbfdc5b72c9c8a9a8551fbab2cc64'  --'Inter BCD Conveyor-Event' there is one Inter-BCD Conveyor-Event
and b.asct_obj_type_key='893dc0d5c11315c9d7e6fcd0fef1fa90c1652c52ff3013338d363196f5ec5d91' --'Industrial Car Instruction'
and b.act_stus_ind = 1
inner join daas_tm_prepared.dh_plan_evt c on b.asct_obj_key=c.plan_evt_key and c.act_stus_ind = 1
inner join daas_tm_prepared.dh_plan_evt_char d on c.plan_evt_key = d.plan_evt_key
and d.char_type_key = '94266c7f69395702e702f923aa2d7cb583118d289fa4f4122833035ddcaac27c' --Industrial Car Instruction
where a.cnvy_key=p_cnvy_key
group by 1;
END;
$$ LANGUAGE plpgsql;