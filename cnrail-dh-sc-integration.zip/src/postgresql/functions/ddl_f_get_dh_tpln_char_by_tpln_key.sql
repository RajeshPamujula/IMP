DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_tpln_char_by_tpln_key(bytea) cascade;


CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_tpln_char_by_tpln_key(p_tpln_key bytea)
RETURNS TABLE 
(
tpln_key bytea,
"dataHubCreationTimestamp" timestamp,

"action" text,
"committedTotalGoalHours" text,
"customerGoalNumber" text,
"customerGoalType" text,

"destinationETA"  text,
"destinationServiceYard333" text,
"destinationServiceYardProvinceStateCode" text,
"goalCutOffTimestamp" text,

"goalTimestamp" text,
"goalTotalHours" text,
"jeopardyReasonCode" text,
"originServiceYard333" text,

"originServiceYardProvinceStateCode" text,
"rescheduleReasonCode" text,
"stationSequenceNumber" text,
"totalScheduledMinutes" text
)
AS $$
begin
return query

select 
a.tpln_key as "tripPlanKey",
max(a.data_hub_crt_ts) as "dataHubCreationTimestamp",
max(case when type_cd = 'Action' then char_val else null end) as "action",
max(case when type_cd = 'Committed Total Goal Hours' then char_val else null end) as "committedTotalGoalHours",
max(case when type_cd = 'Customer Goal Number' then char_val else null end) as "customerGoalNumber",
max(case when type_cd = 'Customer Goal Type' then char_val else null end) as "customerGoalType",

max(case when type_cd = 'Destination ETA' then char_val else null end) as "destinationETA",
max(case when type_cd = 'Destination Service Yard 333' then char_val else null end) as "destinationServiceYard333",
max(case when type_cd = 'Destination Service Yard Province State Code' then char_val else null end) as "destinationServiceYardProvinceStateCode",
max(case when type_cd = 'Goal Cut Off Timestamp' then char_val else null end) as "goalCutOffTimestamp",

max(case when type_cd = 'Goal Timestamp' then char_val else null end) as "goalTimestamp",
max(case when type_cd = 'Goal Total Hours' then char_val else null end) as "goalTotalHours",
max(case when type_cd = 'Jeopardy Reason Code' then char_val else null end) as "jeopardyReasonCode",
max(case when type_cd = 'Origin Service Yard 333' then char_val else null end) as "originServiceYard333",

max(case when type_cd = 'Origin Service Yard Province State Code' then char_val else null end) as "originServiceYardProvinceStateCode",
max(case when type_cd = 'Reschedule Reason Code' then char_val else null end) as "rescheduleReasonCode",
max(case when type_cd = 'Station Sequence Number' then char_val else null end) as "stationSequenceNumber",
max(case when type_cd = 'Total Scheduled Minutes' then char_val else null end) as "totalScheduledMinutes"
from daas_tm_prepared.dh_tpln_char a
inner join daas_tm_prepared.dh_ref_type ref on ref.type_key=a.char_type_key
where a.tpln_key = p_tpln_key
and a.act_stus_ind = 1
group by 1;
end;
$$
LANGUAGE 'plpgsql';








