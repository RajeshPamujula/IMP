DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_latest_transportation_event_by_train_id();

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_latest_transportation_event_by_train_id(p_trn_id TEXT)
RETURNS TABLE 
(
	trn_id TEXT,
	trsp_evt_key BYTEA,
	rk BIGINT
)
AS $$
BEGIN
    RETURN query
	SELECT p_trn_id AS trn_id
			, te.trsp_evt_key 
			, row_number() over (partition by c.cnvy_key ORDER BY tec.char_val DESC, te.trsp_evt_val DESC) AS rk -- Departure over Arrival to break Event Station Sequence Timestamp tie
	FROM daas_tm_prepared.dh_cnvy c
	JOIN daas_tm_prepared.dh_cnvy_asct ca ON ca.act_stus_ind = 1 AND ca.cnvy_key = c.cnvy_key
	JOIN daas_tm_prepared.dh_trsp_evt te ON te.act_stus_ind = 1 AND te.trsp_evt_key = ca.asct_obj_key
	JOIN daas_tm_prepared.dh_ref_type r1 ON ca.cnvy_type_key = r1.type_key AND r1.type_cd = 'Train'
	JOIN daas_tm_prepared.dh_ref_type r2 ON ca.asct_obj_type_key = r2.type_key AND r2.type_cd = 'Train Event' AND r2.prnt_type_cd = 'Transportation Event'
	JOIN daas_tm_prepared.dh_trsp_evt_char tec ON tec.act_stus_ind = 1 AND te.trsp_evt_key = tec.trsp_evt_key 
	and tec.char_type_key = '2cb5b0e9672838ba34acfd341a4d3e8f6e8e95c42fd7bfbe215fe72f2b3904e9'  -- Station Sequence Number
	
	WHERE c.act_stus_ind = 1
	AND c.id_val = p_trn_id	
	;
END;
$$ LANGUAGE plpgsql;
