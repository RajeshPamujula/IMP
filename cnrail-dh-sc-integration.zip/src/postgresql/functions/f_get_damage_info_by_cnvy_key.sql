DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_damage_info_by_cnvy_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_damage_info_by_cnvy_key(p_cnvy_key bytea)
-- it seems for chassis only
RETURNS TABLE
(
  cnvy_key bytea,
  "damageIteration" bigint,
  "damageWhatCode" text,
  "damageWhereCode" text,
  "damageWhyCode" text,
  "damageResponsibility" text,
  "damageText" text

)
AS $$
BEGIN
RETURN QUERY

with mydata as(
select c.cnvy_key,a.cnvy_cmp_key,   b.type_cd, a.char_val
from daas_tm_prepared.dh_cnvy_cmp_char a
inner join daas_tm_prepared.dh_ref_type b on a.char_type_key = b.type_key
inner join daas_tm_prepared.dh_cnvy_cmp c on c.cnvy_cmp_key = a.cnvy_cmp_key
where a.act_stus_ind=1 and c.act_stus_ind=1
and c.cnvy_key= p_cnvy_key  --'81f00f8cd936ac0b829a1a13f3401645288bd095033cc6c51f36b55ec7fb74a0'  -- p_cnvy_key
)
,mypivot as (select mydata.cnvy_key
,mydata.cnvy_cmp_key
,min(case when type_cd='Damage What Code' then char_val else null end ) as "damageWhatCode"
,min(case when type_cd='Damage Where Code' then char_val else null end ) as "damageWhereCode"
,min(case when type_cd='Damage Why Code' then char_val else null end ) as "damageWhyCode"
,min(case when type_cd='Responsibility' then char_val else null end ) as "damageResponsibility"
,min(case when type_cd='Text' then char_val else null end ) as "damageText"
from mydata
group by 1,2
)
select mypivot.cnvy_key, rank() over( partition by mypivot.cnvy_key order by mypivot.cnvy_cmp_key) as "damageIteration", 
mypivot."damageWhatCode",mypivot."damageWhereCode",mypivot."damageWhyCode",mypivot."damageResponsibility",mypivot."damageText"
from mypivot;

END;
$$ LANGUAGE plpgsql;
