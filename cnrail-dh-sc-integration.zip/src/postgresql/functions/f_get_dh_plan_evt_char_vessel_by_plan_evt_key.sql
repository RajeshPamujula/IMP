CREATE OR REPLACE FUNCTION f_get_dh_plan_evt_char_vessel_by_plan_evt_key(p_plan_evt_key bytea)
returns table(plan_evt_key bytea,
Original_Arrival_Tz_Dst_Cd text,
Original_Arrival_UTC text,
Scheduled_Arrival_Tz_Dst_Cd text,
Scheduled_Arrival_UTC text,
Scheduled_Cut_Off_Tz_Dst_Cd text,
Scheduled_Cut_Off_UTC text,
Scheduled_Sailing_Tz_Dst_Cd text,
Scheduled_Sail_UTC text)
AS $$
begin
return query
select main.plan_evt_key,
max(case when ref_type.type_cd = 'Original Arrival Tz Dst Cd' then c.char_val else null end) as Original_Arrival_Tz_Dst_Cd,
max(case when ref_type.type_cd = 'Original Arrival UTC' then c.char_val else null end) as Original_Arrival_UTC,
max(case when ref_type.type_cd = 'Scheduled Arrival Tz Dst Cd' then c.char_val else null end) as Scheduled_Arrival_Tz_Dst_Cd,
max(case when ref_type.type_cd = 'Scheduled Arrival UTC' then c.char_val else null end) as Scheduled_Arrival_UTC,
max(case when ref_type.type_cd = 'Scheduled Cut Off Tz Dst Cd' then c.char_val else null end) as Scheduled_Cut_Off_Tz_Dst_Cd,
max(case when ref_type.type_cd = 'Scheduled Cut-Off UTC' then c.char_val else null end) as Scheduled_Cut_Off_UTC,
max(case when ref_type.type_cd = 'Scheduled Sailing Tz Dst Cd' then c.char_val else null end) as Scheduled_Sailing_Tz_Dst_Cd,
max(case when ref_type.type_cd = 'Scheduled Sail UTC' then c.char_val else null end) as Scheduled_Sail_UTC
from daas_tm_prepared.dh_plan_evt main
left  join daas_tm_prepared.dh_plan_evt_char c
on    main.plan_evt_key = c.plan_evt_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.plan_evt_key = p_plan_evt_key and main.act_stus_ind = 1
group by main.plan_evt_key;
end;
$$ LANGUAGE plpgsql;

