DROP FUNCTION IF EXISTS daas_tm_trusted.f_run_dh_get_cnvy_cond_by_container(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_run_dh_get_cnvy_cond_by_container(p_cnvy_key bytea)
RETURNS TABLE 
(

"badOrderCode" text,
"firstStorageChargeDate" text,
cnvy_key bytea,
"conveyorConditionProcessTimestamp" timestamp without time zone
)
AS $$
begin
return query

select 
cnvy_cond.char_val as "badOrderCode",
cnvy_cond_3.char_val as "firstStorageChargeDate",
a.cnvy_key,
cnvy_cond.rpt_sor_proc_ts as "conveyorConditionProcessTimestamp"

from daas_tm_prepared.dh_cnvy a
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond on (a.cnvy_key = cnvy_cond.cnvy_key and cnvy_cond.act_stus_ind = 1 and cnvy_cond.char_type_key = '07ed1078042c7692da1672e604d7b8cca3f42fad6fc79385ab9c57c9a23a2ce2') -- bad order code
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_3 on (a.cnvy_key = cnvy_cond_3.cnvy_key and cnvy_cond_3.act_stus_ind = 1 and cnvy_cond_3.char_type_key = 'd9fb9ddc0f66f8f86633f9eafc57a87e40c6d21e75b1f97c1997c6b96e835d85') -- First Storage Charge Date
where a.cnvy_key = p_cnvy_key
and a.act_stus_ind = 1;
end;
$$ LANGUAGE plpgsql;