DROP FUNCTION IF EXISTS daas_tm_trusted.f_is_date(character varying) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_is_date(character varying)
RETURNS bool AS 
$$
begin
perform s::date;
return true;
exception when others then
return false;
end;
$$ LANGUAGE plpgsql;