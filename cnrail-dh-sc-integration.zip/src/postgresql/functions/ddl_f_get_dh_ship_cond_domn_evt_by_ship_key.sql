DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_cond_domn_evt_by_ship_key(bytea, timestamp) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_cond_domn_evt_by_ship_key(p_ship_key bytea, p_sor_proc_ts timestamp )
/*
p_sor_proc_ts: pass rpt_sor_proc_ts from dh_ship_cond not dh_ship
no data in the 
*/
RETURNS TABLE 
(
"shipmentKey" bytea,
"sourceProcessDateTime" timestamp without time zone,


"intermodalHandlingCode1" text,
"intermodalHandlingCode2" text,
"intermodalHandlingCode3" text,


"specialConditionCode1" text,
"specialConditionCode2" text,
"specialConditionCode3" text,
"specialConditionCode4" text,
"specialConditionCode5" text,
"specialConditionCode6" text
)
AS $$
begin
return query




with prvs_ship_cond as (
select distinct ref.type_cd,  a.char_val, a.sor_proc_ts
,dense_rank() over(PARTITION BY a.ship_key,ref.type_cd order by a.sor_proc_ts desc, a.data_hub_crt_ts desc) as rk
,a.ship_key
from daas_tm_prepared.dh_ship_cond_domn_evt  a
inner join daas_tm_prepared.dh_ref_type ref on ref.type_key=a.cond_char_key
where a.ship_key= p_ship_key --'5d41cbf68128101d45cc00304e48e73f519f1b2e70a3cbd89da04ec8dd75a1d3'
--and sor_proc_ts <p_sor_proc_ts  -- TO_TIMESTAMP(    '2021-01-15 13:01:15.4690000',    'YYYY-MM-DD HH24:MI:SS.nnnnnnn')::timestamp
)
select 
ship_key as "shipmentKey",
sor_proc_ts as "sourceProcessDateTime",


max(case when type_cd = 'Intermodal Handling Code 1' then char_val else null end) as "intermodalHandlingCode1",
max(case when type_cd = 'Intermodal Handling Code 2' then char_val else null end) as "intermodalHandlingCode2",
max(case when type_cd = 'Intermodal Handling Code 3' then char_val else null end) as "intermodalHandlingCode3",
max(case when type_cd = 'Special Condition Code 1' then char_val else null end) as "specialConditionCode1",

max(case when type_cd = 'Special Condition Code 2' then char_val else null end) as "specialConditionCode2",
max(case when type_cd = 'Special Condition Code 3' then char_val else null end) as "specialConditionCode3",
max(case when type_cd = 'Special Condition Code 4' then char_val else null end) as "specialConditionCode4",
max(case when type_cd = 'Special Condition Code 5' then char_val else null end) as "specialConditionCode5",

max(case when type_cd = 'Special Condition Code 6' then char_val else null end) as "specialConditionCode6"

from prvs_ship_cond
where rk=2
group by 1,2;

end;
$$
LANGUAGE 'plpgsql';



