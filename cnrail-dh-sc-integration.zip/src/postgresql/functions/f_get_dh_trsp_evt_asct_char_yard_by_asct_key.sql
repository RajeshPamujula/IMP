DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_trsp_evt_asct_char_yard_by_asct_key(p_asct_key bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_trsp_evt_asct_char_yard_by_asct_key(p_asct_key bytea)
returns table(asct_key bytea,
"dataHubCreationTimestamp" timestamp,
Lift_Code text,
Lot text,
Park_or_Track_Code text,
"row" text,
Spot text,
Track_Area text,
Track_Number text,
Event_Station_333 text,
Event_Station_Province_State_Code text,
Event_Station_Carrier_Abbreviation text,
Event_Station_FSAC text)
AS $$
begin
return query
select main.asct_key,
max(c.data_hub_crt_ts) as "dataHubCreationTimestamp",
max(case when ref_type.type_cd = 'Lift Code' then c.char_val else null end) as Lift_Code,
max(case when ref_type.type_cd = 'Lot' then c.char_val else null end) as Lot,
max(case when ref_type.type_cd = 'Park or Track Code' then c.char_val else null end) as Park_or_Track_Code,
max(case when ref_type.type_cd = 'Row' then c.char_val else null end) as "row",
max(case when ref_type.type_cd = 'Spot' then c.char_val else null end) as Spot,
max(case when ref_type.type_cd = 'Track Area' then c.char_val else null end) as Track_Area,
max(case when ref_type.type_cd = 'Track Number' then c.char_val else null end) as Track_Number,
max(case when ref_type.type_cd = 'Event Station 333' then c.char_val else null end) as Event_Station_333, 
max(case when ref_type.type_cd = 'Event Station Province State Code' then c.char_val else null end) as Event_Station_Province_State_Code,
max(case when ref_type.type_cd = 'Event Station Carrier Abbreviation' then c.char_val else null end) as Event_Station_Carrier_Abbreviation,
max(case when ref_type.type_cd = 'Event Station FSAC' then c.char_val else null end) as Event_Station_FSAC 
from daas_tm_prepared.dh_trsp_evt_asct main
left join daas_tm_prepared.dh_trsp_evt_asct_char c
on main.asct_key = c.asct_key
and c.act_stus_ind = 1
left join daas_tm_prepared.dh_ref_type ref_type
on c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key and main.act_stus_ind = 1
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;