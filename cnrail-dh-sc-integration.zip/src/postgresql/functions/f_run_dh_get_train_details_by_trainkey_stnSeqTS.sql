--function to get train details by station sequence timestamp
DROP FUNCTION if exists f_run_dh_get_train_details_by_trainkey_stnSeqTS(bytea,text) cascade;
--function to get train details by station sequence timestamp
CREATE OR REPLACE FUNCTION f_run_dh_get_train_details_by_trainkey_stnSeqTS(p_cnvy_key bytea, p_max_station_sequence_ts text)
RETURNS TABLE 
(trsp_evt_val text,
"stationSequenceTimestamp" text,
"stationScac" text,
"stationFsac" text,
"station333" character varying(9),
"stationProvinceState" character(2),
"stationName" character varying(19),
"subdivisionCode" character(4),
"divisionCode" character(2),
"subregionCode" character(2),
"regionCode" character(2),
"loadedCarCount" text,
"emptyCarCount" text,
"totalCarWeight" text,
"totalCarWeightUnitOfMeasure" text,
"totalCarLength" text,
"totalCarLengthUOM" text,
"totalLocomotiveWeight" text,
"totalLocomotiveWeightUOM" text,
"totalLocomotiveLength" text,
"totalLocomotiveLengthUOM" text,
"horsepowerPerTon" text,
"totalAvailableHorsepower" text,
"distributedPowerIndicator" text,
"trainTimestampUtc" timestamp without time zone,
"trainTimestampTimezoneLabel" character varying(10),
"trainTimestampOffsetValueHours" numeric(5,3))
AS $$
begin
return query
select te.trsp_evt_val,
tec.char_val as "stationSequenceTimestamp", 
tec1.char_val as "stationScac",
tec2.char_val as "stationFsac",
stn_333 as "station333", 
stn_st as "stationProvinceState", 
stn_nm as "stationName", 
sdiv_cd as "subdivisionCode",
div_cd as "divisionCode", 
srgn_cd as "subregionCode",
rgn_cd as "regionCode", 
tec3.char_val as "loadedCarCount",
tec4.char_val as "emptyCarCount",
tec5.char_val as "totalCarWeight",
tec6.char_val as "totalCarWeightUnitOfMeasure",
tec7.char_val as "totalCarLength",
tec8.char_val as "totalCarLengthUOM",
tec9.char_val as "totalLocomotiveWeight",
tec10.char_val as "totalLocomotiveWeightUOM",
tec11.char_val as "totalLocomotiveLength",
tec12.char_val as "totalLocomotiveLengthUOM",
tec13.char_val as "horsePowerPerTon",
tec14.char_val as "totalavailablehorsePower",
tec15.char_val as "distributedPowerIndicator",
te.sor_evt_ts as "trainTimestampUtc",
tz.tz_lbl as "trainTimestampTimezoneLabel",
tz.utc_ofst_val_hr as "trainTimestampOffsetValueHours"
from daas_tm_prepared.dh_cnvy_asct ca
inner join daas_tm_prepared.dh_trsp_evt te on (ca.asct_obj_key = te.trsp_evt_key and te.act_stus_ind = 1)
left join daas_tm_prepared.dh_trsp_evt_char tec on (te.trsp_evt_key = tec.trsp_evt_key and tec.act_stus_ind = 1 and tec.char_type_key = 'a4a7f99206741fbff8e56a0d3d32b2881ce75a59728c8aaa64c36918d0e40609' and tec.char_val <= p_max_station_sequence_ts)  -- station sequence timestamp
left join daas_tm_prepared.dh_trsp_evt_char tec1 on (te.trsp_evt_key = tec1.trsp_evt_key and tec1.act_stus_ind = 1 and tec1.char_type_key = '2b77baf8b844500829fffd11357d1e243ee020adec77ea2cdc4b2934d8577d2a')  -- station scac
left join daas_tm_prepared.dh_trsp_evt_char tec2 on (te.trsp_evt_key = tec2.trsp_evt_key and tec2.act_stus_ind = 1 and tec2.char_type_key = '61d9f08af8e5f9cc63abd8d3d1b42f2e3d4933e41449815f3574673e10cfe1fa')  -- station fsac
left join daas_tm_prepared.dh_trsp_evt_char tec3 on (te.trsp_evt_key = tec3.trsp_evt_key and tec3.act_stus_ind = 1 and tec3.char_type_key = 'e132cbd462163886412bd30aedc2e5d755deb097fc8fa192d5c9d458829688e2')  -- Loaded Car Count
left join daas_tm_prepared.dh_trsp_evt_char tec4 on (te.trsp_evt_key = tec4.trsp_evt_key and tec4.act_stus_ind = 1 and tec4.char_type_key = 'd93535156c0b78ff02141c91fb26849a6963bb45758b233437ea86f3be30398f')  -- Empty Car Count
left join daas_tm_prepared.dh_trsp_evt_char tec5 on (te.trsp_evt_key = tec5.trsp_evt_key and tec5.act_stus_ind = 1 and tec5.char_type_key = '41ddd7402a2472cad0b6934384b861f43129a26a4e7cfa63e99fb300beb4f7ed')  -- Total Car Weight
left join daas_tm_prepared.dh_trsp_evt_char tec6 on (te.trsp_evt_key = tec6.trsp_evt_key and tec6.act_stus_ind = 1 and tec6.char_type_key = 'bad2b2df015349d823072064d2869157337a7b3222ccf19546d2adaebf0a1b0a')  -- Total Car Weigt UOM
left join daas_tm_prepared.dh_trsp_evt_char tec7 on (te.trsp_evt_key = tec7.trsp_evt_key and tec7.act_stus_ind = 1 and tec7.char_type_key = '182bc50ebffede7cbc8df4849d9a17277b2026bbdea95bb2ef62bc5fd43dc4af')  -- Total Car Length
left join daas_tm_prepared.dh_trsp_evt_char tec8 on (te.trsp_evt_key = tec8.trsp_evt_key and tec8.act_stus_ind = 1 and tec8.char_type_key = 'c6859585ea1959dbf9adb554b1062bc4e909eeed52b20c18b545d653f6e2e069')  -- Total Car Length UOM
left join daas_tm_prepared.dh_trsp_evt_char tec9 on (te.trsp_evt_key = tec9.trsp_evt_key and tec9.act_stus_ind = 1 and tec9.char_type_key = '390482c2fbb8f9dd6dd49a957cd3a25f6c49aaf414984c19234a2b943ac90aef')  -- total Locomotive Weight
left join daas_tm_prepared.dh_trsp_evt_char tec10 on (te.trsp_evt_key = tec10.trsp_evt_key and tec10.act_stus_ind = 1 and tec10.char_type_key = '2e00f00c58f672b78f74e65b79614235e0a217bbef364fbc728d09a8a9b54ed1')  -- total locomotive Weight UOM
left join daas_tm_prepared.dh_trsp_evt_char tec11 on (te.trsp_evt_key = tec11.trsp_evt_key and tec11.act_stus_ind = 1 and tec11.char_type_key = '2d391aceb762217ae2a8d75fde1a70979acba26c15f4f1d749d36125cd1b162c')  -- total Locomotive Length
left join daas_tm_prepared.dh_trsp_evt_char tec12 on (te.trsp_evt_key = tec12.trsp_evt_key and tec12.act_stus_ind = 1 and tec12.char_type_key = '3b4223c02e1b029f187309c40e5024d91ea4025c1509d36604df8e8579468aaa')  -- total locomotive length UOM
left join daas_tm_prepared.dh_trsp_evt_char tec13 on (te.trsp_evt_key = tec13.trsp_evt_key and tec13.act_stus_ind = 1 and tec13.char_type_key = '9c0c00f6b30a3448e9b5292066bb75c2fe52fcea32bcf9c5473760c0076f86ef')  -- horse power per ton
left join daas_tm_prepared.dh_trsp_evt_char tec14 on (te.trsp_evt_key = tec14.trsp_evt_key and tec14.act_stus_ind = 1 and tec14.char_type_key = 'a5c72173eee7783fd5dcc7b9335e2490a2fd4aa092115a9e4d96cdd62b7982da')  -- total available horse power
left join daas_tm_prepared.dh_trsp_evt_char tec15 on (te.trsp_evt_key = tec15.trsp_evt_key and tec15.act_stus_ind = 1 and tec15.char_type_key = '9a5cd524cd89d84dc4ee9738871d6176cad76899aa60e72a5dfdcde8e07be590')  -- distributed power
left join daas_tm_prepared.dh_rail_station station on (tec1.char_val = station.scac and tec2.char_val = station.fsac)
left join daas_tm_prepared.dh_tz_dst_ref tz on (te.sor_evt_ts_tz_dst_cd = tz.tz_dst_cd)
where ca.cnvy_key = p_cnvy_key and ca.act_stus_ind = 1;
end;
$$ LANGUAGE plpgsql;
