DROP FUNCTION IF EXISTS daas_tm_trusted."f_vCarOrderIn"( text) cascade; -- 

CREATE or replace FUNCTION daas_tm_trusted."f_vCarOrderIn"( p_railcarId text )
RETURNS TABLE(

"dataHubCreationTimestamp" timestamp,
"railcarId" text, 
"equipmentInitial"  text, 
"equipmentNumber"  text, 

"operatingCustomer633"   text, 
"operatingCity333"   text,
"operatingCityProvinceStateCode"   text,
"opZts"   text,
"customerSwitchCode"   text,
"carLocationCode"   text,

"currentSpot"   text,
"trackNumber"   text,
"trackStation333" varchar(9),
"trackStationProvinceStateCode" varchar(2),
"badOrderCode"    text,
"mechanicalStatusCode1"   text,
"mechanicalStatusCode2"   text,
"mechanicalStatusCode3"   text,
"transportationServiceOffice333"   text,
"transportationServiceOfficeProvinceStateCode"   text,
"operatingTransportationServiceOffice333"   varchar(9),
"operatingTransportationServiceOfficeProvinceStateCode"  varchar(2),

"waybillNumber"   text,
"waybillRecordType"   text,

"waybillStatusCode"   text,
"specialConditionCode1"   text,
"specialConditionCode2"   text,
"specialConditionCode3"   text,
"specialConditionCode4"   text,
"specialConditionCode5"   text,
"specialConditionCode6"   text,
"loadEmptyStatusCode"   text,

"waybillIdentifier"  text, -- internal fields
ship_key  bytea, -- internal fields
"waybillLastChangeTs"  timestamp, -- internal fields
"waybillRank" integer -- internal fields

    )
AS $$
BEGIN


-- part 1: parse parameters

create temporary table tbl_id ( id_val text, cnvy_key bytea PRIMARY KEY)
on commit drop
  ;
insert into tbl_id(id_val, cnvy_key)
 select distinct cnvy.id_val, cnvy.cnvy_key
 from (select trim(unnest(string_to_array(p_railcarId ,','))) as id_val ) as m 
 inner join daas_tm_prepared.dh_cnvy cnvy on m.id_val=cnvy.id_val
 and (cnvy.cnvy_type_key = 'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' -- Rail Car
or cnvy.cnvy_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' ) -- RailCar
 ;

create index tbl_id_io on tbl_id(id_val, cnvy_key);


-- part 2: create table tbl_cnvy_ship due to performance issue
create temporary table tbl_cnvy_ship 
on commit drop 
as
select cnvy.cnvy_key
,cnvy.id_val as "railcarId"
,g.char_val as "waybillStatusCode"
,main.id_val as "waybillIdentifier"
,main.ship_key
,c.data_hub_crt_ts as"waybillLastChangeTs" 
--, rank() over (partition by cnvy.id_val order by (case when  g.char_val ='A' then 1 else 2 end) , g.data_hub_crt_ts  desc) as "waybillRank"
FROM tbl_id cnvy
inner join daas_tm_prepared.dh_ship_char c on c.act_stus_ind=1
and c.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
and cnvy.id_val=c.char_val
inner join daas_tm_prepared.dh_ship main on main.ship_key=c.ship_key and main.act_stus_ind=1
inner join daas_tm_prepared.dh_ship_cond g on g.ship_key=main.ship_key 

and g.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083'  -- waybill status
and g.act_stus_ind=1;

create index tbl_cnvy_ship_io on tbl_cnvy_ship(cnvy_key);


-- part 3: create table tbl_waybill

create temporary table tbl_waybill_info 
on commit drop 
as 
select 
cnvy.cnvy_key
,cnvy.id_val as "railcarId"
,sc.Waybill_Number as "waybillNumber"
,sc.Waybill_Record_Type as "waybillRecordType"
,b."waybillStatusCode"
,scond."specialConditionCode1"
,scond."specialConditionCode2"
,scond."specialConditionCode3"
,scond."specialConditionCode4"
,scond."specialConditionCode5"
,scond."specialConditionCode6"
,sc.Load_Empty_Status_Code as "loadEmptyStatusCode"
,b."waybillIdentifier"
,b.ship_key
,b."waybillLastChangeTs" 
, rank() over (partition by cnvy.id_val order by (case when  b."waybillStatusCode" ='A' then 1 else 2 end) , b."waybillLastChangeTs"  desc) as "waybillRank"
,greatest(sc."dataHubCreationTimestamp",scond."dataHubCreationTimestamp" ) as max_data_hub_crt_ts
FROM tbl_id cnvy
left join tbl_cnvy_ship b on cnvy.cnvy_key=b.cnvy_key and b."waybillStatusCode" in ('A','S','O' ) 
left join daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(b.ship_key) sc on 1=1
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key (b.ship_key) scond on 1=1
;



create index tbl_waybill_info_io on tbl_waybill_info(cnvy_key);


-- part 4: return details
RETURN QUERY 


select 
greatest(a.max_data_hub_crt_ts,ccond."dataHubCreationTimestamp", tea.data_hub_crt_ts ) as "dataHubCreationTimestamp"
,a."railcarId"
,cnvy_char.Equipment_Initial as "equipmentInitial"
,cast(cast(cnvy_char.Equipment_Number  as integer) as text) as "equipmentNumber"

,ccond."operatingCustomer633"
,ccond."operatingCity333"
,ccond."operatingCity333ProvinceStateCode" as "operatingCityProvinceStateCode"
,ccond."operatingZoneTrackSpot" as "opZts"
,ccond."customerSwitchCode"
,ccond."carLocationCode"


,trsp_evt_asct_char.current_spot AS "currentSpot"
,trim(trsp_evt_asct_char.Track_Number) AS "trackNumber"
,cast(trim(trk.stn_333) as varchar(9)) as "trackStation333"
,cast(trim(trk.stn_prst_cd) as varchar(2)) as "trackStatoinProvinceStateCode"
,ccond."badOrderCode" 
,ccond."mechanicalStatusCode1"
,ccond."mechanicalStatusCode2"
,ccond."mechanicalStatusCode3"
,ccond."transportationServiceOffice333" -- blank
,ccond."transportationServiceOfficeProvinceStateCode"  -- blank
,cast('optso333' as varchar(9))as "operatingTransportationServiceOffice333" -- r1.tso_333 as "operatingTransportationServiceOffice333"  -- varchar(9)
,cast('st' as varchar(2)) as "operatingTransportationServiceOfficeProvinceStateCode" -- r1.tso_st as "operatingTransportationServiceOfficeProvinceStateCode"  --varchar(2)

,a."waybillNumber"
,a."waybillRecordType"

,a."waybillStatusCode"
,a."specialConditionCode1"
,a."specialConditionCode2"
,a."specialConditionCode3"
,a."specialConditionCode4"
,a."specialConditionCode5"
,a."specialConditionCode6"
,a."loadEmptyStatusCode"
,a."waybillIdentifier"  -- internal fields
,a.ship_key -- internal fields
,a."waybillLastChangeTs"  -- internal fields
,cast(a."waybillRank" as integer) as "waybillRank"-- internal fields
FROM tbl_waybill_info a
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key (a.cnvy_key) cnvy_char ON 1= 1
left join daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key(a.cnvy_key) ccond on 1=1
LEFT JOIN daas_tm_prepared.dh_ship_asct sa ON sa.asct_obj_key = a.cnvy_key AND sa.act_stus_ind = 1 
AND sa.asct_obj_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' -- Railcar
LEFT JOIN daas_tm_prepared.dh_trsp_evt te ON te.trsp_evt_key = sa.asct_obj_key AND te.act_stus_ind = 1
LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON te.trsp_evt_key = tea.trsp_evt_key --AND tea.act_stus_ind = 1
left join daas_tm_trusted.f_get_dh_trsp_evt_asct_char_equipment_by_asct_key (tea.asct_key) trsp_evt_asct_char on 1 = 1
left join daas_tm_prepared.dh_trk_ref trk on trk.trk_nbr=trim(trsp_evt_asct_char.Track_Number)
left join daas_tm_prepared.dh_rail_station r1 on r1.stn_333=ccond."operatingCity333"
and r1.stn_st=ccond."operatingCity333ProvinceStateCode"
;




END;$$ SECURITY DEFINER
LANGUAGE plpgsql;


--GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vCarOrderIn"(  text) TO public;



--select * from daas_tm_trusted."f_vCarOrderIn"('DTTX645866');

--select * from daas_tm_trusted."f_vCarOrderIn"('DTTX645866,DTTX645867,DTTX645868');


--select * from daas_tm_trusted."f_vCarOrderIn"('DTTX645866,DTTX645867,DTTX645867');


