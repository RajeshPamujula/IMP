CREATE OR REPLACE FUNCTION f_get_dh_trsp_evt_asct_char_equipment_by_asct_key(p_asct_key bytea)
returns table(asct_key bytea,
Current_Spot text,
Track_Number text,
Track_Sequence_Number text)
AS $$
begin
return query
select main.asct_key,
max(case when ref_type.type_cd = 'Current Spot' then c.char_val else null end) as Current_Spot,
max(case when ref_type.type_cd = 'Track Number' then c.char_val else null end) as Track_Number,
max(case when ref_type.type_cd = 'Track Sequence Number' then c.char_val else null end) as Track_Sequence_Number
from daas_tm_prepared.dh_trsp_evt_asct main
left  join daas_tm_prepared.dh_trsp_evt_asct_char c
on    main.asct_key = c.asct_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key 
--and main.act_stus_ind = 1  --will rollback
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;
