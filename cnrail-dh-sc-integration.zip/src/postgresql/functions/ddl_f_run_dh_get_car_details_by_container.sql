--function to get car details by container
DROP FUNCTION IF EXISTS daas_tm_trusted.f_run_dh_get_car_details_by_container(bytea) cascade ;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_run_dh_get_car_details_by_container(p_cnvy_key bytea)
RETURNS TABLE 
(
asct_sor_proc_ts timestamp without time zone,
dasc_sor_proc_ts timestamp without time zone,
sor_ingt_crt_ts timestamp without time zone,
sor_evt_ts timestamp without time zone,
eqp_init character varying(4),
eqp_nbr character varying(10),
trsp_evt_val text,
eventtimestamputc timestamp without time zone,
badordercode text,
holdcode text,
opZTS text,
carLocationCode text,
tracknumber text,
tracksequencenumber text,
trainidentification text,
processtimestamputc timestamp without time zone,
stn_333_key bytea,
sor_evt_ts_tz_dst_cd smallint,
sor_proc_ts_tz_dst_cd smallint,
max_data_hub_crt_ts timestamp without time zone
)
AS $$
begin
return query
select
    cont_car.asct_sor_proc_ts,
    cont_car.dasc_sor_proc_ts,
    cont_car.sor_ingt_crt_ts,
    cont_car.sor_evt_ts,
    RCAR.eqp_init,
    RCAR.eqp_nbr,
    tde.trsp_evt_val,
    tde.sor_evt_ts as eventTimestampUtc,
    cnvy_cond.char_val as badOrderCode,
    cnvy_cond_2.char_val as holdCode,
    cnvy_cond_3.char_val as opZTS,
    cnvy_cond_4.char_val as carLocationCode,
    tac.char_val as trackNumber,
    tac_2.char_val as trackSequenceNumber,
    sa_char.char_val as trainIdentification,
    tde.rpt_sor_proc_ts as processTimestampUtc,
    TEA.asct_obj_key as stn_333_key,
    tde.sor_evt_ts_tz_dst_cd,
    tde.sor_proc_ts_tz_dst_cd,
	/*tde.data_hub_crt_ts,
	rcar.data_hub_crt_ts,
	cnvy_cond.data_hub_crt_ts,
	tea.data_hub_crt_ts,
	ship_asct.data_hub_crt_ts,*/
	
	(select max(x) from unnest(array[tde.data_hub_crt_ts,	rcar.data_hub_crt_ts,	cnvy_cond.data_hub_crt_ts,	tea.data_hub_crt_ts,	ship_asct.data_hub_crt_ts  ]) as x ) as max_data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_asct cont_car
         inner join DAAS_TM_PREPARED.DH_TRSP_EVT TDE on (cont_car.asct_obj_key = TDE.trsp_evt_key and TDE.act_stus_ind = 1 and tDE.TRSP_EVT_TYPE_KEY =  'f6b530b0ea00c27747543eb950d814eb0aedce2edfdc5ac49313296fb2238f02') -- for 'Railcar Event' from Car Inventory)
         inner join daas_tm_prepared.dh_rcar_ref RCAR on (TDE.TRSP_EVT_KEY = rcar.rcar_key)
         left join daas_tm_prepared.dh_cnvy_cond cnvy_cond on (tde.trsp_evt_key = cnvy_cond.cnvy_key and cnvy_cond.act_stus_ind = 1 and cnvy_cond.char_type_key = '07ed1078042c7692da1672e604d7b8cca3f42fad6fc79385ab9c57c9a23a2ce2') -- bad order code
         left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_2 on (tde.trsp_evt_key = cnvy_cond_2.cnvy_key and cnvy_cond_2.act_stus_ind = 1 and cnvy_cond_2.char_type_key = '665ce7a009722311c22f1e1011f1fc80fdc720870d1b70499485d5d9a766a538') -- mechanical status code
         left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_3 on (tde.trsp_evt_key = cnvy_cond_3.cnvy_key and cnvy_cond_3.act_stus_ind = 1 and cnvy_cond_3.char_type_key = '3906d5d1ce0de47ce42e8777788ca8ed5634909d874846155c1f89ebf160283b') -- Op ZTS
         left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_4 on (tde.trsp_evt_key = cnvy_cond_4.cnvy_key and cnvy_cond_4.act_stus_ind = 1 and cnvy_cond_4.char_type_key = '152b3084acd766f46b6fc8ad813990cfbc37a204f92b02f8f9aa52e34a437799') -- Car Location code
         inner join DAAS_TM_PREPARED.dh_trsp_evt_asct TEA on (tde.trsp_evt_key = tea.trsp_evt_key
--         AND  tea.act_stus_ind = 1
         )
         left join daas_tm_prepared.dh_trsp_evt_asct_char TAC on (TEA.asct_key = TAC.asct_key 
--         and tac.act_stus_ind = 1 
         and tac.char_type_key = '22fba95bb00160a504606f34b153dbd889ed746cc7d7f794472aa48b7bdbb41a')   -- track number
         left join daas_tm_prepared.dh_trsp_evt_asct_char TAC_2 on (TEA.asct_key = TAC_2.asct_key 
--         and tac_2.act_stus_ind = 1 
         and tac_2.char_type_key = 'a83fa7f14d9937952df568bcfb79fb3516b4f847ecb90799dd431c0c25215af9')   -- track sequence number
		 
         left join daas_tm_prepared.dh_ship_asct ship_asct on (TDE.trsp_evt_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
         left join daas_tm_prepared.dh_ship_asct_char sa_char on (ship_asct.asct_key = sa_char.asct_key and sa_char.act_stus_ind =1 and sa_char.char_type_key = '06336730586527e31d5f9f12871d505364457590976fc83d32651a06869d3aa1') -- Current Assignment
where cont_car.cnvy_key = p_cnvy_key
  and cont_car.cnvy_type_key = '8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a'    ---   container
  and cont_car.asct_type_key = '0ba452470ff9f23b1d2e999f5afea823e1d7bab4913da2dc17aba3c6e784f011'    ---   Intra-BCD Container-Railcar
  and cont_car.asct_obj_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9'    ---   Railcar
  and cont_car.act_stus_ind = 1;
end;
$$ LANGUAGE plpgsql;


