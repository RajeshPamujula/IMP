DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_container_info_by_railcar_key(bytea);

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_container_info_by_railcar_key(p_cnvy_key bytea)
RETURNS TABLE
(
  cnvy_key bytea,
  "containerInfo" text[]
  )
AS $$
BEGIN
RETURN QUERY
select m.cnvy_key , array_agg(m."containerInfo") as "containerInfo"
from (
select   
a.cnvy_key
, a.id_val as "equipmentIdentification"
, e.id_val as "containerIdentification"
, e.cnvy_key as container_cnvy_key
, b.asct_key 
, f1.char_val as "containerInitial"
, f2.char_val as "containerNumber"
, f1.char_val || ',' || f2.char_val ||','|| 'Container Position on Flat Car' as "containerInfo"
FROM daas_tm_prepared.dh_cnvy a
inner join daas_tm_prepared.dh_cnvy_asct b on a.cnvy_key=b.asct_obj_key and b.act_stus_ind=1 
and b.asct_type_key='0ba452470ff9f23b1d2e999f5afea823e1d7bab4913da2dc17aba3c6e784f011' --Intra-BCD Container-Railcar
and b.cnvy_type_key='8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a' -- container
inner join daas_tm_prepared.dh_cnvy e on b.cnvy_key=e.cnvy_key --and e.act_stus_ind=1
left join daas_tm_prepared.dh_cnvy_char f1 on e.cnvy_key=f1.cnvy_key  and f1.act_stus_ind=1
and f1.char_type_key='53223cc5252d3111a784717f660a45a277a813430ed44561fc46bd7028fc6836' --Equipment Initial, not use container initial
left join daas_tm_prepared.dh_cnvy_char f2 on e.cnvy_key=f2.cnvy_key  and f2.act_stus_ind=1
and f2.char_type_key='4b784c8ef416376b15dcc4a491e6fefe7f994d1da63a1729d18e793799de3b86' --Equipment Number
where  a.cnvy_type_key='dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' -- 'railcar'
and a.cnvy_key=p_cnvy_key -- '7cfffab6517b0f73a72c538146ee2b9e9e26512ecd3157ca22299dffe7637cde'-- 'DTTX645320'
) as m 
group by 1;
END;
$$ LANGUAGE plpgsql;



