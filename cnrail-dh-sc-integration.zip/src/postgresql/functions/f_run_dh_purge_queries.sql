drop function if exists f_run_dh_purge_queries
;  /*to drop on next promotion*/
drop PROCEDURE if exists daas_tm_trusted.f_run_dh_purge_queries
;  /*to drop on next promotion*/
-- call daas_tm_trusted.f_run_dh_purge_queries (NULL);
-- call daas_tm_trusted.f_run_dh_purge_queries (1) ;


CREATE PROCEDURE daas_tm_trusted.f_run_dh_purge_queries(p_purge_id int default null)

AS $$
DECLARE
	qry RECORD;
	v_pre_rowcount int;
	v_post_rowcount int;
	_temp_table text;
	v_sqlstate text;
	ofs int;
	step int;
	v_to_purge_rowcount int;
	v_purge_rowcount int;
	counter int;
	count_retry int;
BEGIN
	if p_purge_id is null or p_purge_id =1 then
		with EquipmentMultipleActiveWaybill as (
		select schar.char_val , count(1)
		from daas_tm_prepared.dh_ship_cond scond
		inner join daas_tm_prepared.dh_ship ship on ship.ship_key=scond.ship_key and ship.act_stus_ind=1
		inner join daas_tm_prepared.dh_ship_char schar on ship.ship_key=schar.ship_key and schar.act_stus_ind=1
		and schar.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
		where scond.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083' -- waybill status
		and scond.char_val in ('A'
		--,'S','O' 
		)
		and scond.act_stus_ind=1
		group by 1
		having count(1) >1
		)
		,ActiveWaybill as (
		select a.char_val, scond.ship_key, scond.char_val, scond.sor_ingt_crt_ts, 
		 rank() over( partition by a.char_val order by scond.sor_ingt_crt_ts desc) as rk
		from EquipmentMultipleActiveWaybill a
		inner join daas_tm_prepared.dh_ship_char schar on a.char_val=schar.char_val and schar.act_stus_ind=1
		and schar.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
		inner join daas_tm_prepared.dh_ship_cond scond on schar.ship_key =scond.ship_key and scond.act_stus_ind=1
		and scond.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083' -- waybill status
		and scond.char_val in ('A'
		--,'S','O' 
		) 
		)
		update  daas_tm_prepared.dh_ship_cond 
		set char_val='C', rpt_clnt_id='Purge' 
		where dh_ship_cond.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083' and 
		exists (select 1 from 
		ActiveWaybill where dh_ship_cond.ship_key=ActiveWaybill.ship_key and ActiveWaybill.rk>1);
		raise notice 'Set duplicated active waybill status to C ';
	end if;
	_temp_table='temp1';
	EXECUTE 'Drop table if exists ' || _temp_table ; 
	raise notice 'Begin  f_run_dh_purge_queries %',now();
	FOR qry IN   EXECUTE 'SELECT t.purge_id,t.table_name,t.description,	t.temp_table,t.temp_table_column_list,t.purge_query
							FROM   daas_tm_prepared.dh_purge_queries t
							WHERE  t.active_status = ''A'' 
							ORDER  BY t.purge_id'  LOOP	

		 
		 
		 if qry.purge_id =p_purge_id or p_purge_id IS NULL  THEN
		 
		     raise notice 'PURGE ID % ',qry.purge_id;
	         raise notice 'TABLE TO PURGE % ',qry.table_name;
			 EXECUTE '	Create temp table ' || _temp_table || '  on commit preserve rows 
					as ' || qry.temp_table || '
					;' ;				
			 GET DIAGNOSTICS v_to_purge_rowcount = ROW_COUNT;
			
			 raise notice 'TO DELETE % records ',v_to_purge_rowcount;
			 step=10000 ; 
			 
			 FOR counter IN   1..v_to_purge_rowcount by step  LOOP
				 ofs= (counter - 1 )  ;
				EXECUTE format('
				With filter (%3$s) as 
				  (select * from temp1 limit %1$s offset %2$s)
				  %4$s
				', step , ofs ,qry.temp_table_column_list ,  qry.purge_query );

				GET DIAGNOSTICS v_purge_rowcount = ROW_COUNT;	
				raise notice 'Deleted % Records',v_purge_rowcount; 
				
				COMMIT;   

				insert into daas_tm_prepared.dh_purge_results (purge_time, purge_id, pre_rowcount, purge_rowcount, post_rowcount )
				values(now(),qry.purge_id, COALESCE(v_to_purge_rowcount,0), COALESCE(v_purge_rowcount,0) ,0);				
				
				COMMIT;
					
			 END LOOP;
			
			EXECUTE 'Drop table ' || _temp_table ; 
		END if;
		
	
		
		
    END LOOP;
    raise notice 'END  f_run_dh_purge_queries %',now();
   
END;$$
LANGUAGE plpgsql;