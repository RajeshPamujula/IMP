DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_trsp_evt_asct_char_domn_evt_by_car_trsp_key(bytea, timestamp) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_trsp_evt_asct_char_domn_evt_by_car_trsp_key(p_asct_key bytea, p_curr_sor_proc_ts timestamp )
/*
p_curr_sor_proc_ts: pass rpt_sor_proc_ts from dh_trsp_evt
*/

RETURNS TABLE 
(

"transportationEventAssociateKey" bytea,
"sourceProcessDateTime" timestamp without time zone,
"trackNumber"  text,
"trackSequenceNumber"  text
)
AS $$
begin
return query


with prvs_dh_trsp_evt_asct_char as (
select distinct ref.type_cd,  a.char_val, a.sor_proc_ts
,dense_rank() over(PARTITION BY a.asct_key,ref.type_cd order by a.sor_proc_ts desc, a.data_hub_crt_ts desc) as rk 
,a.asct_key
from daas_tm_prepared.dh_trsp_evt_asct_char_domn_evt a
inner join daas_tm_prepared.dh_ref_type ref on ref.type_key=a.char_type_key
where a.asct_key=p_asct_key  --'09546f6648c310e4956dc3d00644e7681b3b0252cb6082601df6c0284cf3834e'
--and  a.sor_proc_ts< p_curr_sor_proc_ts  -- TO_TIMESTAMP(    '2021-01-13 08:01:13.2810000',    'YYYY-MM-DD HH:MI:SS.nnnnnnn')::timestamp


)
select asct_key as "transportationEventAssociateKey",
sor_proc_ts as "sourceProcessDateTime",
max(case when type_cd='Track Number' then char_val else '' end ) as "trackNumber",
max(case when type_cd='Track Sequence Number' then char_val else '' end ) as "trackSequenceNumber"
from prvs_dh_trsp_evt_asct_char
where rk=2  -- get the second last verion, the prevoius versoin
group by 1,2;


end;
$$
LANGUAGE 'plpgsql';
