CREATE OR REPLACE FUNCTION f_get_dh_rte_char_vessel_by_rte_key(p_rte_key bytea)
returns table(rte_key bytea,
Direction_Code text,
Vessel_Id text,
Voyage_Number text)
AS $$
begin
return query
select main.rte_key,
max(case when ref_type.type_cd = 'Direction Code' then c.char_val else null end) as Direction_Code,
max(case when ref_type.type_cd = 'Vessel Id' then c.char_val else null end) as Vessel_Id,
max(case when ref_type.type_cd = 'Voyage Number' then c.char_val else null end) as Voyage_Number
from daas_tm_prepared.dh_rte main
left  join daas_tm_prepared.dh_rte_char c
on    main.rte_key = c.rte_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.rte_key = p_rte_key and main.act_stus_ind = 1
group by main.rte_key;
end;
$$ LANGUAGE plpgsql;

