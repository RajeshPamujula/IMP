DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_cmp_char_vessel_by_ship_cmp_key(bytea) cascade;
/*
drop cascades to view daas_tm_trusted."vUnitShipmentDetailCustomer"
drop cascades to view daas_tm_trusted."vShipmentDetail"
drop cascades to view daas_tm_trusted."vWaybillVesselProfile"

*/

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_cmp_char_vessel_by_ship_cmp_key(p_ship_cmp_key bytea)
returns table(ship_cmp_key bytea,
"dataHubCreationTimestamp" timestamp,
"eventTimestamp" timestamp,
Carrier_Abbreviation_Current text,
Carrier_Abbreviation_Previous text,
Country_Code text,
Customer_Book_Id text,
Flight_Voyage_Number text,
Flight_Voyage_Terminal text,
Inbound_Outbound_Code text,
Manifest_Creation_Date text,
Pier_Name text,
Pier_Number text,
Sail_Date text,
Sail_Time text,
State text,
Vessel_Direction text,
Vessel_Name text,
Voyage_Booking_Date text,
Voyage_Booking_Number text,
Voyage_Port_Function text,
Voyage_Port_Name text,
Vessel_Id text)
AS $$
begin
return query
select main.ship_cmp_key,
max(c.data_hub_crt_ts) as "dataHubCreationTimestamp",
max(c.sor_evt_ts) as "eventTimestamp",
max(case when ref_type.type_cd = 'Carrier Abbreviation Current' then c.char_val else null end) as Carrier_Abbreviation_Current,
max(case when ref_type.type_cd = 'Carrier Abbreviation Previous' then c.char_val else null end) as Carrier_Abbreviation_Previous,
max(case when ref_type.type_cd = 'Country Code' then c.char_val else null end) as Country_Code,
max(case when ref_type.type_cd = 'Customer Book Id' then c.char_val else null end) as Customer_Book_Id,
max(case when ref_type.type_cd = 'Flight Voyage Number' then c.char_val else null end) as Flight_Voyage_Number,
max(case when ref_type.type_cd = 'Flight Voyage Terminal' then c.char_val else null end) as Flight_Voyage_Terminal,
max(case when ref_type.type_cd = 'Inbound Outbound Code' then c.char_val else null end) as Inbound_Outbound_Code,
max(case when ref_type.type_cd = 'Manifest Creation Date' then c.char_val else null end) as Manifest_Creation_Date,
max(case when ref_type.type_cd = 'Pier Name' then c.char_val else null end) as Pier_Name,
max(case when ref_type.type_cd = 'Pier Number' then c.char_val else null end) as Pier_Number,
max(case when ref_type.type_cd = 'Sail Date' then c.char_val else null end) as Sail_Date,
max(case when ref_type.type_cd = 'Sail Time' then c.char_val else null end) as Sail_Time,
max(case when ref_type.type_cd = 'State' then c.char_val else null end) as State,
max(case when ref_type.type_cd = 'Vessel Direction' then c.char_val else null end) as Vessel_Direction,
max(case when ref_type.type_cd = 'Vessel Name' then c.char_val else null end) as Vessel_Name,
max(case when ref_type.type_cd = 'Voyage Booking Date' then c.char_val else null end) as Voyage_Booking_Date,
max(case when ref_type.type_cd = 'Voyage Booking Number' then c.char_val else null end) as Voyage_Booking_Number,
max(case when ref_type.type_cd = 'Voyage Port Function' then c.char_val else null end) as Voyage_Port_Function,
max(case when ref_type.type_cd = 'Voyage Port Name' then c.char_val else null end) as Voyage_Port_Name,
max(case when ref_type.type_cd = 'Vessel Id' then c.char_val else null end) as Vessel_Id
from daas_tm_prepared.dh_ship_cmp main
left  join daas_tm_prepared.dh_ship_cmp_char c
on    main.ship_cmp_key = c.ship_cmp_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.ship_cmp_key = p_ship_cmp_key and main.act_stus_ind = 1
group by main.ship_cmp_key;
end;
$$ LANGUAGE plpgsql;



-- select * from daas_tm_trusted.f_get_dh_ship_cmp_char_vessel_by_ship_cmp_key('7725989a3e60c2a936dbe24cbb881d676782bbe73442c317673b6274c8b8b746') ;