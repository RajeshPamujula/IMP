DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_cnvy_cond_domn_evt_by_cnvy_key(bytea, timestamp) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_cnvy_cond_domn_evt_by_cnvy_key(p_cnvy_key bytea, p_curr_sor_proc_ts timestamp )
/*
p_curr_sor_proc_ts: pass rpt_sor_proc_ts from dh_cnvy_cond or dh_cnvy
drop cascades to view daas_tm_trusted."vIntermodalUnitUpdateHistory"
drop cascades to view daas_tm_trusted."vCarInventoryUpdateHistory
*/
RETURNS TABLE 
(
"conveyorKey" bytea,
"sourceProcessDateTime" timestamp without time zone,
"badOrderCode" text,
"customerCarOrderNumber" text,
"mechanicalStatusCode1" text,
"mechanicalStatusCode2" text,
"mechanicalStatusCode3" text,
"loadSheetHoldCode" text,
"eventAccountCode" text,
"firstStorageChargeDate" text
)
AS $$
begin
return query

with prvs_cnvy_cond as (
select type_cd,  a.char_val, a.sor_proc_ts
,dense_rank() over(PARTITION BY a.cnvy_key, ref.type_cd  order by a.sor_proc_ts desc, a.data_hub_crt_ts desc) as rk
,a.cnvy_key
from daas_tm_prepared.dh_cnvy_cond_domn_evt a
inner join daas_tm_prepared.dh_ref_type ref on type_key=a.char_type_key
where a.cnvy_key=p_cnvy_key
--and sor_proc_ts< p_curr_sor_proc_ts
)
select 
cnvy_key as "conveyorKey",
max(sor_proc_ts) as"eventCreationDateTime",
max(case when type_cd ='Bad Order Code' then char_val else null end) as "badOrderCode",
max(case when type_cd ='CCO Number' then char_val else null end) as "customerCarOrderNumber",
max(case when type_cd ='Mechanical Status Code 1' then char_val else null end) as "mechanicalStatusCode1",
max(case when type_cd ='Mechanical Status Code 2' then char_val else null end) as "mechanicalStatusCode2",
max(case when type_cd ='Mechanical Status Code 3' then char_val else null end) as "mechanicalStatusCode3",
max(case when type_cd ='Load Sheet Hold Code' then char_val else null end) as "loadSheetHoldCode",
max(case when type_cd ='Event Account Code' then char_val else null end) as "eventAccountCode",
max(case when type_cd ='First Storage Charge Date' then char_val else null end) as "firstStorageChargeDate"


from prvs_cnvy_cond
where rk=2
group by 1;

end;
$$
LANGUAGE 'plpgsql';
