DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_seal_range_by_ship_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_seal_range_by_ship_key(p_ship_key bytea)
RETURNS TABLE
(
  ship_key bytea,
  "sealRange" text[]

)
AS $$
BEGIN
RETURN QUERY
select m.ship_key, 
array_agg('sealSequence:'||"sealSequence" ||' ;sealRangeLow:'||"sealRangeLow" ||' ;sealRangeHigh:' ||"sealRangeHigh" ||' ;sealNumber:'||"sealNumber") as "sealRange"
from (select a.ship_key
, a.id_val as "sealSequence"
, seallow.char_val as "sealRangeLow"
, sealhigh.char_val as "sealRangeHigh"
, seallow.char_val as "sealNumber"
from daas_tm_prepared.dh_ship_cmp a
inner join daas_tm_prepared.dh_ship_cmp_char seallow on a.ship_cmp_key=seallow.ship_cmp_key and seallow.act_stus_ind=1
and seallow.char_type_key='b879af0fdce9f98bb4650d42ea2e2e07eee7202dcd9a02882217514a3367abe9' --Seal Range Low
inner join daas_tm_prepared.dh_ship_cmp_char sealhigh on a.ship_cmp_key=sealhigh.ship_cmp_key and sealhigh.act_stus_ind=1
and sealhigh.char_type_key='6538d1ed951005a3972121f14ad984424729b83cfc650b56ad81b5ded4959061' --Seal Range High
where a.ship_cmp_type_key='f6d1c2ca1bba8cd0c7177a00218a3cf8cc43afc7dd37d542775d15a7a76eeebe'  --Intra-Domain Shipment-Seal
and a.ship_key =p_ship_key
--'bcfecaffa82de77c19006ac4732985c680be44ff9eb64a17d8b57fb0d82fc8be'
and a.act_stus_ind=1
order by a.id_val
) as m 
group by m.ship_key;

END;
$$ LANGUAGE plpgsql;