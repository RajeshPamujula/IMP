DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_asct_char_commodity_by_asct_key(bytea) cascade;


CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_asct_char_commodity_by_asct_key(p_asct_key bytea)
returns table(
asct_key bytea,
"articleQuantity" text,
"ediActualWeight" text,
"ediActualWeightUom" text,
"harmonizedCode" text,
"ladingActualWeight" text,
"ladingActualWeightUom" text,
"ladingVolume" text,
"ladingVolumeUom" text,
"packageType" text,
"standardTransportationCommodityCode" text,
"tankCompartment" text
)
AS $$
begin
return query
select main.asct_key,

max(case when ref_type.type_cd = 'Article Quantity' then c.char_val else null end) as "articleQuantity",
max(case when ref_type.type_cd = 'EDI Actual Weight' then c.char_val else null end) as "ediActualWeight",
max(case when ref_type.type_cd = 'EDI Actual Weight UOM' then c.char_val else null end) as "ediActualWeightUom",
max(case when ref_type.type_cd = 'Harmonized Code' then c.char_val else null end) as "harmonizedCode",
max(case when ref_type.type_cd = 'Lading Actual Weight' then c.char_val else null end) as "ladingActualWeight",
max(case when ref_type.type_cd = 'Lading Actual Weight UOM' then c.char_val else null end) as "ladingActualWeightUom",
max(case when ref_type.type_cd = 'Lading Volume' then c.char_val else null end) as "ladingVolume",
max(case when ref_type.type_cd = 'Lading Volume UOM' then c.char_val else null end) as "ladingVolumeUom",
max(case when ref_type.type_cd = 'Package Type' then c.char_val else null end) as "packageType",
max(case when ref_type.type_cd = 'Standard Transportation Commodity Code' then c.char_val else null end) as "standardTransportationCommodityCode",
max(case when ref_type.type_cd = 'Tank Compartment' then c.char_val else null end) as "tankCompartment"

from daas_tm_prepared.dh_ship_asct main
left  join daas_tm_prepared.dh_ship_asct_char c
on    main.asct_key = c.asct_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key and main.act_stus_ind = 1
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;
