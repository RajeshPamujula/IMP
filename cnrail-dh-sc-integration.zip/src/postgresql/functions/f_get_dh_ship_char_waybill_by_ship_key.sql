DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(bytea) cascade;
/*
drop cascades to view daas_tm_trusted."vIntermodalContainerInformationHazelcast"
drop cascades to view daas_tm_trusted."vIntermodalContainerInformation"
drop cascades to view daas_tm_trusted."vTrainConsistDetail"
drop cascades to view daas_tm_trusted."vTrainConsistDetailL2Railcar"
drop cascades to view daas_tm_trusted."vShipmentRailMovementUpdate"
drop cascades to view daas_tm_trusted."vContainerVessel"
*/

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(p_ship_key bytea)
returns table(ship_key bytea,
"dataHubCreationTimestamp" timestamp,
"eventTimestamp" timestamp,
Bill_of_Lading_Date text,
Bill_of_Lading_Number text,
Carrier_Abbreviation_On text,
Customer_Supplied_Net_Weight text,
Customer_Supplied_Weight_Code text,
Customer_Supplied_Weight_UOM text,
Destination_Ramp_333 text,
Destination_Ramp_333_Province_State_Code text,
Equipment_ID text,
Event_Date_Time_UTC text,
First_CN_Origin_Carrier_Abbreviation text,
First_CN_Origin_Station_Number text,
Gross_Scale_Weight text,
Gross_Scale_Weight_UOM text,
Import_Export_Code text,
Ingate_Placard_Code text,
Intermodal_Plan_Number text,
Last_CN_Origin_Carrier_Abbreviation text,
Last_CN_Origin_Station_Number text,
Level_of_Service_Code text,
Load_Empty_Status_Code text,
Log_User text,
Log_User_Name text,
Net_Scale_Weight text,
Net_Scale_Weight_UOM text,
Operating_City text,
Operating_City_Province_State_Code text,
Operating_Destination_FSAC text,
Operating_Destination_SCAC text,
Operating_Railroad_At_Junction_Point text,
Origin_Ramp_333 text,
Origin_Ramp_333_Province_State_Code text,
PPSI_Code text,
PPSI_Cool_Indicator text,
PPSI_Rule_Code text,
PPSI_Temparature text,
PPSI_Temperature_UOM text,
Rail_Destination_333 text,
Rail_Destination_333_Province_State_Code text,
Rail_Origin_333 text,
Rail_Origin_333_Province_State_Code text,
Railroad_At_Junction_Point text,
Regulatory_Authority text,
Reservation_Number text,
Speed_Restriction text,
Speed_Restriction_Unit_of_Measure text,
Standard_Transportation_Commodity_Code text,
Total_Lading_Weight text,
Total_Lading_Weight_UOM text,
Waybill_EDI_Code text,
Waybill_Date text,
Waybill_Number text,
Waybill_Record_Type text,
Weight_Allowance_1 text,
Weight_Allowance_1_UOM text,
Weight_Allowance_2 text,
Weight_Allowance_2_UOM text,
Weight_Unit_Code text,
Pickup_Number text,
Waybill_Status_Code text ,
Load_Sheet_Block_Hold text,
Check_Digit text

)
AS $$
begin
return query
select main.ship_key,
max(c.data_hub_crt_ts) as "dataHubCreationTimestamp",
max(c.sor_evt_ts) as "eventTimestamp",
max(case when ref_type.type_cd = 'Bill of Lading Date' then c.char_val else null end) as Bill_of_Lading_Date,
max(case when ref_type.type_cd = 'Bill of Lading Number' then c.char_val else null end) as Bill_of_Lading_Number,
max(case when ref_type.type_cd = 'Carrier Abbreviation On' then c.char_val else null end) as Carrier_Abbreviation_On,
max(case when ref_type.type_cd = 'Customer Supplied Net Weight' then c.char_val else null end) as Customer_Supplied_Net_Weight,
max(case when ref_type.type_cd = 'Customer Supplied Weight Code' then c.char_val else null end) as Customer_Supplied_Weight_Code,
max(case when ref_type.type_cd = 'Customer Supplied Weight UOM' then c.char_val else null end) as Customer_Supplied_Weight_UOM,
max(case when ref_type.type_cd = 'Destination Ramp 333' then c.char_val else null end) as Destination_Ramp_333,
max(case when ref_type.type_cd = 'Destination Ramp 333 Province State Code' then c.char_val else null end) as Destination_Ramp_333_Province_State_Code,
max(case when ref_type.type_cd = 'Equipment ID' then c.char_val else null end) as Equipment_ID,
max(case when ref_type.type_cd = 'Event Date Time UTC' then c.char_val else null end) as Event_Date_Time_UTC,

max(case when ref_type.type_cd = 'First CN Origin Carrier Abbreviation' then c.char_val else null end) as First_CN_Origin_Carrier_Abbreviation,
max(case when ref_type.type_cd = 'First CN Origin Station Number' then c.char_val else null end) as First_CN_Origin_Station_Number,
max(case when ref_type.type_cd = 'Gross Scale Weight' then c.char_val else null end) as Gross_Scale_Weight,
max(case when ref_type.type_cd = 'Gross Scale Weight UOM' then c.char_val else null end) as Gross_Scale_Weight_UOM,
max(case when ref_type.type_cd = 'Import Export Code' then c.char_val else null end) as Import_Export_Code,
max(case when ref_type.type_cd = 'Ingate Placard Code' then c.char_val else null end) as Ingate_Placard_Code,
max(case when ref_type.type_cd = 'Intermodal Plan Number' then c.char_val else null end) as Intermodal_Plan_Number,
max(case when ref_type.type_cd = 'Last CN Origin Carrier Abbreviation' then c.char_val else null end) as Last_CN_Origin_Carrier_Abbreviation,
max(case when ref_type.type_cd = 'Last CN Origin Station Number' then c.char_val else null end) as Last_CN_Origin_Station_Number,
max(case when ref_type.type_cd = 'Level of Service Code' then c.char_val else null end) as Level_of_Service_Code,
max(case when ref_type.type_cd = 'Load Empty Status Code' then c.char_val else null end) as Load_Empty_Status_Code,
max(case when ref_type.type_cd = 'Log User' then c.char_val else null end) as Log_User,
max(case when ref_type.type_cd = 'Log User Name' then c.char_val else null end) as Log_User_Name,
max(case when ref_type.type_cd = 'Net Scale Weight' then c.char_val else null end) as Net_Scale_Weight,
max(case when ref_type.type_cd = 'Net Scale Weight UOM' then c.char_val else null end) as Net_Scale_Weight_UOM,
max(case when ref_type.type_cd = 'Operating City' then c.char_val else null end) as Operating_City,
max(case when ref_type.type_cd = 'Operating City Province State Code' then c.char_val else null end) as Operating_City_Province_State_Code,
max(case when ref_type.type_cd = 'Operating Destination FSAC' then c.char_val else null end) as Operating_Destination_FSAC,
max(case when ref_type.type_cd = 'Operating Destination SCAC' then c.char_val else null end) as Operating_Destination_SCAC,
max(case when ref_type.type_cd = 'Operating Railroad At Junction Point' then c.char_val else null end) as Operating_Railroad_At_Junction_Point,
max(case when ref_type.type_cd = 'Origin Ramp 333' then c.char_val else null end) as Origin_Ramp_333,
max(case when ref_type.type_cd = 'Origin Ramp 333 Province State Code' then c.char_val else null end) as Origin_Ramp_333_Province_State_Code,
max(case when ref_type.type_cd = 'PPSI Code' then c.char_val else null end) as PPSI_Code,
max(case when ref_type.type_cd = 'PPSI Cool Indicator' then c.char_val else null end) as PPSI_Cool_Indicator,
max(case when ref_type.type_cd = 'PPSI Rule Code' then c.char_val else null end) as PPSI_Rule_Code,
max(case when ref_type.type_cd = 'PPSI Temparature' then c.char_val else null end) as PPSI_Temparature,
max(case when ref_type.type_cd = 'PPSI Temperature UOM' then c.char_val else null end) as PPSI_Temperature_UOM,
max(case when ref_type.type_cd = 'Rail Destination 333' then c.char_val else null end) as Rail_Destination_333,
max(case when ref_type.type_cd = 'Rail Destination 333 Province State Code' then c.char_val else null end) as Rail_Destination_333_Province_State_Code,
max(case when ref_type.type_cd = 'Rail Origin 333' then c.char_val else null end) as Rail_Origin_333,
max(case when ref_type.type_cd = 'Rail Origin 333 Province State Code' then c.char_val else null end) as Rail_Origin_333_Province_State_Code,
max(case when ref_type.type_cd = 'Railroad At Junction Point' then c.char_val else null end) as Railroad_At_Junction_Point,

max(case when ref_type.type_cd = 'Regulatory Authority' then c.char_val else null end) as Regulatory_Authority,
max(case when ref_type.type_cd = 'Reservation Number' then c.char_val else null end) as Reservation_Number,
max(case when ref_type.type_cd = 'Speed Restriction' then c.char_val else null end) as Speed_Restriction,
max(case when ref_type.type_cd = 'Speed Restriction Unit of Measure' then c.char_val else null end) as Speed_Restriction_Unit_of_Measure,
max(case when ref_type.type_cd = 'Standard Transportation Commodity Code' then c.char_val else null end) as Standard_Transportation_Commodity_Code,
max(case when ref_type.type_cd = 'Total Lading Weight' then c.char_val else null end) as Total_Lading_Weight,
max(case when ref_type.type_cd = 'Total Lading Weight UOM' then c.char_val else null end) as Total_Lading_Weight_UOM,

max(case when ref_type.type_cd = 'Waybill EDI Code' then c.char_val else null end) as Waybill_EDI_Code,
max(case when ref_type.type_cd = 'Waybill Date' then c.char_val else null end) as Waybill_Date,
max(case when ref_type.type_cd = 'Waybill Number' then c.char_val else null end) as Waybill_Number,
max(case when ref_type.type_cd = 'Waybill Record Type' then c.char_val else null end) as Waybill_Record_Type,
max(case when ref_type.type_cd = 'Weight Allowance 1' then c.char_val else null end) as Weight_Allowance_1,
max(case when ref_type.type_cd = 'Weight Allowance 1 UOM' then c.char_val else null end) as Weight_Allowance_1_UOM,
max(case when ref_type.type_cd = 'Weight Allowance 2' then c.char_val else null end) as Weight_Allowance_2,
max(case when ref_type.type_cd = 'Weight Allowance 2 UOM' then c.char_val else null end) as Weight_Allowance_2_UOM,
max(case when ref_type.type_cd = 'Weight Unit Code' then c.char_val else null end) as Weight_Unit_Code,
max(case when ref_type.type_cd = 'Pickup Number' then c.char_val else null end) as Pickup_Number,
max(case when ref_type.type_cd = 'Waybill Status Code' then c.char_val else null end) as Waybill_Status_Code,

max(case when ref_type.type_cd = 'Load Sheet Block/Hold' then c.char_val else null end) as Load_Sheet_Block_Hold,
max(case when ref_type.type_cd = 'Check Digit' then c.char_val else null end) as Check_Digit
from daas_tm_prepared.dh_ship main
left  join daas_tm_prepared.dh_ship_char c
on    main.ship_key = c.ship_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.ship_key = p_ship_key and main.act_stus_ind = 1
group by main.ship_key;
end;
$$ LANGUAGE plpgsql;