CREATE OR REPLACE FUNCTION f_get_dh_loc_asct_char_train_by_asct_key(p_asct_key bytea)
returns table(asct_key bytea,
Crew_Change_Indicator text,
Refuel_Point text,
Required_Inspection_Flag text,
Re_Wheel_Point text,
Station_Sequence_Number text,
Station_Sequence_Timestamp text,
Station_Type_Code text,
TJS_Inclusive_Flag text,
Work_Order_Flag text)
AS $$
begin
return query
select main.asct_key,
max(case when ref_type.type_cd = 'Crew Change Indicator' then c.char_val else null end) as Crew_Change_Indicator,
max(case when ref_type.type_cd = 'Refuel Point' then c.char_val else null end) as Refuel_Point,
max(case when ref_type.type_cd = 'Required Inspection Flag' then c.char_val else null end) as Required_Inspection_Flag,
max(case when ref_type.type_cd = 'Re-Wheel Point' then c.char_val else null end) as Re_Wheel_Point,
max(case when ref_type.type_cd = 'Station Sequence Number' then c.char_val else null end) as Station_Sequence_Number,
max(case when ref_type.type_cd = 'Station Sequence Timestamp' then c.char_val else null end) as Station_Sequence_Timestamp,
max(case when ref_type.type_cd = 'Station Type Code' then c.char_val else null end) as Station_Type_Code,
max(case when ref_type.type_cd = 'TJS Inclusive Flag' then c.char_val else null end) as TJS_Inclusive_Flag,
max(case when ref_type.type_cd = 'Work Order Flag' then c.char_val else null end) as Work_Order_Flag
from daas_tm_prepared.dh_loc_asct main
left  join daas_tm_prepared.dh_loc_asct_char c
on    main.asct_key = c.asct_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key and main.act_stus_ind = 1
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;

