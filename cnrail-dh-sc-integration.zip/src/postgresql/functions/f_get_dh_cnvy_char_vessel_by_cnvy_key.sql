CREATE OR REPLACE FUNCTION f_get_dh_cnvy_char_vessel_by_cnvy_key(p_cnvy_key bytea)
returns table(cnvy_key bytea,
Vessel_EDI_indicator text,
Vessel_Name text,
Vessel_Owner text)
AS $$
begin
return query
select main.cnvy_key,
max(case when ref_type.type_cd = 'Vessel EDI indicator' then c.char_val else null end) as Vessel_EDI_indicator,
max(case when ref_type.type_cd = 'Vessel Name' then c.char_val else null end) as Vessel_Name,
max(case when ref_type.type_cd = 'Vessel Owner' then c.char_val else null end) as Vessel_Owner
from daas_tm_prepared.dh_cnvy main
left  join daas_tm_prepared.dh_cnvy_char c
on    main.cnvy_key = c.cnvy_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.cnvy_key = p_cnvy_key and main.act_stus_ind = 1
group by main.cnvy_key;
end;
$$ LANGUAGE plpgsql;
