DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_asct_char_domn_evt_equipment_by_asct_key(bytea, timestamp ) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_asct_char_domn_evt_equipment_by_asct_key(p_asct_key bytea, p_sor_proc_ts timestamp)
returns table(
asct_key bytea,
"emptyOrderNumber"  text
)
AS $$
begin
return query

with prvs_ship_asct_char as (
select distinct ref.type_cd,  a.char_val, a.sor_proc_ts
,dense_rank() over(PARTITION BY a.asct_key order by a.sor_proc_ts desc) as rk
,a.asct_key
from daas_tm_prepared.dh_ship_asct_char_domn_evt  a
inner join daas_tm_prepared.dh_ref_type ref on ref.type_key=a.char_type_key
where a.asct_key= p_asct_key --'3b77fa4bb3b349803dfe938fa7bbf5fba7dbb88cc29ad87d8fd4e15b1b8a21f9'
and sor_proc_ts <p_sor_proc_ts  -- TO_TIMESTAMP(    '2021-01-15 13:01:15.4690000',    'YYYY-MM-DD HH24:MI:SS.nnnnnnn')::timestamp
)
select prvs_ship_asct_char.asct_key,
max(case when type_cd = 'Empty Order Number' then char_val else null end) as "emptyOrderNumber"
from prvs_ship_asct_char
where rk=1
group by 1;
end;
$$ LANGUAGE plpgsql;





