DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_cond_bp_role_char_waybill_by_ship_key(bytea) cascade;


CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_cond_bp_role_char_waybill_by_ship_key(p_ship_key bytea)
RETURNS TABLE 
(
ship_key bytea,
sor_evt_ts timestamp without time zone,
data_hub_crt_ts timestamp without time zone,
"shipperCity333"   text,
"shipperProvinceState"   text,
"shipperStationNumber"   text,
"shipperCustomer633"   text,
"shipperCarrierAbbreviation"   text,
"shipperCityName"   text,
"shipperZip"   text,
"shipperCustomerAddress"   text,
"shipperCustomerNumber"   text,
"shipperCustomerName"    text,


"consigneeCity333"   text,
"consigneeProvinceState"   text,
"consigneeStationNumber"   text,
"consigneeCustomer633"   text,
"consigneeCarrierAbbreviation"   text,
"consigneeCityName"   text,
"consigneeZip"   text,
"consigneeCustomerAddress"   text,
"consigneeCustomerNumber"   text,
"consigneeCustomerName"    text,

"payingCustomerCity333"   text,
"payingCustomerProvinceState"   text,
"payingCustomerStationNumber"   text,
"payingCustomerCustomer633"   text,
"payingCustomerCarrierAbbreviation"   text,
"payingCustomerCityName"   text,
"payingCustomerZip"   text,
"payingCustomerCustomerAddress"   text,
"payingCustomerCustomerNumber"   text,
"payingCustomerCustomerName" text,

"careOfCity333"   text,
"careOfProvinceState"   text,
"careOfStationNumber"   text,
"careOfCustomer633"   text,
"careOfCarrierAbbreviation"   text,
"careOfCityName"   text,
"careOfZip"   text,
"careOfCustomerAddress"   text,
"careOfCustomerNumber"   text,
"careOfCustomerName"    text,

"finalDestinationCity333"   text,
"finalDestinationProvinceState"   text,
"finalDestinationStationNumber"   text,
"finalDestinationCustomer633"   text,
"finalDestinationCarrierAbbreviation"   text,
"finalDestinationCityName"   text,
"finalDestinationZip"   text,
"finalDestinationCustomerAddress"   text,
"finalDestinationCustomerNumber"   text,
"finalDestinationCustomerName"   text,


"priorOriginCity333"   text,
"priorOriginProvinceState"   text,
"priorOriginStationNumber"   text,
"priorOriginCustomer633"   text,
"priorOriginCarrierAbbreviation"   text,
"priorOriginCityName"   text,
"priorOriginZip"   text,
"priorOriginCustomerAddress"   text,
"priorOriginCustomerNumber"   text,
"priorOriginCustomerName"  text,

"shipFromCity333"   text,
"shipFromProvinceState"   text,
"shipFromStationNumber"   text,
"shipFromCustomer633"   text,
"shipFromCarrierAbbreviation"   text,
"shipFromCityName"   text,
"shipFromZip"   text,
"shipFromCustomerAddress"   text,
"shipFromCustomerNumber"   text,
"shipFromCustomerName"    text
)
AS $$
begin
return query


select ship_cmp.ship_key
, max(ship_cmp_char.sor_evt_ts) as sor_evt_ts
, max(ship_cmp_char.data_hub_crt_ts) as data_hub_crt_ts
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='City 333' then ship_cmp_char.char_val else '' end ) as "shipperCity333"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='Province State' then ship_cmp_char.char_val else '' end ) as "shipperProvinceState"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='Station Number' then ship_cmp_char.char_val else '' end ) as "shipperStationNumber"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='Customer 633' then ship_cmp_char.char_val else '' end ) as "shipperCustomer633"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='Carrier Abbreviation' then ship_cmp_char.char_val else '' end ) as "shipperCarrierAbbreviation"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='City Name' then ship_cmp_char.char_val else '' end ) as "shipperCityName"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='Postal Code' then ship_cmp_char.char_val else '' end ) as "shipperZip"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='Customer Address' then ship_cmp_char.char_val else '' end ) as "shipperCustomerAddress"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='Customer Number' then ship_cmp_char.char_val else '' end ) as "shipperCustomerNumber"
, max(case when ship_cmp.id_val='Shipper' and c.type_cd='Customer Name' then ship_cmp_char.char_val else '' end ) as "shipperCustomerName"


, max(case when ship_cmp.id_val='Consignee' and c.type_cd='City 333' then ship_cmp_char.char_val else '' end ) as "consigneeCity333"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='Province State' then ship_cmp_char.char_val else '' end ) as "consigneeProvinceState"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='Station Number' then ship_cmp_char.char_val else '' end ) as "consigneeStationNumber"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='Customer 633' then ship_cmp_char.char_val else '' end ) as "consigneeCustomer633"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='Carrier Abbreviation' then ship_cmp_char.char_val else '' end ) as "consigneeCarrierAbbreviation"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='City Name' then ship_cmp_char.char_val else '' end ) as "consigneeCityName"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='Postal Code' then ship_cmp_char.char_val else '' end ) as "consigneeZip"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='Customer Address' then ship_cmp_char.char_val else '' end ) as "consigneeCustomerAddress"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='Customer Number' then ship_cmp_char.char_val else '' end ) as "consigneeCustomerNumber"
, max(case when ship_cmp.id_val='Consignee' and c.type_cd='Customer Name' then ship_cmp_char.char_val else '' end ) as "consigneeCustomerName"

, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='City 333' then ship_cmp_char.char_val else '' end ) as "payingCustomerCity333"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='Province State' then ship_cmp_char.char_val else '' end ) as "payingCustomerProvinceState"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='Station Number' then ship_cmp_char.char_val else '' end ) as "payingCustomerStationNumber"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='Customer 633' then ship_cmp_char.char_val else '' end ) as "payingCustomerCustomer633"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='Carrier Abbreviation' then ship_cmp_char.char_val else '' end ) as "payingCustomerCarrierAbbreviation"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='City Name' then ship_cmp_char.char_val else '' end ) as "payingCustomerCityName"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='Postal Code' then ship_cmp_char.char_val else '' end ) as "payingCustomerZip"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='Customer Address' then ship_cmp_char.char_val else '' end ) as "payingCustomerCustomerAddress"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='Customer Number' then ship_cmp_char.char_val else '' end ) as "payingCustomerCustomerNumber"
, max(case when ship_cmp.id_val='Paying Customer' and c.type_cd='Customer Name' then ship_cmp_char.char_val else '' end ) as "payingCustomerCustomerName"

, max(case when ship_cmp.id_val='Care Of' and c.type_cd='City 333' then ship_cmp_char.char_val else '' end ) as "careOfCity333"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='Province State' then ship_cmp_char.char_val else '' end ) as "careOfProvinceState"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='Station Number' then ship_cmp_char.char_val else '' end ) as "careOfStationNumber"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='Customer 633' then ship_cmp_char.char_val else '' end ) as "careOfCustomer633"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='Carrier Abbreviation' then ship_cmp_char.char_val else '' end ) as "careOfCarrierAbbreviation"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='City Name' then ship_cmp_char.char_val else '' end ) as "careOfCityName"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='Postal Code' then ship_cmp_char.char_val else '' end ) as "careOfZip"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='Customer Address' then ship_cmp_char.char_val else '' end ) as "careOfCustomerAddress"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='Customer Number' then ship_cmp_char.char_val else '' end ) as "careOfCustomerNumber"
, max(case when ship_cmp.id_val='Care Of' and c.type_cd='Customer Name' then ship_cmp_char.char_val else '' end ) as "careOfCustomerName"

, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='City 333' then ship_cmp_char.char_val else '' end ) as "finalDestinationCity333"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='Province State' then ship_cmp_char.char_val else '' end ) as "finalDestinationProvinceState"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='Station Number' then ship_cmp_char.char_val else '' end ) as "finalDestinationStationNumber"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='Customer 633' then ship_cmp_char.char_val else '' end ) as "finalDestinationCustomer633"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='Carrier Abbreviation' then ship_cmp_char.char_val else '' end ) as "finalDestinationCarrierAbbreviation"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='City Name' then ship_cmp_char.char_val else '' end ) as "finalDestinationCityName"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='Postal Code' then ship_cmp_char.char_val else '' end ) as "finalDestinationZip"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='Customer Address' then ship_cmp_char.char_val else '' end ) as "finalDestinationCustomerAddress"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='Customer Number' then ship_cmp_char.char_val else '' end ) as "finalDestinationCustomerNumber"
, max(case when ship_cmp.id_val='Final Destination' and c.type_cd='Customer Name' then ship_cmp_char.char_val else '' end ) as "finalDestinationCustomerName"

, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='City 333' then ship_cmp_char.char_val else '' end ) as "priorOriginCity333"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='Province State' then ship_cmp_char.char_val else '' end ) as "priorOriginProvinceState"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='Station Number' then ship_cmp_char.char_val else '' end ) as "priorOriginStationNumber"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='Customer 633' then ship_cmp_char.char_val else '' end ) as "priorOriginCustomer633"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='Carrier Abbreviation' then ship_cmp_char.char_val else '' end ) as "priorOriginCarrierAbbreviation"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='City Name' then ship_cmp_char.char_val else '' end ) as "priorOriginCityName"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='Postal Code' then ship_cmp_char.char_val else '' end ) as "priorOriginZip"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='Customer Address' then ship_cmp_char.char_val else '' end ) as "priorOriginCustomerAddress"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='Customer Number' then ship_cmp_char.char_val else '' end ) as "priorOriginCustomerNumber"
, max(case when ship_cmp.id_val='Prior Origin' and c.type_cd='Customer Name' then ship_cmp_char.char_val else '' end ) as "priorOriginCustomerName"

, max(case when ship_cmp.id_val='Ship From' and c.type_cd='City 333' then ship_cmp_char.char_val else '' end ) as "shipFromCity333"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='Province State' then ship_cmp_char.char_val else '' end ) as "shipFromProvinceState"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='Station Number' then ship_cmp_char.char_val else '' end ) as "shipFromStationNumber"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='Customer 633' then ship_cmp_char.char_val else '' end ) as "shipFromCustomer633"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='Carrier Abbreviation' then ship_cmp_char.char_val else '' end ) as "shipFromCarrierAbbreviation"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='City Name' then ship_cmp_char.char_val else '' end ) as "shipFromCityName"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='Postal Code' then ship_cmp_char.char_val else '' end ) as "shipFromZip"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='Customer Address' then ship_cmp_char.char_val else '' end ) as "shipFromCustomerAddress"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='Customer Number' then ship_cmp_char.char_val else '' end ) as "shipFromCustomerNumber"
, max(case when ship_cmp.id_val='Ship From' and c.type_cd='Customer Name' then ship_cmp_char.char_val else '' end ) as "shipFromCustomerName"
from daas_tm_prepared.dh_ship_cmp ship_cmp
inner join daas_tm_prepared.dh_ref_type b on ship_cmp.id_type_key = b.type_key
inner join daas_tm_prepared.dh_ship_cmp_char ship_cmp_char on ship_cmp_char.ship_cmp_key = ship_cmp.ship_cmp_key
inner join daas_tm_prepared.dh_ref_type c on ship_cmp_char.char_type_key = c.type_key

where ship_cmp.act_stus_ind=1
and ship_cmp.id_type_key='0da6b367be535ff480a461a0ddfac98d53635e128106bd40291b8147966a0435' --BP Role
and ship_cmp.ship_key=p_ship_key --'000421aa3207ae64274bacb5d11b4b216757600beb24794f0d2ed4d548238281'
and ship_cmp_char.char_type_key 
in ( 
'f7fea258257900efc47bfc66fd0a3cec16e032f5a50f164092a477f425ad8681',  --City 333
'73f840ebda7254d5b8215cf633a9e6fc95a2e824e7e175f5bc5b7f0ed699afd3', --Province State
'8546e3dfa49300181d5491a0599b2703e11cce3b6ca4502c0b124f9d02e388e0' ,-- station number
'bd9dae217a0a467e1d4ab7e34974038e2001b9361a106a8a088debd5c5430e14', --Customer 633
'74c9f9b9a92dd37961cb4ed43c425d37f0c757d9f7ce71188a701b194a75d4b1', --Carrier Abbreviation

'dd2a8b3f34c68f6e94e9178fc6fd67c80a03b238c72760807a73f8c09a010a55' ,  --City Name
'a22902c4483e08f8b5aed795d536ca8c1a7344e77409a817268c1e233401eb34',   --Postal Code
'b9c7dee798cc41fa7b84d7d669cc777145514a64fb7fa5d87b2c08090f7e163c' ,  --Customer Address
'0b1821f40450113c8ce372b1cc14a2865520c66493a36d225a353a1f6bbbeb94' ,   --Customer Number
'28fa08b6d074f1abef54d8137ee775f0c86b5d3246929eb140b56e963c8263c6'    --Customer Name/CustomerFull
)
group by ship_cmp.ship_key;

end;
$$
LANGUAGE 'plpgsql';