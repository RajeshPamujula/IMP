drop function if exists f_run_dh_purge_queries
;
CREATE FUNCTION f_run_dh_purge_queries(p_purge_id int default null)
RETURNS TABLE(
    table_name varchar(64),
	description varchar(100),
    pre_rowcount int,
    purge_rowcount int,
    post_rowcount int)
AS $$
DECLARE
	queries CURSOR FOR
	SELECT t.purge_id,
	t.table_name,
	t.description,
	split_part(t.pre_query, ';', 1) as pre_query_1,
	split_part(t.pre_query, ';', 2) as pre_query_2,
	split_part(t.pre_query, ';', 3) as pre_query_3,
	split_part(t.pre_query, ';', 4) as pre_query_4,
	t.purge_query,
	t.post_query,
	t.validate_query
	FROM   daas_tm_prepared.dh_purge_queries t
	WHERE  t.active_status = 'A' and coalesce(p_purge_id, t.purge_id) = t.purge_id
	ORDER  BY t.purge_id;
	v_pre_rowcount int;
	v_post_rowcount int;
	v_purge_rowcount int;
BEGIN
    CREATE TEMP TABLE mytemp(
		id serial,
		purge_id int,
		table_name varchar(64),
		description varchar(100),
		pre_rowcount int,
		purge_rowcount int,
		post_rowcount int
    ) on commit drop;

    FOR qry IN queries LOOP
		EXECUTE qry.validate_query INTO v_pre_rowcount;
		EXECUTE qry.pre_query_1;
		EXECUTE qry.pre_query_2;
		EXECUTE qry.pre_query_3;
		EXECUTE qry.pre_query_4;
		EXECUTE qry.purge_query;
		GET DIAGNOSTICS v_purge_rowcount = ROW_COUNT;
		EXECUTE qry.post_query;
		EXECUTE qry.validate_query into v_post_rowcount;
		insert into mytemp(purge_id, table_name, description, pre_rowcount,purge_rowcount, post_rowcount)
		values(qry.purge_id, qry.table_name, qry.description, v_pre_rowcount,v_purge_rowcount, v_post_rowcount);
    END LOOP;

    EXECUTE 'insert into daas_tm_prepared.dh_purge_results SELECT now(), t.purge_id, t.pre_rowcount, t.purge_rowcount, t.post_rowcount FROM mytemp t order by t.id';
    RETURN QUERY SELECT t.table_name, t.description, t.pre_rowcount, t.purge_rowcount, t.post_rowcount FROM mytemp t order by t.id;
END;$$ SECURITY DEFINER
LANGUAGE plpgsql;
