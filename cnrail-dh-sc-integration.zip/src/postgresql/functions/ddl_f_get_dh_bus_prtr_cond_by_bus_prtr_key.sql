DROP FUNCTION IF EXISTS f_get_dh_bus_prtr_cond_by_bus_prtr_key(bytea) cascade;

  

CREATE OR REPLACE FUNCTION f_get_dh_bus_prtr_cond_by_bus_prtr_key(p_bus_prtr_key bytea)
RETURNS TABLE 
(
bus_prtr_key bytea,
"agreementEffectiveDate" text,
"agreementExpiryDate" text,
"customerStatus" text
)
AS $$
begin
return query

select
a.bus_prtr_key,
bus_prtr_cond1.char_val as "agreementEffectiveDate",
bus_prtr_cond2.char_val as "agreementExpiryDate",
bus_prtr_cond3.char_val as "customerStatus"
from daas_tm_prepared.dh_bus_prtr a
left join daas_tm_prepared.dh_bus_prtr_cond  bus_prtr_cond1 on (a.bus_prtr_key = bus_prtr_cond1.bus_prtr_key and bus_prtr_cond1.act_stus_ind = 1 and bus_prtr_cond1.char_type_key = '55821f53a1d132182bec83869f96c8837749609bc4976a3fa0aab11e41b05bd3') -- Agreement Effective Date
left join daas_tm_prepared.dh_bus_prtr_cond  bus_prtr_cond2 on (a.bus_prtr_key = bus_prtr_cond2.bus_prtr_key and bus_prtr_cond2.act_stus_ind = 1 and bus_prtr_cond2.char_type_key = '42f6a2c985101108c42cc5750bd589f9aabd0f756267253a3d382d8da1d1cb9f') -- Agreement Expiry Date
left join daas_tm_prepared.dh_bus_prtr_cond  bus_prtr_cond3 on (a.bus_prtr_key = bus_prtr_cond3.bus_prtr_key and bus_prtr_cond3.act_stus_ind = 1 and bus_prtr_cond3.char_type_key = 'b0dbb55054f31f2fe32f4b5d2d283ec890ed91aaa61a8b6413a6b70508c13c95') -- Customer Status
where a.bus_prtr_key = p_bus_prtr_key
and a.act_stus_ind = 1;

end;
$$
LANGUAGE 'plpgsql';
