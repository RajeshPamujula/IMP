DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_trsp_evt_char_domn_evt_by_car_trsp_key(bytea,timestamp) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_trsp_evt_char_domn_evt_by_car_trsp_key(p_trsp_evt_key bytea, p_curr_sor_proc_ts timestamp )
/*
p_curr_sor_proc_ts: pass rpt_sor_proc_ts from dh_trsp_evt
*/

RETURNS TABLE 
(

"transportationEventKey" bytea,
"sourceProcessDateTime" timestamp without time zone,
"event"  text,
"eventDate"  text,
"eventTime"  text
)
AS $$
begin
return query


With prvs_dh_trsp_evt_char as (
select distinct 
tec3.sor_proc_ts, tec3.trsp_evt_key
,dense_rank() over(PARTITION BY tec3.trsp_evt_key ,ref.type_cd order by tec3.sor_proc_ts desc, tec3.data_hub_crt_ts desc) as rk
,ref.type_cd,tec3.char_val
from  daas_tm_prepared.dh_trsp_evt_char_domn_evt tec3 
inner join daas_tm_prepared.dh_ref_type ref on ref.type_key=tec3.char_type_key
where tec3.trsp_evt_key= p_trsp_evt_key -- 'c12cac3cec2d9c086fc08aa1361c997b27310550f9834888c05207e9b9a7d573' --
--and tec3.sor_proc_ts <  p_curr_sor_proc_ts   --TO_TIMESTAMP('2021-01-13 08:01:13.2810000',    'YYYY-MM-DD HH:MI:SS.nnnnnnn')::timestamp)  -- 
)
select trsp_evt_key as "transportationEventKey",
sor_proc_ts as "sourceProcessDateTime",
max(case when type_cd='Event' then char_val else '' end ) as "event",
max(case when type_cd='Event Date' then char_val else '' end ) as "eventDate",
max(case when type_cd='Event Time' then char_val else '' end ) as "eventTime"
from prvs_dh_trsp_evt_char
where rk=2
group by 1,2;


end;
$$
LANGUAGE 'plpgsql';
