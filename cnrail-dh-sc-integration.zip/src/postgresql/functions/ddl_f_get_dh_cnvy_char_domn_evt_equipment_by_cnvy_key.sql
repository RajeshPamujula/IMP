DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_cnvy_char_domn_evt_equipment_by_cnvy_key(bytea, timestamp) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_cnvy_char_domn_evt_equipment_by_cnvy_key(p_cnvy_key bytea, p_curr_sor_proc_ts timestamp )
/*
p_curr_sor_proc_ts: pass rpt_sor_proc_ts from dh_cnvy_char or dh_cnvy
*/
returns table(

"conveyorKey" bytea,
"sourceProcessDateTime" timestamp without time zone,


Equipment_Owner_Abbreviation text,
Equipment_Tare text,
Equipment_Tare_LB text,
Equipment_Tare_UOM text,

Load_Limit text,
Load_Limit_LB text,
Load_Limit_UOM text,

Equipment_Lessee_Abbreviation text

)
AS $$
begin
return query

with prvs_cnvy_char as (
select distinct ref.type_cd,  a.char_val, a.sor_proc_ts
,dense_rank() over(PARTITION BY a.cnvy_key,ref.type_cd order by a.sor_proc_ts desc , a.data_hub_crt_ts desc) as rk
,a.cnvy_key
from daas_tm_prepared.dh_cnvy_char_domn_evt a
inner join daas_tm_prepared.dh_ref_type ref on ref.type_key=a.char_type_key
where a.cnvy_key= p_cnvy_key --'c12cac3cec2d9c086fc08aa1361c997b27310550f9834888c05207e9b9a7d573'
--and sor_proc_ts< p_curr_sor_proc_ts --TO_TIMESTAMP(    '2021-01-13 08:01:13.2810000',    'YYYY-MM-DD HH:MI:SS.nnnnnnn')::timestamp

)
select cnvy_key as "conveyorKey",
max(sor_proc_ts) as "sourceProcessDateTime",

max(case when type_cd = 'Equipment Owner Abbreviation' then char_val else null end) as Equipment_Owner_Abbreviation,
max(case when type_cd = 'Equipment Tare' then char_val else null end) as Equipment_Tare,
max(case when type_cd = 'Equipment Tare LB' then char_val else null end) as Equipment_Tare_LB,
max(case when type_cd = 'Equipment Tare UOM' then char_val else null end) as Equipment_Tare_UOM,

max(case when type_cd = 'Load Limit' then char_val else null end) as Load_Limit,
max(case when type_cd = 'Load Limit LB' then char_val else null end) as Load_Limit_LB,
max(case when type_cd = 'Load Limit UOM' then char_val else null end) as Load_Limit_UOM,

max(case when type_cd = 'Equipment Lessee Abbreviation' then char_val else null end) as Equipment_Lessee_Abbreviation

from prvs_cnvy_char
where rk=2
group by 1;

end;
$$ LANGUAGE plpgsql;
