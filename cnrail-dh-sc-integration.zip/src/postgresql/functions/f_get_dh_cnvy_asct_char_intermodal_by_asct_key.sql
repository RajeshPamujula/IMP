CREATE OR REPLACE FUNCTION f_get_dh_cnvy_asct_char_intermodal_by_asct_key(p_asct_key bytea)
returns table(asct_key bytea,
Attach_Date_Time text,
Attach_Date_Time_Time_Zone text,
Equipment_Ramp_Status text,
Equipment_Sequence_Number text)
AS $$
begin
return query
select main.asct_key,
max(case when ref_type.type_cd = 'Attach Date Time' then c.char_val else null end) as Attach_Date_Time,
max(case when ref_type.type_cd = 'Attach Date Time Time Zone' then c.char_val else null end) as Attach_Date_Time_Time_Zone,
max(case when ref_type.type_cd = 'Equipment Ramp Status' then c.char_val else null end) as Equipment_Ramp_Status,
max(case when ref_type.type_cd = 'Equipment Sequence Number' then c.char_val else null end) as Equipment_Sequence_Number
from daas_tm_prepared.dh_cnvy_asct main
left  join daas_tm_prepared.dh_cnvy_asct_char c
on    main.asct_key = c.asct_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key and main.act_stus_ind = 1
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;
