CREATE OR REPLACE FUNCTION f_get_dh_cnvy_char_gate_by_cnvy_key(p_cnvy_key bytea)
returns table(cnvy_key bytea,
Chassis_Car_Kind text,
Chassis_Id text,
Chassis_Initial text,
Chassis_Number text,
Container_Id text,
Container_Initial text,
Container_Number text,
Tractor_License text)
AS $$
begin
return query
select main.cnvy_key,
max(case when ref_type.type_cd = 'Chassis Car Kind' then c.char_val else null end) as Chassis_Car_Kind,
max(case when ref_type.type_cd = 'Chassis Id' then c.char_val else null end) as Chassis_Id,
max(case when ref_type.type_cd = 'Chassis Initial' then c.char_val else null end) as Chassis_Initial,
max(case when ref_type.type_cd = 'Chassis Number' then c.char_val else null end) as Chassis_Number,
max(case when ref_type.type_cd = 'Container Id' then c.char_val else null end) as Container_Id,
max(case when ref_type.type_cd = 'Container Initial' then c.char_val else null end) as Container_Initial,
max(case when ref_type.type_cd = 'Container Number' then c.char_val else null end) as Container_Number,
max(case when ref_type.type_cd = 'Tractor License' then c.char_val else null end) as Tractor_License
from daas_tm_prepared.dh_cnvy main
left  join daas_tm_prepared.dh_cnvy_char c
on    main.cnvy_key = c.cnvy_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.cnvy_key = p_cnvy_key and main.act_stus_ind = 1
group by main.cnvy_key;
end;
$$ LANGUAGE plpgsql;
