DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_tpln_seg_char_by_tpln_seg_key(bytea) cascade;


CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_tpln_seg_char_by_tpln_seg_key(p_tpln_seg_key bytea)
RETURNS TABLE 
(
tpln_seg_key bytea,

"dataHubCreationTimestamp" timestamp,
"actualEventTimestamp" text,
"associatedEquipmentInitial" text,
"associatedEquipmentNumber" text,
"estimatedEventTimestamp" text,

"eventCode"  text,
"eventStatusCode" text,
"jeopardyReasonCode" text,
"operatingRailroadAtJunctionPoint" text,

"opZTS" text,
"rescheduleReasonCode" text,
"scheduleEventTimestamp" text,
"station333" text,

"stationProvinceStateCode" text,
"stationSequenceNumber" text,
"trainBlock" text,
"trainIdentification" text,

"tripPlanSequenceNumber" text,
"tripTypeCode" text,
"yardBlock" text,
"yardBlockConnectionIndicator" text
)
AS $$
begin
return query

select 
a.tpln_seg_key as "tripPlanSegmentKey",
max(a.data_hub_crt_ts) as "dataHubCreationTimestamp",
max(case when type_cd = 'Actual Event Timestamp' then char_val else null end) as "actualEventTimestamp",
max(case when type_cd = 'Associated Equipment Initial' then char_val else null end) as "associatedEquipmentInitial",
max(case when type_cd = 'Associated Equipment Number' then char_val else null end) as "associatedEquipmentNumber",
max(case when type_cd = 'Estimated Event Timestamp' then char_val else null end) as "estimatedEventTimestamp",

max(case when type_cd = 'Event Code' then char_val else null end) as "eventCode",
max(case when type_cd = 'Event Status Code' then char_val else null end) as "eventStatusCode",
max(case when type_cd = 'Jeopardy Reason Code' then char_val else null end) as "jeopardyReasonCode",
max(case when type_cd = 'Operating Railroad at Junction Point' then char_val else null end) as "operatingRailroadAtJunctionPoint",

max(case when type_cd = 'OP ZTS' then char_val else null end) as "opZTS",
max(case when type_cd = 'Reschedule Reason Code' then char_val else null end) as "rescheduleReasonCode",
max(case when type_cd = 'Schedule Event Timestamp' then char_val else null end) as "scheduleEventTimestamp",
max(case when type_cd = 'Station 333' then char_val else null end) as "station333",

max(case when type_cd = 'Station Province State Code' then char_val else null end) as "stationProvinceStateCode",
max(case when type_cd = 'Station Sequence Number' then char_val else null end) as "stationSequenceNumber",
max(case when type_cd = 'Train Block' then char_val else null end) as "trainBlock",
max(case when type_cd = 'Train ID' then char_val else null end) as "trainIdentification",

max(case when type_cd = 'Trip Plan Sequence Number' then char_val else null end) as "tripPlanSequenceNumber",
max(case when type_cd = 'Trip Type Code' then char_val else null end) as "tripTypeCode",
max(case when type_cd = 'Yard Block' then char_val else null end) as "yardBlock",
max(case when type_cd = 'Yard Block Connection Indicator' then char_val else null end) as "yardBlockConnectionIndicator"
from daas_tm_prepared.dh_tpln_seg_char a
inner join daas_tm_prepared.dh_ref_type ref on ref.type_key=a.char_type_key
where a.tpln_seg_key = p_tpln_seg_key
and a.act_stus_ind = 1
group by 1;
end;
$$
LANGUAGE 'plpgsql';




