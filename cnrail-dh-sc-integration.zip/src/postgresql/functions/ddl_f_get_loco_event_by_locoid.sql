DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_loco_event_by_locoid(text) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_loco_event_by_locoid(locoid text)
RETURNS table 
(

"locoIdentification"  text,
"eventCode"  text,
"eventStatus" text,
"eventLocationStation333" varchar(9),
"eventLocationStationState" bpchar(2),
"eventDateTime" timestamp,
"eventTimezoneLabel"  varchar(10),
"eventOffsetHours"    numeric(5,3),
"latitude" text,
"longitude" text,
"locomotiveCurrentPositionTimestamp" timestamp,
"locoArrivalSequence" text,
"locomotiveStatus"   text,
"locomotiveLocationCode" text,
"trainShortIdentifier" text , 
"timestampUpdate" timestamp 
)
AS $$
begin
return query
/* Once data quality issue is resolved, we may change code to get the first rank first and then lookup other tables */
with locoevt as (
SELECT  
 aset.id_val AS "locomotiveIdentification"
,substring(trsp.trsp_evt_val from 1 for 2) AS "eventCode"
,substring(trsp.trsp_evt_val from 3 for 2) AS "eventStatus"
,stn.stn_333 AS "eventLocationStation333"
,stn.stn_st AS "eventLocationStationState"
,TO_TIMESTAMP(trspc.char_val , 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone as "eventDateTime"
,tz_ref.tz_lbl AS "eventTimezoneLabel"
,tz_ref.utc_ofst_val_hr AS "eventOffsetHours"
,aset_cond_1.char_val AS "latitude"
,aset_cond_2.char_val AS "longitude"
,aset_cond_1.sor_evt_ts as "locomotiveCurrentPositionTimestamp"
,arrivalsequence.char_val as "locoArrivalSequence"
,aset_cond_3.char_val AS "locomotiveStatus"
,aset_cond_4.char_val AS "locomotiveLocationCode"
,train.char_val as "trainShortIdentifier"
,trsp.data_hub_crt_ts as "timestampUpdate"
, ROW_NUMBER() OVER (PARTITION BY aset.id_val ORDER BY aset_asct.asct_sor_proc_ts DESC) rk

FROM daas_tm_prepared.dh_aset as aset
LEFT JOIN daas_tm_prepared.dh_aset_char as aset_char ON aset.aset_key= aset_char.aset_key AND aset_char.char_type_key = '1eae340932d52fe2223892cd8950e6af82434a4ab95a09616315ab2e1fbe7f03'--- to get Locomotive Id
LEFT JOIN daas_tm_prepared.dh_aset_asct as aset_asct on aset.aset_key = aset_asct.aset_key AND aset.act_stus_ind = 1 AND aset_asct.asct_type_key = 'f704495b434218d4a49f0ca9af97b8bb126553eb50d0f77456b9232e83b9b53e'--- to associate loco to conveyor
LEFT JOIN daas_tm_prepared.dh_trsp_evt as trsp on trsp.trsp_evt_key = aset.aset_key AND trsp.act_stus_ind = 1 AND trsp.trsp_evt_type_key = 'fda02cd8241999c41cec8807dd74ffd911c1c59507adc3cebac0c140abb6f219'--- to get the loco event
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char as trspc on trsp.trsp_evt_key = trspc.trsp_evt_key AND trspc.act_stus_ind = 1 AND trspc.char_type_key = '47315209be802f75a9e4e3f07baf68f4c82f572b32d5dcea9eda9fbc91a92f32'--- Event Date Time UTC
LEFT join daas_tm_prepared.dh_tz_dst_ref as tz_ref on (trsp.sor_evt_ts_tz_dst_cd = tz_ref.tz_dst_cd)
LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct as ta on trsp.trsp_evt_key = ta.trsp_evt_key AND ta.act_stus_ind = 1 AND ta.asct_obj_type_key ='3243be7c53d81a4ed2e0224d66e8452715f18aaefb95df70de85575b6b070306'--- to get the loco station
LEFT JOIN daas_tm_prepared.dh_rail_station as stn on stn.stn_333_cn_key = ta.asct_obj_key or stn.stn_333_cn_key_conv = ta.asct_obj_key
LEFT JOIN daas_tm_prepared.dh_aset_asct_char as train on aset_asct.asct_key = train.asct_key and train.char_type_key ='41e632e1e2d9c26384340a3a399c52feb831346e53fd9f6dd71a587613d1f685' -- Train ID
LEFT JOIN daas_tm_prepared.dh_aset_asct_char as arrivalsequence on aset_asct.asct_key = arrivalsequence.asct_key and arrivalsequence.char_type_key = '1480f6c114604d3e849afb4a8ae8781346687935f3aab2ae92ab13343473e2ef' -- Arrival Sequence Number
LEFT JOIN daas_tm_prepared.dh_aset_cond as aset_cond_1 ON aset.aset_key = aset_cond_1.aset_key and aset_cond_1.act_stus_ind = 1 AND aset_cond_1.char_type_key = '63b1339bfe1572688e3e42e39d7e6998fb5429f0257868bdaf79ca8b03129905' -- Lococ latitude
LEFT JOIN daas_tm_prepared.dh_aset_cond aset_cond_2 ON aset.aset_key = aset_cond_2.aset_key and aset_cond_2.act_stus_ind = 1 AND aset_cond_2.char_type_key = 'af6a730d48880a4e1fbd4f0d3b6b48b6568557fbc74bceb543457b106c57daad' --- Loco longitude
LEFT JOIN daas_tm_prepared.dh_aset_cond aset_cond_3 ON aset.aset_key = aset_cond_3.aset_key and aset_cond_3.act_stus_ind = 1 AND aset_cond_3.char_type_key = '2a04009a57b3f9d53626268239cca9163f437bb0760928eeb6d5755a48b7e830' -- Locomotive Operating Status Code
LEFT JOIN daas_tm_prepared.dh_aset_cond aset_cond_4 ON aset.aset_key = aset_cond_4.aset_key and aset_cond_4.act_stus_ind = 1 AND aset_cond_4.char_type_key = '3ce4380d9151bfc571dfa300027e32d0e21b43727aa1fe86a88399bd6a03c9a4' -- Locomotive Location Code
where  aset.id_val=locoid
)
SELECT 
m."locomotiveIdentification"
,m."eventCode"
,m."eventStatus"
,m."eventLocationStation333"
,m."eventLocationStationState"
,m."eventDateTime"
,m."eventTimezoneLabel"
,m."eventOffsetHours"
,m."latitude"
,m."longitude"
,m."locomotiveCurrentPositionTimestamp"
,m."locoArrivalSequence"
,m."locomotiveStatus"
,m."locomotiveLocationCode"
,m."trainShortIdentifier"
,m."timestampUpdate"

FROM locoevt M
WHERE RK=1;
end;

$$ LANGUAGE plpgsql;