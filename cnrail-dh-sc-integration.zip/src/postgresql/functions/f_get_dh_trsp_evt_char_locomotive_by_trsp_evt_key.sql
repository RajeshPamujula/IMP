CREATE OR REPLACE FUNCTION f_get_dh_trsp_evt_char_locomotive_by_trsp_evt_key(p_trsp_evt_key bytea)
returns table(trsp_evt_key bytea,
Event_Code text,
Event_Status_Code text)
AS $$
begin
return query
select main.trsp_evt_key,
max(case when ref_type.type_cd = 'Event Code' then c.char_val else null end) as Event_Code,
max(case when ref_type.type_cd = 'Event Status Code' then c.char_val else null end) as Event_Status_Code
from daas_tm_prepared.dh_trsp_evt main
left  join daas_tm_prepared.dh_trsp_evt_char c
on    main.trsp_evt_key = c.trsp_evt_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.trsp_evt_key = p_trsp_evt_key and main.act_stus_ind = 1
group by main.trsp_evt_key;
end;
$$ LANGUAGE plpgsql;
