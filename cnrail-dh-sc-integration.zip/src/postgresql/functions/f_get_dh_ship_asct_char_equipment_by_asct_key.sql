DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_asct_char_equipment_by_asct_key(bytea) cascade;


CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_asct_char_equipment_by_asct_key(p_asct_key bytea)
returns table(asct_key bytea,
"dataHubCreationTimestamp" timestamp,
"eventTimestamp" timestamp,
Current_Assignment text,
Customer_Switch_Code text,
Empty_Order_Number text,
Next_Assignment_Train_Day text,
Next_Assignment_Train_Section text,
Next_Assignment_Train_Symbol text,
Next_Assignment_Train_Type text,
Operating_Customer_633 text,
Operating_Origin_333 text,
Operating_Origin_333_Province_State_Code text,
Operating_Railroad_At_Junction_Point text,
Operating_Station_333 text,
Operating_Station_333_Province_State_Code text,
Op_ZTS text,
Setout_Station_333 text,
Setout_Station_333_Province_State_Code text,
Shuttle_Destination_333 text,
Shuttle_Destination_333_Province_State_Code text,
Train_Block text,
Yard_Block text
)
AS $$
begin
return query
select main.asct_key,
max(c.data_hub_crt_ts) as "dataHubCreationTimestamp",
max(c.sor_evt_ts) as "eventTimestamp",
max(case when ref_type.type_cd = 'Current Assignment' then c.char_val else null end) as Current_Assignment,
max(case when ref_type.type_cd = 'Customer Switch Code' then c.char_val else null end) as Customer_Switch_Code,
max(case when ref_type.type_cd = 'Empty Order Number' then c.char_val else null end) as Empty_Order_Number,
max(case when ref_type.type_cd = 'Next Assignment Train Day' then c.char_val else null end) as Next_Assignment_Train_Day,
max(case when ref_type.type_cd = 'Next Assignment Train Section' then c.char_val else null end) as Next_Assignment_Train_Section,
max(case when ref_type.type_cd = 'Next Assignment Train Symbol' then c.char_val else null end) as Next_Assignment_Train_Symbol,
max(case when ref_type.type_cd = 'Next Assignment Train Type' then c.char_val else null end) as Next_Assignment_Train_Type,
max(case when ref_type.type_cd = 'Operating Customer 633' then c.char_val else null end) as Operating_Customer_633,
max(case when ref_type.type_cd = 'Operating Origin 333' then c.char_val else null end) as Operating_Origin_333,
max(case when ref_type.type_cd = 'Operating Origin 333 Province State Code' then c.char_val else null end) as Operating_Origin_333_Province_State_Code,
max(case when ref_type.type_cd = 'Operating Railroad At Junction Point' then c.char_val else null end) as Operating_Railroad_At_Junction_Point,
max(case when ref_type.type_cd = 'Operating Station 333' then c.char_val else null end) as Operating_Station_333,
max(case when ref_type.type_cd = 'Operating Station 333 Province State Code' then c.char_val else null end) as Operating_Station_333_Province_State_Code,
max(case when ref_type.type_cd = 'Op ZTS' then c.char_val else null end) as Op_ZTS,
max(case when ref_type.type_cd = 'Setout Station 333' then c.char_val else null end) as Setout_Station_333,
max(case when ref_type.type_cd = 'Setout Station 333 Province State Code' then c.char_val else null end) as Setout_Station_333_Province_State_Code,
max(case when ref_type.type_cd = 'Shuttle Destination 333' then c.char_val else null end) as Shuttle_Destination_333,
max(case when ref_type.type_cd = 'Shuttle Destination 333 Province State Code' then c.char_val else null end) as Shuttle_Destination_333_Province_State_Code,
max(case when ref_type.type_cd = 'Train Block' then c.char_val else null end) as Train_Block,
max(case when ref_type.type_cd = 'Yard Block' then c.char_val else null end) as Yard_Block
from daas_tm_prepared.dh_ship_asct main
left  join daas_tm_prepared.dh_ship_asct_char c
on    main.asct_key = c.asct_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key and main.act_stus_ind = 1
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;