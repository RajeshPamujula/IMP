DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_cnvy_cond_non_unit_location_by_cnvy_key (bytea) cascade;
/*
drop cascades to view daas_tm_trusted."vIntermodalUnitDetail"
drop cascades to view daas_tm_trusted."vIntermodalUnitDetailHistory"
exclude any attributes from transportation.unit-location-updated kafka
*/

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_cnvy_cond_non_unit_location_by_cnvy_key(p_cnvy_key bytea)
RETURNS TABLE 
(
cnvy_key bytea,
"ProcessTimestamp"  timestamp without time zone,
"dataHubCreationTimestamp"  timestamp without time zone,
"eventTimestamp"  timestamp without time zone,
"arrivalStation333" text,
"arrivalStation333ProvinceState" text,
"badOrderCode" text,
"badOrderEstimatedTimeToRepairHours" text,
"carLocationCode" text,

"customerCarOrderNumber" text,
"customerSwitchCode" text,
"firstStorageChargeDate" text,
"mechanicalStatusCodes" text,
"mechanicalStatusCode1" text,
"mechanicalStatusCode2" text,
"mechanicalStatusCode3" text,
"nextAssignment" text,

"operatingZoneTrackSpot" text,
"operatingCity333" text,
"operatingCity333CarrierAbbreviation" text,
"operatingCity333ProvinceStateCode" text,
"operatingCustomer633" text,

"operatingOrigin333" text,
"operatingOrigin333CarrierAbbreviation" text,
"operatingOrigin333ProvinceStateCode" text,
"operatingRailroadAtJunctionPoint" text,
"previousTrackNumber" text,

"setOutCarrierAbbreviation" text,
"speedRestriction" text,
"storageChargeStatusCode" text,
"trainBlock" text,
"trainID" text,

"yardBlock" text,

"endServiceDate" text,
"loadSheetHoldCode" text,
"eventAccountCode"  text,
"balanceOwedIndicator" text,

"equipmentLocationCode" text,
--"spot" text,
--"lotTrackId" text,
--"row" text,
"shuttleEquipmentIndicator" text,
"refrigeratorRunningTemperature" text,
"refrigeratorFuelLevel"  text,
--"parkingTracksideIndicator" text,
--"tier" text,
"statusIndicator" text
)
AS $$
begin
return query
select a.cnvy_key,
max(cnvy_cond.rpt_sor_proc_ts) as "ProcessTimestamp", 
max(cnvy_cond.data_hub_crt_ts) as "dataHubCreationTimestamp", 
max(cnvy_cond.sor_evt_ts) as "eventTimestamp", 
max(case when ref.type_cd ='Arrival Station 333' then cnvy_cond.char_val else null end) as "arrivalStation333",
max(case when ref.type_cd ='Arrival Station 333 Province State' then cnvy_cond.char_val else null end) as "arrivalStation333ProvinceState",
max(case when ref.type_cd ='Bad Order Code' then cnvy_cond.char_val else null end) as "badOrderCode",
max(case when ref.type_cd ='Bad Order Estimated Time to Repair Hours' then cnvy_cond.char_val else null end) as "badOrderEstimatedTimeToRepairHours",
max(case when ref.type_cd ='Car Location Code' then cnvy_cond.char_val else null end) as "carLocationCode",

max(case when ref.type_cd ='CCO Number' then cnvy_cond.char_val else null end) as "customerCarOrderNumber",
max(case when ref.type_cd ='Customer Switch Code' then cnvy_cond.char_val else null end) as "customerSwitchCode",
max(case when ref.type_cd ='First Storage Charge Date' then cnvy_cond.char_val else null end) as "firstStorageChargeDate",
max(case when ref.type_cd ='Mechanical Status Codes' then cnvy_cond.char_val else null end) as "mechanicalStatusCodes",
max(case when ref.type_cd ='Mechanical Status Code 1' then cnvy_cond.char_val else null end) as "mechanicalStatusCode1",
max(case when ref.type_cd ='Mechanical Status Code 2' then cnvy_cond.char_val else null end) as "mechanicalStatusCode2",
max(case when ref.type_cd ='Mechanical Status Code 3' then cnvy_cond.char_val else null end) as "mechanicalStatusCode3",
max(case when ref.type_cd ='Next Assignment' then cnvy_cond.char_val else null end) as "nextAssignment",


max(case when ref.type_cd ='OP ZTS' then cnvy_cond.char_val else null end) as "operatingZoneTrackSpot",
max(case when ref.type_cd ='Operating City 333' then cnvy_cond.char_val else null end) as "operatingCity333",
max(case when ref.type_cd ='Operating City 333 Carrier Abbreviation' then cnvy_cond.char_val else null end) as "operatingCity333CarrierAbbreviation",
max(case when ref.type_cd ='Operating City 333 Province State Code' then cnvy_cond.char_val else null end) as "operatingCity333ProvinceStateCode",
max(case when ref.type_cd ='Operating Customer 633' then cnvy_cond.char_val else null end) as "operatingCustomer633",

max(case when ref.type_cd ='Operating Origin 333' then cnvy_cond.char_val else null end) as "operatingOrigin333",
max(case when ref.type_cd ='Operating Origin 333 Carrier Abbreviation' then cnvy_cond.char_val else null end) as "operatingOrigin333CarrierAbbreviation",
max(case when ref.type_cd ='Operating Origin 333 Province State Code' then cnvy_cond.char_val else null end) as "operatingOrigin333ProvinceStateCode",
max(case when ref.type_cd ='Operating Railroad at Junction Point' then cnvy_cond.char_val else null end) as "operatingRailroadAtJunctionPoint",
max(case when ref.type_cd ='Previous Track Number' then cnvy_cond.char_val else null end) as "previousTrackNumber",

max(case when ref.type_cd ='Set Out Carrier Abbreviation' then cnvy_cond.char_val else null end) as "setOutCarrierAbbreviation",
max(case when ref.type_cd ='Speed Restriction' then cnvy_cond.char_val else null end) as "speedRestriction",
max(case when ref.type_cd ='Storage Charge Status Code' then cnvy_cond.char_val else null end) as "storageChargeStatusCode",
max(case when ref.type_cd ='Train Block' then cnvy_cond.char_val else null end) as "trainBlock",
max(case when ref.type_cd ='Train ID' then cnvy_cond.char_val else null end) as "trainID",


max(case when ref.type_cd ='Yard Block' then cnvy_cond.char_val else null end) as "yardBlock",

max(case when ref.type_cd ='End of Service Date' then cnvy_cond.char_val else null end) as "endServiceDate",
max(case when ref.type_cd ='Load Sheet Hold Code' then cnvy_cond.char_val else null end) as "loadSheetHoldCode",
max(case when ref.type_cd ='Event Account Code' then cnvy_cond.char_val else null end) as "eventAccountCode",
max(case when ref.type_cd ='Balance Owed Indicator' then cnvy_cond.char_val else null end) as "balanceOwedIndicator",

max(case when ref.type_cd = 'Equipment Location Code' then cnvy_cond.char_val else null end) as "equipmentLocationCode",
--max(case when ref.type_cd = 'Spot' then cnvy_cond.char_val else null end) as "spot",
--max(case when ref.type_cd = 'Lot Track Id' then cnvy_cond.char_val else null end) as "lotTrackId",
--max(case when ref.type_cd = 'Row' then cnvy_cond.char_val else null end) as "row",
max(case when ref.type_cd = 'Shuttle Equipment Indicator' then cnvy_cond.char_val else null end) as "shuttleEquipmentIndicator",
max(case when ref.type_cd = 'Refrigerator Running Temperature' then cnvy_cond.char_val else null end) as "refrigeratorRunningTemperature",
max(case when ref.type_cd = 'Refrigerator Fuel Level' then cnvy_cond.char_val else null end) as "refrigeratorFuelLevel",
--max(case when ref.type_cd = 'Parking Trackside Indicator' then cnvy_cond.char_val else null end)  as "parkingTracksideIndicator",
--max(case when ref.type_cd = 'Tier' then cnvy_cond.char_val else null end) as "tier",
max(case when ref.type_cd = 'Status Indicator' then cnvy_cond.char_val else null end) as "statusIndicator"

from daas_tm_prepared.dh_cnvy a
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond on a.cnvy_key=cnvy_cond.cnvy_key and cnvy_cond.act_stus_ind=1
and cnvy_cond.sor_tpic_nm not like '%unit-location-updated%'
left join daas_tm_prepared.dh_ref_type ref on (cnvy_cond.char_type_key = ref.type_key)
where a.cnvy_key=p_cnvy_key
and a.act_stus_ind=1
group by a.cnvy_key; 
end;
$$
LANGUAGE 'plpgsql';