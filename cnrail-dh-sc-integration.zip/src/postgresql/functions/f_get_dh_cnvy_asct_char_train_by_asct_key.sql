CREATE OR REPLACE FUNCTION f_get_dh_cnvy_asct_char_train_by_asct_key(p_asct_key bytea)
returns table(asct_key bytea,
Car_Residue_Flag text,
Dangerous_Load_Flag text,
Dimensional_Flag text,
End_of_Car_Cushion_Flag text,
Heavy_Axle_Flag text,
Pickup_Flag text,
Set_Out_Flag text,
Set_Out_Station_Sequence_Number text,
Set_Out_Station_Sequence_Timestamp text,
Set_Out_Track text,
Special_Dangerous_Flag text,
Train_Sequence_Number text,
Setout_Track_Sequence_Number text,
Platform_Code text,
Platform_Position_Code text)
AS $$
begin
return query
select main.asct_key,
max(case when ref_type.type_cd = 'Car Residue Flag' then c.char_val else null end) as Car_Residue_Flag,
max(case when ref_type.type_cd = 'Dangerous Load Flag' then c.char_val else null end) as Dangerous_Load_Flag,
max(case when ref_type.type_cd = 'Dimensional Flag' then c.char_val else null end) as Dimensional_Flag,
max(case when ref_type.type_cd = 'End of Car Cushion Flag' then c.char_val else null end) as End_of_Car_Cushion_Flag,
max(case when ref_type.type_cd = 'Heavy Axle Flag' then c.char_val else null end) as Heavy_Axle_Flag,
max(case when ref_type.type_cd = 'Pickup Flag' then c.char_val else null end) as Pickup_Flag,
max(case when ref_type.type_cd = 'Set Out Flag' then c.char_val else null end) as Set_Out_Flag,
max(case when ref_type.type_cd = 'Set Out Station Sequence Number' then c.char_val else null end) as Set_Out_Station_Sequence_Number,
max(case when ref_type.type_cd = 'Set Out Station Sequence Timestamp' then c.char_val else null end) as Set_Out_Station_Sequence_Timestamp,
max(case when ref_type.type_cd = 'Set Out Track' then c.char_val else null end) as Set_Out_Track,
max(case when ref_type.type_cd = 'Special Dangerous Flag' then c.char_val else null end) as Special_Dangerous_Flag,
max(case when ref_type.type_cd = 'Train Sequence Number' then c.char_val else null end) as Train_Sequence_Number,
max(case when ref_type.type_cd = 'Setout Track Sequence Number' then c.char_val else null end) as Setout_Track_Sequence_Number,
max(case when ref_type.type_cd = 'Platform Code' then c.char_val else null end) as Platform_Code,
max(case when ref_type.type_cd = 'Platform Position Code' then c.char_val else null end) as Platform_Position_Code
from daas_tm_prepared.dh_cnvy_asct main
left  join daas_tm_prepared.dh_cnvy_asct_char c
on    main.asct_key = c.asct_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key and main.act_stus_ind = 1
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;
