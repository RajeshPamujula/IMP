DROP FUNCTION if exists f_run_dh_get_train_station_detail_by_trainid(text) cascade;

CREATE OR REPLACE FUNCTION f_run_dh_get_train_station_detail_by_trainid(trainid text)
RETURNS TABLE
(
"trainIdentification" text,
"stationSequenceNumber" text,
"stationScac" character varying(4),
"stationFsac" character varying(6),
"stationSequenceTimestamp" text,
"estimatedArrivalUtc" text,
"estimatedArrivalTimezoneLabel"  character varying(10),
"estimatedArrivalUtcOffsetValueHours"  numeric(5,3),
"estimatedDepartureUtc" text,
"estimatedDepartureTimezoneLabel" character varying(10),
"estimatedDepartureUtcOffsetValueHours"  numeric(5,3),
"topcEstimatedArrivalUtc" text,
"topcEstimatedArrivalTimezoneLabel" character varying(10),
"topcEstimatedArrivalUtcOffsetValueHours"  numeric(5,3),
"topcEstimatedDepartureUtc" text,
"topcEstimatedDepartureTimezoneLabel" character varying(10),
"topcEstimatedDepartureUtcOffsetValueHours"  numeric(5,3)

)
AS $$
begin
return query
select cnvy_char_sel.char_val as "trainIdentification",-- trn_id
la_char.char_val as "stationSequenceNumber",
rail_stat.scac as "stationScac",
rail_stat.fsac as "stationFsac",
max(la_char_2.char_val) as "stationSequenceTimestamp",

MAX(CASE when char_type.type_cd = 'Estimated Arrival UTC' THEN pac.char_val else '' End) as "estimatedArrivalUtc",
CAST (MAX(CASE when char_type.type_cd = 'Estimated Arrival Tz Dst Cd' THEN tz_dep.tz_lbl else '' End) as VARCHAR(10)) as "estimatedArrivalTimezoneLabel",
MAX(CASE when char_type.type_cd = 'Estimated Arrival Tz Dst Cd' THEN tz_dep.utc_ofst_val_hr else cast( null as numeric(5,3) ) End) as "estimatedArrivalUtcOffsetValueHours",

MAX(CASE when char_type.type_cd = 'Estimated Departure UTC' THEN pac.char_val else '' End) as "estimatedDepartureUtc",
CAST (MAX(CASE when char_type.type_cd = 'Estimated Departure Tz Dst Cd' THEN tz_dep.tz_lbl else cast( '' as VARCHAR(10)) End) as VARCHAR(10)) as "estimatedDepartureTimezoneLabel",
MAX(CASE when char_type.type_cd = 'Estimated Departure Tz Dst Cd' THEN tz_dep.utc_ofst_val_hr else cast( null as numeric(5,3) ) End) as "estimatedDepartureUtcOffsetValueHours",

MAX(CASE when char_type.type_cd = 'TOPC Estimated Arrival UTC' THEN pac.char_val else '' End) as "topcEstimatedArrivalUtc",
CAST (MAX(CASE when char_type.type_cd = 'TOPC Estimated Arrival Tz Dst Cd' THEN tz_dep.tz_lbl else cast( '' as VARCHAR(10)) End) as VARCHAR(10)) as "topcEstimatedArrivalTimezoneLabel",
MAX(CASE when char_type.type_cd = 'TOPC Estimated Arrival Tz Dst Cd' THEN tz_dep.utc_ofst_val_hr else cast( null as numeric(5,3) ) End) as "topcEstimatedArrivalUtcOffsetValueHours",

MAX(CASE when char_type.type_cd = 'TOPC Estimated Departure UTC' THEN pac.char_val else '' End) as "topcEstimatedDepartureUtc",
CAST (MAX(CASE when char_type.type_cd = 'TOPC Estimated Departure Tz Dst Cd' THEN tz_dep.tz_lbl else cast( '' as VARCHAR(10)) End) as VARCHAR(10)) as "topcEstimatedDepartureTimezoneLabel",
MAX(CASE when char_type.type_cd = 'TOPC Estimated Departure Tz Dst Cd' THEN tz_dep.utc_ofst_val_hr else cast( null as numeric(5,3) ) End) as "topcEstimatedDepartureUtcOffsetValueHours"

from daas_tm_prepared.dh_cnvy_char cnvy_char_sel  
inner join daas_tm_prepared.dh_plan_evt pede on cnvy_char_sel.cnvy_key=pede.prim_obj_key and pede.act_stus_ind = 1 and cnvy_char_sel.act_stus_ind = 1 and cnvy_char_sel.char_type_key = '2de848fbf4f4a1b422a4ac69aca68604254d48919aa8015e71079ec8f69382fb'  --Train Unique Id
left join daas_tm_prepared.dh_plan_evt_char pac on (pede.plan_evt_key = pac.plan_evt_key and pac.act_stus_ind = 1)
left join daas_tm_prepared.dh_ref_type char_type on (pac.Char_TYPE_key = char_type.TYPE_KEY)
left join daas_tm_prepared.dh_plan_evt_asct pade on (pede.plan_evt_key = pade.plan_evt_key and pade.act_stus_ind = 1)
left join daas_tm_prepared.dh_loc_asct la on (pade.asct_obj_key = la.asct_key and la.act_stus_ind = 1 and la.asct_obj_type_key = 'b6b8a958245d0b4e4df6f399bdc2917e48cfce12061a47639aac681966fb8916')  --Train Schedule
left join daas_tm_prepared.dh_rail_station rail_stat on (la.loc_key = rail_stat.stn_FSAC_key)
--inner join daas_tm_trusted.f_run_dh_get_train_schedule_origin_detination_by_trainid(cnvy_char_sel.char_val ) trnOD on 1=1
left join daas_tm_prepared.dh_loc_asct_char la_char on (la.asct_key = la_char.asct_key and la_char.act_stus_ind = 1 --and la_char.char_val <= trnOD."destinationStationSequenceNumber" --p_max_station_sequence_nb 
and la_char.char_type_key = '2cb5b0e9672838ba34acfd341a4d3e8f6e8e95c42fd7bfbe215fe72f2b3904e9') --- station sequence number
left join daas_tm_prepared.dh_loc_asct_char la_char_2 on (la.asct_key = la_char_2.asct_key and la_char_2.act_stus_ind = 1 and la_char_2.char_type_key = '7544a574a5161ba81594b74bafa609149a78ce3e901c078cf773ef8b9a2d9417') --- station sequence timestamp
left join daas_tm_prepared.dh_tz_dst_ref tz_dep on (pac.char_val = CAST(tz_dep.tz_dst_cd AS varchar))
where cnvy_char_sel.char_val=trainid
group by 1, 2, 3, 4 ;
end;
$$ LANGUAGE plpgsql;