DROP FUNCTION IF EXISTS daas_tm_trusted."f_vCarCharacteristicsUpdate"(timestamp , text) cascade; -- 

CREATE or replace FUNCTION daas_tm_trusted."f_vCarCharacteristicsUpdate"(p_data_hub_crt_ts timestamp, p_equipmentIdentifier text )
RETURNS TABLE(

 "dataHubCreationTimestamp"  timestamp
, "equipmentIdentifier"   text
, "equipmentInitial"   text
, "equipmentNumber"   text
, "aarCarKind"   text
, "equipmentOwnerCode"   text
, "equipmentOwnerAbbreviation"   text
, "equipmentLesseeAbbreviation"   text
, "outsideLength"   text
, "outsideLengthUnitOfMeasure"   text
, "outsideWidth"   text
, "outsideWidthUnitOfMeasure"   text
, "outsideHeight"   text
, "outsideHeightUnitOfMeasure"   text
, "equipmentTare"   text
, "equipmentTareUnitOfMeasure"   text
, "axleCount"   text
, "articulatedCode"   text
, "totalWeightRail"   text
, "totalWeightRailUnitOfMeasure"   text
, "loadLimit"   text
, "gstCode"    text
, "carKind"   text
, "bearingTypeCode"   text
, "aarPoolId"    text
, "insideHeight"   text
, "insideHeightUnitOfMeasure"   text
, "insideLength"   text
, "insideLengthUnitOfMeasure"   text
, "insideWidth"   text
, "insideWidthUnitOfMeasure"   text
, "truckCenterLength"   text
, "truckCenterLengthUnitOfMeasure"   text
, "emptyReturnCode"   text
, "endServiceDate"     text
, "platformLoadLimit1"   text
, "platformLoadLimit1UnitOfMeasure"    text
, "platformLoadLimit2"   text
, "platformLoadLimit2UnitOfMeasure"    text
, "platformLoadLimit3"    text
, "platformLoadLimit3UnitOfMeasure"    text
, "platformLoadLimit4"   text
, "platformLoadLimit4UnitOfMeasure"   text
, "platformLoadLimit5"   text
, "platformLoadLimit5UnitOfMeasure"   text
, "platformLoadLimit6"   text
, "platformLoadLimit6UnitOfMeasure"   text
, "platformLoadLimit7"   text
, "platformLoadLimit7UnitOfMeasure"   text
, "platformLoadLimit8"   text
, "platformLoadLimit8UnitOfMeasure"   text
, "platformLoadLimit9"   text
, "platformLoadLimit9UnitOfMeasure"   text
, "platformLoadLimit10"   text
, "platformLoadLimit10UnitOfMeasure"   text
, "platformTareWeight1"   text
, "platformTareWeight1UnitOfMeasure"   text
, "platformTareWeight2"   text
, "platformTareWeight2UnitOfMeasure"   text
, "platformTareWeight3"   text
, "platformTareWeight3UnitOfMeasure"    text
, "platformTareWeight4"   text
, "platformTareWeight4UnitOfMeasure"   text
, "platformTareWeight5"   text
, "platformTareWeight5UnitOfMeasure"   text
, "platformTareWeight6"   text
, "platformTareWeight6UnitOfMeasure"   text
, "platformTareWeight7"   text
, "platformTareWeight7UnitOfMeasure"   text
, "platformTareWeight8"   text
, "platformTareWeight8UnitOfMeasure"   text
, "platformTareWeight9"   text
, "platformTareWeight9UnitOfMeasure"   text
, "platformTareWeight10"   text
, "platformTareWeight10UnitOfMeasure"   text

    )
AS $$
BEGIN

-- part 1: change capture and apply the optional filter , limit 1000 records
create temporary table tbl_changes ( id_val text, cnvy_key bytea PRIMARY KEY)  
on commit drop
;
insert into tbl_changes	(id_val, cnvy_key)
with vCarCharacteristicschanges as (
select cnvy.id_val, a.cnvy_key, a.data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_char a
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.cnvy_key=a.cnvy_key
and  (cnvy.cnvy_type_key = 'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' -- Rail Car
or cnvy.cnvy_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' ) -- RailCar
and cnvy.act_stus_ind=1
where a.data_hub_crt_ts > p_data_hub_crt_ts --now()- interval '38 hours'

union all
select cnvy.id_val,  b.cnvy_key, b.data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_cond b
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.cnvy_key=b.cnvy_key
and  (cnvy.cnvy_type_key = 'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' -- Rail Car
or cnvy.cnvy_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' ) -- RailCar
and cnvy.act_stus_ind=1
where b.char_type_key='0f0cfaff4acf325a3407b96a0ef90378f6831929d513dcf6943f68e2dec87a84'  --End of Service Date
and b.data_hub_crt_ts >  p_data_hub_crt_ts  --now()- interval '38 hours'
)
select id_val, cnvy_key
--, max(data_hub_crt_ts) as data_hub_crt_ts
from vCarCharacteristicschanges 
group by id_val, cnvy_key
order by max(data_hub_crt_ts) 
limit 2000
;

-- part 2: parse parameter string to temporay table 
if p_equipmentIdentifier is not null 
then
create temporary table tbl_id ( id_val text, cnvy_key bytea PRIMARY KEY)  on commit drop;
insert into tbl_id(id_val, cnvy_key)
 select distinct cnvy.id_val, cnvy.cnvy_key
 from (select trim(unnest(string_to_array(p_equipmentIdentifier ,','))) as id_val ) as m 
 inner join daas_tm_prepared.dh_cnvy cnvy on m.id_val=cnvy.id_val;
delete from tbl_changes where not exists (Select 1 from tbl_id where tbl_id.cnvy_key=tbl_changes.cnvy_key );
end if ;


-- part 3: return details
RETURN QUERY 
SELECT 
greatest(a.data_hub_crt_ts, cc.data_hub_crt_ts) AS "dataHubCreationTimestamp"
, cnvy.id_val AS "equipmentIdentifier"
, a.Equipment_Initial AS "equipmentInitial"
, a.Equipment_Number AS "equipmentNumber"
, a.AAR_Car_Kind AS "aarCarKind"
, a.Equipment_Owner_Code AS "equipmentOwnerCode"
, a.Equipment_Owner_Abbreviation AS "equipmentOwnerAbbreviation"
, a.Equipment_Lessee_Abbreviation AS "equipmentLesseeAbbreviation"
, a.Outside_Length AS "outsideLength"
, a.Outside_Length_UOM AS "outsideLengthUnitOfMeasure"
, a.Outside_Width AS "outsideWidth"
, a.Outside_Width_UOM AS "outsideWidthUnitOfMeasure"
, a.Outside_Height AS "outsideHeight"
, a.Outside_Height_UOM AS "outsideHeightUnitOfMeasure"
, a.Equipment_Tare AS "equipmentTare"
, a.Equipment_Tare_UOM AS "equipmentTareUnitOfMeasure"
, a.Axle_Count AS "axleCount"
, a.Articulated_Code AS "articulatedCode"
, a.Total_Weight_Rail AS "totalWeightRail"
, a.Total_Weight_Rail_UOM AS "totalWeightRailUnitOfMeasure"
, a.Load_Limit AS "loadLimit"
, a.GST_Code AS "gstCode" 
, a.Car_Kind AS "carKind"
, a.Bearing_Type_Code AS "bearingTypeCode"
, a.AAR_Pool_Id AS "aarPoolId" 
, a.Inside_Height AS "insideHeight"
, a.Inside_Height_UOM AS "insideHeightUnitOfMeasure"
, a.Inside_Length AS "insideLength"
, a.Inside_Length_UOM AS "insideLengthUnitOfMeasure"
, a.Inside_Width AS "insideWidth"
, a.Inside_Width_UOM AS "insideWidthUnitOfMeasure"
, a.Truck_Center_Length AS "truckCenterLength"
, a.Truck_Center_Length_UOM AS "truckCenterLengthUnitOfMeasure"
, a.ERT_Code AS "emptyReturnCode"
, cc.char_val as "endServiceDate"  
, a.Platform_Load_Limit_1 AS "platformLoadLimit1"
, a.Platform_Load_Limit_1_UOM AS "platformLoadLimit1UnitOfMeasure" 
, a.Platform_Load_Limit_2 AS "platformLoadLimit2"
, a.Platform_Load_Limit_2_UOM AS "platformLoadLimit2UnitOfMeasure" 
, a.Platform_Load_Limit_3 AS "platformLoadLimit3" 
, a.Platform_Load_Limit_3_UOM AS "platformLoadLimit3UnitOfMeasure" 
, a.Platform_Load_Limit_4 AS "platformLoadLimit4"
, a.Platform_Load_Limit_4_UOM AS "platformLoadLimit4UnitOfMeasure"
, a.Platform_Load_Limit_5 AS "platformLoadLimit5"
, a.Platform_Load_Limit_5_UOM AS "platformLoadLimit5UnitOfMeasure"
, a.Platform_Load_Limit_6 AS "platformLoadLimit6"
, a.Platform_Load_Limit_6_UOM AS "platformLoadLimit6UnitOfMeasure"
, a.Platform_Load_Limit_7 AS "platformLoadLimit7"
, a.Platform_Load_Limit_7_UOM AS "platformLoadLimit7UnitOfMeasure"
, a.Platform_Load_Limit_8 AS "platformLoadLimit8"
, a.Platform_Load_Limit_8_UOM AS "platformLoadLimit8UnitOfMeasure"
, a.Platform_Load_Limit_9 AS "platformLoadLimit9"
, a.Platform_Load_Limit_9_UOM AS "platformLoadLimit9UnitOfMeasure"
, a.Platform_Load_Limit_10 AS "platformLoadLimit10"
, a.Platform_Load_Limit_10_UOM AS "platformLoadLimit10UnitOfMeasure"
, a.Platform_Tare_Weight_1 AS "platformTareWeight1"
, a.Platform_Tare_Weight_1_UOM AS "platformTareWeight1UnitOfMeasure"
, a.Platform_Tare_Weight_2 AS "platformTareWeight2"
, a.Platform_Tare_Weight_2_UOM AS "platformTareWeight2UnitOfMeasure"
, a.Platform_Tare_Weight_3 AS "platformTareWeight3"
, a.Platform_Tare_Weight_3_UOM AS "platformTareWeight3UnitOfMeasure" 
, a.Platform_Tare_Weight_4 AS "platformTareWeight4"
, a.Platform_Tare_Weight_4_UOM AS "platformTareWeight4UnitOfMeasure"
, a.Platform_Tare_Weight_5 AS "platformTareWeight5"
, a.Platform_Tare_Weight_5_UOM AS "platformTareWeight5UnitOfMeasure"
, a.Platform_Tare_Weight_6 AS "platformTareWeight6"
, a.Platform_Tare_Weight_6_UOM AS "platformTareWeight6UnitOfMeasure"
, a.Platform_Tare_Weight_7 AS "platformTareWeight7"
, a.Platform_Tare_Weight_7_UOM AS "platformTareWeight7UnitOfMeasure"
, a.Platform_Tare_Weight_8 AS "platformTareWeight8"
, a.Platform_Tare_Weight_8_UOM AS "platformTareWeight8UnitOfMeasure"
, a.Platform_Tare_Weight_9 AS "platformTareWeight9"
, a.Platform_Tare_Weight_9_UOM AS "platformTareWeight9UnitOfMeasure"
, a.Platform_Tare_Weight_10 AS "platformTareWeight10"
, a.Platform_Tare_Weight_10_UOM AS "platformTareWeight10UnitOfMeasure"
FROM tbl_changes cnvy
--inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.cnvy_key=ch.cnvy_key
left JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key(cnvy.cnvy_key) a ON 1 = 1
LEFT JOIN daas_tm_prepared.dh_cnvy_cond cc on cnvy.cnvy_key=cc.cnvy_key and cc.act_stus_ind=1
and cc.char_type_key='0f0cfaff4acf325a3407b96a0ef90378f6831929d513dcf6943f68e2dec87a84'  --End of Service Date
--where  (cnvy.cnvy_type_key = 'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' -- Rail Car
--or cnvy.cnvy_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' ) -- RailCar
--and cnvy.act_stus_ind=1
;

END;$$ SECURITY DEFINER
LANGUAGE plpgsql;

/*
GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vCarCharacteristicsUpdate"( timestamp , text) TO public;


select * from daas_tm_trusted."f_vCarCharacteristicsUpdate"(now()::timestamp - interval '55 days', NULL);

select * from daas_tm_trusted."f_vCarCharacteristicsUpdate"(now()::timestamp - interval '55 days', 'TILX291077,  DTTX646092, DTTX620589');


select * from daas_tm_trusted."f_vCarCharacteristicsUpdate"(now()::timestamp - interval '18890 minutes', 'TILX291077,  DTTX646092, DTTX620589');

*/

