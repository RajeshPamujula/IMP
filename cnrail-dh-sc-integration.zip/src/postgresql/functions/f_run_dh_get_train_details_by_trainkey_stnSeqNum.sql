--function to get train details 
DROP FUNCTION if exists daas_tm_trusted.f_run_dh_get_train_details_by_trainkey_stnSeqNum(bytea,text) cascade;
--function to get train details 

-- set tjsFlag='Y'
-- remove too many sorting 
CREATE OR REPLACE FUNCTION daas_tm_trusted.f_run_dh_get_train_details_by_trainkey_stnSeqNum(p_cnvy_key bytea, p_max_station_sequence_nb text)
RETURNS TABLE 
(
stn_333 character varying(9),
stn_st character(2),
fsac character varying(6),
scac character varying(4),
"stationSequenceNumber" text,
"stationSequenceTimestamp" text,
"crewChangeIndicator" text,
"refuelPoint" text,
"requiredInspection" text,
"rewheel" text,
"tjsFlag" text,
"estimatedArrivalUtc" text, 
"estimatedArrivalTimezoneCode" text, 
"estimatedDepartureUtc" text,  
"estimatedDepartureTimezoneCode" text, 
"topcEstimatedArrivalUtc" text, 
"topcEstimatedDepartureUtc" text,
"plannedDepartureDayOffset" text,
"plannedDepartureTimeLocal" text,
"plannedArrivalDayOffset" text,
"plannedArrivalTimeLocal" text)
AS $$
begin
return query
with train as (
select PEDE.prim_obj_key ,
la.asct_key,
la.loc_key,
la_char.char_val as  "stationSequenceNumber",
la_char_7.char_val as "tjsFlag",
MAX(CASE when char_type.type_cd = 'Estimated Arrival UTC' THEN pac.char_val else '' End) as "estimatedArrivalUtc",
MAX(CASE when char_type.type_cd = 'Estimated Arrival Tz Dst Cd' THEN pac.char_val else '' End) as "estimatedArrivalTimezoneCode",
MAX(CASE when char_type.type_cd = 'Estimated Departure UTC' THEN pac.char_val else '' End) as "estimatedDepartureUtc",
MAX(CASE when char_type.type_cd = 'Estimated Departure Tz Dst Cd' THEN pac.char_val else '' End) as "estimatedDepartureTimezoneCode",
MAX(CASE when char_type.type_cd = 'TOPC Estimated Arrival UTC' THEN pac.char_val else '' End) as "topcEstimatedArrivalUtc",
MAX(CASE when char_type.type_cd = 'TOPC Estimated Departure UTC' THEN pac.char_val else '' End) as "topcEstimatedDepartureUtc",
MAX(CASE when char_type.type_cd = 'Planned Departure Day Offset' THEN pac.char_val else '' End) as "plannedDepartureDayOffset",
MAX(CASE when char_type.type_cd = 'Planned Departure Time Local' THEN pac.char_val else '' End) as "plannedDepartureTimeLocal",
MAX(CASE when char_type.type_cd = 'Planned Arrival Day Offset' THEN pac.char_val else '' End) as "plannedArrivalDayOffset",
MAX(CASE when char_type.type_cd = 'Planned Arrival Time Local' THEN pac.char_val else '' End) as "plannedArrivalTimeLocal"
from daas_tm_prepared.DH_PLAN_EVT pede
inner join daas_tm_prepared.dh_plan_evt_char PAC on (pede.plan_evt_key = PAC.plan_evt_key and pac.act_stus_ind = 1)
inner join daas_tm_prepared.DH_REF_TYPE char_TYPE on (PAC.Char_TYPE_key = char_type.TYPE_KEY)
inner join daas_tm_prepared.dh_plan_evt_asct PADE on (pede.plan_evt_key = PADE.plan_evt_key and pade.act_stus_ind = 1)
inner join daas_tm_prepared.dh_loc_asct LA on (PADE.asct_obj_key = la.asct_key and la.act_stus_ind = 1 and la.asct_obj_type_key = 'b6b8a958245d0b4e4df6f399bdc2917e48cfce12061a47639aac681966fb8916')
--inner join  daas_tm_prepared.dh_rail_station rail_stat on (la.loc_key = rail_stat.stn_FSAC_key)
inner join  daas_tm_prepared.dh_loc_asct_char la_char on (la.asct_key = la_char.asct_key and la_char.act_stus_ind = 1 
and la_char.char_val <= p_max_station_sequence_nb
and la_char.char_type_key = '2cb5b0e9672838ba34acfd341a4d3e8f6e8e95c42fd7bfbe215fe72f2b3904e9') --- station sequence number
inner join  daas_tm_prepared.dh_loc_asct_char la_char_7 on (la.asct_key = la_char_7.asct_key and la_char_7.act_stus_ind = 1 
and la_char_7.char_type_key  = '2bfdbbf5fb059fe956839408aaa4f967504de4c6e5cd9f135b987a02e89de143')   --- TJS flag
and la_char_7.char_val='Y'
where pede.prim_obj_key  = p_cnvy_key --'00ffb6da9cc9f293ecea7314c679c6eab04aab64c67a9b3c5bc4015b2975a3ef' --p_cnvy_key
and pede.act_stus_ind  = 1
group by 1,2,3,4,5
)
select 
rail_stat.stn_333,
rail_stat.stn_st,
rail_stat.fsac,
rail_stat.scac,
la."stationSequenceNumber",
la_char_2.char_val as "stationSequenceTimestamp",
la_char_3.char_val as "crewChangeIndicator",
la_char_4.char_val as "refuelPoint",
la_char_5.char_val as "requiredInspection",
la_char_6.char_val as "rewheel",
la."tjsFlag",
--- add the planned values when they become available
la."estimatedArrivalUtc",
la."estimatedArrivalTimezoneCode",
la."estimatedDepartureUtc",
la."estimatedDepartureTimezoneCode",
la."topcEstimatedArrivalUtc",
la."topcEstimatedDepartureUtc",
la."plannedDepartureDayOffset",
la."plannedDepartureTimeLocal",
la."plannedArrivalDayOffset",
la."plannedArrivalTimeLocal" 
from train la
inner join  daas_tm_prepared.dh_rail_station rail_stat on (la.loc_key = rail_stat.stn_FSAC_key)
inner join daas_tm_prepared.dh_loc_asct_char la_char_2 on (la.asct_key = la_char_2.asct_key and la_char_2.act_stus_ind = 1 
and la_char_2.char_type_key  = '7544a574a5161ba81594b74bafa609149a78ce3e901c078cf773ef8b9a2d9417') --- station sequence timestamp
inner join daas_tm_prepared.dh_loc_asct_char la_char_3 on (la.asct_key = la_char_3.asct_key and la_char_3.act_stus_ind = 1 
and la_char_3.char_type_key  = '849391e89f6f5867a4946029fb55a171ca29a26c1a19629669a63c25372a48c0') --- crew change indicator
inner join  daas_tm_prepared.dh_loc_asct_char la_char_4 on (la.asct_key = la_char_4.asct_key and la_char_4.act_stus_ind = 1 
and la_char_4.char_type_key  = 'eb96f15d7f78f46a2498dcabc3809475e7b7849d08d21c5ee0467ad1268e1e6c') --- refuel point
inner join  daas_tm_prepared.dh_loc_asct_char la_char_5 on (la.asct_key = la_char_5.asct_key and la_char_5.act_stus_ind = 1 
and la_char_5.char_type_key  = 'b0e26e647dcd8c3f238ad16cbb4137b927c88cea96ece61b7fa8db888a8a26a7') --- required inspection 
inner join  daas_tm_prepared.dh_loc_asct_char la_char_6 on (la.asct_key = la_char_6.asct_key and la_char_6.act_stus_ind = 1 
and la_char_6.char_type_key  = '27dc497903ddfe4c113064b638cbf1e726cdabf505505452d70507424dd2f8b4') --- rewheel
;
end;
$$ LANGUAGE plpgsql;