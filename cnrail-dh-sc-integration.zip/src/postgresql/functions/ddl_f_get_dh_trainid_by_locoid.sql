DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_trainid_by_locoid(text) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_trainid_by_locoid(locoid text)
RETURNS TABLE 
(
"trainIdentification"  text,
"locoIdentification"  text,
"eventCode" text,
"eventStatusCode" text,
"timestampUpdate" timestamp,
"eventDateTime" timestamp ,
"eventDate" text,
"eventTime" text,
"eventLocationStation333" varchar(9),
"eventLocationStationState" bpchar(2),
"eventTimezoneLabel"  varchar(10),
"eventOffsetHours"    numeric(5,3)
)
AS $$
begin
return query

with reltrainloco as 
(
SELECT --- to get loco setout utc from planned train
	cnvy.id_val AS "trainIdentification",
	aset.id_val as "locoIdentification",
	substr(train_char_5.char_val,1,2) as "eventCode",
	substr(train_char_5.char_val,3,2) as "eventStatusCode",
	trsp.data_hub_crt_ts as "timestampUpdate",
	train_char_8.char_val as "eventDateTime",
	train_char_6.char_val as "eventDate",
	train_char_7.char_val as "eventTime",
	stn.stn_333 as "eventLocationStation333",
	stn.stn_st as "eventLocationStationState",
	tz_ref.tz_lbl AS "eventTimezoneLabel",
    tz_ref.utc_ofst_val_hr AS "eventOffsetHours",
	ROW_NUMBER() OVER (PARTITION BY aset.id_val ORDER BY to_timestamp( train_char_8.char_val , 'YYYY-MM-DD HH24:MI:SS') DESC, trsp.sor_evt_ts DESC) rk --train_char_8.char_val 
FROM daas_tm_prepared.dh_trsp_evt as trsp
INNER JOIN daas_tm_prepared.dh_cnvy_asct as b 
	ON b.prim_obj_key = trsp.trsp_evt_key
	AND trsp_evt_type_key = '62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a' --- Train Event Transportation Event
	and b.cnvy_type_key='c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698' -- train 
	AND b.act_stus_ind = 1 
	AND trsp.act_stus_ind = 1
INNER JOIN daas_tm_prepared.dh_cnvy as cnvy 	on cnvy.cnvy_key = b.cnvy_key 	--AND cnvy.act_stus_ind = 1	
INNER JOIN daas_tm_prepared.dh_aset_asct as aa ON trsp.prim_obj_key = aa.prim_obj_key AND aa.act_stus_ind = 1

INNER JOIN daas_tm_prepared.dh_aset as aset ON aset.aset_key = aa.aset_key AND aset.act_stus_ind = 1 and aset.aset_type_key='08e8d3db4a88f4048af2d4afa8e241965560177eeaa88d8f5eab57e9641c2249' -- aset type:Locomotive 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_5 on (trsp.trsp_evt_key = train_char_5.trsp_evt_key and train_char_5.act_stus_ind = 1 and train_char_5.char_type_key = '07814f276206869eb5b8e6777b5f06a1597ee49b2957f04b609d3c99093d11d7' )  -- event code 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_6 on (trsp.trsp_evt_key = train_char_6.trsp_evt_key and train_char_6.act_stus_ind = 1 and train_char_6.char_type_key = 'ab003fb8d838bb009a23e10b96fdea5b5dbaa691dd6a658146851df3f7801130' )  -- event date  
inner join daas_tm_prepared.dh_trsp_evt_char train_char_7 on (trsp.trsp_evt_key = train_char_7.trsp_evt_key and train_char_7.act_stus_ind = 1 and train_char_7.char_type_key = 'f5b3a3d43967a9d40508621b349f54966f1babc8d8c6233efbcff57e41aed3fe' )  -- event time 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_8 on (trsp.trsp_evt_key = train_char_8.trsp_evt_key and train_char_8.act_stus_ind = 1 and train_char_8.char_type_key = '47315209be802f75a9e4e3f07baf68f4c82f572b32d5dcea9eda9fbc91a92f32' )  -- Event Date Time UTC
inner join daas_tm_prepared.dh_trsp_evt_char train_char_4 on (trsp.trsp_evt_key = train_char_4.trsp_evt_key and train_char_8.act_stus_ind = 1 and train_char_4.char_type_key = '2b77baf8b844500829fffd11357d1e243ee020adec77ea2cdc4b2934d8577d2a' )  -- Event Station Carrier Abbreviation
inner join daas_tm_prepared.dh_trsp_evt_char train_char_3 on (trsp.trsp_evt_key = train_char_3.trsp_evt_key and train_char_8.act_stus_ind = 1 and train_char_3.char_type_key = '61d9f08af8e5f9cc63abd8d3d1b42f2e3d4933e41449815f3574673e10cfe1fa' )  -- Event Station FSAC 
inner join daas_tm_prepared.dh_rail_station stn on stn.fsac=train_char_3.char_val and stn.scac=train_char_4.char_val
LEFT join daas_tm_prepared.dh_tz_dst_ref as tz_ref on (trsp.sor_evt_ts_tz_dst_cd = tz_ref.tz_dst_cd)
--where aset.id_val like 'CN2132'   
where aset.id_val=locoid  
)
select 
reltrainloco."trainIdentification",
reltrainloco."locoIdentification", 
reltrainloco."eventCode",
reltrainloco."eventStatusCode",
reltrainloco."timestampUpdate",
TO_TIMESTAMP(reltrainloco."eventDateTime", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone as "eventDateTime",
reltrainloco."eventDate",
reltrainloco."eventTime",
reltrainloco."eventLocationStation333",
reltrainloco."eventLocationStationState",
reltrainloco."eventTimezoneLabel",
reltrainloco."eventOffsetHours"
from reltrainloco
where rk=1;
end;
$$
LANGUAGE 'plpgsql';



