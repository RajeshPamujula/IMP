DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_stcc_description_by_stcc(text);

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_stcc_description_by_stcc(p_stcc text)
RETURNS TABLE
(
  "standardTransportationCommodityCode" text,
  "commodityDescriptionAbbreviation" text,
  "commodity15Description" text
)
AS $$
BEGIN
RETURN QUERY
select a.id_val as "standardTransportationCommodityCode"
,max(case when c.type_cd= 'Commodity Description Abbreviation' then  b.char_val  else null end ) as "commodityDescriptionAbbreviation"
,max(case when c.type_cd= 'Commodity 15 Description' then  b.char_val  else null end ) as "commodity15Description"
from daas_tm_prepared.dh_cmdy a
inner join daas_tm_prepared.dh_cmdy_char b on a.cmdy_key = b.cmdy_key and a.act_stus_ind =1 and  b.act_stus_ind=1
inner join daas_tm_prepared.dh_ref_type c on b.char_type_key = c.type_key
where a.id_val=p_stcc  --'2211230'
group by 1;
END;
$$ LANGUAGE plpgsql;