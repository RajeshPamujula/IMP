DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_trsp_evt_char_gate_by_trsp_evt_key(p_trsp_evt_key bytea) cascade;
-- dependency: v_chassis_event_details

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_trsp_evt_char_gate_by_trsp_evt_key(p_trsp_evt_key bytea)
returns table(trsp_evt_key bytea,
Carter_Customer_633 text,
Carter_Customer_Name text,
Carter_Customer_Number text,
Carter_SCAC text,
CN_Tractor_Indicator text,
Event_Code text,
Event_Status text,
Tractor_License text)
AS $$
begin
return query
select main.trsp_evt_key,
max(case when ref_type.type_cd = 'Carter Customer 633' then c.char_val else null end) as Carter_Customer_633,
max(case when ref_type.type_cd = 'Carter Customer Name' then c.char_val else null end) as Carter_Customer_Name,
max(case when ref_type.type_cd = 'Carter Customer Number' then c.char_val else null end) as Carter_Customer_Number,
max(case when ref_type.type_cd = 'Carter SCAC' then c.char_val else null end) as Carter_SCAC,
max(case when ref_type.type_cd = 'CN Tractor Indicator' then c.char_val else null end) as CN_Tractor_Indicator,
max(case when ref_type.type_cd = 'Event Code' then c.char_val else null end) as Event_Code,
max(case when ref_type.type_cd = 'Event Status'  or ref_type.type_cd =  'Event Status Code'then c.char_val else null end) as Event_Status,
max(case when ref_type.type_cd = 'Tractor License' then c.char_val else null end) as Tractor_License
from daas_tm_prepared.dh_trsp_evt main
left  join daas_tm_prepared.dh_trsp_evt_char c
on    main.trsp_evt_key = c.trsp_evt_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.trsp_evt_key = p_trsp_evt_key and main.act_stus_ind = 1
group by main.trsp_evt_key;
end;
$$ LANGUAGE plpgsql;
