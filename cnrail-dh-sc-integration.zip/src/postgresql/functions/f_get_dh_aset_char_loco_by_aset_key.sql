CREATE OR REPLACE FUNCTION f_get_dh_aset_char_loco_by_aset_key(p_aset_key bytea)
returns table(aset_key bytea,
Brake_System_Code text,
Dynamic_Brake_Range_Code text,
ETD_Id text,
Locomotive_Id text,
Locomotive_Length text,
Locomotive_Length_UOM text,
Locomotive_Operating_Code text,
Locomotive_Weight text,
Locomotive_Weight_UOM text)
AS $$
begin
return query
select main.aset_key,
max(case when ref_type.type_cd = 'Brake System Code' then c.char_val else null end) as Brake_System_Code,
max(case when ref_type.type_cd = 'Dynamic Brake Range Code' then c.char_val else null end) as Dynamic_Brake_Range_Code,
max(case when ref_type.type_cd = 'ETD Id' then c.char_val else null end) as ETD_Id,
max(case when ref_type.type_cd = 'Locomotive Id' then c.char_val else null end) as Locomotive_Id,
max(case when ref_type.type_cd = 'Locomotive Length' then c.char_val else null end) as Locomotive_Length,
max(case when ref_type.type_cd = 'Locomotive Length UOM' then c.char_val else null end) as Locomotive_Length_UOM,
max(case when ref_type.type_cd = 'Locomotive Operating Code' then c.char_val else null end) as Locomotive_Operating_Code,
max(case when ref_type.type_cd = 'Locomotive Weight' then c.char_val else null end) as Locomotive_Weight,
max(case when ref_type.type_cd = 'Locomotive Weight UOM' then c.char_val else null end) as Locomotive_Weight_UOM
from daas_tm_prepared.dh_aset main
left  join daas_tm_prepared.dh_aset_char c
on    main.aset_key = c.aset_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.aset_key = p_aset_key and main.act_stus_ind = 1
group by main.aset_key;
end;
$$ LANGUAGE plpgsql;
