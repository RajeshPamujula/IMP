DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_additional_stcc_by_ship_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_additional_stcc_by_ship_key(p_ship_key bytea)
RETURNS TABLE
(
  ship_key bytea,
  "additionalStcc" text[]

)
AS $$
BEGIN
RETURN QUERY
select m.ship_key, array_agg(stcc) as "additionalStcc"
from (
select  a.ship_key, f0.char_val
,NULLIF(f0.char_val,'')||'|'||NULLIF(f1.char_val,'') ||'|'||NULLIF(f2.char_val,'') as stcc
from daas_tm_prepared.dh_ship_asct a --lading 
inner join daas_tm_prepared.dh_cmdy b on a.asct_obj_key=b.cmdy_key and a.act_stus_ind = 1
and a.asct_obj_type_key='4423ec467eaa71c2a18230248464198cc3aee507d64ab3f706ec6928513fabc4' --Shipment Commodity
and a.asct_type_key= 'e5f3fd59caf7dc0eb131d6b81aed6a07bd1f6b04488e979cb19be3fdf9daff44' --Inter-BCD Shipment-Commodity ! 
--this is for bill of lading or for everything?
left join daas_tm_prepared.dh_cmdy_char f0 on b.cmdy_key = f0.cmdy_key and f0.act_stus_ind = 1
and f0.char_type_key = '384f5b7339b33adefe3edeee78962574f0d747f5c37222508e5ec2647294022a' --STCC
left join daas_tm_prepared.dh_cmdy_char f1 on b.cmdy_key = f1.cmdy_key and f1.act_stus_ind = 1
and f1.char_type_key = 'ba24910ac0e8ca3c483c08f90d28d666eb3c046b17f5f937563e87c105709c41' --Commodity Description Abbreviation
left join daas_tm_prepared.dh_cmdy_char f2 on b.cmdy_key = f2.cmdy_key and f2.act_stus_ind = 1
and f2.char_type_key = '1361eedf3353ffcb60a1e037cfaa1a16a78e1f87ad4303635cdae8f20645f32e' --Commodity 15 Description
where   b.act_stus_ind=1
and a.ship_key=
p_ship_key --
--'85aa2156d8b7945a471ca383472f12911e7f3389cd9df0a491404b2a0b2d7dd2'
) as m 
group by m.ship_key;
END;
$$ LANGUAGE plpgsql;