DROP FUNCTION IF EXISTS daas_tm_trusted."f_vShipmentUpdate"(timestamp , text) cascade; -- 


CREATE or replace FUNCTION daas_tm_trusted."f_vShipmentUpdate"(p_data_hub_crt_ts timestamp, p_waybillNumber text )
RETURNS TABLE(

"dataHubCreationTimestamp"  timestamp,
"eventTimestamp"  timestamp,
"waybillNumber"   text,
"waybillIdentification"   text,

"shipperCity333"   text,
"shipperProvinceState"   text,
"shipperStationNumber"   text,
"shipperCustomer633"   text,
"shipperCarrierAbbreviation"   text,
"shipperCityName"   text,
"shipperZip"   text,
"shipperCustomerAddress"   text,
"shipperCustomerName"   text,
"shipperCustomerNumber"   text,


"consigneeCity333"   text,
"consigneeProvinceState"   text,
"consigneeStationNumber"   text,
"consigneeCustomer633"   text,
"consigneeCarrierAbbreviation"   text,
"consigneeCityName"   text,
"consigneeZip"   text,
"consigneeCustomerAddress"   text,
"consigneeCustomerName"   text,
"consigneeCustomerNumber"   text,

"payingCustomerCity333"   text,
"payingCustomerProvinceState"   text,
"payingCustomerStationNumber"   text,
"payingCustomerCustomer633"   text,
"payingCustomerCarrierAbbreviation"   text,
"payingCustomerCityName"   text,
"payingCustomerZip"   text,
"payingCustomerCustomerAddress"   text,
"payingCustomerCustomerName"   text,
"payingCustomerCustomerNumber"   text,

"careOfCity333"   text,
"careOfProvinceState"   text,
"careOfStationNumber"   text,
"careOfCustomer633"   text,
"careOfCarrierAbbreviation"   text,
"careOfCityName"   text,
"careOfZip"   text,
"careOfCustomerAddress"   text,
"careOfCustomerName"   text,
"careOfCustomerNumber"   text,


"finalDestinationCity333"   text,
"finalDestinationProvinceState"   text,
"finalDestinationStationNumber"   text,
"finalDestinationCustomer633"   text,
"finalDestinationCarrierAbbreviation"   text,
"finalDestinationCityName"   text,
"finalDestinationZip"   text,
"finalDestinationCustomerAddress"   text,
"finalDestinationCustomerName"   text,
"finalDestinationCustomerNumber"   text,

"priorOriginCity333"   text,
"priorOriginProvinceState"   text,
"priorOriginStationNumber"   text,
"priorOriginCustomer633"   text,
"priorOriginCarrierAbbreviation"   text,
"priorOriginCityName"   text,
"priorOriginZip"   text,
"priorOriginCustomerAddress"   text,
"priorOriginCustomerName"   text,
"priorOriginCustomerNumber"   text,



"shipFromCity333"   text,
"shipFromProvinceState"   text,
"shipFromStationNumber"   text,
"shipFromCustomer633"   text,
"shipFromCarrierAbbreviation"   text,
"shipFromCityName"   text,
"shipFromZip"   text,
"shipFromCustomerAddress"   text,
"shipFromCustomerName"   text,
"shipFromCustomerNumber"   text,


"billOfLadingNumber"    text,
"carKind"   text,
"customerSuppliedNetWeight"   text,
"customerSuppliedWeightCode"   text,
"customerSuppliedWeightUom"   text,
"destinationRamp333"   text,
"destinationRamp333ProvinceStateCode"   text,
"equipmentIdentification"   text,
"loadEmptyStatusCode"   text,
"operatingCity"   text,
"operatingCityProvinceStateCode"   text,
"operatingDestinationFsac"   text,
"operatingDestinationScac"   text,
"railOrigin333"   text,
"originRamp333"   text,
"originRamp333ProvinceStateCode"   text,
"railOrigin333ProvinceStateCode"   text,
"standardTransportationCommodityCode"   text,
"waybillTypeCode"   text,


"specialConditionCode1"   text,
"specialConditionCode2"   text,
"specialConditionCode3"   text,
"specialConditionCode4"   text,
"specialConditionCode5"   text,
"specialConditionCode6"   text,

"waybillStatusCode"   text,
type_cd   varchar(50), -- double check
"railDestination333"   text,
"railDestination333ProvinceStateCode"   text,
"grossScaleWeight"   text,
"grossScaleWeightUom"   text,
"netScaleWeight"   text,
"netScaleWeightUom"   text,
"regulatoryAuthority"   text,

"waybillDate"   text,
"waybillEdiCode"   text,
"firstCnOriginCarrierAbbreviation"   text,
"firstCnOriginStationNumber"   text,
"lastCnOriginCarrierAbbreviation"   text,
"lastCnOriginStationNumber"   text,
"lastCnOriginStation333"   varchar(9),
"lastCnOriginStation333ProvinceStateCode" bpchar(2),

"operatingZoneTrackSpot"   text,
"articleQuantity"   text,
"packageType"   text,

"packageTypeDescriptionInEnglish"   text,
"packageTypeDescriptionInFrench"   text,

"referenceNumber"   text,
"referenceNumberCode"   text,

"sailDate"   text,
"sailTime"   text,
"vesselName"   text,

"additionalStcc"    text,
ship_key  bytea




    )
AS $$
BEGIN

-- part 1: change capture and apply the optional filter , limit 1000 records
create temporary table tbl_changes ( ship_key bytea PRIMARY KEY)  on commit drop;

insert into tbl_changes	(ship_key)
with "vShipmentChange" as (
select ship.ship_key, ship.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship ship
where ship.data_hub_crt_ts > p_data_hub_crt_ts
and ship.act_stus_ind=1
union 
select ship_char.ship_key, ship_char.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_char ship_char 
where ship_char.data_hub_crt_ts > p_data_hub_crt_ts
and ship_char.act_stus_ind=1
union 
select ship_cond.ship_key, ship_cond.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_cond ship_cond
where ship_cond.data_hub_crt_ts > p_data_hub_crt_ts
and ship_cond.act_stus_ind=1
union
select a.ship_key, b.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_asct a
inner join daas_tm_prepared.dh_ship_asct_char b on a.asct_key=b.asct_key
where b.sor_tpic_nm  like '%waybill%'
and b.act_stus_ind =1
and b.data_hub_crt_ts > p_data_hub_crt_ts
union
select ship_cmp.ship_key, ship_cmp_char.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_cmp ship_cmp
inner join daas_tm_prepared.dh_ship_cmp_char ship_cmp_char on ship_cmp_char.ship_cmp_key = ship_cmp.ship_cmp_key
where ship_cmp.act_stus_ind=1
and ship_cmp_char.sor_tpic_nm not like '%reference%'
and ship_cmp_char.data_hub_crt_ts > p_data_hub_crt_ts
and ship_cmp_char.act_stus_ind=1
union 
select sc.ship_key, cc.data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_char cc
inner join daas_tm_prepared.dh_cnvy cnvy on cc.cnvy_key = cnvy.cnvy_key
inner join daas_tm_prepared.dh_ship_char sc on sc.char_val =cnvy.id_val 
and sc.char_type_key='31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
where cc.sor_tpic_nm like '%wayBill%' and cc.act_stus_ind=1
and cc.char_type_key='dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8'  -- car kind
and cc.data_hub_crt_ts > p_data_hub_crt_ts
)
select a.ship_key
--, max("dataHubCreationTimestamp") as data_hub_crt_ts
from "vShipmentChange" a
group by a.ship_key
order by max(a."dataHubCreationTimestamp") 
limit 1000;




-- part 2: parse parameter string to temporay table 
if p_waybillNumber is not null and  p_waybillNumber<>''
then
create temporary table tbl_id ( id_val text, ship_key bytea PRIMARY KEY)  on commit drop;
insert into tbl_id(id_val, ship_key)
 select distinct m.id_val, sc.ship_key
 from (select trim(unnest(string_to_array(p_waybillNumber ,','))) as id_val ) as m 
 inner join daas_tm_prepared.dh_ship_char  sc on m.id_val=sc.char_val 
 and sc.char_type_key='8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0' ; --Waybill Number;
delete from tbl_changes where not exists (Select 1 from tbl_id where tbl_id.ship_key=tbl_changes.ship_key );
end if ;


create temporary table tbl_changes_final
( ship_key bytea , 
cnvy_key bytea,
PRIMARY KEY(ship_key,cnvy_key))  on commit drop;

insert into tbl_changes_final(ship_key, cnvy_key)
select distinct  a.ship_key, cnvy.cnvy_key
from tbl_changes a
inner join daas_tm_prepared.dh_ship_char b on a.ship_key=b.ship_key 
and b.char_type_key ='31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.id_val=b.char_val;

 
 

-- part 3: return details
RETURN QUERY 
select
greatest(ship.data_hub_crt_ts, ship_char."dataHubCreationTimestamp", ship_asct_cnvy_char."dataHubCreationTimestamp", cnvy_char.data_hub_crt_ts, b.data_hub_crt_ts , ship_cond."dataHubCreationTimestamp", scf2."dataHubCreationTimestamp") as "dataHubCreationTimestamp"
,greatest(ship.sor_evt_ts, ship_char."eventTimestamp", ship_asct_cnvy_char."eventTimestamp" , cnvy_char.sor_evt_ts, b.sor_evt_ts, ship_cond."eventTimestamp", scf2."eventTimestamp") as "eventTimestamp"
, wbnbr.char_val as "waybillNumber"
, ship.id_val as "waybillIdentification"

, b."shipperCity333"
, b."shipperProvinceState"
, b."shipperStationNumber"
, b."shipperCustomer633"
, b."shipperCarrierAbbreviation"
, b."shipperCityName"
, b."shipperZip"
, b."shipperCustomerAddress"
, b."shipperCustomerName"
, b."shipperCustomerNumber"


, b."consigneeCity333"
, b."consigneeProvinceState"
, b."consigneeStationNumber"
, b."consigneeCustomer633"
, b."consigneeCarrierAbbreviation"
, b."consigneeCityName"
, b."consigneeZip"
, b."consigneeCustomerAddress"
, b."consigneeCustomerName"
, b."consigneeCustomerNumber"

, b."payingCustomerCity333"
, b."payingCustomerProvinceState"
, b."payingCustomerStationNumber"
, b."payingCustomerCustomer633"
, b."payingCustomerCarrierAbbreviation"
, b."payingCustomerCityName"
, b."payingCustomerZip"
, b."payingCustomerCustomerAddress"
, b."payingCustomerCustomerName"
, b."payingCustomerCustomerNumber"

, b."careOfCity333"
, b."careOfProvinceState"
, b."careOfStationNumber"
, b."careOfCustomer633"
, b."careOfCarrierAbbreviation"
, b."careOfCityName"
, b."careOfZip"
, b."careOfCustomerAddress"
, b."careOfCustomerName"
, b."careOfCustomerNumber"


, b."finalDestinationCity333"
, b."finalDestinationProvinceState"
, b."finalDestinationStationNumber"
, b."finalDestinationCustomer633"
, b."finalDestinationCarrierAbbreviation"
, b."finalDestinationCityName"
, b."finalDestinationZip"
, b."finalDestinationCustomerAddress"
, b."finalDestinationCustomerName"
, b."finalDestinationCustomerNumber"

, b."priorOriginCity333"
, b."priorOriginProvinceState"
, b."priorOriginStationNumber"
, b."priorOriginCustomer633"
, b."priorOriginCarrierAbbreviation"
, b."priorOriginCityName"
, b."priorOriginZip"
, b."priorOriginCustomerAddress"
, b."priorOriginCustomerName"
, b."priorOriginCustomerNumber"



, b."shipFromCity333"
, b."shipFromProvinceState"
, b."shipFromStationNumber"
, b."shipFromCustomer633"
, b."shipFromCarrierAbbreviation"
, b."shipFromCityName"
, b."shipFromZip"
, b."shipFromCustomerAddress"
, b."shipFromCustomerName"
, b."shipFromCustomerNumber"


,ship_char.bill_of_lading_number as "billOfLadingNumber"
,cnvy_char.char_val as "carKind"
,ship_char.customer_supplied_net_weight as "customerSuppliedNetWeight"
,ship_char.customer_supplied_weight_code as "customerSuppliedWeightCode"
,ship_char.Customer_Supplied_Weight_UOM as "customerSuppliedWeightUom"
,ship_char.destination_ramp_333 as "destinationRamp333"
,ship_char.destination_ramp_333_province_state_code as "destinationRamp333ProvinceStateCode"
,ship_char.equipment_id as "equipmentIdentification"
,ship_char.load_empty_status_code as "loadEmptyStatusCode"
,ship_char.operating_city as "operatingCity"
,ship_char.operating_city_province_state_code as "operatingCityProvinceStateCode"
,ship_char.operating_destination_fsac as "operatingDestinationFsac"
,ship_char.operating_destination_scac as "operatingDestinationScac"
,ship_char.rail_origin_333 as "railOrigin333"
,ship_char.origin_ramp_333 as "originRamp333"
,ship_char.origin_ramp_333_province_state_code as "originRamp333ProvinceStateCode"
,ship_char.rail_origin_333_province_state_code as "railOrigin333ProvinceStateCode"
,ship_char.standard_transportation_commodity_code as "standardTransportationCommodityCode"
,ship_char.Waybill_Record_Type as "waybillTypeCode"


,ship_cond."specialConditionCode1"
,ship_cond."specialConditionCode2"
,ship_cond."specialConditionCode3"
,ship_cond."specialConditionCode4"
,ship_cond."specialConditionCode5"
,ship_cond."specialConditionCode6"

,ship_cond."waybillStatusCode"
,cnvy_type.type_cd
,ship_char.Rail_Destination_333 as "railDestination333"
,ship_char.Rail_Destination_333_Province_State_Code as "railDestination333ProvinceStateCode"
,ship_char.Gross_Scale_Weight as "grossScaleWeight"
,ship_char.Gross_Scale_Weight_UOM as "grossScaleWeightUom"
,ship_char.Net_Scale_Weight as "netScaleWeight"
,ship_char.Net_Scale_Weight_UOM as "netScaleWeightUom"
,ship_char.Regulatory_Authority as "regulatoryAuthority"
--,ship_char.Standard_Transportation_Commodity_Code as "standardTransportationCommodityCode"
,ship_char.Waybill_Date as "waybillDate"
,ship_char.Waybill_EDI_Code as "waybillEdiCode"
,ship_char.First_CN_Origin_Carrier_Abbreviation as "firstCnOriginCarrierAbbreviation"
,ship_char.First_CN_Origin_Station_Number as "firstCnOriginStationNumber"
,ship_char.Last_CN_Origin_Carrier_Abbreviation as "lastCnOriginCarrierAbbreviation"
,ship_char.Last_CN_Origin_Station_Number as "lastCnOriginStationNumber"
,stn.stn_333 as "lastCnOriginStation333"
,stn.stn_st as "lastCnOriginStation333ProvinceStateCode"
--,ship_char.Operating_City as "operatingCity"
,ship_asct_cnvy_char.op_zts AS "operatingZoneTrackSpot"
,ship_asct_comm_char."articleQuantity"
,ship_asct_comm_char."packageType"

,'packageTypeDescriptionInEnglish' as "packageTypeDescriptionInEnglish"

,'packageTypeDescriptionInFrench' as "packageTypeDescriptionInFrench"

,scf1."referenceNumber"
,scf1."referenceNumberCode"

,scf2.Sail_Date as "sailDate"
,scf2.Sail_Time as "sailTime"
,scf2.Vessel_Name as "vesselName"

,cmdy_char.char_val as "additionalStcc"
,ship.ship_key --techincal field used with vShipmentChange




from tbl_changes_final  
inner join daas_tm_prepared.dh_ship ship on tbl_changes_final.ship_key=ship.ship_key
inner join daas_tm_prepared.dh_ship_char as wbnbr on wbnbr.ship_key =tbl_changes_final.ship_key 
and wbnbr.act_stus_ind=1
and wbnbr.char_type_key='8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0' --Waybill Number
inner join daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(tbl_changes_final.ship_key) ship_char on true
left join daas_tm_trusted.f_get_dh_ship_cond_bp_role_char_waybill_by_ship_key(tbl_changes_final.ship_key) b on true
--inner join on ship.ship_key=a.ship_key and -- first change
/*
left join daas_tm_prepared.dh_ship_cond ship_cond1 on ship.ship_key=ship_cond1.ship_key
and ship_cond1.act_stus_ind =1 and ship_cond1.char_type_key = 'f3c0d6f82e7737e9e08d2180b7c1203f442a37ca40669441a61565b2d480b81a' --Special Condition Code
left join daas_tm_prepared.dh_ship_cond ship_cond2 on ship.ship_key=ship_cond2.ship_key
and ship_cond2.act_stus_ind =1 and ship_cond2.char_type_key = '1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083' --Waybill Status Code;
*/
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(tbl_changes_final.ship_key) as ship_cond on true
left join daas_tm_prepared.dh_cnvy cnvy on (tbl_changes_final.cnvy_key = cnvy.cnvy_key and cnvy.act_stus_ind = 1)
left join daas_tm_prepared.dh_cnvy_char cnvy_char on (cnvy.cnvy_key = cnvy_char.cnvy_key and cnvy_char.act_stus_ind = 1 and cnvy_char.char_type_key = 'dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8' )
left join daas_tm_prepared.dh_ref_type cnvy_type on cnvy_type.type_key=cnvy.cnvy_type_key
left join daas_tm_prepared.dh_rail_station stn on stn.scac=ship_char.Last_CN_Origin_Carrier_Abbreviation and LPAD(stn.fsac, 6, '0')=ship_char.Last_CN_Origin_Station_Number
-- ship asct and ship asct equipemnet char
left join daas_tm_prepared.dh_ship_asct sa1 on sa1.ship_key=tbl_changes_final.ship_key
and sa1.act_stus_ind=1
and sa1.ship_type_key = 'd7b91437ff74a3bfd70ba3ebe8d16b8b5c2658cb589c7e5fa9d8f67d354e3b80' -- Waybill
and sa1.asct_type_key='3de22246a9c11b9fa0fae553613839d4fa5e077ff8bbbf7ee43eef0725c434c2' --Inter-BCD Shipment-Conveyor
left join daas_tm_trusted.f_get_dh_ship_asct_char_equipment_by_asct_key (sa1.asct_key) ship_asct_cnvy_char on 1 = 1

-- ship asct and ship asct commodity char
left join daas_tm_prepared.dh_ship_asct sa2 on sa2.ship_key=tbl_changes_final.ship_key
and sa2.act_stus_ind=1
and sa2.ship_type_key = 'd7b91437ff74a3bfd70ba3ebe8d16b8b5c2658cb589c7e5fa9d8f67d354e3b80' -- Waybill
and sa2.asct_type_key='e5f3fd59caf7dc0eb131d6b81aed6a07bd1f6b04488e979cb19be3fdf9daff44' --Inter-BCD Shipment-Commodity
left join daas_tm_trusted.f_get_dh_ship_asct_char_commodity_by_asct_key (sa2.asct_key) ship_asct_comm_char on 1 = 1

--sh cmp and waybill reference
left join daas_tm_prepared.dh_ship_cmp sc1 on sc1.ship_key=tbl_changes_final.ship_key
and sc1.ship_cmp_type_key='4ba31249118427e3579be1407f8a067652b3d2327833b0066d8491a2ba5ad25e' --Intra-Domain Shipment-Reference
and sc1.act_stus_ind=1
left join daas_tm_trusted.f_get_dh_ship_asct_char_waybill_reference_by_asct_key(sc1.ship_cmp_key) scf1 on true

--sh cmp and vessel
left join daas_tm_prepared.dh_ship_cmp sc2 on sc2.ship_key=tbl_changes_final.ship_key
and sc2.ship_cmp_type_key='af82909b34df99ece8af4b140307841a3a899bac846f096ff2a3efcbed32f44c' --Intra-Domain Shipment-Shipment-Voyage-Segment
and sc2.act_stus_ind=1
left join daas_tm_trusted.f_get_dh_ship_cmp_char_vessel_by_ship_cmp_key(sc2.ship_cmp_key) scf2 on true

-- ship asct and lading/additional stcc
left join daas_tm_prepared.dh_ship_asct sa3 on sa3.ship_key=tbl_changes_final.ship_key
and sa3.act_stus_ind=1
and sa3.asct_obj_type_key='27d689b061a6dc690a7e43b2f63913fdb060b98c6c67ff6c3888e4bf64641359' --commodity
and sa3.asct_type_key='e5f3fd59caf7dc0eb131d6b81aed6a07bd1f6b04488e979cb19be3fdf9daff44' --Inter-BCD Shipment-Commodity
left join daas_tm_prepared.dh_cmdy cmdy on sa3.asct_obj_key=cmdy.cmdy_key
left join daas_tm_prepared.dh_cmdy_char cmdy_char on cmdy_char.cmdy_key=cmdy.cmdy_key and cmdy_char.act_stus_ind = 1
and cmdy_char.char_type_key = '384f5b7339b33adefe3edeee78962574f0d747f5c37222508e5ec2647294022a' --STCC
where ship.act_stus_ind=1 
and greatest(ship.data_hub_crt_ts, ship_char."dataHubCreationTimestamp", ship_asct_cnvy_char."dataHubCreationTimestamp", cnvy_char.data_hub_crt_ts, b.data_hub_crt_ts , ship_cond."dataHubCreationTimestamp")
> p_data_hub_crt_ts
--now() - interval '10 minutes'
;

END;$$ SECURITY DEFINER
LANGUAGE plpgsql;

/*
GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vShipmentUpdate"( timestamp , text) TO public;


select * from daas_tm_trusted."f_vShipmentUpdate"(now()::timestamp - interval '45 days', NULL);
select * from daas_tm_trusted."f_vShipmentUpdate"(now()::timestamp - interval '100 days', '');

select * from daas_tm_trusted."f_vShipmentUpdate"(now()::timestamp - interval '45 days', '989999,393399,403868,396791');
*/
