--function to get car detaills by container
DROP FUNCTION if exists f_run_dh_get_train_schedule_origin_detination_by_trainid(text) cascade;


--function to get train details by car
CREATE OR REPLACE FUNCTION f_run_dh_get_train_schedule_origin_detination_by_trainid(trainid text)
RETURNS TABLE
(
"trainIdentification" text,
"originStation_333" character varying(9),
"originStationSt" character(2),
"originStationFsac" character varying(6),
"originStationScac" character varying(4),
"originStationSequenceNumber" text,
"destinationStation_333" character varying(9),
"destinationStationSt" character(2),
"destinationStationFsac" character varying(6),
"destinationStationScac" character varying(4),
"destinationStationSequenceNumber" text
)
AS $$
begin
return query
select distinct cnvy.id_val as "trainIdentification",-- trn_id
FIRST_VALUE(rail_stat.stn_333)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val) as "originStation_333",
FIRST_VALUE(rail_stat.stn_st)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val) as "originStationSt", 
FIRST_VALUE(rail_stat.fsac)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val) as "originStationFsac",
FIRST_VALUE(rail_stat.scac)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val) as "originStationScac", 
FIRST_VALUE(la_char.char_val)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val) as "originStationSequenceNumber", 
FIRST_VALUE(rail_stat.stn_333)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val desc) as "destinationStation_333",
FIRST_VALUE(rail_stat.stn_st)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val desc) as "destinationStationSt", 
FIRST_VALUE(rail_stat.fsac)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val desc) as "destinationStationFsac",
FIRST_VALUE(rail_stat.scac)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val desc) as "destinationStationScac",
FIRST_VALUE(la_char.char_val)OVER (PARTITION BY cnvy.id_val ORDER BY la_char.char_val desc) as "destinationStationSequenceNumber"
from daas_tm_prepared.dh_cnvy cnvy  
inner join daas_tm_prepared.dh_plan_evt pede on cnvy.cnvy_key=pede.prim_obj_key and pede.act_stus_ind = 1 and cnvy.act_stus_ind = 1 
inner join daas_tm_prepared.dh_plan_evt_asct pade on (pede.plan_evt_key = pade.plan_evt_key and pade.act_stus_ind = 1)
inner join daas_tm_prepared.dh_loc_asct la on (pade.asct_obj_key = la.asct_key and la.act_stus_ind = 1 and la.asct_obj_type_key = 'b6b8a958245d0b4e4df6f399bdc2917e48cfce12061a47639aac681966fb8916')  --Train Schedule
inner join daas_tm_prepared.dh_rail_station rail_stat on (la.loc_key = rail_stat.stn_FSAC_key)
inner join daas_tm_prepared.dh_loc_asct_char la_char on (la.asct_key = la_char.asct_key and la_char.act_stus_ind = 1 --and la_char.char_val <= '00100' --p_max_station_sequence_nb 
and la_char.char_type_key = '2cb5b0e9672838ba34acfd341a4d3e8f6e8e95c42fd7bfbe215fe72f2b3904e9') --- station sequence number
where 1=1
and cnvy.id_val=trainid  --'A4002120210811'
;

end;
$$ LANGUAGE plpgsql;



