DROP FUNCTION IF EXISTS daas_tm_trusted."f_vUnitLocation"( text) cascade; -- 

CREATE or replace FUNCTION daas_tm_trusted."f_vUnitLocation"( p_equipmentIdentifier text )
RETURNS TABLE(

 "equipmentIdentifier"  text
, "equipmentInitial"  text
, "equipmentNumber"   text
, "eventTimestamp"   timestamp
, "stationScac"   varchar(4)
, "stationFsac"   varchar(6)
, "equipmentLocationCode"  text
, "opZts"  text
, "currentAssignment"  text

, "lot"  text

, "row"  text
, "spot"   text
, "trackNumber"  text
, "trackArea"  text
, "liftCode"  text
, "parkOrTrackCode"  text
, "railcarAssociation" text
, "trackSequenceNumber"  text 
, "platformCode"  text 
, "platformPosition" text
, "carKind"  text
, "equipmentType"  character varying(50)
, "tier"  text
, "statusIndicator" text

    )
AS $$
BEGIN


-- part 1: create table 
create temporary table tbl_id ( 
id_val text,
cnvy_type_key bytea ,
asct_obj_key bytea null, -- dh_trsp_evt_asct.asct_obj_key
asct_key bytea null,   --dh_trsp_evt_asct.asct_key
dh_cnvy_asct_asct_key bytea null, --dh_cnvy_asct.asct_key
sor_evt_ts timestamp null, --dh_trsp_evt
cnvy_key bytea 
 )  on commit drop;

create index io on tbl_id (cnvy_key,asct_obj_key, asct_key,dh_cnvy_asct_asct_key);

-- part 2: parse parameter string to temporay table 

insert into tbl_id(id_val,cnvy_type_key, asct_obj_key,asct_key,cnvy_key,dh_cnvy_asct_asct_key,sor_evt_ts)
 select distinct cnvy.id_val, cnvy.cnvy_type_key, tea.asct_obj_key, tea.asct_key , cnvy.cnvy_key, b.asct_key as dh_cnvy_asct_asct_key, te.sor_evt_ts
 from (select trim(unnest(string_to_array(p_equipmentIdentifier ,','))) as id_val ) as m   --
 inner join daas_tm_prepared.dh_cnvy cnvy on m.id_val=cnvy.id_val and cnvy.act_stus_ind=1 
left JOIN daas_tm_prepared.dh_trsp_evt te ON te.act_stus_ind = 1 AND cnvy.cnvy_key = te.trsp_evt_key
left JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON tea.act_stus_ind = 1 AND te.trsp_evt_key = tea.trsp_evt_key
LEFT JOIN daas_tm_prepared.dh_cnvy_asct b ON cnvy.cnvy_key=b.cnvy_key 
and b.asct_type_key='0ba452470ff9f23b1d2e999f5afea823e1d7bab4913da2dc17aba3c6e784f011' 
and b.act_stus_ind=1 ;-- Intra-BCD Container-Railcar

-- part 3: create cnvy_asct_char
create temporary table cnvy_asct_char ( 
"platformCode" text null,
"platformPosition" text null,
cnvy_key bytea 
 )  on commit drop;

 create  index i2 on cnvy_asct_char ( cnvy_key);

 
insert into cnvy_asct_char(cnvy_key,"platformCode" ,"platformPosition")
select c.cnvy_key
,case when COALESCE(cc1.data_hub_crt_ts , '1900-01-01') >COALESCE(d1.data_hub_crt_ts  , '1900-01-01') then cc1.char_val else d1.char_val end as "platformCode"
,case when COALESCE(cc2.data_hub_crt_ts , '1900-01-01') >COALESCE(d2.data_hub_crt_ts  , '1900-01-01') then cc2.char_val else d2.char_val end as "platformPosition"
from tbl_id c
LEFT JOIN daas_tm_prepared.dh_cnvy_asct_char d1 ON c.dh_cnvy_asct_asct_key=d1.asct_key 
and d1.char_type_key= '4d8db4222b8246af57f924cab221bf48a29077323041d2c57d4870aebef0fe17' --Platform Code
LEFT JOIN daas_tm_prepared.dh_cnvy_asct_char d2 ON c.dh_cnvy_asct_asct_key=d2.asct_key 
and d2.char_type_key= 'db442b26e87d44a5489f02aa88d7b42cacdc24f189585abbda3f6583b89e5397' --Platform Position Code
left join daas_tm_prepared.dh_cnvy_cond cc1 on c.cnvy_key=cc1.cnvy_key
and cc1.char_type_key= '4d8db4222b8246af57f924cab221bf48a29077323041d2c57d4870aebef0fe17' --Platform Code
left join daas_tm_prepared.dh_cnvy_cond cc2 on c.cnvy_key=cc2.cnvy_key
and cc2.char_type_key= 'db442b26e87d44a5489f02aa88d7b42cacdc24f189585abbda3f6583b89e5397' --Platform Position Code
;

-- part 4: return details
set enable_hashjoin=FALSE;
SET enable_mergejoin=FALSE;
RETURN QUERY 

SELECT c.id_val AS "equipmentIdentifier"
, cnvy_char.equipment_initial as "equipmentInitial"
, cnvy_char.equipment_number as "equipmentNumber"
, c.sor_evt_ts as "eventTimestamp"
, stn.scac AS "stationScac"
, stn.fsac AS "stationFsac"
, cc1.char_val AS "equipmentLocationCode"
, rcar.opZTS AS "opZts"
, rcar.trainidentification AS "currentAssignment"

, trim(case when COALESCE(cnvy_cond."latestLotTrackIdTs" , '1900-01-01') >COALESCE(cnvy_cond."latestLotTs" , '1900-01-01')  then cnvy_cond."lotTrackId" else cnvy_cond."lot" end) as "lot"

--, cnvy_cond."lotTrackId" as "lot"
, trim(cnvy_cond."row") as "row"
, trim(cnvy_cond."spot") as "spot"
, rcar.tracknumber as "trackNumber"
, trsp_evt_asct_char.track_area as "trackArea"
, trsp_evt_asct_char.lift_code as "liftCode"
, cnvy_cond."parkingTracksideIndicator" as "parkOrTrackCode"
, rcar.eqp_init || rcar.eqp_nbr as "railcarAssociation"
, rcar.tracksequencenumber as "trackSequenceNumber"
, cnvy_asct_char."platformCode"
, cnvy_asct_char."platformPosition"
, cnvy_char.Car_Kind as "carKind"
, r.type_cd as "equipmentType"
, cnvy_cond."tier" as "tier"
, cnvy_cond."statusIndicator" as "statusIndicator"
FROM 
--daas_tm_prepared.dh_cnvy c
tbl_id c
left JOIN daas_tm_prepared.dh_ref_type r on c.cnvy_type_key = r.type_key AND r.type_cd in ( 'Container' , 'Chassis' , 'Trailer')

left JOIN daas_tm_prepared.dh_rail_station stn ON (stn.stn_333_key = c.asct_obj_key or stn.stn_333_cn_key = c.asct_obj_key

or stn.stn_fsac_key = c.asct_obj_key) 
left join daas_tm_prepared.dh_cnvy_cond cc1 on cc1.cnvy_key = c.cnvy_key and cc1.act_stus_ind=1
and cc1.char_type_key='4ea81b8a03299ac5c6a2fd8a6821868bff1bf08eea4e810ba8373f574d33119f' --Equipment Location Code
LEFT JOIN daas_tm_trusted.f_run_dh_get_car_details_by_container(c.cnvy_key) rcar ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key (c.cnvy_key) cnvy_char ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key (c.cnvy_key) cnvy_cond ON 1=1
LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_asct_char_yard_by_asct_key (c.asct_key) trsp_evt_asct_char ON 1=1
LEFT JOIN cnvy_asct_char ON cnvy_asct_char.cnvy_key=c.cnvy_key
;


END;$$ SECURITY DEFINER
LANGUAGE plpgsql;


--GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vUnitLocation"(  text) TO public;



--select * from daas_tm_trusted."f_vUnitLocation"('CNRU530254');

--select * from daas_tm_trusted."f_vUnitLocation"('SIMU600842,SIMU600844,STMU201533');
