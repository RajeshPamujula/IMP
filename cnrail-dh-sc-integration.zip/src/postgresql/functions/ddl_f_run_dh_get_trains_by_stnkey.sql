--function to get list of trains passing the station
DROP FUNCTION if exists f_run_dh_get_trains_by_stnkey(bytea)
cascade;

--function to get list of trains passing the station
CREATE OR REPLACE FUNCTION f_run_dh_get_trains_by_stnkey(p_loc_key bytea)
RETURNS TABLE 
(cnvy_key bytea,
train_id text,
max_station_sequence_nb text,
max_station_sequence_timestamp text)
AS $$
begin
return query
select all_trains.cnvy_key, all_trains.train_id, all_trains.max_station_sequence_nb, all_trains.max_station_sequence_timestamp
from (	
select tempo.*, rank() over (partition by tempo.cnvy_key order by tempo.max_station_sequence_nb desc, tempo.max_station_sequence_timestamp desc) as rk
from (select cnvy_char_sel.cnvy_key,
cnvy_char_sel.char_val as train_id, 
la_char_sel.char_val as "max_station_sequence_nb" ,  
la_char_sel2.char_val as "max_station_sequence_timestamp" , 
MAX(CASE when char_type_sel.type_cd = 'Estimated Arrival UTC' THEN 
(Case when pac_sel.char_val = '' then to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else to_timestamp(pac_sel.char_val, 'YYYY-MM-DD HH24:MI:SS') end)
else to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS') end) as estimated_arrival_utc,
MAX(CASE when char_type_sel.type_cd = 'Estimated Departure UTC' THEN 
(Case when pac_sel.char_val = '' then to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
else to_timestamp(pac_sel.char_val, 'YYYY-MM-DD HH24:MI:SS') end)
else to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')  end) as estimated_departure_utc 
from  daas_tm_prepared.dh_loc_asct LA_sel
inner join  daas_tm_prepared.dh_loc_asct_char la_char_sel on (la_sel.asct_key = la_char_sel.asct_key and la_char_sel.act_stus_ind = 1  and la_char_sel.char_type_key = '2cb5b0e9672838ba34acfd341a4d3e8f6e8e95c42fd7bfbe215fe72f2b3904e9')   --- station sequence number
inner join  daas_tm_prepared.dh_loc_asct_char la_char_sel2 on (la_sel.asct_key = la_char_sel2.asct_key and la_char_sel2.act_stus_ind = 1 and la_char_sel2.char_type_key  = '7544a574a5161ba81594b74bafa609149a78ce3e901c078cf773ef8b9a2d9417')   --- station sequence timestamp
inner join daas_tm_prepared.dh_plan_evt_asct PADE_sel on (la_sel.asct_key = PADE_sel.asct_obj_key and pade_sel.act_stus_ind = 1)
inner join daas_tm_prepared.dh_plan_evt_char  PAC_sel on (pade_sel.plan_evt_key = PAC_sel.plan_evt_key and pac_sel.act_stus_ind = 1)
inner join daas_tm_prepared.DH_REF_TYPE char_TYPE_sel on (PAC_sel.Char_TYPE_key = char_type_sel.TYPE_KEY)
inner join daas_tm_prepared.dh_cnvy_char  cnvy_char_sel on (pade_sel.prim_obj_key = cnvy_char_sel.cnvy_key and cnvy_char_sel.act_stus_ind  = 1  and cnvy_char_sel.char_type_key = '2de848fbf4f4a1b422a4ac69aca68604254d48919aa8015e71079ec8f69382fb') 
where la_sel.loc_key = p_loc_key and LA_sel.act_stus_ind          = 1
group by 1, 2, 3, 4) tempo
where estimated_arrival_utc   >= current_date - interval '2 day' 
or  estimated_departure_utc  >= current_date - interval '2 day'
) all_trains
where rk = 1;	
end;
$$ LANGUAGE plpgsql;
