DROP FUNCTION IF EXISTS daas_tm_trusted."f_vCarInventoryUpdateHistory"(timestamp , text) cascade; -- 

CREATE or replace FUNCTION daas_tm_trusted."f_vCarInventoryUpdateHistory"(p_data_hub_crt_ts timestamp, p_railcarId text )
RETURNS TABLE(

  "dataHubCreationTimestamp"  timestamp
, "railcarId" text
, "equipmentInitial" varchar(4)
, "equipmentNumber"   varchar(10)
, "transportationEventKey" bytea
, "transportationProcessTimestamp" timestamp
, "transportationEventAssociateKey"  bytea
, "eventCode"    text
, "eventStatusCode"   text
, "eventTimestamp"   text
, "previousEventCode"     text
, "previousEventStatusCode"     text
, "previousEventTimestamp"    text 

, "scac"   varchar(4)
, "fsac"   varchar(6)

, "conveyorKey" bytea
, "conveyorConditionProcessTimestamp" text
, "conveyorCharacterProcessTimestamp"   text
, "conveyorProcessTimestamp"  text
, "trackNumber"      text
, "previousTrackNumber"     text
, "currentSpot"   text
, "trackSequenceNumber"   text

, "previousTrackSequenceNumber"    text
, "currentAssignment"   text
, "loadEmptyStatusCode"     text
, "carLocationCode"   text
, "opZts"   text
, "badOrderCode"   text

, "mechanicalStatusCode1"   text
, "mechanicalStatusCode2"   text
, "mechanicalStatusCode3"   text
, "previousMechanicalStatusCode1"   text
, "previousMechanicalStatusCode2"   text
, "previousMechanicalStatusCode3"   text
, "customerCarOrderNumber"    text
, "previousCustomerCarOrderNumber"    text
, "yardBlock"   text
, "cnPoolId"       text
, "previousCNPoolID"    text
, "carKind"   text
, "customerSwitchCode"   text
--, sa.ship_key
, "shipmentConditionProcessTimestamp"   text
, "specialConditionCode1"   text
, "specialConditionCode2"   text
, "specialConditionCode3"   text
, "specialConditionCode4"   text
, "specialConditionCode5"   text
, "specialConditionCode6"   text
, "previousSpecialConditionCode1"   text
, "previousSpecialConditionCode2"   text
, "previousSpecialConditionCode3"   text
, "previousSpecialConditionCode4"   text
, "previousSpecialConditionCode5"   text
, "previousSpecialConditionCode6"   text
    )
AS $$
BEGIN

-- part 1: change capture and apply the optional filter , limit 1000 records
create temporary table tbl_changes 
( 
trsp_evt_key bytea , 
cnvy_key bytea , 
id_val text, 
data_hub_crt_ts timestamp, 
rpt_sor_proc_ts timestamp
)  
on commit drop
;
create index tbl_changes_i0 on tbl_changes (trsp_evt_key, cnvy_key, id_val );

create index tbl_changes_i1 on tbl_changes (cnvy_key );


insert into tbl_changes	(trsp_evt_key, cnvy_key, id_val, data_hub_crt_ts,rpt_sor_proc_ts)
with "vCarInventoryChange" as (
select te.trsp_evt_key, cnvy.cnvy_key,cnvy.id_val,  te.data_hub_crt_ts, te.rpt_sor_proc_ts
from daas_tm_prepared.dh_trsp_evt te
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.cnvy_key = te.trsp_evt_key and cnvy.act_stus_ind=1
where te.act_stus_ind = 1   
AND te.trsp_evt_type_key = '\x66366235333062306561303063323737343735343365623935306438313465623061656463653265646664633561633439333133323936666232323338663032' -- Railcar Event
 AND te.data_hub_crt_ts > p_data_hub_crt_ts
 --now() - interval '2 minutes'
 union all 
 select te.trsp_evt_key, cnvy.cnvy_key,cnvy.id_val,  ter.data_hub_crt_ts, ter.rpt_sor_proc_ts
from daas_tm_prepared.dh_trsp_evt te
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.cnvy_key = te.trsp_evt_key and cnvy.act_stus_ind=1
inner join daas_tm_prepared.dh_trsp_evt_char ter on ter.trsp_evt_key=te.trsp_evt_key and ter.act_stus_ind=1
where te.act_stus_ind = 1     
AND te.trsp_evt_type_key = '\x66366235333062306561303063323737343735343365623935306438313465623061656463653265646664633561633439333133323936666232323338663032' -- Railcar Event
 AND ter.data_hub_crt_ts > p_data_hub_crt_ts
 --now() - interval '2 minutes'
 
)
select a.trsp_evt_key, a.cnvy_key, a.id_val
, max("data_hub_crt_ts") as data_hub_crt_ts
, max("rpt_sor_proc_ts") as rpt_sor_proc_ts
from "vCarInventoryChange" a
group by a.trsp_evt_key, a.cnvy_key, a.id_val 
order by max(a."data_hub_crt_ts") 
limit 2000
;




-- part 2: parse parameter string to temporay table 
if p_railcarId is not null and p_railcarId <> '' 
then
create temporary table tbl_id ( id_val text)  on commit drop;
insert into tbl_id(id_val)
 select distinct m.id_val
 from (select trim(unnest(string_to_array(p_railcarId ,','))) as id_val ) as m 
 ;
delete from tbl_changes where not exists (Select 1 from tbl_id where tbl_id.id_val=tbl_changes.id_val );
end if ;


-- part 3.1: trsp_evt_asct_char

create temporary table trsp_evt_asct_char 
ON COMMIT DROP 
as
select a.cnvy_key
, stn."scac"
, stn."fsac"
, teac1.char_val AS "trackNumber" 
, COALESCE(b."trackNumber", '') AS "previousTrackNumber"
, teac2.char_val AS "currentSpot"
, teac3.char_val  AS "trackSequenceNumber"
, COALESCE(b."trackSequenceNumber", '') AS "previousTrackSequenceNumber" 

from  tbl_changes a
LEFT JOIN daas_tm_prepared.dh_ship_asct sa ON sa.act_stus_ind = 1 AND sa.asct_obj_key = a.cnvy_key
LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON 
--tea.act_stus_ind = 1 AND 
tea.trsp_evt_key = a.cnvy_key 
LEFT JOIN daas_tm_prepared.dh_rail_station stn ON 
(stn.stn_333_key = tea.asct_obj_key or stn.stn_333_cn_key = tea.asct_obj_key  or stn.stn_333_cn_key_conv = tea.asct_obj_key)
left join daas_tm_prepared.dh_trsp_evt_asct_char teac1 on teac1.act_stus_ind=1 and teac1.asct_key=tea.asct_key
and teac1.char_type_key='22fba95bb00160a504606f34b153dbd889ed746cc7d7f794472aa48b7bdbb41a'  --Track Number
left join daas_tm_prepared.dh_trsp_evt_asct_char teac2 on teac2.act_stus_ind=1 and teac2.asct_key=tea.asct_key
and teac2.char_type_key='4d22a567d1055951004f888db2dd262d966078ccadc2b560356bd30effa624df'  --Current Spot
left join daas_tm_prepared.dh_trsp_evt_asct_char teac3 on teac3.act_stus_ind=1 and teac3.asct_key=tea.asct_key
and teac3.char_type_key='a83fa7f14d9937952df568bcfb79fb3516b4f847ecb90799dd431c0c25215af9'  --Track Sequence Number
left join daas_tm_trusted.f_get_dh_trsp_evt_asct_char_domn_evt_by_car_trsp_key(tea.asct_key,null)  as b on true 
;

create index trsp_evt_asct_char_i0 on trsp_evt_asct_char (cnvy_key );
-- part 3.2: trsp_evt_char

create temporary table trsp_evt_char 
ON COMMIT DROP 
as
select cnvy.cnvy_key
, cast(cc1.char_val as varchar(4)) AS "equipmentInitial"
, cast(cc2.char_val as varchar(10)) AS "equipmentNumber"
, cc3.char_val AS "cnPoolId"    
, cc4.char_val AS "carKind"
, COALESCE(SUBSTRING(tec1.char_val, 1, 2), '') AS "eventCode"
, COALESCE(SUBSTRING(tec1.char_val, 3, 2), '') AS "eventStatusCode"
, COALESCE(CONCAT(tec2.char_val, ' ', tec3.char_val), '') AS "eventTimestamp"
, COALESCE(SUBSTRING(a."event", 1, 2), '') AS "previousEventCode"  
, COALESCE(SUBSTRING(a."event", 3, 2), '') AS "previousEventStatusCode"  
, COALESCE(CONCAT(a."eventDate", ' ', a."eventTime"), '')  as "previousEventTimestamp"
FROM tbl_changes cnvy
inner join daas_tm_prepared.dh_cnvy_char cc1 on cc1.cnvy_key=cnvy.cnvy_key and cc1.act_stus_ind=1 
and cc1.char_type_key='53223cc5252d3111a784717f660a45a277a813430ed44561fc46bd7028fc6836'  --Equipment Initial
inner join daas_tm_prepared.dh_cnvy_char cc2 on cc2.cnvy_key=cnvy.cnvy_key and cc2.act_stus_ind=1 
and cc2.char_type_key='4b784c8ef416376b15dcc4a491e6fefe7f994d1da63a1729d18e793799de3b86'  --Equipment Number
inner join daas_tm_prepared.dh_cnvy_char cc3 on cc3.cnvy_key=cnvy.cnvy_key and cc3.act_stus_ind=1 
and cc3.char_type_key='59be9e9993007f599102786df280bcf73fccbdb3a97d3f2b4483934a265d4b8d'  --CN Pool Id
inner join daas_tm_prepared.dh_cnvy_char cc4 on cc4.cnvy_key=cnvy.cnvy_key and cc4.act_stus_ind=1 
and cc4.char_type_key='dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8'  --Car Kind
--LEFT JOIN daas_tm_trusted.f_get_dh_trsp_evt_char_equipment_by_trsp_evt_key (cnvy.trsp_evt_key) AS tec on true 
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec1 on tec1.act_stus_ind=1 and tec1.trsp_evt_key=cnvy.trsp_evt_key
and tec1.char_type_key='07814f276206869eb5b8e6777b5f06a1597ee49b2957f04b609d3c99093d11d7' -- evet
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec2 on tec2.act_stus_ind=1 and tec2.trsp_evt_key=cnvy.trsp_evt_key
and tec2.char_type_key='ab003fb8d838bb009a23e10b96fdea5b5dbaa691dd6a658146851df3f7801130' -- evet date
LEFT JOIN daas_tm_prepared.dh_trsp_evt_char tec3 on tec3.act_stus_ind=1 and tec3.trsp_evt_key=cnvy.trsp_evt_key
and tec3.char_type_key='f5b3a3d43967a9d40508621b349f54966f1babc8d8c6233efbcff57e41aed3fe' -- evet time
left join daas_tm_trusted.f_get_dh_trsp_evt_char_domn_evt_by_car_trsp_key( cnvy.trsp_evt_key,null)  as a on true 
;
create index trsp_evt_char_i0 on trsp_evt_char (cnvy_key );
-- part 3.3: cnvy_cond
create temporary table cnvy_cond 
ON COMMIT DROP 
as
select cnvy.cnvy_key
, ccond."carLocationCode"
, ccond."operatingZoneTrackSpot" AS "opZts"
, ccond."badOrderCode"

, ccond."mechanicalStatusCode1"
, ccond."mechanicalStatusCode2"
, ccond."mechanicalStatusCode3"
, COALESCE(c."mechanicalStatusCode1", '') AS "previousMechanicalStatusCode1"
, COALESCE(c."mechanicalStatusCode2", '') AS "previousMechanicalStatusCode2"
, COALESCE(c."mechanicalStatusCode3", '') AS "previousMechanicalStatusCode3"
, ccond."customerCarOrderNumber" 
, COALESCE(c."customerCarOrderNumber", '') AS "previousCustomerCarOrderNumber" 
, ccond."yardBlock"
, ccond."customerSwitchCode"
FROM tbl_changes cnvy
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key(cnvy.cnvy_key) ccond on true 
left join daas_tm_trusted.f_get_dh_cnvy_cond_domn_evt_by_cnvy_key(cnvy.cnvy_key, null ) as c on true
;
create index cnvy_cond_i0 on trsp_evt_char (cnvy_key );
-- part 4: return details
set enable_hashjoin=FALSE;
SET enable_mergejoin=FALSE;
RETURN QUERY 
SELECT 
 cnvy.data_hub_crt_ts AS "dataHubCreationTimestamp"
, cnvy.id_val AS "railcarId"
, b."equipmentInitial"
, b."equipmentNumber"
, cast('NA' as bytea)  AS "transportationEventKey"
, cnvy.rpt_sor_proc_ts as "transportationProcessTimestamp"
, cast('NA' as bytea) as "transportationEventAssociateKey"
, b."eventCode"
, b."eventStatusCode"
, b."eventTimestamp"
, b."previousEventCode"  
, b."previousEventStatusCode"  
, b."previousEventTimestamp"

, a."scac"
, a."fsac"

, cast('NA' as bytea) as "conveyorKey"
, 'NA'  as "conveyorConditionProcessTimestamp"
, 'NA' as "conveyorCharacterProcessTimestamp"
, 'NA' as "conveyorProcessTimestamp"
, a."trackNumber" 
, a."previousTrackNumber"
, a."currentSpot"
, a."trackSequenceNumber"

, a."previousTrackSequenceNumber" 
, 'NA' AS "currentAssignment"
, 'NA' AS "loadEmptyStatusCode"  
, c."carLocationCode"
, c."opZts"
, c."badOrderCode"

, c."mechanicalStatusCode1"
, c."mechanicalStatusCode2"
, c."mechanicalStatusCode3"
, c."previousMechanicalStatusCode1"
, c."previousMechanicalStatusCode2"
, c."previousMechanicalStatusCode3"
, c."customerCarOrderNumber" 
, c."previousCustomerCarOrderNumber" 
, c."yardBlock"
, b."cnPoolId"    
, 'NA' AS "previousCNPoolID" 
, b."carKind"
, c."customerSwitchCode"
--, sa.ship_key
, 'NA' as "shipmentConditionProcessTimestamp"
, 'NA' AS "specialConditionCode1"
, 'NA' AS "specialConditionCode2"
, 'NA' AS "specialConditionCode3"
, 'NA' AS "specialConditionCode4"
, 'NA' AS "specialConditionCode5"
, 'NA' AS "specialConditionCode6"
, 'NA' AS "previousSpecialConditionCode1"
, 'NA' AS "previousSpecialConditionCode2"
, 'NA' AS "previousSpecialConditionCode3"
, 'NA' AS "previousSpecialConditionCode4"
, 'NA' AS "previousSpecialConditionCode5"
, 'NA' AS "previousSpecialConditionCode6"
FROM tbl_changes cnvy
inner join trsp_evt_asct_char a on cnvy.cnvy_key=a.cnvy_key
left join trsp_evt_char b on cnvy.cnvy_key=b.cnvy_key
left join cnvy_cond c on cnvy.cnvy_key=c.cnvy_key
;

END;$$ SECURITY DEFINER
LANGUAGE plpgsql;

/*
GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vCarInventoryUpdateHistory"( timestamp , text) TO public;


select * from daas_tm_trusted."f_vCarInventoryUpdateHistory"(now()::timestamp - interval '2 minutes', NULL);


select * from daas_tm_trusted."f_vCarInventoryUpdateHistory"(now()::timestamp - interval '35 days', NULL);

select * from daas_tm_trusted."f_vCarInventoryUpdateHistory"(now()::timestamp - interval '95 days', NULL);  -- on INT

select * from daas_tm_trusted."f_vCarInventoryUpdateHistory"(now()::timestamp - interval '90 days', 'SMEU790069,SMEU790065, SMEU790059');

*/


