DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_current_stop_order_by_cnvy_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_current_stop_order_by_cnvy_key(p_cnvy_key bytea)
/*
drop cascades to view daas_tm_trusted."vIntermodalUnitUpdateHistory"

ex: select * from daas_tm_trusted.f_get_current_stop_order_by_cnvy_key('818c6fecef54e32923d47be47b67cb3e22cd987710c706205547e34c7b57d136' );

*/
RETURNS TABLE
(
cnvy_key bytea,
cnvy_cmp_key bytea,
"dataHubCreationTimestamp"  timestamp,
"eventTimestamp"   timestamp,
"stopOrderIteration" bigint,
"stopTimestamp" text,
"stopOrderAuthorization" text,
"stopOrder" text,
"eventCode" text,
"eventCodeOverride" text,
"stopOrderStation333" text,
"stopOrderStationProvinceState" text
)
AS $$
BEGIN
RETURN QUERY

with mydata as(
select c.cnvy_key,a.cnvy_cmp_key, b.type_cd, a.char_val, c.data_hub_crt_ts, 
c.data_hub_crt_ts as "dataHubCreationTimestamp" ,  
c.sor_evt_ts as "eventTimestamp" 
from daas_tm_prepared.dh_cnvy_cmp_char a
inner join daas_tm_prepared.dh_ref_type b on a.char_type_key = b.type_key
inner join daas_tm_prepared.dh_cnvy_cmp c on c.cnvy_cmp_key = a.cnvy_cmp_key
and c.cnvy_cmp_type_key='d7cd65078ac119c66041926ff2612b6612994a6a4d583ae8401b54ad0f71edfa'  --Intra-Domain Conveyor-Stop Order
where a.act_stus_ind=1 and c.act_stus_ind=1
and c.cnvy_key= p_cnvy_key --'0f6062ce66cfbe4888d862044c83ad6415110305a7b508199303191047568358' -- p_cnvy_key
)
,mypivot as (
select mydata.cnvy_key
,mydata.cnvy_cmp_key 
,mydata.data_hub_crt_ts
,max(case when type_cd='Stop Timestamp' then char_val else null end ) as "stopTimestamp"
,max(case when type_cd='Stop Order Authorization' then char_val else null end ) as "stopOrderAuthorization"
,max(case when type_cd='Stop Order' then char_val else null end ) as "stopOrder"  -- I think stop order is number in source 
,max(case when type_cd='Event Code' then char_val else null end ) as "eventCode"
,max(case when type_cd='Event Code Override' then char_val else null end ) as "eventCodeOverride"
,max(case when type_cd='Station 333' then char_val else null end ) as "stopOrderStation333"
,max(case when type_cd='Station Province State Code' then char_val else null end ) as "stopOrderStationProvinceState"

,max(case when type_cd='Program Date' then char_val else null end ) as "programDate"
,max(case when type_cd='Program Time' then char_val else null end ) as "programTime"
,max(mydata."dataHubCreationTimestamp") as "dataHubCreationTimestamp"
,max(mydata."eventTimestamp") as "eventTimestamp"
from mydata
group by 1,2,3
)
,mypivotrank as ( select mypivot.cnvy_key,mypivot.cnvy_cmp_key,  rank() over( partition by mypivot.cnvy_key   order by mypivot."programDate" desc, mypivot."programTime" desc,  mypivot.data_hub_crt_ts) as "stopOrderIteration", mypivot."stopTimestamp",
mypivot."stopOrderAuthorization",mypivot."stopOrder",mypivot."eventCode",mypivot."eventCodeOverride",mypivot."dataHubCreationTimestamp",mypivot."eventTimestamp",
mypivot."stopOrderStation333",mypivot."stopOrderStationProvinceState"
from mypivot)
select mypivotrank.cnvy_key,mypivotrank.cnvy_cmp_key,  
mypivotrank."dataHubCreationTimestamp",
mypivotrank."eventTimestamp", 
mypivotrank."stopOrderIteration", mypivotrank."stopTimestamp",
mypivotrank."stopOrderAuthorization",mypivotrank."stopOrder",mypivotrank."eventCode",mypivotrank."eventCodeOverride",
mypivotrank."stopOrderStation333",mypivotrank."stopOrderStationProvinceState"
from mypivotrank
where mypivotrank."stopOrderIteration"=1;

END;
$$ LANGUAGE plpgsql;