--DROP FUNCTION IF EXISTS f_run_dh_runtime_monitoring_current_state();

CREATE OR REPLACE FUNCTION f_run_dh_runtime_monitoring_current_state(p_startdate date)
 RETURNS TABLE(table_name text, sor_tpic_nm text, stats_interval timestamp without time zone, exec_date timestamp without time zone, min_sor_raw interval, min_wait_raw interval, min_raw_de interval, min_wait_de interval, min_de_pg interval, min_sor_pg interval, min_raw_pg interval, avg_sor_raw interval, avg_wait_raw interval, avg_raw_de interval, avg_wait_de interval, avg_de_pg interval, avg_sor_pg interval, avg_raw_pg interval, max_sor_raw interval, max_wait_raw interval, max_raw_de interval, max_wait_de interval, max_de_pg interval, max_sor_pg interval, max_raw_pg interval, sor_raw_90 interval, wait_raw_90 interval, raw_de_90 interval, wait_de_90 interval, de_pg_90 interval, sor_pg_90 interval, raw_pg_90 interval, count_de_pg int8)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
    tablenames CURSOR FOR
        SELECT t.tablename AS table_name
        FROM   pg_catalog.pg_tables t
        WHERE  schemaname = 'daas_tm_prepared'
          AND  tablename in ('dh_aset','dh_aset_asct','dh_aset_asct_char','dh_aset_char','dh_aset_cond','dh_bus_prtr','dh_bus_prtr_asct','dh_bus_prtr_char','dh_bus_prtr_cond','dh_cmdy','dh_cmdy_char','dh_cmdy_cond','dh_cnvy','dh_cnvy_asct','dh_cnvy_asct_char','dh_cnvy_char','dh_cnvy_cmp','dh_cnvy_cmp_char','dh_cnvy_cond','dh_loc','dh_loc_asct','dh_loc_asct_char','dh_loc_char','dh_loc_cond','dh_plan_evt','dh_plan_evt_asct','dh_plan_evt_char','dh_rte','dh_rte_char','dh_ship','dh_ship_asct','dh_ship_asct_char','dh_ship_char','dh_ship_cmp','dh_ship_cmp_char','dh_ship_cond','dh_tpln','dh_tpln_asct','dh_tpln_char','dh_tpln_seg','dh_tpln_seg_char','dh_trsp_evt','dh_trsp_evt_asct','dh_trsp_evt_asct_char','dh_trsp_evt_char','dh_cnvy_asct_char_flat','dh_tpln_seg_char_flatten');
BEGIN
    CREATE TEMP TABLE tmp(
        tmp_table_name  text,
        tmp_sor_tpic_nm text,
		tmp_stats_interval timestamp,
        tmp_exec_date timestamp,
        tmp_min_sor_raw  INTERVAL,
        tmp_min_wait_raw  INTERVAL,
        tmp_min_raw_de INTERVAL,
        tmp_min_wait_de INTERVAL,
        tmp_min_de_pg INTERVAL,
        tmp_min_sor_pg INTERVAL,
        tmp_min_raw_pg INTERVAL,
        tmp_avg_sor_raw INTERVAL,
        tmp_avg_wait_raw INTERVAL,
        tmp_avg_raw_de INTERVAL,
        tmp_avg_wait_de INTERVAL,
        tmp_avg_de_pg INTERVAL,
        tmp_avg_sor_pg INTERVAL,
        tmp_avg_raw_pg INTERVAL,
        tmp_max_sor_raw INTERVAL,
        tmp_max_wait_raw INTERVAL,
        tmp_max_raw_de INTERVAL,
        tmp_max_wait_de INTERVAL,
        tmp_max_de_pg INTERVAL,
        tmp_max_sor_pg INTERVAL,
        tmp_max_raw_pg INTERVAL,
        tmp_sor_raw_90 INTERVAL,
        tmp_wait_raw_90 INTERVAL,
        tmp_raw_de_90 INTERVAL,
        tmp_wait_de_90 INTERVAL,
        tmp_de_pg_90 INTERVAL,
        tmp_sor_pg_90 INTERVAL,
        tmp_raw_pg_90 INTERVAL,
        tmp_count_de_pg int8
    ) ON COMMIT DROP;
    
    FOR qry IN tablenames LOOP
        EXECUTE CONCAT(
            'with rawdata as ('
            '   select ''', qry.table_name, ''' table_name,'
            '   sor_tpic_nm,'
            '   sor_ingt_crt_ts - sor_evt_ts as sor_raw,'
            '   sor_read_ts - sor_ingt_crt_ts as wait_raw,'
            '   domn_evt_crt_ts - sor_read_ts as raw_de,'
            '   domn_evt_read_ts - domn_evt_crt_ts as wait_de,'
            '   data_hub_crt_ts - sor_evt_ts as sor_pg,'
            '   data_hub_crt_ts - domn_evt_read_ts as de_pg,'
            '   data_hub_crt_ts - sor_read_ts as raw_pg,'
			'	data_hub_crt_ts'
            '  from daas_tm_prepared.', qry.table_name,
            ' where date(data_hub_crt_ts) = ''', to_char(coalesce(p_startdate, current_date-1), 'YYYY-MM-DD'),''')'
            ' insert into tmp(tmp_table_name, tmp_sor_tpic_nm, tmp_stats_interval, tmp_exec_date, tmp_min_sor_raw, tmp_min_wait_raw, tmp_min_raw_de, tmp_min_wait_de, tmp_min_de_pg, tmp_min_sor_pg, tmp_min_raw_pg, tmp_avg_sor_raw, tmp_avg_wait_raw, tmp_avg_raw_de, tmp_avg_wait_de, tmp_avg_de_pg, tmp_avg_sor_pg, tmp_avg_raw_pg, tmp_max_sor_raw, tmp_max_wait_raw, tmp_max_raw_de, tmp_max_wait_de, tmp_max_de_pg, tmp_max_sor_pg, tmp_max_raw_pg, tmp_sor_raw_90, tmp_wait_raw_90, tmp_raw_de_90, tmp_wait_de_90, tmp_de_pg_90, tmp_sor_pg_90, tmp_raw_pg_90,tmp_count_de_pg)'
            ' select '
            '   ''', qry.table_name, ''' table_name,'
            '   sor_tpic_nm::text,'
			'   date_trunc(''hour'', data_hub_crt_ts) as hourly_timestamp,'
            '   NOW()::timestamp AS exec_date,'
            '   null as min_sor_raw,'
            '   MIN(wait_raw) as min_wait_raw,'
            '   MIN(raw_de)   as min_raw_de,'
            '   MIN(wait_de)  as min_wait_de,'
            '   MIN(de_pg)    as min_de_pg,'
            '   null   as min_sor_pg,'
            '   MIN(raw_pg)   as min_raw_pg,'
            '   null  as avg_sor_raw,'
            '   AVG(wait_raw) as avg_wait_raw,'
            '   AVG(raw_de)   as avg_raw_de,'
            '   AVG(wait_de)  as avg_wait_de,'
            '   AVG(de_pg)    as avg_de_pg,'
            '   null   as avg_sor_pg,'
            '   AVG(raw_pg)   as avg_raw_pg,'
            '   null  as max_sor_raw,'
            '   MAX(wait_raw) as max_wait_raw,'
            '   MAX(raw_de)   as max_raw_de,'
            '   MAX(wait_de)  as max_wait_de,'
            '   MAX(de_pg)    as max_de_pg,'
            '   null   as max_sor_pg,'
            '   MAX(raw_pg)   as max_raw_pg,'
            '   null as  sor_raw_90,'
            '   percentile_disc(0.90) within group (order by wait_raw) wait_raw_90,'
            '   percentile_disc(0.90) within group (order by raw_de)   raw_de_90,'
            '   percentile_disc(0.90) within group (order by wait_de)  wait_de_90,'
            '   percentile_disc(0.90) within group (order by de_pg)    de_pg_90,'
            '   null as   sor_pg_90,'
            '   percentile_disc(0.90) within group (order by raw_pg)   raw_pg_90,'
			'   COUNT(*)  as count_de_pg'
            ' 	from rawdata group by sor_tpic_nm, date_trunc(''hour'', data_hub_crt_ts)'
        );
    END LOOP;
    
        insert into daas_tm_prepared.dh_monitor_de_runtimes SELECT t.tmp_table_name, t.tmp_sor_tpic_nm, t.tmp_exec_date, date(t.tmp_stats_interval), t.tmp_stats_interval, t.tmp_min_sor_raw, t.tmp_min_wait_raw, t.tmp_min_raw_de, t.tmp_min_wait_de, t.tmp_min_de_pg, t.tmp_min_sor_pg, t.tmp_min_raw_pg, t.tmp_avg_sor_raw, t.tmp_avg_wait_raw, t.tmp_avg_raw_de, t.tmp_avg_wait_de, t.tmp_avg_de_pg, t.tmp_avg_sor_pg, t.tmp_avg_raw_pg, t.tmp_max_sor_raw, t.tmp_max_wait_raw, t.tmp_max_raw_de, t.tmp_max_wait_de, t.tmp_max_de_pg, t.tmp_max_sor_pg, t.tmp_max_raw_pg, t.tmp_sor_raw_90, t.tmp_wait_raw_90, t.tmp_raw_de_90, t.tmp_wait_de_90, t.tmp_de_pg_90, t.tmp_sor_pg_90, t.tmp_raw_pg_90, t.tmp_count_de_pg FROM tmp t where t.tmp_table_name is not null;
    RETURN QUERY SELECT t.tmp_table_name, t.tmp_sor_tpic_nm, t.tmp_stats_interval, t.tmp_exec_date, t.tmp_min_sor_raw, t.tmp_min_wait_raw, t.tmp_min_raw_de, t.tmp_min_wait_de, t.tmp_min_de_pg, t.tmp_min_sor_pg, t.tmp_min_raw_pg, t.tmp_avg_sor_raw, t.tmp_avg_wait_raw, t.tmp_avg_raw_de, t.tmp_avg_wait_de, t.tmp_avg_de_pg, t.tmp_avg_sor_pg, t.tmp_avg_raw_pg, t.tmp_max_sor_raw, t.tmp_max_wait_raw, t.tmp_max_raw_de, t.tmp_max_wait_de, t.tmp_max_de_pg, t.tmp_max_sor_pg, t.tmp_max_raw_pg, t.tmp_sor_raw_90, t.tmp_wait_raw_90, t.tmp_raw_de_90, t.tmp_wait_de_90, t.tmp_de_pg_90, t.tmp_sor_pg_90, t.tmp_raw_pg_90, t.tmp_count_de_pg FROM tmp t where t.tmp_table_name is not null;
END;
$function$
;