DROP FUNCTION IF EXISTS f_run_dh_get_train_details_by_car();
--function to get train details by car
CREATE OR REPLACE FUNCTION f_run_dh_get_train_details_by_car(p_eqp_init varchar(4), p_eqp_nbr varchar(10))
RETURNS TABLE 
(
eqp_init varchar(4),
eqp_nbr varchar(10),
stationscac text,
stationfsac text,
eventcode text,
eventstatuscode text,
sor_evt_ts timestamp without time zone,
sor_evt_ts_tz_dst_cd smallint,
rpt_sor_proc_ts timestamp without time zone,
sor_proc_ts_tz_dst_cd smallint,
stationsequencetimestamp text,
rk bigint)
AS $$
begin
return query
select RCAR.eqp_init, RCAR.eqp_nbr, 
train_char_2.char_val as stationScac,  
train_char_3.char_val as stationFsac,
substr(train_char_5.char_val,1,2) as eventCode,
substr(train_char_5.char_val,3,2) as eventStatusCode,
train.sor_evt_ts,
train.sor_evt_ts_tz_dst_cd,
train.rpt_sor_proc_ts,  
train.sor_proc_ts_tz_dst_cd,
train_char_4.char_val as stationSequenceTimestamp,
ROW_NUMBER() OVER (PARTITION BY RCAR.eqp_init, RCAR.eqp_nbr ORDER BY train.sor_evt_ts DESC) rk
from DAAS_TM_PREPARED.DH_TRSP_EVT TDE 
inner join daas_tm_prepared.dh_rcar_ref RCAR on (TDE.TRSP_EVT_KEY = rcar.rcar_key)
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (TDE.trsp_evt_key = cnvy_asct.cnvy_key and cnvy_asct.act_stus_ind = 1)
inner join daas_tm_prepared.dh_trsp_evt train on (cnvy_asct.asct_obj_key = train.trsp_evt_key and train.act_stus_ind = 1)
inner join daas_tm_prepared.dh_trsp_evt_char train_char_2 on (train.trsp_evt_key = train_char_2.trsp_evt_key and train_char_2.act_stus_ind = 1 and train_char_2.char_type_key = '2b77baf8b844500829fffd11357d1e243ee020adec77ea2cdc4b2934d8577d2a' ) -- scac event station carrier abbreviation 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_3 on (train.trsp_evt_key = train_char_3.trsp_evt_key and train_char_3.act_stus_ind = 1 and train_char_3.char_type_key = '61d9f08af8e5f9cc63abd8d3d1b42f2e3d4933e41449815f3574673e10cfe1fa' ) -- fsac event station FSAC 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_4 on (train.trsp_evt_key = train_char_4.trsp_evt_key and train_char_4.act_stus_ind = 1 and train_char_4.char_type_key = 'a4a7f99206741fbff8e56a0d3d32b2881ce75a59728c8aaa64c36918d0e40609' ) -- sequence timestamp 
inner join daas_tm_prepared.dh_trsp_evt_char train_char_5 on (train.trsp_evt_key = train_char_5.trsp_evt_key and train_char_5.act_stus_ind = 1 and train_char_5.char_type_key = '07814f276206869eb5b8e6777b5f06a1597ee49b2957f04b609d3c99093d11d7' ) -- event code 
where tde.act_stus_ind = 1 
and cnvy_asct.cnvy_type_Key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' --  'Railcar'   --
and cnvy_asct.asct_obj_type_key = '62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a' -- 'Train Event'   --
and RCAR.eqp_init = p_eqp_init
and RCAR.eqp_nbr = p_eqp_nbr;
end;
$$ LANGUAGE plpgsql;
