DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_trsp_evt_char_container_event_by_trsp_evt_key(p_trsp_evt_key bytea) cascade;
--  dependency: daas_tm_trusted."vContainerEvent"
CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_trsp_evt_char_container_event_by_trsp_evt_key(p_trsp_evt_key bytea)
returns table(
trsp_evt_key bytea,
sor_tpic_nm varchar(80),
"dataHubCreationTimestamp" timestamp,
sor_evt_ts timestamp ,
Event_Code text,
Event_Date text,
Event_Daylight_Saving_Time_Flag text,
Event_Status text,
Event_Time text,
Action text,
Equipment_Cycle_Id text,
--Equipment_Initial text, -- removed
--Equipment_Number text, -- removed
"notation" text,
Event_Date_Time_UTC text,
Event_Timestamp_Time_Zone_Daylight_Savings_Code text)
AS $$
begin

/*
a. use Event Status Code instead of Event Status from Gate Event
b. use Event Date and Event Time and Event date  from Intermodal Notes Event instead of effective date and effective timestamp
c. rename Cycle Identification to Cycle Id from Intermodal Notes Event
d. introduce Event Date Time UTC and Event Timestamp Time Zone Daylight Savings Code from Intermodal Notes Event

*/
return query
select main.trsp_evt_key, main.sor_tpic_nm, 
max(c.data_hub_crt_ts) as "dataHubCreationTimestamp",
max(c.sor_evt_ts) as sor_evt_ts,
max(case when ref_type.type_cd = 'Event Code' then c.char_val else null end ) as Event_Code ,
/*
max(case when (main.sor_tpic_nm like '%currInvEvt%' or main.sor_tpic_nm like '%yardEvent%' ) and ref_type.type_cd = 'Event Date' then c.char_val
when main.sor_tpic_nm like '%event-notation%' and ref_type.type_cd = 'Effective Date' then c.char_val 
else NULL end) as  Event_Date,
*/
max(case when ref_type.type_cd = 'Event Date' then c.char_val else null end ) as Event_Date ,
max(case when ref_type.type_cd = 'Event Daylight Saving Time Flag' then c.char_val else null end) as Event_Daylight_Saving_Time_Flag,
/*
max(case when (main.sor_tpic_nm like '%currInvEvt%' or main.sor_tpic_nm like '%event-notation%' ) and ref_type.type_cd = 'Event Status Code' then c.char_val
when main.sor_tpic_nm like '%yardEvent%' and ref_type.type_cd = 'Event Status' then c.char_val 
else NULL end) as Event_Status ,*/
max(case when ref_type.type_cd = 'Event Status Code' then c.char_val else null end ) as Event_Status ,

/*max(case when (main.sor_tpic_nm like '%currInvEvt%' or main.sor_tpic_nm like '%yardEvent%' ) and ref_type.type_cd = 'Event Time' then c.char_val
when main.sor_tpic_nm like '%event-notation%' and ref_type.type_cd = 'Effective Time' then c.char_val 
else NULL end) as  Event_Time,*/
max(case when ref_type.type_cd = 'Event Time' then c.char_val else null end ) as Event_Time ,
max(case when main.sor_tpic_nm like '%yardEvent%' and ref_type.type_cd = 'Action' then c.char_val else null end) as Action, -- action is for yard only
max(case when ( main.sor_tpic_nm like '%event-notation%' ) and ref_type.type_cd = 'Cycle Id' then c.char_val  
when main.sor_tpic_nm like '%yardEvent%' and ref_type.type_cd = 'Equipment Cycle Id' then c.char_val 
else NULL end ) as  Equipment_Cycle_Id,   -- okay
max(case when main.sor_tpic_nm like '%event-notation%' and ref_type.type_cd = 'Notation' then c.char_val else null end) as "notation",  --for evtnote only
max(case when ref_type.type_cd = 'Event Date Time UTC' then c.char_val else null end) as Event_Date_Time_UTC,  -- ok: yard and curevt, evt note has been implemented on iteration 15
max(case when ref_type.type_cd = 'Event Timestamp Time Zone Daylight Savings Code' then c.char_val else null end) 
as Event_Timestamp_Time_Zone_Daylight_Savings_Code  -- ok: evt note has been implemented on iteration 16
from daas_tm_prepared.dh_trsp_evt main
left join daas_tm_prepared.dh_trsp_evt_char c
on main.trsp_evt_key = c.trsp_evt_key
--and main.sor_tpic_nm = c.sor_tpic_nm
--and c.act_stus_ind = 1
left join daas_tm_prepared.dh_ref_type ref_type
on c.char_type_key = ref_type.type_key
where main.trsp_evt_key = p_trsp_evt_key and main.act_stus_ind = 1
group by main.trsp_evt_key, main.sor_tpic_nm ;
end;
$$ LANGUAGE plpgsql;

--select * from daas_tm_trusted.f_get_dh_trsp_evt_char_container_event_by_trsp_evt_key('81caea31d41ec457d609d0a5586544f9b633c5c7c1f980f44a9f371adc13c4d6');

