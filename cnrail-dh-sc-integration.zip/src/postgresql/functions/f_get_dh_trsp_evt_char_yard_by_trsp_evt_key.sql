DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_trsp_evt_char_yard_by_trsp_evt_key(p_trsp_evt_key bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_trsp_evt_char_yard_by_trsp_evt_key(p_trsp_evt_key bytea)
returns table(trsp_evt_key bytea,
"dataHubCreationTimestamp" timestamp,
Event_Code text,
Event_Date text,
Event_Daylight_Saving_Time_Flag text,
Event_Status text,
Event_Time text,
Action text,
Equipment_Cycle_Id text,
Equipment_Initial text,
Equipment_Number text,
"notation" text,
Event_Date_Time_UTC text,
Event_Timestamp_Time_Zone_Daylight_Savings_Code text)
AS $$
begin
return query
select main.trsp_evt_key,
max(c.data_hub_crt_ts) as "dataHubCreationTimestamp",
max(case when ref_type.type_cd = 'Event Code' then c.char_val else null end) as Event_Code,
max(case when ref_type.type_cd = 'Event Date' then c.char_val else null end) as Event_Date,
max(case when ref_type.type_cd = 'Event Daylight Saving Time Flag' then c.char_val else null end) as Event_Daylight_Saving_Time_Flag,
max(case when ref_type.type_cd = 'Event Status' or ref_type.type_cd = 'Event Status Code'  then c.char_val else null end) as Event_Status,
max(case when ref_type.type_cd = 'Event Time' then c.char_val else null end) as Event_Time,
max(case when ref_type.type_cd = 'Action' then c.char_val else null end) as Action,
max(case when ref_type.type_cd = 'Equipment Cycle Id' then c.char_val else null end) as Equipment_Cycle_Id,
max(case when ref_type.type_cd = 'Equipment Initial' then c.char_val else null end) as Equipment_Initial,
max(case when ref_type.type_cd = 'Equipment Number' then c.char_val else null end) as Equipment_Number,
max(case when ref_type.type_cd = 'Notation' then c.char_val else null end) as "notation",
max(case when ref_type.type_cd = 'Event Date Time UTC' then c.char_val else null end) as Event_Date_Time_UTC,
max(case when ref_type.type_cd = 'Event Timestamp Time Zone Daylight Savings Code' then c.char_val else null end) as Event_Timestamp_Time_Zone_Daylight_Savings_Code
from daas_tm_prepared.dh_trsp_evt main
left join daas_tm_prepared.dh_trsp_evt_char c
on main.trsp_evt_key = c.trsp_evt_key
and c.act_stus_ind = 1
left join daas_tm_prepared.dh_ref_type ref_type
on c.char_type_key = ref_type.type_key
where main.trsp_evt_key = p_trsp_evt_key and main.act_stus_ind = 1
group by main.trsp_evt_key;
end;
$$ LANGUAGE plpgsql;
