DROP FUNCTION IF EXISTS daas_tm_trusted."f_vUnitDetails"( text) cascade; -- 

CREATE or replace FUNCTION daas_tm_trusted."f_vUnitDetails"( p_equipmentIdentifier text )
RETURNS TABLE(

"equipmentIdentifier" text, 
"equipmentInitial"  text, 
"equipmentNumber"  text, 
"waybillNumber" text, 
"waybillIdentifier" text, 
"outsideLength"  text, 
"outsideLengthUnitOfMeasure"  text,
"railControlCode"  text,
"leaseeCode"  text,
"outsideHeight"  text,
"outsideHeightUnitOfMeasure"  text,
"outsideWidth"  text,
"outsideWidthUnitOfMeasure"  text,
"aarCarKind"  text,
"carKind"  text,
"mechanicalStatusCode1"  text,
"mechanicalStatusCode2"  text,
"mechanicalStatusCode3"  text,
"equipmentTareWeight"  text,
"equipmentTareWeightUnitOfMeasure"  text,
"equipmentOwnerAbbreviation"  text,
"badOrderCode"  text,
"eventAccountCode"  text,
"waterCarrierFlag"  text,
"railPrivateCode"  text,
"balanceOwedIndicator"  text,
"lastResponsibleRoadAbbreviation"  text
,"mechanicalStatusCode1EnglishDescription" text
,"mechanicalStatusCode1FrenchDescription"  text
,"mechanicalStatusCode2EnglishDescription" text
,"mechanicalStatusCode2FrenchDescription"  text
,"mechanicalStatusCode3EnglishDescription" text
,"mechanicalStatusCode3FrenchDescription"  text
    )
AS $$
BEGIN


-- part 1: parse parameters

create temporary table tbl_id ( id_val text, cnvy_key bytea PRIMARY KEY)
  on commit drop
  ;
insert into tbl_id(id_val, cnvy_key)
 select distinct cnvy.id_val, cnvy.cnvy_key
 from (select trim(unnest(string_to_array(p_equipmentIdentifier ,','))) as id_val ) as m 
 inner join daas_tm_prepared.dh_cnvy cnvy on m.id_val=cnvy.id_val;




-- part 2: create table tbl_waybill
create temporary table tbl_waybill 
on commit drop 
as 
with unitWaybill as (
select 
m.cnvy_key
,m.id_val
,main.id_val as "waybillIdentifier"
,g.char_val as "waybillStatus"
, main.ship_key
,d.char_val as "waybillNumber"
FROM tbl_id m 
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.cnvy_key= m.cnvy_key 
inner join daas_tm_prepared.dh_ship_char c
on c.act_stus_ind = 1
AND c.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
and cnvy.id_val=c.char_val 
inner join daas_tm_prepared.dh_ship_cond g on c.ship_key=g.ship_key 
and g.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083'  -- waybill status
and g.act_stus_ind=1
and g.char_val in ('A','S','O' )
inner join daas_tm_prepared.dh_ship main on main.ship_key=c.ship_key
and main.act_stus_ind =1
left join daas_tm_prepared.dh_ship_char d
on c.ship_key = d.ship_key and d.act_stus_ind = 1
AND d.char_type_key = '8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0' --Waybill Number
)
select p.cnvy_key
, p.id_val
,p."waybillIdentifier"
,p.ship_key
,p."waybillNumber"
from unitWaybill p
union all
select a.cnvy_key, a.id_val, null , null, null 
from tbl_id a
left join   unitWaybill m on a.id_val=m.id_val 
where m.id_val is null
;


create index tbl_waybill_io on tbl_waybill(cnvy_key);


-- part 3: return details
RETURN QUERY 

SELECT
cnvy.id_val as "equipmentIdentifier"
,cnvy_char.Equipment_Initial as "equipmentInitial"
,cast(cast(cnvy_char.Equipment_Number  as integer) as text) as "equipmentNumber"
,cnvy."waybillNumber"
,cnvy."waybillIdentifier"
,cnvy_char.Outside_Length as "outsideLength"
,cnvy_char.Outside_Length_uom as "outsideLengthUnitOfMeasure"
,cnvy_char.Rail_Control_Code as "railControlCode"
,cnvy_char.equipment_lessee_abbreviation as "leaseeCode"
,cnvy_char.Outside_Height as "outsideHeight"
,cnvy_char.Outside_Height_uom as "outsideHeightUnitOfMeasure"
,cnvy_char.Outside_Width as "outsideWidth"
,cnvy_char.outside_width_uom as "outsideWidthUnitOfMeasure"
,cnvy_char.AAR_Car_Kind as "aarCarKind"
,cnvy_char.Car_Kind as "carKind"
,cnvy_cond."mechanicalStatusCode1" as "mechanicalStatusCode1"
,cnvy_cond."mechanicalStatusCode2" as "mechanicalStatusCode2"
,cnvy_cond."mechanicalStatusCode3" as "mechanicalStatusCode3"
,cnvy_char.Equipment_Tare as "equipmentTareWeight"
,cnvy_char.Equipment_Tare_UOM as "equipmentTareWeightUnitOfMeasure"
,cnvy_char.Equipment_Owner_Abbreviation as "equipmentOwnerAbbreviation"
,cnvy_cond."badOrderCode"
,cnvy_cond."eventAccountCode"
,'waterCarrierFlag' as "waterCarrierFlag"
,cnvy_char.Rail_Private_Code  as "railPrivateCode"
,cnvy_cond."balanceOwedIndicator"
,cc1.char_val as "lastResponsibleRoadAbbreviation"
,trim(mc1.trsp_cd_dsc_eng) as "mechanicalStatusCode1EnglishDescription"
,trim(mc1.trsp_cd_dsc_fr)  as "mechanicalStatusCode1FrenchDescription"
,trim(mc2.trsp_cd_dsc_eng) as "mechanicalStatusCode2EnglishDescription"
,trim(mc2.trsp_cd_dsc_fr)  as "mechanicalStatusCode2FrenchDescription"
,trim(mc3.trsp_cd_dsc_eng) as "mechanicalStatusCode3EnglishDescription"
,trim(mc3.trsp_cd_dsc_fr)  as "mechanicalStatusCode3FrenchDescription"
FROM 

tbl_waybill cnvy
LEFT JOIN daas_tm_trusted.f_get_dh_cnvy_char_equipment_by_cnvy_key (cnvy.cnvy_key) cnvy_char ON 1= 1
left join daas_tm_trusted.f_get_dh_cnvy_cond_by_cnvy_key (cnvy.cnvy_key) cnvy_cond on 1= 1
left join daas_tm_prepared.dh_cnvy_cond cc1 on cc1.cnvy_key=cnvy.cnvy_key and cc1.act_stus_ind=1
and cc1.char_type_key='7cb27be3630145de8dcd9e5d36667fc8a65ca120e884532e891d6b3ce4fc3e00' --Last Responsible Road Abbreviation
left join daas_tm_prepared.dh_trsp_cd_ref  mc1 on mc1.trsp_cd=cnvy_cond."mechanicalStatusCode1" and mc1.trsp_cd_type='Mechanical Status Code'
left join daas_tm_prepared.dh_trsp_cd_ref  mc2 on mc2.trsp_cd=cnvy_cond."mechanicalStatusCode2" and mc2.trsp_cd_type='Mechanical Status Code'
left join daas_tm_prepared.dh_trsp_cd_ref  mc3 on mc3.trsp_cd=cnvy_cond."mechanicalStatusCode3" and mc3.trsp_cd_type='Mechanical Status Code'
;



END;$$ SECURITY DEFINER
LANGUAGE plpgsql;


--GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vUnitDetails"(  text) TO public;



--select * from daas_tm_trusted."f_vUnitDetails"('CNRU530254');

--select * from daas_tm_trusted."f_vUnitDetails"('SIMU600842,SIMU600844,STMU201533');


--select * from daas_tm_trusted."f_vUnitDetails"('SIMU600842,SIMU600844,STMU201533');


