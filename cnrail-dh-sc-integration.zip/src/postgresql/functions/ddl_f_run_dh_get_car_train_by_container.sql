DROP FUNCTION IF EXISTS f_run_dh_get_car_train_by_container(bytea) cascade;

CREATE OR REPLACE FUNCTION f_run_dh_get_car_train_by_container(p_cnvy_key bytea)
RETURNS TABLE 
(

sor_evt_ts timestamp without time zone,
rcar_key bytea,
eqp_init character varying(4),
eqp_nbr character varying(10),

"mechanicalStatusCode1"  text,
"mechanicalStatusCode2"  text,
"mechanicalStatusCode3"  text,

"trainIdentification" text,

"specialConditionCode1"       text,  
"specialConditionCode2"       text,   
"specialConditionCode3"       text,   
"specialConditionCode4"       text,   
"specialConditionCode5"       text,   
"specialConditionCode6"       text,         

"intermodalHandlingCode1"       text, 
"intermodalHandlingCode2"       text, 
"intermodalHandlingCode3"       text
)
AS $$
begin
return query

select
cont_car.sor_evt_ts as cnvy_asct_sor_evt_ts,
rcar.rcar_key,
RCAR.eqp_init,
RCAR.eqp_nbr,


substring(cnvy_cond_2.char_val from 1 for 2) AS "mechanicalStatusCode1",
substring(cnvy_cond_2.char_val from 3 for 2) AS "mechanicalStatusCode2",
substring(cnvy_cond_2.char_val from 5 for 2) AS "mechanicalStatusCode3",


sa_char.char_val as "trainIdentification",


substring(scond.char_val from 1 for 2) AS "specialConditionCode1",
substring(scond.char_val from 3 for 2) AS "specialConditionCode2",
substring(scond.char_val from 5 for 2) AS "specialConditionCode3",
substring(scond.char_val from 7 for 2) AS "specialConditionCode4",
substring(scond.char_val from 9 for 2) AS "specialConditionCode5",
substring(scond.char_val from 11 for 2) AS "specialConditionCode6",

substring(scond2.char_val from 1 for 2) AS "intermodalHandlingCode1",
substring(scond2.char_val from 3 for 2) AS "intermodalHandlingCode2",
substring(scond2.char_val from 5 for 2) AS "intermodalHandlingCode3"

from daas_tm_prepared.dh_cnvy_asct cont_car
inner join DAAS_TM_PREPARED.DH_TRSP_EVT TDE on (cont_car.asct_obj_key = TDE.trsp_evt_key and TDE.act_stus_ind = 1 and tDE.TRSP_EVT_TYPE_KEY =  'f6b530b0ea00c27747543eb950d814eb0aedce2edfdc5ac49313296fb2238f02') -- for 'Railcar Event' from Car Inventory)
inner join daas_tm_prepared.dh_rcar_ref RCAR on (TDE.TRSP_EVT_KEY = rcar.rcar_key)
left join daas_tm_prepared.dh_cnvy_cond cnvy_cond_2 on (tde.trsp_evt_key = cnvy_cond_2.cnvy_key and cnvy_cond_2.act_stus_ind = 1 and cnvy_cond_2.char_type_key = '665ce7a009722311c22f1e1011f1fc80fdc720870d1b70499485d5d9a766a538') -- mechanical status code
left join daas_tm_prepared.dh_ship_asct ship_asct on (TDE.trsp_evt_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
left join daas_tm_prepared.dh_ship_asct_char sa_char on (ship_asct.asct_key = sa_char.asct_key and sa_char.act_stus_ind =1 and sa_char.char_type_key = '06336730586527e31d5f9f12871d505364457590976fc83d32651a06869d3aa1')  -- Current Assignment
LEFT JOIN daas_tm_prepared.dh_ship_cond scond ON scond.act_stus_ind = 1 AND scond.ship_key = ship_asct.ship_key AND scond.char_type_key = '\x66336330643666383265373733376539653038643231383062376331323033663434326133376361343036363934343161363135363562326434383062383161' -- Special Condition Code
left join daas_tm_prepared.dh_ship_cond scond2 on scond2.act_stus_ind = 1 AND scond2.ship_key = ship_asct.ship_key AND scond2.char_type_key = '0097a93fa71285c12def51a43f540e023878d6109c95b081670914b9bc9cf972'  --Intermodal Handling Code
where cont_car.cnvy_key = p_cnvy_key
and cont_car.cnvy_type_key = '8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a'    ---   container, intermodal unit
and cont_car.asct_type_key = '0ba452470ff9f23b1d2e999f5afea823e1d7bab4913da2dc17aba3c6e784f011'    ---   Intra-BCD Container-Railcar
and cont_car.asct_obj_type_key = '394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9'    ---   Railcar
and cont_car.act_stus_ind = 1;
end;
$$ LANGUAGE plpgsql;