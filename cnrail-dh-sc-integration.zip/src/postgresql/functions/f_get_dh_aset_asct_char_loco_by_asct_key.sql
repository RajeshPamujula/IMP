CREATE OR REPLACE FUNCTION f_get_dh_aset_asct_char_loco_by_asct_key(p_asct_key bytea)
returns table(asct_key bytea,
Arrival_Date text,
Arrival_Sequence_Number text,
Setoff_SCAC text,
Setoff_Station_Number text,
Train_Day text,
Train_Departure_Date text,
Train_ID text,
Train_Section text,
Train_Sequence_Number text,
Train_Symbol text,
Train_Type text)
AS $$
begin
return query
select main.asct_key,
max(case when ref_type.type_cd = 'Arrival Date' then c.char_val else null end) as Arrival_Date,
max(case when ref_type.type_cd = 'Arrival Sequence Number' then c.char_val else null end) as Arrival_Sequence_Number,
max(case when ref_type.type_cd = 'Setoff SCAC' then c.char_val else null end) as Setoff_SCAC,
max(case when ref_type.type_cd = 'Setoff Station Number' then c.char_val else null end) as Setoff_Station_Number,
max(case when ref_type.type_cd = 'Train Day' then c.char_val else null end) as Train_Day,
max(case when ref_type.type_cd = 'Train Departure Date' then c.char_val else null end) as Train_Departure_Date,
max(case when ref_type.type_cd = 'Train ID' then c.char_val else null end) as Train_ID,
max(case when ref_type.type_cd = 'Train Section' then c.char_val else null end) as Train_Section,
max(case when ref_type.type_cd = 'Train Sequence Number' then c.char_val else null end) as Train_Sequence_Number,
max(case when ref_type.type_cd = 'Train Symbol' then c.char_val else null end) as Train_Symbol,
max(case when ref_type.type_cd = 'Train Type' then c.char_val else null end) as Train_Type
from daas_tm_prepared.dh_aset_asct main
left  join daas_tm_prepared.dh_aset_asct_char c
on    main.asct_key = c.asct_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key and main.act_stus_ind = 1
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;
