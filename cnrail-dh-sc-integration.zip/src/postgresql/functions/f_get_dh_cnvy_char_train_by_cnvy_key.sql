CREATE OR REPLACE FUNCTION f_get_dh_cnvy_char_train_by_cnvy_key(p_cnvy_key bytea)
returns table(cnvy_key bytea,
Train_Departure_Date text,
Train_Section text,
Train_Symbol text,
Train_Type text,
Train_Unique_Id text)
AS $$
begin
return query
select main.cnvy_key,
max(case when ref_type.type_cd = 'Train Departure Date' then c.char_val else null end) as Train_Departure_Date,
max(case when ref_type.type_cd = 'Train Section' then c.char_val else null end) as Train_Section,
max(case when ref_type.type_cd = 'Train Symbol' then c.char_val else null end) as Train_Symbol,
max(case when ref_type.type_cd = 'Train Type' then c.char_val else null end) as Train_Type,
max(case when ref_type.type_cd = 'Train Unique Id' then c.char_val else null end) as Train_Unique_Id
from daas_tm_prepared.dh_cnvy main
left  join daas_tm_prepared.dh_cnvy_char c
on    main.cnvy_key = c.cnvy_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.cnvy_key = p_cnvy_key and main.act_stus_ind = 1
group by main.cnvy_key;
end;
$$ LANGUAGE plpgsql;
