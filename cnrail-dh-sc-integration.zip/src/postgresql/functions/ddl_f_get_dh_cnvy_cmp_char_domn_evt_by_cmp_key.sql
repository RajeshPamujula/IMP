DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_cnvy_cmp_char_domn_evt_by_cmp_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_cnvy_cmp_char_domn_evt_by_cmp_key(p_cnvy_cmp_key bytea )
/*

drop cascades to view daas_tm_trusted."vIntermodalUnitUpdateHistory"

ex: select * from daas_tm_trusted.f_get_dh_cnvy_cmp_char_domn_evt_by_cmp_key('abcd' );
*/
RETURNS TABLE 
(
"conveyorCompositeKey" bytea,
"sourceProcessDateTime" timestamp without time zone,
"stopOrderAuthorization" text
)
AS $$
begin
return query

with prvs_cnvy_cmp_char as (
select ref.type_cd,  a.char_val, a.sor_proc_ts
,dense_rank() over(PARTITION BY a.cnvy_cmp_key, ref.type_cd  order by a.sor_proc_ts desc, a.data_hub_crt_ts desc) as rk
,a.cnvy_cmp_key
from daas_tm_prepared.dh_cnvy_cmp_char_domn_evt a
inner join daas_tm_prepared.dh_ref_type ref on type_key=a.char_type_key
where a.cnvy_cmp_key=p_cnvy_cmp_key

)
select 
cnvy_cmp_key as "conveyorCompositeKey",
max(sor_proc_ts) as"eventCreationDateTime",
max(case when type_cd ='Stop Order Authorization' then char_val else null end) as "stopOrderAuthorization"
from prvs_cnvy_cmp_char
where rk=2
group by 1;

end;
$$
LANGUAGE 'plpgsql';
