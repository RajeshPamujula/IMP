DROP FUNCTION IF EXISTS daas_tm_trusted.f_run_dh_get_cnvy_char_by_container(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_run_dh_get_cnvy_char_by_container(p_cnvy_key bytea)
RETURNS TABLE 
(
cnvy_key  bytea,
"conveyorType" character varying(50),  

"equipmentInitial"  text,
"equipmentNumber"  text,
"containerInitial"  text,
"containerNumber"  text,
"chassisInitial"  text,
"chassisNumber"  text,
"carKind"  text,
"outsideLength" text,
"outsideLengthFeet"  text,
"outsideLengthInches"  text,
"outsideLengthUnitOfMeasure" text,
"outsideHeight" text,
"outsideHeightFeet"  text,
"outsideHeightInches"  text,
"outsideHeightUnitOfMeasure" text,
"outsideWidth" text,
"outsideWidthFeet"  text,
"outsideWidthInches"  text,
"outsideWidthUnitOfMeasure" text,
"trueKingpin"   text,
"equipmentTareLb" text,
"equipmentTareWeight" text,
"equipmentTareWeightUnitOfMeasure" text,
"loadLimit" text,
"equipmentOwnerAbbreviation" text,
"equipmentOwnerType" text,
"vesselOwner" text,
"conveyorCharProcessTimestamp" timestamp without time zone,
"dataHubCreationTimestamp"  timestamp without time zone,
"eventTimestamp"  timestamp without time zone,
"equipmentLesseeAbbreviation" text
)
AS $$
begin
return query

select  a.cnvy_key,
b.type_cd  as "conveyorType",
case when max(case when c.type_cd ='Equipment Initial' then cnvy_char.char_val else null end) is not null then max(case when c.type_cd ='Equipment Initial' then cnvy_char.char_val else null end)
when max(case when c.type_cd ='Chassis Number' then cnvy_char.char_val else null end) is not null then max(case when c.type_cd ='Chassis Number' then cnvy_char.char_val else null end)
else max(case when c.type_cd ='Container Initial' then cnvy_char.char_val else null end) end  as "equipmentInitial",

case when max(case when c.type_cd ='Equipment Number' then cnvy_char.char_val else null end) is not null then max(case when c.type_cd ='Equipment Number' then cnvy_char.char_val else null end)
when max(case when c.type_cd ='Chassis Number' then cnvy_char.char_val else null end) is not null then max(case when c.type_cd ='Chassis Number' then cnvy_char.char_val else null end)
else max(case when c.type_cd ='Container Number' then cnvy_char.char_val else null end) end  as "equipmentNumber",

max(case when c.type_cd ='Container Initial' then cnvy_char.char_val else null end) as "containerInitial",
max(case when c.type_cd ='Container Number' then cnvy_char.char_val else null end) as "containerNumber",
max(case when c.type_cd ='Chassis Initial' then cnvy_char.char_val else null end) as "chassisInitial",
max(case when c.type_cd ='Chassis Number' then cnvy_char.char_val else null end) as "chassisNumber",
max(case when c.type_cd ='Car Kind' then cnvy_char.char_val else null end) as "carKind",

max(case when c.type_cd = 'Outside Length' then cnvy_char.char_val else null end) as "outsideLength",
max(case when c.type_cd ='Outside Length Feet' then cnvy_char.char_val else null end) as "outsideLengthFeet",
max(case when c.type_cd ='Outside Length Inches' then cnvy_char.char_val else null end) as "outsideLengthInches",
max(case when c.type_cd = 'Outside Length UOM' then cnvy_char.char_val else null end) as "outsideLengthUnitOfMeasure",

max(case when c.type_cd = 'Outside Height' then cnvy_char.char_val else null end) as "outsideHeight",
max(case when c.type_cd ='Outside Height Feet' then cnvy_char.char_val else null end) as "outsideHeightFeet",
max(case when c.type_cd ='Outside Height Inches' then cnvy_char.char_val else null end) as "outsideHeightInches",
max(case when c.type_cd = 'Outside Height UOM' then cnvy_char.char_val else null end) as "outsideHeightUnitOfMeasure",

max(case when c.type_cd = 'Outside Width' then cnvy_char.char_val else null end) as "outsideWidth",
max(case when c.type_cd ='Outside Width Feet' then cnvy_char.char_val else null end) as "outsideWidthFeet",
max(case when c.type_cd ='Outside Width Inches' then cnvy_char.char_val else null end) as "outsideWidthInches",
max(case when c.type_cd = 'Outside Width UOM' then cnvy_char.char_val else null end) as "outsideWidthUnitOfMeasure",

max(case when c.type_cd ='True Kingpin' then cnvy_char.char_val else null end) as "trueKingpin",
max(case when c.type_cd ='Equipment Tare LB' then cnvy_char.char_val else null end) as "equipmentTareLb",
max(case when c.type_cd ='Equipment Tare' then cnvy_char.char_val else null end) as "equipmentTare",
max(case when c.type_cd ='Equipment Tare UOM' then cnvy_char.char_val else null end) as "equipmentTareUnitOfMeasure",
max(case when c.type_cd ='Load Limit' then cnvy_char.char_val else null end) as "loadLimit",

max(case when c.type_cd ='Equipment Owner Abbreviation' then cnvy_char.char_val else null end) as "equipmentOwnerAbbreviation",
max(case when c.type_cd ='Equipment Owner Type' then cnvy_char.char_val else null end) as "equipmentOwnerType",
max(case when c.type_cd ='Vessel Owner' then cnvy_char.char_val else null end) as "vesselOwner",
max(cnvy_char.rpt_sor_proc_ts) as "conveyorCharProcessTimestamp",
max(cnvy_char.data_hub_crt_ts) as "dataHubCreationTimestamp", 
max(cnvy_char.sor_evt_ts) as "eventTimestamp", 
max(case when c.type_cd ='Equipment Lessee Abbreviation' then cnvy_char.char_val else null end) as "equipmentLesseeAbbreviation"

from daas_tm_prepared.dh_cnvy a
inner join daas_tm_prepared.dh_ref_type b on a.cnvy_type_key=b.type_key and a.act_stus_ind=1 
--and ( a.cnvy_type_key ='8d8e33739978092cfc719dd0996498c1b1fb334c3b75d98fe6c73e8fb767a91a'  -- Container
--or a.cnvy_type_key ='20ba3d6edbfbaab0653bd3314bf4ec3a1f6049daa8ab757fd2c8621944a3f4cf'  ----Chassis
--or  a.cnvy_type_key = 'e91b3bb060fea6f9d741db9db19e3328be5f64f34429ff2e66aa176cdcf24133'  -- intermodal unit
--) 
left join daas_tm_prepared.dh_cnvy_char cnvy_char on cnvy_char.cnvy_key = a.cnvy_key and  cnvy_char.act_stus_ind=1
left join  daas_tm_prepared.dh_ref_type c on cnvy_char.char_type_key = c.type_key
where a.cnvy_key=p_cnvy_key
group by 1,2;
end;
$$ LANGUAGE plpgsql;
