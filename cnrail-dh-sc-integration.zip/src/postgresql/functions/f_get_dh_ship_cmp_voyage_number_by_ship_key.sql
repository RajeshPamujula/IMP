DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_cmp_voyage_number_by_ship_key(bytea) cascade;

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_cmp_voyage_number_by_ship_key(p_ship_key bytea)
RETURNS TABLE
(ship_key bytea,
"referenceNumberCode" text,
"voyageNumber" text 
)
AS $$
begin
return query
SELECT distinct 
  a.ship_key
, a.id_val as "referenceNumberCode"
,b.char_val as "voyageNumber"
FROM daas_tm_prepared.dh_ship_cmp a
INNER JOIN daas_tm_prepared.dh_ship_cmp_char b  ON a.ship_cmp_key = b.ship_cmp_key and a.act_stus_ind = 1 and b.act_stus_ind=1
and b.char_type_key='d4f53dc6ab8256d581e1b5c2671de5860d6fd862889c99bc1a0b527c6e3aad0e' ---'Reference Number'
where a.id_val = '&7'  -- change to &7
and a.ship_key = p_ship_key  --'555c18c4b97ef3f904afc8e30e71d8567b842c9b46323ebfb5e4f7f003ccbf4d'  --
;
end;
$$
LANGUAGE 'plpgsql';


--select * from daas_tm_trusted.f_get_dh_ship_cmp_voyage_number_by_ship_key('555c18c4b97ef3f904afc8e30e71d8567b842c9b46323ebfb5e4f7f003ccbf4d');