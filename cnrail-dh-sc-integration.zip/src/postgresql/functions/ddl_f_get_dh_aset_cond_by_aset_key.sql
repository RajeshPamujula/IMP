DROP FUNCTION IF EXISTS f_get_dh_aset_cond_by_aset_key(bytea) cascade;


CREATE OR REPLACE FUNCTION f_get_dh_aset_cond_by_aset_key(p_aset_key bytea)
RETURNS TABLE 
(
aset_key bytea,
"latitude" text,
"locomotiveLocationCode" text,
"locomotiveOperatingStatusCode" text,
"longitude" text
)
AS $$
begin
return query
select
a.aset_key,
aset1.char_val as "latitude",
aset2.char_val as "locomotiveLocationCode",
aset3.char_val as "locomotiveOperatingStatusCode",
aset4.char_val as "longitude"
from daas_tm_prepared.dh_aset a
left join daas_tm_prepared.dh_aset_cond  aset1 on (a.aset_key = aset1.aset_key and aset1.act_stus_ind = 1 and aset1.char_type_key = '63b1339bfe1572688e3e42e39d7e6998fb5429f0257868bdaf79ca8b03129905') -- Latitude
left join daas_tm_prepared.dh_aset_cond  aset2 on (a.aset_key = aset2.aset_key and aset2.act_stus_ind = 1 and aset2.char_type_key = '3ce4380d9151bfc571dfa300027e32d0e21b43727aa1fe86a88399bd6a03c9a4') -- Locomotive Location Code
left join daas_tm_prepared.dh_aset_cond  aset3 on (a.aset_key = aset3.aset_key and aset3.act_stus_ind = 1 and aset3.char_type_key = '2a04009a57b3f9d53626268239cca9163f437bb0760928eeb6d5755a48b7e830') -- Locomotive Operating Status Code
left join daas_tm_prepared.dh_aset_cond  aset4 on (a.aset_key = aset4.aset_key and aset4.act_stus_ind = 1 and aset4.char_type_key = 'af6a730d48880a4e1fbd4f0d3b6b48b6568557fbc74bceb543457b106c57daad') -- Longitude
where a.aset_key = p_aset_key
and a.act_stus_ind = 1;
end;
$$
LANGUAGE 'plpgsql';
