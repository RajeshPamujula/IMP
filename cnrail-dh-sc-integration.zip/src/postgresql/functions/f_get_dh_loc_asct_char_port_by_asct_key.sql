CREATE OR REPLACE FUNCTION f_get_dh_loc_asct_char_port_by_asct_key(p_asct_key bytea)
returns table(asct_key bytea,
eeSea_port_code text,
Port_Cut_off text)
AS $$
begin
return query
select main.asct_key,
max(case when ref_type.type_cd = 'eeSea port code' then c.char_val else null end) as eeSea_port_code,
max(case when ref_type.type_cd = 'Port Cut-off' then c.char_val else null end) as Port_Cut_off
from daas_tm_prepared.dh_loc_asct main
left  join daas_tm_prepared.dh_loc_asct_char c
on    main.asct_key = c.asct_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.asct_key = p_asct_key and main.act_stus_ind = 1
group by main.asct_key;
end;
$$ LANGUAGE plpgsql;

