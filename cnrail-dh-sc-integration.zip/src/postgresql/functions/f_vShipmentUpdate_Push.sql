DROP FUNCTION IF EXISTS daas_tm_trusted."f_vShipmentUpdate_Push"(timestamp , text) cascade; -- 


CREATE or replace FUNCTION daas_tm_trusted."f_vShipmentUpdate_Push"(p_data_hub_crt_ts timestamp, p_waybillNumber text )
RETURNS TABLE(

"dataHubCreationTimestamp"  timestamp,
"eventTimestamp"  timestamp,
"waybillNumber"   text,
"waybillIdentification"   text,

"shipperCity333"   text,
"shipperProvinceState"   text,
"shipperStationNumber"   text,
"shipperCarrierAbbreviation"   text,
"shipperCustomerNumber"   text,

"consigneeCity333"   text,
"consigneeProvinceState"   text,
"consigneeStationNumber"   text,
"consigneeCarrierAbbreviation"   text,
"consigneeCustomerNumber"   text,

"payingCustomerCity333"   text,
"payingCustomerProvinceState"   text,
"payingCustomerStationNumber"   text,
"payingCustomerCarrierAbbreviation"   text,
"payingCustomerCustomerNumber"   text,

"careOfCity333"   text,
"careOfProvinceState"   text,
"careOfStationNumber"   text,
"careOfCarrierAbbreviation"   text,
"careOfCustomerNumber"   text,

"finalDestinationCity333"   text,
"finalDestinationProvinceState"   text,
"finalDestinationStationNumber"   text,
"finalDestinationCarrierAbbreviation"   text,
"finalDestinationCustomerNumber"   text,

"priorOriginCity333"   text,
"priorOriginProvinceState"   text,
"priorOriginStationNumber"   text,
"priorOriginCarrierAbbreviation"   text,
"priorOriginCustomerNumber"   text,

"shipFromCity333"   text,
"shipFromProvinceState"   text,
"shipFromStationNumber"   text,
"shipFromCarrierAbbreviation"   text,
"shipFromCustomerNumber"   text,


"billOfLadingNumber"    text,
"carKind"   text,
"customerSuppliedNetWeight"   text,
"customerSuppliedWeightUom"   text,
"destinationRamp333"   text,
"destinationRamp333ProvinceStateCode"   text,
"equipmentIdentification"   text,
"loadEmptyStatusCode"   text,
"operatingCity"   text,
"operatingCityProvinceStateCode"   text,
"operatingDestinationFsac"   text,
"operatingDestinationScac"   text,
"railOrigin333"   text,
"originRamp333"   text,
"originRamp333ProvinceStateCode"   text,
"railOrigin333ProvinceStateCode"   text,
"standardTransportationCommodityCode"   text,
"waybillTypeCode"   text,


"specialConditionCode1"   text,
"specialConditionCode2"   text,
"specialConditionCode3"   text,
"specialConditionCode4"   text,
"specialConditionCode5"   text,
"specialConditionCode6"   text,

"waybillStatusCode"   text,


ship_key  bytea  




    )
AS $$
BEGIN

-- part 1: change capture and apply the optional filter , limit 1000 records
create temporary table tbl_changes ( ship_key bytea PRIMARY KEY)  
on commit drop
;

insert into tbl_changes	(ship_key)
with "vShipmentChange" as (
select ship.ship_key, ship.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship ship
where ship.data_hub_crt_ts > p_data_hub_crt_ts
and ship.act_stus_ind=1
union 
select ship_char.ship_key, ship_char.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_char ship_char 
where ship_char.data_hub_crt_ts > p_data_hub_crt_ts
and ship_char.act_stus_ind=1
union 
select ship_cond.ship_key, ship_cond.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_cond ship_cond
where ship_cond.data_hub_crt_ts > p_data_hub_crt_ts
and ship_cond.act_stus_ind=1
/*union
select a.ship_key, b.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_asct a
inner join daas_tm_prepared.dh_ship_asct_char b on a.asct_key=b.asct_key
where b.sor_tpic_nm  like '%waybill%'
and b.act_stus_ind =1
and b.data_hub_crt_ts > p_data_hub_crt_ts
*/
union
select ship_cmp.ship_key, ship_cmp_char.data_hub_crt_ts AS "dataHubCreationTimestamp"
from daas_tm_prepared.dh_ship_cmp ship_cmp
inner join daas_tm_prepared.dh_ship_cmp_char ship_cmp_char on ship_cmp_char.ship_cmp_key = ship_cmp.ship_cmp_key
where ship_cmp.act_stus_ind=1
and ship_cmp_char.sor_tpic_nm not like '%reference%'
and ship_cmp_char.data_hub_crt_ts > p_data_hub_crt_ts
and ship_cmp_char.act_stus_ind=1
union 
select sc.ship_key, cc.data_hub_crt_ts
from daas_tm_prepared.dh_cnvy_char cc
inner join daas_tm_prepared.dh_cnvy cnvy on cc.cnvy_key = cnvy.cnvy_key
inner join daas_tm_prepared.dh_ship_char sc on sc.char_val =cnvy.id_val 
and sc.char_type_key='31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
where cc.sor_tpic_nm like '%wayBill%' and cc.act_stus_ind=1
and cc.char_type_key='dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8'  -- car kind
and cc.data_hub_crt_ts > p_data_hub_crt_ts
)
select a.ship_key
--, max("dataHubCreationTimestamp") as data_hub_crt_ts
from "vShipmentChange" a
group by a.ship_key
order by max(a."dataHubCreationTimestamp") 
limit 2000;




-- part 2: parse parameter string to temporay table 
if p_waybillNumber is not null and  p_waybillNumber<>''
then
create temporary table tbl_id ( id_val text, ship_key bytea PRIMARY KEY)  
on commit drop
;
insert into tbl_id(id_val, ship_key)
 select distinct m.id_val, sc.ship_key
 from (select trim(unnest(string_to_array(p_waybillNumber ,','))) as id_val ) as m 
 inner join daas_tm_prepared.dh_ship_char  sc on m.id_val=sc.char_val 
 and sc.char_type_key='8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0' ; --Waybill Number;
delete from tbl_changes where not exists (Select 1 from tbl_id where tbl_id.ship_key=tbl_changes.ship_key );
end if ;


create temporary table tbl_changes_final
( ship_key bytea , 
cnvy_key bytea,
PRIMARY KEY(ship_key,cnvy_key))  
on commit drop
;

insert into tbl_changes_final(ship_key, cnvy_key)
select distinct  a.ship_key, cnvy.cnvy_key
from tbl_changes a
inner join daas_tm_prepared.dh_ship_char b on a.ship_key=b.ship_key 
and b.char_type_key ='31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.id_val=b.char_val;

 
 

-- part 3: return details
RETURN QUERY 
select
greatest(ship.data_hub_crt_ts, ship_char."dataHubCreationTimestamp",  cnvy_char.data_hub_crt_ts, b.data_hub_crt_ts , ship_cond."dataHubCreationTimestamp") as "dataHubCreationTimestamp"
,greatest(ship.sor_evt_ts, ship_char."eventTimestamp", cnvy_char.sor_evt_ts, b.sor_evt_ts, ship_cond."eventTimestamp") as "eventTimestamp"
, wbnbr.char_val as "waybillNumber"
, ship.id_val as "waybillIdentification"

, b."shipperCity333"
, b."shipperProvinceState"
, b."shipperStationNumber"
, b."shipperCarrierAbbreviation"
, b."shipperCustomerNumber"


, b."consigneeCity333"
, b."consigneeProvinceState"
, b."consigneeStationNumber"
, b."consigneeCarrierAbbreviation"
, b."consigneeCustomerNumber"

, b."payingCustomerCity333"
, b."payingCustomerProvinceState"
, b."payingCustomerStationNumber"
, b."payingCustomerCarrierAbbreviation"
, b."payingCustomerCustomerNumber"

, b."careOfCity333"
, b."careOfProvinceState"
, b."careOfStationNumber"
, b."careOfCarrierAbbreviation"
, b."careOfCustomerNumber"


, b."finalDestinationCity333"
, b."finalDestinationProvinceState"
, b."finalDestinationStationNumber"
, b."finalDestinationCarrierAbbreviation"
, b."finalDestinationCustomerNumber"

, b."priorOriginCity333"
, b."priorOriginProvinceState"
, b."priorOriginStationNumber"
, b."priorOriginCarrierAbbreviation"
, b."priorOriginCustomerNumber"



, b."shipFromCity333"
, b."shipFromProvinceState"
, b."shipFromStationNumber"
, b."shipFromCarrierAbbreviation"
, b."shipFromCustomerNumber"




,ship_char.bill_of_lading_number as "billOfLadingNumber"
,cnvy_char.char_val as "carKind"
,ship_char.customer_supplied_net_weight as "customerSuppliedNetWeight"
,ship_char.Customer_Supplied_Weight_UOM as "customerSuppliedWeightUom"
,ship_char.destination_ramp_333 as "destinationRamp333"
,ship_char.destination_ramp_333_province_state_code as "destinationRamp333ProvinceStateCode"
,ship_char.equipment_id as "equipmentIdentification"
,ship_char.load_empty_status_code as "loadEmptyStatusCode"
,ship_char.operating_city as "operatingCity"
,ship_char.operating_city_province_state_code as "operatingCityProvinceStateCode"
,ship_char.operating_destination_fsac as "operatingDestinationFsac"
,ship_char.operating_destination_scac as "operatingDestinationScac"
,ship_char.rail_origin_333 as "railOrigin333"
,ship_char.origin_ramp_333 as "originRamp333"
,ship_char.origin_ramp_333_province_state_code as "originRamp333ProvinceStateCode"
,ship_char.rail_origin_333_province_state_code as "railOrigin333ProvinceStateCode"
,ship_char.standard_transportation_commodity_code as "standardTransportationCommodityCode"
,ship_char.Waybill_Record_Type as "waybillTypeCode"


,ship_cond."specialConditionCode1"
,ship_cond."specialConditionCode2"
,ship_cond."specialConditionCode3"
,ship_cond."specialConditionCode4"
,ship_cond."specialConditionCode5"
,ship_cond."specialConditionCode6"

,ship_cond."waybillStatusCode"

,ship.ship_key --techincal field used with vShipmentChange




from tbl_changes_final  
inner join daas_tm_prepared.dh_ship ship on tbl_changes_final.ship_key=ship.ship_key
inner join daas_tm_prepared.dh_ship_char as wbnbr on wbnbr.ship_key =tbl_changes_final.ship_key 
and wbnbr.act_stus_ind=1
and wbnbr.char_type_key='8e84c3aded0761bb1ad23fdf33a9a5034d66956295218dc0b6def535530ac3f0' --Waybill Number
inner join daas_tm_trusted.f_get_dh_ship_char_waybill_by_ship_key(tbl_changes_final.ship_key) ship_char on true
left join daas_tm_trusted.f_get_dh_ship_cond_bp_role_char_waybill_by_ship_key(tbl_changes_final.ship_key) b on true

left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(tbl_changes_final.ship_key) as ship_cond on true
left join daas_tm_prepared.dh_cnvy cnvy on (tbl_changes_final.cnvy_key = cnvy.cnvy_key and cnvy.act_stus_ind = 1)
left join daas_tm_prepared.dh_cnvy_char cnvy_char on (cnvy.cnvy_key = cnvy_char.cnvy_key and cnvy_char.act_stus_ind = 1 
and cnvy_char.char_type_key = 'dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8' )



where ship.act_stus_ind=1 
and greatest(ship.data_hub_crt_ts, ship_char."dataHubCreationTimestamp",  cnvy_char.data_hub_crt_ts, b.data_hub_crt_ts , ship_cond."dataHubCreationTimestamp")
> p_data_hub_crt_ts
--now() - interval '10 minutes'
;

END;$$ SECURITY DEFINER
LANGUAGE plpgsql;

/*
GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vShipmentUpdate_Push"( timestamp , text) TO public;


select * from daas_tm_trusted."f_vShipmentUpdate_Push"(now()::timestamp - interval '45 days', NULL);
select * from daas_tm_trusted."f_vShipmentUpdate_Push"(now()::timestamp - interval '45 days', '');

select * from daas_tm_trusted."f_vShipmentUpdate_Push"(now()::timestamp - interval '45 days', '989999,393399,403868,396791');
*/
