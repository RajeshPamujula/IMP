DROP FUNCTION IF EXISTS daas_tm_trusted."f_vIntermodalUnitUpdateHistory"(timestamp , text) cascade; -- 

CREATE or replace FUNCTION daas_tm_trusted."f_vIntermodalUnitUpdateHistory"(p_data_hub_crt_ts timestamp, p_unitIdentification text )
RETURNS TABLE(
cnvy_key bytea,
"dataHubCreationTimestamp"  timestamp,
"eventTimestamp"   timestamp,
"conveyorType"   character varying(50),
"equipmentInitial"   text,
"equipmentNumber"   text,
"unitIdentification"   text,
"carKind"   text,
"badOrderCode"   text,
"loadSheetHoldCode"   text,
"storageChargeIndicator"   text,  
"specialConditionCode1"   text,
"specialConditionCode2"   text,
"specialConditionCode3"   text,
"specialConditionCode4"   text,
"specialConditionCode5"   text,
"specialConditionCode6"   text,
"mechanicalStatusCode1"   text,
"mechanicalStatusCode2"   text,
"mechanicalStatusCode3"   text,
"firstStorageChargeDate"   text,  
"intermodalHandlingCode1"   text,
"intermodalHandlingCode2"   text,
"intermodalHandlingCode3"   text,
"outsideLength"   text,
"outsideLengthUnitOfMeasure"   text,
"outsideHeight"   text,
"outsideHeightUnitOfMeasure"   text,
"outsideWidth"   text,
"outsideWidthUnitOfMeasure"   text,
"trueKingpin"   text,
"equipmentTareWeight"   text,
"equipmentTareWeightUnitOfMeasure"   text,
"loadLimit"   text,
"equipmentOwnerAbbreviation"   text,
"unitLeasee"   text,
"emptyOrderNumber"    text,

"previousEquipmentTareWeight"    text,
"previousEquipmentTareWeightUnitOfMeasure"    text,
"previousEquipmentTareWeightPound"    text,
"previousUnitLeasee"	    text,													  
"previousLoadLimit"    text,
"previousLoadLimitUnitOfMeasure"    text,
"previousEquipmentOwnerAbbreviation"    text,

"previousBadOrderCode"    text,
"previousMechanicalStatusCode1"    text,
"previousMechanicalStatusCode2"    text,
"previousMechanicalStatusCode3"    text,

"previousIntermodalHandlingCode1"    text,
"previousIntermodalHandlingCode2"    text,
"previousIntermodalHandlingCode3"    text,
"previousSpecialConditionCode1"    text,
"previousSpecialConditionCode2"    text,
"previousSpecialConditionCode3"    text,
"previousSpecialConditionCode4"    text,
"previousSpecialConditionCode5"    text,
"previousSpecialConditionCode6"    text,

"previousEmptyOrderNumber"    text,
"previousLoadSheetHoldCode"    text,
"eventAccountCode"  text,
"previousEventAccountCode" text,
"previousFirstStorageChargeDate" text,

"stopOrderAuthorization" text,
"previousStopOrderAuthorization" text
    )
AS $$
BEGIN

-- part 1: change capture and apply the optional filter , limit 1000 records
create temporary table tbl_changes ( id_val text, cnvy_key bytea PRIMARY KEY)  on commit drop;
insert into tbl_changes	(id_val ,cnvy_key)


with "vIntermodalUnitChange" as (
select a.id_val as "unitIdentification", a.cnvy_key,  ship_asct.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy a 
inner join daas_tm_prepared.dh_ship_asct ship_asct on (a.cnvy_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
where a.act_stus_ind =1 
and a.cnvy_type_key not in (
'd6663f4bdac4e24ddee5b7e3f8ebafbc903c50890d331ece54b7225f9b9a1a79' , --Tractor
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
)
and ship_asct.data_hub_crt_ts > p_data_hub_crt_ts --(now() - interval '2 hours ')
union
-- new change capture
/*
select a.id_val as "unitIdentification", a.cnvy_key,  ship_cond.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy a 
inner join daas_tm_prepared.dh_ship_asct ship_asct on (a.cnvy_key = ship_asct.asct_obj_key and ship_asct.act_stus_ind = 1)
inner join daas_tm_prepared.dh_ship_cond ship_cond on ship_asct.ship_key=ship_cond.ship_key and ship_cond.act_stus_ind=1
where a.act_stus_ind =1 
and a.cnvy_type_key not in (
'd6663f4bdac4e24ddee5b7e3f8ebafbc903c50890d331ece54b7225f9b9a1a79' , --Tractor
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
)
and ship_cond.data_hub_crt_ts >  p_data_hub_crt_ts --(now() - interval '2 hours ')
*/

select cnvy.id_val ,cnvy.cnvy_key, m.data_hub_crt_ts
from 
(Select sc.ship_key, max(sc.data_hub_crt_ts) as data_hub_Crt_ts
from daas_tm_prepared.dh_ship_cond sc 
where sc.data_hub_crt_ts > p_data_hub_crt_ts -- now() - interval '0.01 hours '
group by 1
) m 
inner join daas_tm_prepared.dh_ship_cond sc1 on sc1.ship_key=m.ship_key 
and sc1.char_val in ('A','S','O' ) -- to keep active waybill association only
and sc1.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083'  -- waybill status
and sc1.act_stus_ind=1
inner join daas_tm_prepared.dh_ship_char c
on m.ship_key = c.ship_key and c.act_stus_ind = 1
AND c.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.id_val=c.char_val 
and cnvy.cnvy_type_key not in (
'd6663f4bdac4e24ddee5b7e3f8ebafbc903c50890d331ece54b7225f9b9a1a79' , --Tractor
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
)

union
select a.id_val as "unitIdentification", cnvy_char.cnvy_key,  cnvy_char.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy_char cnvy_char
inner join daas_tm_prepared.dh_cnvy a  on a.cnvy_key=cnvy_char.cnvy_key
and a.cnvy_type_key not in (
'd6663f4bdac4e24ddee5b7e3f8ebafbc903c50890d331ece54b7225f9b9a1a79' , --Tractor
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
) 
where  cnvy_char.act_stus_ind=1
and cnvy_char.data_hub_crt_ts >   p_data_hub_crt_ts  --(now() - interval '2 hours ')
union
select a.id_val as "unitIdentification",  cnvy_cond_3.cnvy_key,  cnvy_cond_3.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy_cond cnvy_cond_3
inner join daas_tm_prepared.dh_cnvy a  on a.cnvy_key=cnvy_cond_3.cnvy_key
and a.cnvy_type_key not in (
'd6663f4bdac4e24ddee5b7e3f8ebafbc903c50890d331ece54b7225f9b9a1a79' , --Tractor
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
) 
where cnvy_cond_3.act_stus_ind = 1 and cnvy_cond_3.sor_tpic_nm  not like '%unit-location-updated%'
 and cnvy_cond_3.data_hub_crt_ts > p_data_hub_crt_ts
--(now() - interval '2 hours ')
union 
select a.id_val as "unitIdentification", a.cnvy_key,  cnvy_cmp_char.data_hub_crt_ts as "dataHubCreationTimestamp"
from daas_tm_prepared.dh_cnvy_cmp_char cnvy_cmp_char
inner join daas_tm_prepared.dh_cnvy_cmp cnvy_cmp on cnvy_cmp_char.cnvy_cmp_key = cnvy_cmp.cnvy_cmp_key
and cnvy_cmp_char.char_type_key = 'a5ed7afff2e29e812aa79b76c07d1b77c0d66041ea22fa73d8c0b717a67daf55' --Stop Order Authorization
and cnvy_cmp.cnvy_cmp_type_key='d7cd65078ac119c66041926ff2612b6612994a6a4d583ae8401b54ad0f71edfa'  --Intra-Domain Conveyor-Stop Order
inner join daas_tm_prepared.dh_cnvy a  on a.cnvy_key=cnvy_cmp.cnvy_key
and a.cnvy_type_key not in (
'd6663f4bdac4e24ddee5b7e3f8ebafbc903c50890d331ece54b7225f9b9a1a79' , --Tractor
'5919fa9d7b96612183d1658bafa36eed27d732ee1b82527edea426ddc8e6fc62' , --Vessel
'394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9' , --Railcar
'dd641351594c37545a70c415525a3aed3213f9483aada133cdf26837da06022d' , --Rail Car
'c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'   --Train
) 
where  cnvy_cmp_char.act_stus_ind=1
and cnvy_cmp_char.data_hub_crt_ts > p_data_hub_crt_ts
--(now() - interval '2 hours ')
)
select a."unitIdentification" , a.cnvy_key
--, max("dataHubCreationTimestamp") as data_hub_crt_ts
from "vIntermodalUnitChange" a
group by  a."unitIdentification" , a.cnvy_key
order by max(a."dataHubCreationTimestamp") 
limit 1000
;




-- part 2: parse parameter string to temporay table 
if p_unitIdentification is not null 
then
create temporary table tbl_id ( id_val text, cnvy_key bytea PRIMARY KEY)  on commit drop;
insert into tbl_id(id_val, cnvy_key)
 select distinct cnvy.id_val, cnvy.cnvy_key
 from (select trim(unnest(string_to_array(p_unitIdentification ,','))) as id_val ) as m 
 inner join daas_tm_prepared.dh_cnvy cnvy on m.id_val=cnvy.id_val;
delete from tbl_changes where not exists (Select 1 from tbl_id where tbl_id.cnvy_key=tbl_changes.cnvy_key );
end if ;

--part 3: build cnvy_key and ship_key relationship
set enable_hashjoin=FALSE;
SET enable_mergejoin=FALSE;
create temporary table tbl_waybill 
on commit drop 
as 
with unitWaybill as (
select 
 m.cnvy_key
,m.id_val
,c.ship_key
,rank() over( partition by m.cnvy_key   order by  g.data_hub_crt_ts desc) as rk
,g.char_val , g.data_hub_crt_ts 
FROM tbl_changes m 
inner join daas_tm_prepared.dh_ship_char c
on c.act_stus_ind = 1
AND c.char_type_key = '31479967411e5e49ab3f8a29ec27b0374a2422ea101e2e872a6a4cddb36b4296' --Equipment ID
and m.id_val=c.char_val 
inner join daas_tm_prepared.dh_ship_cond g on c.ship_key=g.ship_key 
and g.char_type_key='1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083'  -- waybill status
and g.act_stus_ind=1
and g.char_val in ('A','S','O' )
)
select p.cnvy_key
,p.id_val
,p.ship_key
from unitWaybill p
where rk=1
union all
select a.cnvy_key, a.id_val, null 
from tbl_changes a
left join   unitWaybill m on a.id_val=m.id_val and rk=1
where m.id_val is null
;


-- part 4: return details
RETURN QUERY 
select 
b.cnvy_key,
greatest( p."dataHubCreationTimestamp",ship_asct.data_hub_crt_ts, q1."dataHubCreationTimestamp", q2."dataHubCreationTimestamp", so."dataHubCreationTimestamp") as "dataHubCreationTimestamp",
greatest( p."eventTimestamp",ship_asct.sor_evt_ts, q1."eventTimestamp", q2."eventTimestamp", so."eventTimestamp" ) as "eventTimestamp",
p."conveyorType",
p."equipmentInitial",
p."equipmentNumber",
b.id_val as "unitIdentification",
p."carKind",
q2."badOrderCode",
q2."loadSheetHoldCode",
q2."balanceOwedIndicator" as "storageChargeIndicator",  
q1."specialConditionCode1",
q1."specialConditionCode2",
q1."specialConditionCode3",
q1."specialConditionCode4",
q1."specialConditionCode5",
q1."specialConditionCode6",
q2."mechanicalStatusCode1",
q2."mechanicalStatusCode2",
q2."mechanicalStatusCode3",
q2."firstStorageChargeDate",  
q1."intermodalHandlingCode1",
q1."intermodalHandlingCode2",
q1."intermodalHandlingCode3",
p."outsideLength",
p."outsideLengthUnitOfMeasure",
p."outsideHeight",
p."outsideHeightUnitOfMeasure",
p."outsideWidth",
p."outsideWidthUnitOfMeasure",
p."trueKingpin",
p."equipmentTareWeight",
p."equipmentTareWeightUnitOfMeasure",
p."loadLimit",
p."equipmentOwnerAbbreviation",
p."equipmentLesseeAbbreviation" as "unitLeasee",
sa_char1.char_val as "emptyOrderNumber" 

,w.equipment_tare as "previousEquipmentTareWeight"
,w.equipment_tare_uom as "previousEquipmentTareWeightUnitOfMeasure"
,w.equipment_tare_lb as "previousEquipmentTareWeightPound"
,w.Equipment_Lessee_Abbreviation as "previousUnitLeasee"														  
,w.load_limit as "previousLoadLimit"
,w.load_limit_uom as "previousLoadLimitUnitOfMeasure"
,w.equipment_owner_abbreviation as "previousEquipmentOwnerAbbreviation"

, u."badOrderCode" as "previousBadOrderCode"
, u."mechanicalStatusCode1" as "previousMechanicalStatusCode1"
, u."mechanicalStatusCode2" as "previousMechanicalStatusCode2"
, u."mechanicalStatusCode3" as "previousMechanicalStatusCode3"

,v."intermodalHandlingCode1" as "previousIntermodalHandlingCode1"
,v."intermodalHandlingCode2" as "previousIntermodalHandlingCode2"
,v."intermodalHandlingCode3" as "previousIntermodalHandlingCode3"
,v."specialConditionCode1" as "previousSpecialConditionCode1"
,v."specialConditionCode2" as "previousSpecialConditionCode2"
,v."specialConditionCode3" as "previousSpecialConditionCode3"
,v."specialConditionCode4" as "previousSpecialConditionCode4"
,v."specialConditionCode5" as "previousSpecialConditionCode5"
,v."specialConditionCode6" as "previousSpecialConditionCode6"

,x."emptyOrderNumber" as "previousEmptyOrderNumber"
,u."loadSheetHoldCode" as "previousLoadSheetHoldCode"
,q2."eventAccountCode" as "eventAccountCode"
,u."eventAccountCode" as "previousEventAccountCode"
,u."firstStorageChargeDate" as "previousFirstStorageChargeDate"
,so."stopOrderAuthorization"
,pso."stopOrderAuthorization"  as "previousStopOrderAuthorization"
from  tbl_waybill b
--inner join daas_tm_prepared.dh_cnvy b on b.cnvy_key=tbl_changes.cnvy_key
inner join daas_tm_trusted.f_run_dh_get_cnvy_char_by_container(b.cnvy_key) p on true
left join daas_tm_prepared.dh_ship_asct ship_asct on ship_asct.asct_obj_key=b.cnvy_key and ship_asct.act_stus_ind=1
and ship_asct.asct_type_key  ='3de22246a9c11b9fa0fae553613839d4fa5e077ff8bbbf7ee43eef0725c434c2'  --Inter-BCD Shipment-Conveyor
left join daas_tm_prepared.dh_ship_asct_char sa_char1 on (ship_asct.asct_key = sa_char1.asct_key and sa_char1.act_stus_ind =1 and sa_char1.char_type_key = 'd9d99aec0ae95b5ffc046ffa2f1812bc215f3915ee2ca8f2b326c59c6b81e057')  -- Empty Order Number
left join daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(b.ship_key) q1 on true
left join daas_tm_trusted.f_get_dh_cnvy_cond_non_unit_location_by_cnvy_key(b.cnvy_key ) q2 on true  -- rail car cnvy key

left join daas_tm_trusted.f_get_dh_cnvy_char_domn_evt_equipment_by_cnvy_key  
(b.cnvy_key,p."conveyorCharProcessTimestamp") as w on true
left join daas_tm_trusted.f_get_dh_cnvy_cond_domn_evt_by_cnvy_key
(q2.cnvy_key, null) as u on true  --railcar cnvy key
left join daas_tm_trusted.f_get_dh_ship_cond_domn_evt_by_ship_key
(b.ship_key ,null) as v on true 
left join daas_tm_trusted.f_get_dh_ship_asct_char_domn_evt_equipment_by_asct_key
(sa_char1.asct_key,null) as x on true 
left join daas_tm_trusted.f_get_current_stop_order_by_cnvy_key(b.cnvy_key) so on true 
left join daas_tm_trusted.f_get_dh_cnvy_cmp_char_domn_evt_by_cmp_key(so.cnvy_cmp_key  ) pso on true
;

END;$$ SECURITY DEFINER
LANGUAGE plpgsql;

/*
GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vIntermodalUnitUpdateHistory"( timestamp , text) TO public;


select * from daas_tm_trusted."f_vIntermodalUnitUpdateHistory"(now()::timestamp - interval '105 days', NULL);



select * from daas_tm_trusted."f_vIntermodalUnitUpdateHistory"(now()::timestamp - interval '35 days', 'HRTU200004,BRAU210027,SEMZ205098 ');

*/

