DROP FUNCTION IF EXISTS daas_tm_trusted."f_vTripPlanSegment"(timestamp , text) cascade; -- 

CREATE or replace FUNCTION daas_tm_trusted."f_vTripPlanSegment"(p_data_hub_crt_ts timestamp, p_equipmentIdentification text )
RETURNS TABLE(
"dataHubCreationTimestamp"   timestamp,
"waybillIdentification"    text,
"equipmentIdentification"    text,
"tripPlanSequence"    text,
"carKind"    text,
"tripTypeCode"     text,
"eventCode"    text,
"eventStatusCode"    text,
"stationScac"    varchar(4),
"stationFsac" varchar(6),
"scheduleEventTimestamp"   timestamp,
"estimatedEventTimestamp"   timestamp,
"actualEventTimestamp"   timestamp,
"stationSequenceNumber"    text,
"trainIdentification"    text,
"trainBlock"    text,
"yardBlock"    text,
"jeopardyReasonCode"    text,
"rescheduleReasonCode"    text,
"associatedEquipmentIdentification"    text,
"operatingRailroadAtJunctionPoint"    text,
"opZTS"    text
    )
AS $$
BEGIN

-- part 1: change capture and apply the optional filter , limit 1000 records
create temporary table tbl_changes ( tpln_seg_key bytea PRIMARY KEY)  
on commit drop
;

insert into tbl_changes	(tpln_seg_key)
with "vTripPlanSegmentChange" as (
select tpln_seg_key, data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_tpln_seg_char_flatten
where data_hub_crt_ts > p_data_hub_crt_ts --(now() - interval '2 hours ')
and act_stus_ind=1
union all
select tpln_seg_key, data_hub_crt_ts as data_hub_crt_ts
from daas_tm_prepared.dh_tpln_seg
where data_hub_crt_ts > p_data_hub_crt_ts --(now() - interval '2 hours ')
and act_stus_ind=1
)
select a.tpln_seg_key
--, max("data_hub_crt_ts") as data_hub_crt_ts
from "vTripPlanSegmentChange" a
inner join daas_tm_prepared.dh_tpln_seg b on b.tpln_seg_key=a.tpln_seg_key
inner join daas_tm_prepared.dh_cnvy cnvy on b.prim_obj_key = cnvy.cnvy_key and cnvy.act_stus_ind=1
group by a.tpln_seg_key
order by max(a."data_hub_crt_ts") 
limit 2000
;




-- part 2: parse parameter string to temporay table 
if p_equipmentIdentification is not null 
then
create temporary table tbl_id ( id_val text, tpln_seg_key bytea PRIMARY KEY)  on commit drop;
insert into tbl_id(id_val, tpln_seg_key)
 select distinct m.id_val, tplnseg.tpln_seg_key
 from (select trim(unnest(string_to_array(p_equipmentIdentification ,','))) as id_val ) as m 
 inner join daas_tm_prepared.dh_cnvy cnvy on cnvy.id_val=m.id_val 
 inner join daas_tm_prepared.dh_tpln_seg tplnseg on cnvy.cnvy_key=tplnseg.prim_obj_key;
delete from tbl_changes where not exists (Select 1 from tbl_id where tbl_id.tpln_seg_key=tbl_changes.tpln_seg_key );
end if ;


set enable_hashjoin=FALSE;
SET enable_mergejoin=FALSE;
create temporary table tbl_changes_final 
on commit drop
as 
select c.tpln_seg_key
, c.tpln_seg_val as "tripPlanSequence"
, a.asct_obj_key as ship_key
, a.prim_obj_key as cnvy_key
, c.data_hub_crt_ts
from tbl_changes 
inner join daas_tm_prepared.dh_tpln_seg c on tbl_changes.tpln_seg_key=c.tpln_seg_key and c.act_stus_ind=1
inner join daas_tm_prepared.dh_tpln_asct a on   a.prim_obj_key = c.prim_obj_key and a.act_stus_ind=1
;

create index tbl_changes_final_io on tbl_changes_final (tpln_seg_key);


RETURN QUERY 
select 
Greatest(d.data_hub_crt_ts, c.data_hub_crt_ts) as "dataHubCreationTimestamp"
,b.id_val as "waybillIdentification"
,cnvy.id_val as "equipmentIdentification"
,c."tripPlanSequence"
,cc.char_val as "carKind"
,d.trip_type_cd as "tripTypeCode"
,d.evt_cd as "eventCode"
,d.evst_cd as "eventStatusCode"
,stn.scac as "stationScac" 
,stn.fsac as "stationFsac" 
,CASE WHEN d.sch_evt_ts  = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d.sch_evt_ts, 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "scheduleEventTimestamp"
,CASE WHEN d.est_evt_ts = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d.est_evt_ts, 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "estimatedEventTimestamp"
,CASE WHEN d.actl_evt_ts = ''
THEN to_timestamp('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')::timestamp
else (to_timestamp(d.actl_evt_ts, 'YYYY-MM-DD HH24:MI:SS'))::timestamp end  AS  "actualEventTimestamp"
,d.stn_seq_nbr as "stationSequenceNumber"
,d.trn_id as "trainIdentification"
,d.tblk as "trainBlock"
,d.yblk as "yardBlock"
,d.jpdy_rsn_cd as "jeopardyReasonCode"
,d.resch_rsn_cd as "rescheduleReasonCode"
,d.asct_eqp_init || d.asct_eqp_nbr  as "associatedEquipmentIdentification"
,d.oper_rr_at_jct as "operatingRailroadAtJunctionPoint"
,d.op_zts as "opZTS"
--,c.tpln_seg_key -- technical field used with vTripPlanSegmentChange
from tbl_changes_final c

inner join daas_tm_prepared.dh_ship b on c.ship_key=b.ship_key and b.act_stus_ind=1
inner join daas_tm_prepared.dh_cnvy cnvy on c.cnvy_key = cnvy.cnvy_key and cnvy.act_stus_ind=1
inner join daas_tm_prepared.dh_cnvy_char cc on cc.cnvy_key=cnvy.cnvy_key
and cc.char_type_key='dfdd3aa142b76224ee103bf8ad2cbe50d4bdd1add774d8c3506bd64febbd0ae8' --Car Kind
and cc.act_stus_ind=1
inner join daas_tm_prepared.dh_tpln_seg_char_flatten d on (c.tpln_seg_key = d.tpln_seg_key)  -- and d.act_stus_ind = 1) 
left join daas_tm_prepared.dh_rail_station stn on stn.stn_333=d.stn_333 
and stn.stn_st= case when d.stn_prov_st_cd='QC' then 'PQ' else d.stn_prov_st_cd end 
where  1=1
order by b.id_val,cnvy.id_val,lpad(c."tripPlanSequence" ,5,'0')
;

END;$$ SECURITY DEFINER
LANGUAGE plpgsql;

/*
GRANT EXECUTE ON FUNCTION daas_tm_trusted."f_vTripPlanSegment"( timestamp , text) TO public;


select * from daas_tm_trusted."f_vTripPlanSegment"(now()::timestamp - interval '35 days', NULL);



select * from daas_tm_trusted."f_vTripPlanSegment"(now()::timestamp - interval '35 days', 'SMEU790069,SMEU790065, SMEU790059');

*/


