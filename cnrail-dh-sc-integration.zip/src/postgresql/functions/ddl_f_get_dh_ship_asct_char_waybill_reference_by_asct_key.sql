DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_asct_char_waybill_reference_by_asct_key(bytea) cascade;


CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_asct_char_waybill_reference_by_asct_key(p_ship_cmp_key bytea)
returns table(
ship_cmp_key bytea,
"completeReferenceNumberCode"   text,	
"referenceKeyIdentification"   text,	
"referenceNumber"   text,	
"referenceNumberCode"   text,	
"referenceNumberComment"   text,	
"referenceNumberCustomer633"   text,	
"referenceNumberDate"   text,	
"referenceNumberTimeLocal"   text	
)
AS $$
begin
return query
select main.ship_cmp_key,
max(case when ref_type.type_cd = 'Complete Reference Number Code' then c.char_val else null end) as "completeReferenceNumberCode",
max(case when ref_type.type_cd = 'Reference Key Id' then c.char_val else null end) as "referenceKeyIdentification",
max(case when ref_type.type_cd = 'Reference Number' then c.char_val else null end) as "referenceNumber",
max(case when ref_type.type_cd = 'Reference Number Code' then c.char_val else null end) as "referenceNumberCode",
max(case when ref_type.type_cd = 'Reference Number Comment' then c.char_val else null end) as "referenceNumberComment",
max(case when ref_type.type_cd = 'Reference Number Customer 633' then c.char_val else null end) as "referenceNumberCustomer633",
max(case when ref_type.type_cd = 'Reference Number Date' then c.char_val else null end) as "referenceNumberDate",
max(case when ref_type.type_cd = 'Reference Number Time Local' then c.char_val else null end) as "referenceNumberTimeLocal"
from daas_tm_prepared.dh_ship_cmp main
left  join daas_tm_prepared.dh_ship_cmp_char c
on    main.ship_cmp_key = c.ship_cmp_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.ship_cmp_key = p_ship_cmp_key and main.act_stus_ind = 1
group by main.ship_cmp_key;
end;
$$ LANGUAGE plpgsql;
