CREATE OR REPLACE FUNCTION f_get_dh_bus_prtr_char_port_info_by_bus_prtr_key(p_bus_prtr_key bytea)
returns table(bus_prtr_key bytea,
Business_Partner_Name text,
Business_Partner_Name_633 text,
Customer_Number text,
ETA_Threshold text)
AS $$
begin
return query
select main.bus_prtr_key,
max(case when ref_type.type_cd = 'Business Partner Name' then c.char_val else null end) as Business_Partner_Name,
max(case when ref_type.type_cd = 'Business Partner Name 633' then c.char_val else null end) as Business_Partner_Name_633,
max(case when ref_type.type_cd = 'Customer Number' then c.char_val else null end) as Customer_Number,
max(case when ref_type.type_cd = 'ETA Threshold' then c.char_val else null end) as ETA_Threshold
from daas_tm_prepared.dh_bus_prtr main
left  join daas_tm_prepared.dh_bus_prtr_char c
on    main.bus_prtr_key = c.bus_prtr_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.bus_prtr_key = p_bus_prtr_key and main.act_stus_ind = 1
group by main.bus_prtr_key;
end;
$$ LANGUAGE plpgsql;
