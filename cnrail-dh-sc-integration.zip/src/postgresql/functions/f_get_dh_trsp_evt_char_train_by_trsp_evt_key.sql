CREATE OR REPLACE FUNCTION f_get_dh_trsp_evt_char_train_by_trsp_evt_key(p_trsp_evt_key bytea)
returns table(trsp_evt_key bytea,
Distributed_Power_Train_Indicator text,
Empty_Car_Count text,
Event text,
Event_Station_Carrier_Abbreviation text,
Event_Station_FSAC text,
Event_Station_Sequence_Timestamp text,
Horse_Power_Per_Ton text,
HPTA text,
Key_Train_indicator text,
Loaded_Car_Count text,
Maximum_speed_restriction text,
Most_restricted_dimensional_load text,
Number_of_Car_Axles text,
Number_of_Dangerous_Loads text,
Number_of_Dimensional_Loads text,
Number_of_Empty_Residue text,
Number_of_Heavy_Axle_Cars text,
Number_of_Loco_Axles text,
Number_of_Special_Dangerous_Loads text,
Number_of_Speed_Restricted_Cars text,
Percentage_of_total_heavy_axle_loads text,
Schedule_Deviation_Code text,
Schedule_Deviation_Time text,
Tons_per_operative_brake text,
Total_Car_Length text,
Total_Car_Length_Unit_of_Measure text,
Total_Car_Weight text,
Total_Car_Weight_Unit_of_Measure text,
Total_Locomotive_Length text,
Total_Locomotive_Length_Unit_of_Measure text,
Total_Locomotive_Weight text,
Total_Locomotive_Weight_Unit_of_Measure text,
Total_Number_of_Available_Horsepower text)
AS $$
begin
return query
select main.trsp_evt_key,
max(case when ref_type.type_cd = 'Distributed Power Train Indicator' then c.char_val else null end) as Distributed_Power_Train_Indicator,
max(case when ref_type.type_cd = 'Empty Car Count' then c.char_val else null end) as Empty_Car_Count,
max(case when ref_type.type_cd = 'Event' then c.char_val else null end) as Event,
max(case when ref_type.type_cd = 'Event Station Carrier Abbreviation' then c.char_val else null end) as Event_Station_Carrier_Abbreviation,
max(case when ref_type.type_cd = 'Event Station FSAC' then c.char_val else null end) as Event_Station_FSAC,
max(case when ref_type.type_cd = 'Event Station Sequence Timestamp' then c.char_val else null end) as Event_Station_Sequence_Timestamp,
max(case when ref_type.type_cd = 'Horse Power Per Ton' then c.char_val else null end) as Horse_Power_Per_Ton,
max(case when ref_type.type_cd = 'HPTA' then c.char_val else null end) as HPTA,
max(case when ref_type.type_cd = 'Key Train indicator' then c.char_val else null end) as Key_Train_indicator,
max(case when ref_type.type_cd = 'Loaded Car Count' then c.char_val else null end) as Loaded_Car_Count,
max(case when ref_type.type_cd = 'Maximum speed restriction' then c.char_val else null end) as Maximum_speed_restriction,
max(case when ref_type.type_cd = 'Most restricted dimensional load' then c.char_val else null end) as Most_restricted_dimensional_load,
max(case when ref_type.type_cd = 'Number of Car Axles' then c.char_val else null end) as Number_of_Car_Axles,
max(case when ref_type.type_cd = 'Number of Dangerous Loads' then c.char_val else null end) as Number_of_Dangerous_Loads,
max(case when ref_type.type_cd = 'Number of Dimensional Loads' then c.char_val else null end) as Number_of_Dimensional_Loads,
max(case when ref_type.type_cd = 'Number of Empty Residue' then c.char_val else null end) as Number_of_Empty_Residue,
max(case when ref_type.type_cd = 'Number of Heavy Axle Cars' then c.char_val else null end) as Number_of_Heavy_Axle_Cars,
max(case when ref_type.type_cd = 'Number of Loco Axles' then c.char_val else null end) as Number_of_Loco_Axles,
max(case when ref_type.type_cd = 'Number of Special Dangerous Loads' then c.char_val else null end) as Number_of_Special_Dangerous_Loads,
max(case when ref_type.type_cd = 'Number of Speed Restricted Cars' then c.char_val else null end) as Number_of_Speed_Restricted_Cars,
max(case when ref_type.type_cd = 'Percentage of total heavy axle loads' then c.char_val else null end) as Percentage_of_total_heavy_axle_loads,
max(case when ref_type.type_cd = 'Schedule Deviation Code' then c.char_val else null end) as Schedule_Deviation_Code,
max(case when ref_type.type_cd = 'Schedule Deviation Time' then c.char_val else null end) as Schedule_Deviation_Time,
max(case when ref_type.type_cd = 'Tons per operative brake' then c.char_val else null end) as Tons_per_operative_brake,
max(case when ref_type.type_cd = 'Total Car Length' then c.char_val else null end) as Total_Car_Length,
max(case when ref_type.type_cd = 'Total Car Length Unit of Measure' then c.char_val else null end) as Total_Car_Length_Unit_of_Measure,
max(case when ref_type.type_cd = 'Total Car Weight' then c.char_val else null end) as Total_Car_Weight,
max(case when ref_type.type_cd = 'Total Car Weight Unit of Measure' then c.char_val else null end) as Total_Car_Weight_Unit_of_Measure,
max(case when ref_type.type_cd = 'Total Locomotive Length' then c.char_val else null end) as Total_Locomotive_Length,
max(case when ref_type.type_cd = 'Total Locomotive Length Unit of Measure' then c.char_val else null end) as Total_Locomotive_Length_Unit_of_Measure,
max(case when ref_type.type_cd = 'Total Locomotive Weight' then c.char_val else null end) as Total_Locomotive_Weight,
max(case when ref_type.type_cd = 'Total Locomotive Weight Unit of Measure' then c.char_val else null end) as Total_Locomotive_Weight_Unit_of_Measure,
max(case when ref_type.type_cd = 'Total Number of Available Horsepower' then c.char_val else null end) as Total_Number_of_Available_Horsepower
from daas_tm_prepared.dh_trsp_evt main
left  join daas_tm_prepared.dh_trsp_evt_char c
on    main.trsp_evt_key = c.trsp_evt_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.trsp_evt_key = p_trsp_evt_key and main.act_stus_ind = 1
group by main.trsp_evt_key;
end;
$$ LANGUAGE plpgsql;
