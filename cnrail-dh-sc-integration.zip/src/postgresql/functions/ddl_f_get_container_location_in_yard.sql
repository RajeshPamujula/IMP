DROP FUNCTION IF EXISTS f_get_container_location_in_yard();

CREATE OR REPLACE FUNCTION f_get_container_location_in_yard(p_cnvy_key bytea)
RETURNS TABLE
(
  "containerIdentifier" TEXT,
  "equipmentInitial" TEXT,
  "equipmentNumber" TEXT,
  "eventTimestamp" TIMESTAMP,
  "lot" TEXT,
  "row" TEXT,
  "spot" TEXT,
  "trackNumber" TEXT,
  "trackArea" TEXT,
  "liftCode" TEXT,
  "parkOrTrackCode" TEXT
)
AS $$
BEGIN
RETURN QUERY
SELECT
    c.id_val AS "containerIdentifier"
     , cc1.char_val AS "equipmentInitial"
     , cc2.char_val AS "equipmentNumber"
     , te.sor_evt_ts AS "eventTimestamp"
     , teac1.char_val AS "lot"
     , teac2.char_val AS "row"
     , teac3.char_val AS "spot"
     , teac4.char_val AS "trackNumber"
     , teac5.char_val AS "trackArea"
     , teac6.char_val AS "liftCode"
     , teac7.char_val AS "parkOrTrackCode"
FROM daas_tm_prepared.dh_cnvy c
         JOIN daas_tm_prepared.dh_ref_type r ON c.cnvy_type_key = r.type_key
         JOIN daas_tm_prepared.dh_cnvy_char cc1 ON cc1.act_stus_ind = 1 AND c.cnvy_key = cc1.cnvy_key AND cc1.char_type_key = '\x64383738643566643064303962663639613138303966306433646331343864373865333536353636306433333737306365376261303463376266646530393338' -- Container Initial
         JOIN daas_tm_prepared.dh_cnvy_char cc2 ON cc2.act_stus_ind = 1 AND c.cnvy_key = cc2.cnvy_key AND cc2.char_type_key = '\x38363362356364383137396366643562333539306666616439633438326366353365373939333564316138656433306635613733653237313936313362353230' -- Container Number
         LEFT JOIN daas_tm_prepared.dh_trsp_evt te ON te.act_stus_ind = 1 AND c.cnvy_key = te.trsp_evt_key
         LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct tea ON tea.act_stus_ind = 1 AND te.trsp_evt_key = tea.trsp_evt_key
         LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac1 ON teac1.act_stus_ind = 1 AND tea.asct_key = teac1.asct_key AND teac1.char_type_key = '\x66313738343630363833386238313538303039336362366634623139363964633962306137326362636335373634333931656164613362393339663437636539' -- Lot
         LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac2 ON teac2.act_stus_ind = 1 AND tea.asct_key = teac2.asct_key AND teac2.char_type_key = '\x61626432623838626164343331393762633631653939666462373232373566653064303137376538313764643436633839393533396561383332313235653632' -- Row
         LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac3 ON teac3.act_stus_ind = 1 AND tea.asct_key = teac3.asct_key AND teac3.char_type_key = '\x63633463333739313937313661656530623139383562623437396230313363366461396239366536626462653864346232303935613838376364646534343031' -- Spot
         LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac4 ON teac4.act_stus_ind = 1 AND tea.asct_key = teac4.asct_key AND teac4.char_type_key = '\x32326662613935626230303136306135303436303666333462313533646264383839656437343663633764376637393434373261613438623762646262343161' -- Track Number
         LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac5 ON teac5.act_stus_ind = 1 AND tea.asct_key = teac5.asct_key AND teac5.char_type_key = '\x61386563346461353036363462613562666638356563393630346632336566613665663731653731316436343532376463393564613964303931313138323539' -- Track Area
         LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac6 ON teac6.act_stus_ind = 1 AND tea.asct_key = teac6.asct_key AND teac6.char_type_key = '\x37396334616463646566333130666432613130343439306631316461623835373939326662363834346632353433353133303066303735306532616333666337' -- Lift Code
         LEFT JOIN daas_tm_prepared.dh_trsp_evt_asct_char teac7 ON teac7.act_stus_ind = 1 AND tea.asct_key = teac7.asct_key AND teac7.char_type_key = '\x61393133333030643064626637393439353435316432656134666637313032313733383435396162646233316461383737323365353665653933353962363361' -- Park or Track Code
WHERE c.cnvy_key = p_cnvy_key;
END;
$$ LANGUAGE plpgsql;