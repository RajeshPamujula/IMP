DROP FUNCTION IF EXISTS daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(bytea) cascade;
/*
drop cascades to view daas_tm_trusted."vContainerDetail"
drop cascades to view daas_tm_trusted."vCarInventoryUpdated"
drop cascades to view daas_tm_trusted."vCarInventoryUpdateHistory"
drop cascades to view daas_tm_trusted."vUnitShipmentDetailWaybill"
*/

CREATE OR REPLACE FUNCTION daas_tm_trusted.f_get_dh_ship_cond_by_ship_key(p_ship_key bytea)
RETURNS TABLE 
(
ship_key bytea,
--"sourceProcessDateTime" timestamp without time zone,
"ProcessTimestamp"  timestamp without time zone,
"dataHubCreationTimestamp"  timestamp without time zone,
"eventTimestamp"  timestamp without time zone,
"intermodalHandlingCode" text,
"specialConditionCode" text,
"waybillErrorCode" text,
"waybillStatusCode" text,

"intermodalHandlingCode1" text,
"intermodalHandlingCode2" text,
"intermodalHandlingCode3" text,


"specialConditionCode1" text,
"specialConditionCode2" text,
"specialConditionCode3" text,
"specialConditionCode4" text,
"specialConditionCode5" text,
"specialConditionCode6" text
)
AS $$
begin
return query

select 
a.ship_key as "shipmentKey",
--a.sor_proc_ts as "sourceProcessDateTime",
max(a.rpt_sor_proc_ts) as "ProcessTimestamp",  -- eventually remove it.
max(a.data_hub_crt_ts) as "dataHubCreationTimestamp", 
max(a.sor_evt_ts) as "eventTimestamp", 
max(case when type_cd = 'Intermodal Handling Code' then char_val else null end) as "intermodalHandlingCode",
max(case when type_cd = 'Special Condition Code' then char_val else null end) as "specialConditionCode",
max(case when type_cd = 'Waybill Error Code' then char_val else null end) as "waybillErrorCode",
max(case when type_cd = 'Waybill Status Code' then char_val else null end) as "waybillStatusCode",

max(case when type_cd = 'Intermodal Handling Code 1' then char_val else null end) as "intermodalHandlingCode1",
max(case when type_cd = 'Intermodal Handling Code 2' then char_val else null end) as "intermodalHandlingCode2",
max(case when type_cd = 'Intermodal Handling Code 3' then char_val else null end) as "intermodalHandlingCode3",
max(case when type_cd = 'Special Condition Code 1' then char_val else null end) as "specialConditionCode1",

max(case when type_cd = 'Special Condition Code 2' then char_val else null end) as "specialConditionCode2",
max(case when type_cd = 'Special Condition Code 3' then char_val else null end) as "specialConditionCode3",
max(case when type_cd = 'Special Condition Code 4' then char_val else null end) as "specialConditionCode4",
max(case when type_cd = 'Special Condition Code 5' then char_val else null end) as "specialConditionCode5",

max(case when type_cd = 'Special Condition Code 6' then char_val else null end) as "specialConditionCode6"

from daas_tm_prepared.dh_ship_cond a
inner join daas_tm_prepared.dh_ref_type ref on ref.type_key=a.char_type_key
where a.ship_key = p_ship_key
and a.act_stus_ind = 1
group by 1;
end;
$$
LANGUAGE 'plpgsql';



