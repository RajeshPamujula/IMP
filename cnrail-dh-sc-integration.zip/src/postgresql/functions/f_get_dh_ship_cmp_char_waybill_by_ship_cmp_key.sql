CREATE OR REPLACE FUNCTION f_get_dh_ship_cmp_char_waybill_by_ship_cmp_key(p_ship_cmp_key bytea)
returns table(ship_cmp_key bytea,
Appointment_Date text,
Appointment_Time text,
Appointment_Time_Local text,
Appointment_UTC_Timestamp text,
Carrier_Abbreviation text,
City_333 text,
City_Name text,
Customer_633 text,
Customer_Address text,
Customer_Name text,
Customer_Number text,
Drop_Stay_Code text,
Force_Customer_Indicator text,
Postal_Code text,
Province_State text,
Seal_Range_High text,
Seal_Range_Low text,
Station_Number text,
Stop_Off_Carrier_Abbreviation text,
Stop_Off_Complete_Indicator text,
Stop_Off_Consignee_Full_Name text,
Stop_Off_Customer_633 text,
Stop_Off_Patron_Code text,
Stop_Off_Plant_Address text,
Stop_Off_Plant_Postal_Code text,
Stop_Off_State_Code text,
Stop_Off_Station_333 text,
Stop_Off_Station_Full_Name text,
Stop_Off_Station_Number text,
Stop_Off_Status_Code text,
Stop_Off_ZTS_Equipment_Place_Code text,
In_gate_Seal_Number text)
AS $$
begin
return query
select main.ship_cmp_key,
max(case when ref_type.type_cd = 'Appointment Date' then c.char_val else null end) as Appointment_Date,
max(case when ref_type.type_cd = 'Appointment Time' then c.char_val else null end) as Appointment_Time,
max(case when ref_type.type_cd = 'Appointment Time Local' then c.char_val else null end) as Appointment_Time_Local,
max(case when ref_type.type_cd = 'Appointment UTC Timestamp' then c.char_val else null end) as Appointment_UTC_Timestamp,
max(case when ref_type.type_cd = 'Carrier Abbreviation' then c.char_val else null end) as Carrier_Abbreviation,
max(case when ref_type.type_cd = 'City 333' then c.char_val else null end) as City_333,
max(case when ref_type.type_cd = 'City Name' then c.char_val else null end) as City_Name,
max(case when ref_type.type_cd = 'Customer 633' then c.char_val else null end) as Customer_633,
max(case when ref_type.type_cd = 'Customer Address' then c.char_val else null end) as Customer_Address,
max(case when ref_type.type_cd = 'Customer Name' then c.char_val else null end) as Customer_Name,
max(case when ref_type.type_cd = 'Customer Number' then c.char_val else null end) as Customer_Number,
max(case when ref_type.type_cd = 'Drop Stay Code' then c.char_val else null end) as Drop_Stay_Code,
max(case when ref_type.type_cd = 'Force Customer Indicator' then c.char_val else null end) as Force_Customer_Indicator,
max(case when ref_type.type_cd = 'Postal Code' then c.char_val else null end) as Postal_Code,
max(case when ref_type.type_cd = 'Province State' then c.char_val else null end) as Province_State,
max(case when ref_type.type_cd = 'Seal Range High' then c.char_val else null end) as Seal_Range_High,
max(case when ref_type.type_cd = 'Seal Range Low' then c.char_val else null end) as Seal_Range_Low,
max(case when ref_type.type_cd = 'Station Number' then c.char_val else null end) as Station_Number,
max(case when ref_type.type_cd = 'Stop-Off Carrier Abbreviation' then c.char_val else null end) as Stop_Off_Carrier_Abbreviation,
max(case when ref_type.type_cd = 'Stop-Off Complete Indicator' then c.char_val else null end) as Stop_Off_Complete_Indicator,
max(case when ref_type.type_cd = 'Stop-Off Consignee Full Name' then c.char_val else null end) as Stop_Off_Consignee_Full_Name,
max(case when ref_type.type_cd = 'Stop-Off Customer 633' then c.char_val else null end) as Stop_Off_Customer_633,
max(case when ref_type.type_cd = 'Stop-Off Patron Code' then c.char_val else null end) as Stop_Off_Patron_Code,
max(case when ref_type.type_cd = 'Stop-Off Plant Address' then c.char_val else null end) as Stop_Off_Plant_Address,
max(case when ref_type.type_cd = 'Stop-Off Plant Postal Code' then c.char_val else null end) as Stop_Off_Plant_Postal_Code,
max(case when ref_type.type_cd = 'Stop-Off State Code' then c.char_val else null end) as Stop_Off_State_Code,
max(case when ref_type.type_cd = 'Stop-Off Station 333' then c.char_val else null end) as Stop_Off_Station_333,
max(case when ref_type.type_cd = 'Stop-Off Station Full Name' then c.char_val else null end) as Stop_Off_Station_Full_Name,
max(case when ref_type.type_cd = 'Stop-Off Station Number' then c.char_val else null end) as Stop_Off_Station_Number,
max(case when ref_type.type_cd = 'Stop-Off Status Code' then c.char_val else null end) as Stop_Off_Status_Code,
max(case when ref_type.type_cd = 'Stop-Off ZTS Equipment Place Code' then c.char_val else null end) as Stop_Off_ZTS_Equipment_Place_Code,
max(case when ref_type.type_cd = 'In-gate Seal Number' then c.char_val else null end) as In_gate_Seal_Number
from daas_tm_prepared.dh_ship_cmp main
left  join daas_tm_prepared.dh_ship_cmp_char c
on    main.ship_cmp_key = c.ship_cmp_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.ship_cmp_key = p_ship_cmp_key and main.act_stus_ind = 1
group by main.ship_cmp_key;
end;
$$ LANGUAGE plpgsql;
