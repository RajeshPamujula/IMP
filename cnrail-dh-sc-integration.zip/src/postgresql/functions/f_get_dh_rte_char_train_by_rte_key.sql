CREATE OR REPLACE FUNCTION f_get_dh_rte_char_train_by_rte_key(p_rte_key bytea)
returns table(rte_key bytea,
Effective_Date text,
Expiry_Date text,
Maximum_MPH text,
Operating_Status_Code text,
Train_Reporting_Group text,
Train_Schedule_Code text,
Train_Service_Type text)
AS $$
begin
return query
select main.rte_key,
max(case when ref_type.type_cd = 'Effective Date' then c.char_val else null end) as Effective_Date,
max(case when ref_type.type_cd = 'Expiry Date' then c.char_val else null end) as Expiry_Date,
max(case when ref_type.type_cd = 'Maximum MPH' then c.char_val else null end) as Maximum_MPH,
max(case when ref_type.type_cd = 'Operating Status Code' then c.char_val else null end) as Operating_Status_Code,
max(case when ref_type.type_cd = 'Train Reporting Group' then c.char_val else null end) as Train_Reporting_Group,
max(case when ref_type.type_cd = 'Train Schedule Code' then c.char_val else null end) as Train_Schedule_Code,
max(case when ref_type.type_cd = 'Train Service Type' then c.char_val else null end) as Train_Service_Type
from daas_tm_prepared.dh_rte main
left  join daas_tm_prepared.dh_rte_char c
on    main.rte_key = c.rte_key
and   c.act_stus_ind = 1
left  join daas_tm_prepared.dh_ref_type ref_type
on    c.char_type_key = ref_type.type_key
where main.rte_key = p_rte_key and main.act_stus_ind = 1
group by main.rte_key;
end;
$$ LANGUAGE plpgsql;

