DROP TABLE IF EXISTS dh_cdi_ref CASCADE;

CREATE TABLE dh_cdi_ref
(
	cdi_key              BYTEA NOT NULL,
	cust_633_key         BYTEA NOT NULL,
	cust_633             CHAR(12) NOT NULL,
	dest_333             CHAR(9) NOT NULL,
	dest_st              CHAR(2) NOT NULL,
	loc_333_key          BYTEA NOT NULL,
	zts                  CHAR(6) NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	zts_hi               CHAR(6) NOT NULL,
	auto_plc_sys_covr    CHAR(1) NOT NULL,
	auto_plc_load_mpty   CHAR(1) NOT NULL,
	auto_plc_ipsw_cd     CHAR(1) NOT NULL,
	bus_unit_cd          CHAR(2) NOT NULL,
	bus_unit_cd_2        CHAR(2) NOT NULL,
	canc_dt              DATE NOT NULL,
	cp_cd                CHAR(1) NOT NULL,
	dest_instr_cmt       VARCHAR(70) NOT NULL,
	dest_instr_cmt_2     VARCHAR(70) NOT NULL,
	dmrg_type_cd         CHAR(1) NOT NULL,
	door_flip_ind        CHAR(1) NOT NULL,
	eff_dt               DATE NOT NULL,
	jnt_indy_road        CHAR(4) NOT NULL,
	lang_cd              CHAR(1) NOT NULL,
	le_notf              CHAR(1) NOT NULL,
	notf_cd              CHAR(1) NOT NULL,
	notf_pers            VARCHAR(18) NOT NULL,
	notf_tel_nbr         CHAR(15) NOT NULL,
	open_gate_ind        CHAR(1) NOT NULL,
	oper_cust_ind        CHAR(1) NOT NULL,
	rvrt_mpty_pvt_eqp    CHAR(1) NOT NULL,
	self_sw_ind          CHAR(1) NOT NULL,
	side_spot_cpty       CHAR(4) NOT NULL,
	team_trk_ind         CHAR(1) NOT NULL,
	trk_lgt_leas         DECIMAL(5,0) NOT NULL,
	trk_leas_ind         CHAR(1) NOT NULL,
	wb_rlse_ind          CHAR(1) NOT NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	PRIMARY KEY (cdi_key)
);

CREATE UNIQUE INDEX XAK1CUSTOMER_DESTINATION_INSTRUCTION_REFERENCE ON dh_cdi_ref
(
	cust_633 ASC,	dest_333 ASC,	dest_st ASC,	zts ASC
);