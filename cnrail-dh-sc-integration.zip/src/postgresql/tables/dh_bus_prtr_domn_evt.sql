DROP TABLE IF EXISTS dh_bus_prtr_domn_evt CASCADE;

CREATE TABLE dh_bus_prtr_domn_evt
(
	domn_evt_key         BYTEA NOT NULL,
	domn_evt_type_key    BYTEA NOT NULL,
	bus_prtr_key         BYTEA NOT NULL,
	bus_prtr_type_key    BYTEA NOT NULL,
	id_type_key          BYTEA NOT NULL,
	id_val               TEXT NOT NULL,
	sor_crlt_id          VARCHAR(256) NOT NULL,
	sys_key              BYTEA NOT NULL,
	clnt_id              VARCHAR(50) NOT NULL,
	sor_proc_ts          TIMESTAMP NOT NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	domn_evt_crt_ts      TIMESTAMP NOT NULL,
	domn_evt_read_ts     TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
	domn_evt_meta        TEXT NULL,
	sor_evt_ts_tz_dst_cd SMALLINT NULL,
	sor_proc_ts_tz_dst_cd SMALLINT NULL
);

CREATE UNIQUE INDEX XAK1BUSINESS_PARTNER_DOMAIN_EVENT ON dh_bus_prtr_domn_evt
(
	domn_evt_key ASC,	sor_proc_ts ASC
);
