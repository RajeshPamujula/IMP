DROP TABLE IF EXISTS DH_PURGE_RESULTS CASCADE;

CREATE TABLE DH_PURGE_RESULTS (
  purge_time        timestamp NOT NULL,
  purge_id          int NOT NULL,
  pre_rowcount      int NOT NULL,
  purge_rowcount    int NOT NULL,
  post_rowcount     int NOT NULL,
  CONSTRAINT DH_PURGE_RESULTS_pkey PRIMARY KEY (purge_time, purge_id)
);

