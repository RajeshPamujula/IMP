DROP TABLE IF EXISTS dh_ship_char_flat CASCADE;

CREATE TABLE dh_ship_char_flat
(
                ship_key             BYTEA NOT NULL,
                wb_nbr               TEXT NOT NULL,
                wb_dt                TEXT NOT NULL,
                grs_scal_wgt         TEXT NOT NULL,
                grs_scal_wgt_uom     TEXT NOT NULL,
                net_scal_wgt         TEXT NOT NULL,
                net_scal_wgt_uom     TEXT NOT NULL,
                eqp_id               TEXT NOT NULL,
                spdr                 TEXT NOT NULL,
                spdr_uom             TEXT NOT NULL,
                oper_city            TEXT NOT NULL,
                oper_city_prov_st_cd TEXT NOT NULL,
                oper_dest_fsac       TEXT NOT NULL,
                oper_dest_scac       TEXT NOT NULL,
                oper_rajp            TEXT NOT NULL,
                rajp                 TEXT NOT NULL,
                im_plan_nbr          TEXT NOT NULL,
                wb_rec_type          TEXT NOT NULL,
                carr_abr_on          TEXT NOT NULL,
                cust_sply_net_wgt    TEXT NOT NULL,
                cust_sply_wgt_cd     TEXT NOT NULL,
                cust_sply_wgt_uom    TEXT NOT NULL,
                wb_edi_cd            TEXT NOT NULL,
                tot_ldng_wgt         TEXT NOT NULL,
                tot_ldng_wgt_uom     TEXT NOT NULL,
                wgt_allw_1           TEXT NOT NULL,
                wgt_allw_1_uom       TEXT NOT NULL,
                wgt_allw_2_uom       TEXT NOT NULL,
                wgt_allw_2           TEXT NOT NULL,
                wgt_unit_cd          TEXT NOT NULL,
                load_mpty_stus_cd    TEXT NOT NULL,
                impt_expt_cd         TEXT NOT NULL,
                bl_nbr               TEXT NOT NULL,
                bl_dt                TEXT NOT NULL,
                ppsi_tmpr            TEXT NOT NULL,
                ppsi_tmpr_uom        TEXT NOT NULL,
                ppsi_cool_ind        TEXT NOT NULL,
                ppsi_rule_cd         TEXT NOT NULL,
                rail_orig_333        TEXT NOT NULL,
                rail_orig_333_prov_st_cd TEXT NOT NULL,
                ormp_333             TEXT NOT NULL,
                ormp_333_prov_st_cd  TEXT NOT NULL,
                rail_dest_333        TEXT NOT NULL,
                rail_dest_333_prov_st_cd TEXT NOT NULL,
                dest_ramp_333        TEXT NOT NULL,
                dest_ramp_333_prov_st_cd TEXT NOT NULL,
                ppsi_cd              TEXT NOT NULL,
                stcc                 TEXT NOT NULL,
                log_user             TEXT NOT NULL,
                log_user_nm          TEXT NOT NULL,
                lvl_of_serv_cd       TEXT NOT NULL,
                wb_type_cd           TEXT NOT NULL,
                cco_nbr              TEXT NOT NULL,
                frst_rdhl_carr_nbr   TEXT NOT NULL,
                lrhcs                TEXT NOT NULL,
                mvmt_rev_cd          TEXT NOT NULL,
                reg_auth             TEXT NOT NULL,
                tofc_cofc_cd         TEXT NOT NULL,
                evt_dt               TEXT NOT NULL,
                evt_tm               TEXT NOT NULL,
                frst_cn_orig_carr_abr TEXT NOT NULL,
                frst_cn_orig_stn_nbr TEXT NOT NULL,
                last_cn_orig_carr_abr TEXT NOT NULL,
                last_cn_orig_stn_nbr TEXT NOT NULL,
                ingate_plac_cd       TEXT NOT NULL,
                ingate_haz_dclr      TEXT NOT NULL,
                rajp_2               TEXT NOT NULL,
                last_stcc_nbr        TEXT NOT NULL,
                pu_nbr               TEXT NOT NULL,
                load_sht_blk_hold    TEXT NOT NULL,
                rsrv_nbr             TEXT NOT NULL,
                obl                  TEXT NOT NULL,
                voyg_nbr             TEXT NOT NULL,
                fgt_vol              TEXT NOT NULL,
                fgt_uom              TEXT NOT NULL,
                fgt_dt               TEXT NOT NULL,
                dsps_of_rsdu_insn    TEXT NOT NULL,
                act_stus_ind         SMALLINT NOT NULL,
                sor_crlt_id          VARCHAR(256) NOT NULL,
                sys_key              BYTEA NOT NULL,
                rpt_clnt_id          VARCHAR(50) NULL,
                rpt_sor_proc_ts      TIMESTAMP NULL,
                sor_evt_ts           TIMESTAMP NOT NULL,
                rmv_clnt_id          VARCHAR(50) NULL,
                rmv_sor_proc_ts      TIMESTAMP NULL,
                sor_ingt_crt_ts      TIMESTAMP NOT NULL,
                sor_read_ts          TIMESTAMP NOT NULL,
                domn_evt_crt_ts      TIMESTAMP NOT NULL,
                domn_evt_read_ts     TIMESTAMP NOT NULL,
                data_hub_crt_ts      TIMESTAMP NOT NULL,
                sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
                domn_evt_meta        TEXT NULL,
                prim_obj_key         BYTEA NULL,
                sor_evt_ts_tz_dst_cd SMALLINT NULL,
                sor_proc_ts_tz_dst_cd SMALLINT NULL,
                PRIMARY KEY (ship_key)
);


CREATE INDEX XIE1SHIPMENT_CHARACTERISTIC_FLAT ON dh_ship_char_flat
(
	prim_obj_key ASC
);

CREATE INDEX concurrently XIE2SHIPMENT_CHARACTERISTIC_FLAT ON DAAS_TM_PREPARED.dh_ship_char_flat
(
	eqp_id
);

CREATE INDEX concurrently XIE3SHIPMENT_CHARACTERISTIC_FLAT ON DAAS_TM_PREPARED.dh_ship_char_flat
(
	wb_nbr
);

CREATE INDEX concurrently XIE4SHIPMENT_CHARACTERISTIC_FLAT ON DAAS_TM_PREPARED.dh_ship_char_flat
(
	data_hub_crt_ts 
);
