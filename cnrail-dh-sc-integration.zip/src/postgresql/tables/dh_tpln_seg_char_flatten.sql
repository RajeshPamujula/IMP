DROP TABLE IF EXISTS dh_tpln_seg_char_flatten CASCADE;

CREATE TABLE dh_tpln_seg_char_flatten
(
                tpln_seg_key         BYTEA NOT NULL,
                tpln_seq_nbr         TEXT NOT NULL,
                trip_type_cd         TEXT NOT NULL,
                evt_cd               TEXT NOT NULL,
                evst_cd              TEXT NOT NULL,
                stn_333              TEXT NOT NULL,
                stn_prov_st_cd       TEXT NOT NULL,
                sch_evt_ts           TEXT NOT NULL,
                sch_evt_tz_dst_cd    TEXT NOT NULL,
                est_evt_ts           TEXT NOT NULL,
                est_evt_tz_dst_cd    TEXT NOT NULL,
                actl_evt_ts          TEXT NOT NULL,
                actl_evt_tz_dst_cd   TEXT NOT NULL,
                stn_seq_nbr          TEXT NOT NULL,
                trn_id               TEXT NOT NULL,
                tblk                 TEXT NOT NULL,
                yblk                 TEXT NOT NULL,
                jpdy_rsn_cd          TEXT NOT NULL,
                oper_rr_at_jct       TEXT NOT NULL,
                op_zts               TEXT NOT NULL,
                resch_rsn_cd         TEXT NOT NULL,
                asct_eqp_init        TEXT NOT NULL,
                asct_eqp_nbr         TEXT NOT NULL,
                eqp_init             TEXT NOT NULL,
                eqp_nbr              TEXT NOT NULL,
                yblk_cnct            TEXT NOT NULL,
                act_stus_ind         SMALLINT NOT NULL,
                sor_crlt_id          VARCHAR(256) NOT NULL,
                sys_key              BYTEA NOT NULL,
                rpt_clnt_id          VARCHAR(50) NULL,
                rpt_sor_proc_ts      TIMESTAMP NULL,
                sor_evt_ts           TIMESTAMP NOT NULL,
                rmv_clnt_id          VARCHAR(50) NULL,
                rmv_sor_proc_ts      TIMESTAMP NULL,
                sor_ingt_crt_ts      TIMESTAMP NOT NULL,
                sor_read_ts          TIMESTAMP NOT NULL,
                domn_evt_crt_ts      TIMESTAMP NOT NULL,
                domn_evt_read_ts     TIMESTAMP NOT NULL,
                data_hub_crt_ts      TIMESTAMP NOT NULL,
                sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
                domn_evt_meta        TEXT NULL,
                prim_obj_key         BYTEA NULL,
                sor_evt_ts_tz_dst_cd SMALLINT NULL,
                sor_proc_ts_tz_dst_cd SMALLINT NULL,
                PRIMARY KEY (tpln_seg_key)
);


CREATE INDEX XIE1TRIPPLANSEGMENTCHAR_flatten ON dh_tpln_seg_char_flatten
(
	prim_obj_key ASC
);

CREATE INDEX XIE2TRIPPLANSEGMENTCHAR_flatten ON dh_tpln_seg_char_flatten
(
	data_hub_crt_ts ASC, act_stus_ind,tpln_seg_key
);
