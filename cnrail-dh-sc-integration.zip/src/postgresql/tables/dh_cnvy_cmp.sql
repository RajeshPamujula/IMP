DROP TABLE IF EXISTS dh_cnvy_cmp CASCADE;

CREATE TABLE dh_cnvy_cmp
(
	cnvy_cmp_key         BYTEA NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	cnvy_cmp_type_key    BYTEA NOT NULL,
	cnvy_key             BYTEA NOT NULL,
	cnvy_type_key        BYTEA NOT NULL,
	cmp_key              BYTEA NOT NULL,
	cmp_type_key         BYTEA NOT NULL,
	id_type_key          BYTEA NOT NULL,
	id_val               TEXT NOT NULL,
	sor_crlt_id          VARCHAR(256) NOT NULL,
	sys_key              BYTEA NOT NULL,
	rpt_clnt_id          VARCHAR(50) NULL,
	rpt_sor_proc_ts      TIMESTAMP NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	rmv_clnt_id          VARCHAR(50) NULL,
	rmv_sor_proc_ts      TIMESTAMP NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	domn_evt_crt_ts      TIMESTAMP NOT NULL,
	domn_evt_read_ts     TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
	domn_evt_meta        TEXT NULL,
	prim_obj_key         BYTEA NULL,
	sor_evt_ts_tz_dst_cd SMALLINT NULL,
	sor_proc_ts_tz_dst_cd SMALLINT NULL,
	PRIMARY KEY (cnvy_cmp_key)
);

CREATE UNIQUE INDEX XAK1CONVEYOR_COMPOSITE ON dh_cnvy_cmp
(
	cnvy_key ASC,	cmp_key ASC
);

CREATE INDEX XIE1CONVEYOR_COMPOSITE ON dh_cnvy_cmp
(
	id_type_key ASC,	id_val ASC
);