DROP TABLE IF EXISTS dh_ship_char CASCADE;

CREATE TABLE dh_ship_char
(
	ship_key             BYTEA NOT NULL,
	char_type_key        BYTEA NOT NULL,
	char_val             TEXT NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	sor_crlt_id          VARCHAR(256) NOT NULL,
	sys_key              BYTEA NOT NULL,
	rpt_clnt_id          VARCHAR(50) NULL,
	rpt_sor_proc_ts      TIMESTAMP NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	rmv_clnt_id          VARCHAR(50) NULL,
	rmv_sor_proc_ts      TIMESTAMP NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	domn_evt_crt_ts      TIMESTAMP NOT NULL,
	domn_evt_read_ts     TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
	domn_evt_meta        TEXT NULL,
	prim_obj_key         BYTEA NULL,
	sor_evt_ts_tz_dst_cd SMALLINT NULL,
	sor_proc_ts_tz_dst_cd SMALLINT NULL,
	PRIMARY KEY (ship_key,char_type_key)
);

CREATE INDEX XIE1SHIPMENT_CHARACTERISTIC ON dh_ship_char
(
	prim_obj_key ASC
);

CREATE INDEX XIE2SHIPMENT_CHARACTERISTIC ON DAAS_TM_PREPARED.dh_ship_char
(
	char_type_key ASC,	char_val ASC
);

CREATE INDEX concurrently XIE3SHIPMENT_CHARACTERISTIC ON DAAS_TM_PREPARED.dh_ship_char
(
	ship_key,char_type_key, act_stus_ind,char_val
);


CREATE INDEX concurrently XIE4SHIPMENT_CHARACTERISTIC ON DAAS_TM_PREPARED.dh_ship_char
(
	data_hub_crt_ts 
);
