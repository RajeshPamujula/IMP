SET search_path TO daas_tm_prepared;
SET ROLE = daas_tm_prepared_admin;