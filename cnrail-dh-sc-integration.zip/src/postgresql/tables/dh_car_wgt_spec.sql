DROP TABLE IF EXISTS dh_car_wgt_spec CASCADE;

CREATE TABLE dh_car_wgt_spec
(
	car_ser_id           INTEGER NOT NULL,
	car_ser_init         CHAR(4) NOT NULL,
	car_ser_lo_val       CHAR(10) NOT NULL,
	car_ser_hi_val       CHAR(10) NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	car_ser_eff_dt       DATE NOT NULL,
	car_ser_exp_dt       DATE NOT NULL,
	car_ser_note         VARCHAR(50) NULL,
	load_lmt_20ft_bot_pos INTEGER NULL,
	load_lmt_40ft_bot_pos INTEGER NULL,
	load_lmt_40ft_top_pos INTEGER NULL,
	load_lmt_tral        INTEGER NULL,
	load_lmt_plfm        INTEGER NULL,
	load_lmt_bot_rto     DECIMAL(5,2) NULL,
	audt_crt_pgm_id      CHAR(8) NOT NULL,
	audt_crt_ts          TIMESTAMP NOT NULL,
	audt_crt_user_id     CHAR(8) NOT NULL,
	audt_upd_pgm_id      CHAR(8) NOT NULL,
	audt_upd_ts          TIMESTAMP NOT NULL,
	audt_upd_user_id     CHAR(8) NOT NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	PRIMARY KEY (car_ser_id)
);

CREATE UNIQUE INDEX XCWSP1 ON dh_car_wgt_spec
(
	car_ser_id ASC
);

CREATE UNIQUE INDEX XCWSP2 ON dh_car_wgt_spec
(
	car_ser_init ASC, car_ser_lo_val ASC, car_ser_hi_val ASC, car_ser_exp_dt ASC
);