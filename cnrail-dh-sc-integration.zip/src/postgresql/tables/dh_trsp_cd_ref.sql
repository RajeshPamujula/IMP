DROP TABLE IF EXISTS dh_trsp_cd_ref CASCADE;

CREATE TABLE dh_trsp_cd_ref
(
	trsp_cd_type          TEXT NOT NULL,
	trsp_cd               TEXT NOT NULL,
	act_stus_ind          SMALLINT NOT NULL,
	trsp_cd_dsc_eng       VARCHAR(70) NOT NULL,
	trsp_cd_dsc_fr        VARCHAR(70) NOT NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	PRIMARY KEY (trsp_cd_type,trsp_cd)
);