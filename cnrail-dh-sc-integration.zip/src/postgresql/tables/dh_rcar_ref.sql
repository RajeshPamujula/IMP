DROP TABLE IF EXISTS dh_rcar_ref CASCADE;

CREATE TABLE dh_rcar_ref
(
	rcar_key             BYTEA NOT NULL,
	eqp_init             VARCHAR(4) NOT NULL,
	eqp_nbr              VARCHAR(10) NOT NULL,
	isid_lgt_ft          SMALLINT NULL,
	osid_lgt_ft          DECIMAL NULL,
	nbr_of_plfm          SMALLINT NOT NULL,
	artt_cd              CHAR(1) NOT NULL,
	tare_wgt_lb          INTEGER NOT NULL,
	tot_wgt_rail_ton     SMALLINT NOT NULL,
	car_kind             CHAR(3) NOT NULL,
	xtrm_hgt_in          SMALLINT NOT NULL,
	xtrm_wdt_in          SMALLINT NOT NULL,
	load_lmt             SMALLINT NOT NULL,
	axle_cd              CHAR(1) NOT NULL,
	gst_cd               VARCHAR(3) NOT NULL,
	aar_eqp_type_cd      CHAR(4) NOT NULL,
	brng_cd              CHAR(1) NOT NULL,
	clnt_id              VARCHAR(50) NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_ingt_crt_ts      TIMESTAMP NULL,
	sor_read_ts          TIMESTAMP NULL,
	ref_evt_crt_ts       TIMESTAMP NULL,
	ref_evt_read_ts      TIMESTAMP NULL,
	src                  VARCHAR(100) NULL,
	domn_evt_meta        TEXT NULL,
	PRIMARY KEY (rcar_key)
);

CREATE UNIQUE INDEX XAK1RAILCAR_REFERENCE ON dh_rcar_ref
(
	eqp_init ASC,	eqp_nbr ASC
);