DROP TABLE IF EXISTS dh_cnvy_asct_char_flat CASCADE;


CREATE TABLE dh_cnvy_asct_char_flat
(
                asct_key             BYTEA NOT NULL,
                trn_seq_nbr          TEXT NOT NULL,
                sout_trk             TEXT NOT NULL,
                sout_stn_seq_nbr     TEXT NOT NULL,
                sout_stn_seq_ts      TEXT NOT NULL,
                pu_flag              TEXT NOT NULL,
                sout_flag            TEXT NOT NULL,
                eoc_cshn_flag        TEXT NOT NULL,
                car_rsdu_flag        TEXT NOT NULL,
                dngr_load_flag       TEXT NOT NULL,
                spcl_dngr_flag       TEXT NOT NULL,
                hvy_axle_flag        TEXT NOT NULL,
                dim_flag             TEXT NOT NULL,
                sout_scac            TEXT NOT NULL,
                sout_fsac            TEXT NOT NULL,
                sout_trk_seq_nbr     TEXT NOT NULL,
                act_stus_ind         SMALLINT NOT NULL,
                sor_crlt_id          VARCHAR(256) NOT NULL,
                sys_key              BYTEA NOT NULL,
                rpt_clnt_id          VARCHAR(50) NULL,
                rpt_sor_proc_ts      TIMESTAMP NULL,
                sor_evt_ts           TIMESTAMP NOT NULL,
                rmv_clnt_id          VARCHAR(50) NULL,
                rmv_sor_proc_ts      TIMESTAMP NULL,
                sor_ingt_crt_ts      TIMESTAMP NOT NULL,
                sor_read_ts          TIMESTAMP NOT NULL,
                domn_evt_crt_ts      TIMESTAMP NOT NULL,
                domn_evt_read_ts     TIMESTAMP NOT NULL,
                data_hub_crt_ts      TIMESTAMP NOT NULL,
                sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
                domn_evt_meta        TEXT NULL,
                prim_obj_key         BYTEA NULL,
                sor_evt_ts_tz_dst_cd SMALLINT NULL,
                sor_proc_ts_tz_dst_cd SMALLINT NULL,
                PRIMARY KEY (asct_key)
                
);

CREATE INDEX XIE1DH_CNVY_ASCT_CHAR_FLAT ON dh_cnvy_asct_char_flat
(
                prim_obj_key ASC
);

CREATE INDEX XIE2DH_CNVY_ASCT_CHAR_FLAT ON dh_cnvy_asct_char_flat
(
                data_hub_crt_ts ASC
);


