DROP TABLE IF EXISTS dh_trk_ref CASCADE;

CREATE TABLE dh_trk_ref
(
	trk_key              BYTEA NOT NULL,
	stn_333              CHAR(9) NOT NULL,
	stn_prst_cd          CHAR(2) NOT NULL,
	trk_nbr              VARCHAR(4) NOT NULL,
	trk_nm               VARCHAR(35) NOT NULL,
	trk_dir              CHAR(1) NOT NULL,
	trk_type_cd          CHAR(2) NOT NULL,
	trk_lgt_ft           INTEGER NOT NULL,
	pgbk_yd_ind          CHAR(1) NOT NULL,
	oasis_yd_ind         CHAR(1) NOT NULL,
	cust_intn_trk_ind    CHAR(1) NOT NULL,
	auto_strp_drmp_flag  CHAR(1) NOT NULL,
	clnt_id              VARCHAR(50) NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_ingt_crt_ts      TIMESTAMP NULL,
	sor_read_ts          TIMESTAMP NULL,
	ref_evt_crt_ts       TIMESTAMP NULL,
	ref_evt_read_ts      TIMESTAMP NULL,
	src                  VARCHAR(100) NULL,
	domn_evt_meta        TEXT NULL,
	PRIMARY KEY (trk_key)
);

CREATE UNIQUE INDEX XAK1TRACK_REFERENCE ON dh_trk_ref
(
	trk_nbr ASC,	stn_333 ASC,	stn_prst_cd ASC
);