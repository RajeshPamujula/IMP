DROP TABLE IF EXISTS dh_cnvy_cond_domn_evt CASCADE;

CREATE TABLE dh_cnvy_cond_domn_evt
(
	domn_evt_key         BYTEA NOT NULL,
	cond_char_key        BYTEA NOT NULL,
	domn_evt_type_key    BYTEA NOT NULL,
	cnvy_key             BYTEA NOT NULL,
	char_type_key        BYTEA NOT NULL,
	char_val             TEXT NOT NULL,
	sor_crlt_id          VARCHAR(256) NOT NULL,
	sys_key              BYTEA NOT NULL,
	clnt_id              VARCHAR(50) NOT NULL,
	sor_proc_ts          TIMESTAMP NOT NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	domn_evt_crt_ts      TIMESTAMP NOT NULL,
	domn_evt_read_ts     TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
	domn_evt_meta        TEXT NULL,
	sor_evt_ts_tz_dst_cd SMALLINT NULL,
	sor_proc_ts_tz_dst_cd SMALLINT NULL
) partition by hash (cnvy_key);

create table dh_cnvy_cond_domn_evt_p1  partition of dh_cnvy_cond_domn_evt for values with (modulus 5, remainder 0);
create table dh_cnvy_cond_domn_evt_p2  partition of dh_cnvy_cond_domn_evt for values with (modulus 5, remainder 1);
create table dh_cnvy_cond_domn_evt_p3  partition of dh_cnvy_cond_domn_evt for values with (modulus 5, remainder 2);
create table dh_cnvy_cond_domn_evt_p4  partition of dh_cnvy_cond_domn_evt for values with (modulus 5, remainder 3);
create table dh_cnvy_cond_domn_evt_p5  partition of dh_cnvy_cond_domn_evt for values with (modulus 5, remainder 4);

CREATE INDEX XIE1CONVEYOR_CONDITION_DOMAIN_EVENT ON dh_cnvy_cond_domn_evt
( 
	cnvy_key  ASC, char_type_key,  sor_proc_ts ASC
);

CREATE INDEX XIE2CONVEYOR_CONDITION_DOMAIN_EVENT ON dh_cnvy_cond_domn_evt
( 
	domn_evt_key
);