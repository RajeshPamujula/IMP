
DROP TABLE IF EXISTS dh_wb_haz_mat_note CASCADE;

CREATE TABLE dh_wb_haz_mat_note
(
	ship_key             BYTEA NOT NULL,
	haz_seq              SMALLINT NOT NULL,
	haz_note_seq         SMALLINT NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	wb_id                TEXT NOT NULL,
	haz_note             VARCHAR(70) NOT NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	PRIMARY KEY (ship_key,haz_seq,haz_note_seq)
);
