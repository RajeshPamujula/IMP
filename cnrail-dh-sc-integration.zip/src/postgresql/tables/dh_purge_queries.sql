DROP TABLE IF EXISTS daas_tm_prepared.DH_PURGE_QUERIES CASCADE;

CREATE TABLE daas_tm_prepared.DH_PURGE_QUERIES (
  purge_id            serial NOT NULL,
  table_name          varchar(64) NOT NULL,
  description         varchar(2000) NOT NULL,
  temp_table          varchar NULL,
  temp_table_column_list          varchar NULL,
  purge_query         varchar NOT NULL,
  active_status       char(1) NOT NULL DEFAULT 'A',
  CONSTRAINT DH_PURGE_QUERIES_PKEY PRIMARY KEY (purge_id)
);

/*
select purge_id,table_name,description,cast(temp_table as varchar(2000)), temp_table_column_list,purge_query
from dh_purge_queries;
*/
 
------------------------------dh_aset tables -------------------------------------------
/*
in scope: dh_aset_asct_char and dh_aset_asct
out of scope: dh_aset_asct_cond and dh_aset
issue: dh_aset_asct_char with act_stus_ind 

*/
-- dh_aset_asct_char 
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_aset_asct_char','Train Event - dh_aset_asct_char',
'select distinct aset_asct_char.asct_key 
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct           on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
inner join daas_tm_prepared.dh_aset_asct_char aset_asct_char on (cnvy_asct.prim_obj_key = aset_asct_char.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''',
'asct_key'
,'DELETE FROM daas_tm_prepared.dh_aset_asct_char del using filter r
WHERE del.asct_key = r.asct_key
','A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_aset_asct','Train Event - dh_aset_asct',
'select distinct aset_asct.asct_key 
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
inner join daas_tm_prepared.dh_aset_asct aset_asct on (cnvy_asct.prim_obj_key = aset_asct.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
 and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''',
 'asct_key' ,
 'DELETE FROM daas_tm_prepared.dh_aset_asct del using filter r
WHERE del.asct_key = r.asct_key',
'A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_aset_asct_char','Association purge dh_aset_asct_char',
'select distinct asct_key FROM daas_tm_prepared.dh_aset_asct A
 WHERE A.act_stus_ind <> 1',
'asct_key',
'DELETE FROM daas_tm_prepared.dh_aset_asct_char del using filter r
WHERE del.asct_key = r.asct_key','A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_aset_asct','Association purge dh_aset_asct',
'select distinct asct_key FROM daas_tm_prepared.dh_aset_asct A
 WHERE A.act_stus_ind <> 1',
'asct_key',
'DELETE FROM daas_tm_prepared.dh_aset_asct del using filter r
WHERE del.asct_key = r.asct_key','A');




-------------------------------Train Event - dh_plan_evt-------------------------------------
/*
in scope: dh_plan_evt,dh_plan_evt_char and dh_plan_evt_asct
out of scope: 
issue: NA

based on DBA tool, plan event table increasing daily, should have a good plan 
*/

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_plan_evt_char','Train Event - dh_plan_evt_char'
,'select distinct plan_evt_char.plan_evt_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
inner join daas_tm_prepared.dh_plan_evt plan_evt_char   on (cnvy_asct.prim_obj_key = plan_evt_char.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'''
,'plan_evt_key'
,'DELETE FROM daas_tm_prepared.dh_plan_evt_char del using filter r
WHERE del.plan_evt_key = r.plan_evt_key
','A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_plan_evt_asct','Train Event - dh_plan_evt_asct'
,'select distinct plan_evt_asct.asct_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
inner join daas_tm_prepared.dh_plan_evt_asct plan_evt_asct   on (cnvy_asct.prim_obj_key = plan_evt_asct.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_plan_evt_asct del using filter r
WHERE del.asct_key = r.asct_key
','A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_plan_evt','Train Event - dh_plan_evt'
,'select distinct plan_evt.plan_evt_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
inner join daas_tm_prepared.dh_plan_evt plan_evt   on (cnvy_asct.prim_obj_key = plan_evt.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''
',
'plan_evt_key',
'DELETE FROM daas_tm_prepared.dh_plan_evt del using filter r
WHERE del.plan_evt_key = r.plan_evt_key
','A');



insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_plan_evt_asct','Association purge dh_plan_evt_asct'
,'select distinct A.asct_key FROM daas_tm_prepared.dh_plan_evt_asct A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_plan_evt B where B.plan_evt_key  = A.plan_evt_key AND B.act_stus_ind = 1 )
or A.act_stus_ind <> 1'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_plan_evt_asct del using filter r
WHERE del.asct_key = r.asct_key','A');







--------------------------------------------------------dh_cnvy_asct and related tables------------------------------

/*
in scope: dh_cnvy_asct ,dh_cnvy_asct_char, dh_cnvy_asct_char_flat
out of scope: dh_aset_asct_cond and dh_aset
issue: dh_aset_asct_char with act_stus_ind 

*/



-- change to dh_cnvy_asct_char_flat, may use prim_obj_key for performance , initial purge needed, since trains were deleted.
-- delete from daas_tm_prepared.dh_cnvy_asct_char_flat  where data_hub_crt_ts <=current_timestamp  - INTERVAL '25 DAY'
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_asct_char_flat','Train Event - dh_cnvy_asct_char_flat',
'select distinct cnvy_asct_char.asct_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct           on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
inner join daas_tm_prepared.dh_cnvy_asct_char_flat cnvy_asct_char on (cnvy_asct.prim_obj_key = cnvy_asct_char.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''
',
'asct_key',
'DELETE FROM daas_tm_prepared.dh_cnvy_asct_char_flat del using filter r
WHERE del.asct_key = r.asct_key
','A');

-- should have filter index on dh_cnvy_asct
/*
create index XIE5CONVEYOR_ASSOCIATION on dh_cnvy_asct(data_hub_crt_ts , sor_tpic_nm, asct_key)
where sor_tpic_nm like '%.tm.raw.srs.trnReporting.%'

create UNIQUE INDEX XAK2CONVEYOR on dh_cnvy (data_hub_crt_ts  , cnvy_key)
where cnvy_type_key='c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698';


*/
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_asct_char','Train Event - dh_cnvy_asct_char',
'select distinct asct_key from daas_tm_prepared.dh_cnvy_asct cnvy_asct_char
where  (cnvy_asct_char.sor_tpic_nm like ''%.tm.raw.srs.trnReporting.%''
and cnvy_asct_char.data_hub_crt_ts <= current_timestamp - INTERVAL ''25 DAY'')',
'asct_key',
'DELETE FROM daas_tm_prepared.dh_cnvy_asct_char del using filter r
WHERE del.asct_key = r.asct_key'
,'A');


-- delete attribute if parent table act_stus_ind =0
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_asct_char','Association purge dh_cnvy_asct_char',
'select asct_key FROM daas_tm_prepared.dh_cnvy_asct A
 WHERE A.act_stus_ind <> 1',
'asct_key',
'DELETE FROM daas_tm_prepared.dh_cnvy_asct_char del using filter r
WHERE del.asct_key = r.asct_key','A');





insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_asct','Train Event - dh_cnvy_asct',
'select distinct cnvy_asct.asct_key   
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''
',
'asct_key',
'DELETE FROM daas_tm_prepared.dh_cnvy_asct del using filter r
WHERE del.asct_key = r.asct_key
','A');

-- train railcar association
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_asct','Train Event - dh_cnvy_asct',
'select   distinct cnvy_car.asct_key
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_train           on (cnvy.cnvy_key = cnvy_train.cnvy_key 
                                                             and cnvy_train.asct_obj_type_key = ''62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a''                          
                                                             and cnvy_train.cnvy_type_key         = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698'' )   
inner join daas_tm_prepared.dh_cnvy_asct cnvy_car             on (cnvy_train.asct_obj_key = cnvy_car.asct_obj_key
                                                             and  cnvy_car.asct_obj_type_key = ''62e0e5f3779a1a53d0ebade29933bc06fada4b32cad0c8429b6286904cc52d6a''   
                                                             and  cnvy_car.cnvy_type_key     = ''394db0bfdc21ee000a3a1d6fa3b05e99a8d76301862a9c9c866c9305136246d9'')                                                               
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''

',
'asct_key',
'DELETE FROM daas_tm_prepared.dh_cnvy_asct del using filter r
WHERE del.asct_key = r.asct_key
','A');



-- 
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_asct','Association purge dh_cnvy_asct',
'select asct_key FROM daas_tm_prepared.dh_cnvy_asct A
 WHERE A.act_stus_ind <> 1',
'asct_key',
'DELETE FROM daas_tm_prepared.dh_cnvy_asct del using filter r
WHERE del.asct_key = r.asct_key','A');




---------------------------------dh_loc_asct --------------------------------------

/*
in scope: dh_loc_asct ,dh_loc_asct_char
out of scope: NA
issue: dh_loc_asct_char with act_stus_ind 0

*/

-- very slow for deletion script, this table is involved with deadlock lots .
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_loc_asct_char','Train Event - dh_loc_asct_char'
,'select distinct loc_asct_char.asct_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_loc_asct loc_asct_char on (cnvy.cnvy_key = loc_asct_char.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_loc_asct_char del using filter r
WHERE del.asct_key = r.asct_key
','A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_loc_asct','Train Event - dh_loc_asct'
,'select distinct loc_asct.asct_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_loc_asct loc_asct on (cnvy.cnvy_key = loc_asct.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_loc_asct del using filter r
WHERE del.asct_key = r.asct_key
',
'A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_loc_asct_char','Association purge dh_loc_asct_char'
,'select distinct A.asct_key FROM daas_tm_prepared.dh_loc_asct_char A
left join  daas_tm_prepared.dh_loc_asct B on B.asct_key  = A.asct_key AND B.act_stus_ind = 1 
where B.asct_key is null
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_loc_asct_char del using filter r
WHERE del.asct_key = r.asct_key
'
,'A')
;







--------------------------------------------Train Event - dh_trsp_evt-------------------------------------------------------------------------------------------
/*
In scope:dh_trsp_evt_char, trsp_evt_key , dh_trsp_evt_asct_char and dh_trsp_evt_asct
Out of Scope:
Issues:

*/

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_trsp_evt_char','Train Event - dh_trsp_evt_char'
,'select distinct trsp_evt_char.trsp_evt_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
inner join daas_tm_prepared.dh_trsp_evt  trsp_evt_char   on (cnvy_asct.prim_obj_key = trsp_evt_char.prim_obj_key)
where  cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''

'
,'trsp_evt_key'
,'DELETE FROM daas_tm_prepared.trsp_evt_char del using filter r
WHERE del.trsp_evt_key = r.trsp_evt_key','A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_trsp_evt','Train Event - dh_trsp_evt'
,'select distinct trsp_evt.trsp_evt_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_asct cnvy_asct on (cnvy.cnvy_key = cnvy_asct.cnvy_key)
inner join daas_tm_prepared.dh_trsp_evt trsp_evt   on (cnvy_asct.prim_obj_key = trsp_evt.prim_obj_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''
'
,'trsp_evt_key'
,'DELETE FROM daas_tm_prepared.dh_trsp_evt del using filter r
WHERE del.trsp_evt_key = r.trsp_evt_key 
','A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_trsp_evt_asct','Association purge dh_trsp_evt_asct'
,'select distinct asct_key FROM daas_tm_prepared.dh_trsp_evt_asct A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_trsp_evt B where B.trsp_evt_key  = A.trsp_evt_key AND B.act_stus_ind = 1 )
or A.act_stus_ind <> 1'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_trsp_evt_asct del using filter r
WHERE del.asct_key = r.asct_key ','A');



insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_trsp_evt_asct_char','Association purge dh_trsp_evt_asct_char'
,'select asct_key FROM daas_tm_prepared.dh_trsp_evt_asct_char A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_trsp_evt_asct B where B.asct_key  = A.asct_key AND B.act_stus_ind = 1 )
--or A.act_stus_ind <> 1
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_trsp_evt_asct_char del using filter r
WHERE del.asct_key = r.asct_key','A');




-------------------------------Train Event: dh_cnvy_char and dh_cnvy--------------------------------------
/*
in scope: dh_cnvy_char ,dh_cnvy
out of scope: NA
issue: 

*/

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_char','Train Event - dh_cnvy_char','
select distinct cnvy_char.cnvy_key  
from daas_tm_prepared.dh_cnvy cnvy
inner join daas_tm_prepared.dh_cnvy_char cnvy_char on (cnvy.cnvy_key = cnvy_char.cnvy_key)
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''
',
'cnvy_key',
'DELETE FROM daas_tm_prepared.dh_cnvy_char del using filter r
WHERE del.cnvy_key = r.cnvy_key
','A');


---- should be last one from  Train Event --------------------

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy','Train Event - dh_cnvy',
'select distinct cnvy.cnvy_key   
from daas_tm_prepared.dh_cnvy cnvy
where cnvy.data_hub_crt_ts <= current_timestamp  - INTERVAL ''25 DAY''
and cnvy.cnvy_type_key = ''c023d1e31b043d79fc8fd5c7f1c3080812fc64f40cf15e7f2fdbf9a27ea15698''',
'cnvy_key',
'DELETE FROM daas_tm_prepared.dh_cnvy del using filter r
WHERE del.cnvy_key = r.cnvy_key
','A');



------------------------------------------------------Waybill closed or void----------

------------------------------------------------------------------------------------------------------------
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_wb_haz_mat_dsc','Waybill close - dh_wb_haz_mat_dsc',
'select distinct ship_key
from daas_tm_prepared.dh_wb_haz_mat_dsc
where ship_key in (select ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days'')
','ship_key'
,'DELETE FROM daas_tm_prepared.dh_wb_haz_mat_dsc del using filter r
WHERE del.ship_key = r.ship_key'
,'A');
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_wb_haz_mat_note','Waybill close - dh_wb_haz_mat_note'
,'select distinct ship_key
from daas_tm_prepared.dh_wb_haz_mat_note
where ship_key in (select ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days'')
'
,'ship_key'
,'DELETE FROM daas_tm_prepared.dh_wb_haz_mat_note del using filter r
WHERE del.ship_key = r.ship_key','A');
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_wb_haz_wast_info','Waybill close - dh_wb_haz_wast_info'
,'select distinct ship_key
from daas_tm_prepared.dh_wb_haz_wast_info
where ship_key in (select ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days'')
','ship_key'
,'DELETE FROM daas_tm_prepared.dh_wb_haz_wast_info del using filter r
WHERE del.ship_key = r.ship_key'
,'A');


--------------------------------------------------------------------------

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_asct_char','Waybill close - dh_ship_asct_char'
,'select distinct asct_key from daas_tm_prepared.dh_ship_asct_char 
where asct_key in (
SELECT asct_key from daas_tm_prepared.dh_ship_asct
where ship_key in(select ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'') 
and data_hub_crt_ts <= current_timestamp -interval '' 5 days''))
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_ship_asct_char del using filter r
WHERE del.asct_key = r.asct_key','A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_asct','Waybill close - dh_ship_asct',
'select distinct ship_key
from daas_tm_prepared.dh_ship_asct
where ship_key in (select ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days'')'
 ,'ship_key'
 ,'DELETE FROM daas_tm_prepared.dh_ship_asct del using filter r
WHERE del.ship_key = r.ship_key','A');







 
 
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_asct','Association purge dh_ship_asct'
,'select distinct asct_key FROM daas_tm_prepared.dh_ship_asct A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_ship B where B.ship_key  = A.ship_key AND B.act_stus_ind = 1 )
or A.act_stus_ind <> 1'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_ship_asct del using filter r
WHERE del.asct_key = r.asct_key','A');



insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_asct_char','Association purge dh_ship_asct_char'
,'select distinct asct_key FROM daas_tm_prepared.dh_ship_asct_char A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_ship_asct B where B.asct_key  = A.asct_key AND B.act_stus_ind = 1 )
--or A.act_stus_ind <> 1
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_ship_asct_char del using filter r
WHERE del.asct_key = r.asct_key'
,'A');





-----------------------------------------------------------------------------------

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_char','Waybill close - dh_ship_char'
,'select distinct ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days''
','ship_key'
,'DELETE FROM daas_tm_prepared.dh_ship_char del using filter r
WHERE del.ship_key = r.ship_key'
,'A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_cmp_char','Waybill close - dh_ship_cmp_char'
,'select distinct ship_cmp_key from daas_tm_prepared.dh_ship_cmp where ship_key in (
	select ship_key
	from daas_tm_prepared.dh_ship_cmp_char
	where ship_key in (select ship_key
	from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
	and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days''
))
','ship_cmp_key'
,'DELETE FROM daas_tm_prepared.dh_ship_cmp_char del using filter r
WHERE del.ship_cmp_key = r.ship_cmp_key','A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_cmp','Waybill close - dh_ship_cmp'
,'select distinct ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days''
','ship_key'
,'DELETE FROM daas_tm_prepared.dh_ship_cmp del using filter r
WHERE del.ship_key = r.ship_key','A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship','Waybill close - dh_ship'
,'select distinct ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days'' '
 ,'ship_key',
 'DELETE FROM daas_tm_prepared.dh_ship del using filter r
WHERE del.ship_key = r.ship_key'
 ,'A');
 

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_cond','Waybill close - dh_ship_cond'
,'select distinct ship_key
from daas_tm_prepared.dh_ship_cond where char_type_key=''1db3bf376984c20056913c1d5cc24224998ebc705d3896b8eece54ba2cb7f083''
and char_val in (''C'' , ''V'')  
 and data_hub_crt_ts <= current_timestamp -interval '' 5 days''
','ship_key'
,'DELETE FROM daas_tm_prepared.dh_ship_cond del using filter r
WHERE del.ship_key = r.ship_key'
,'A');


---
--------------------------------------------------dh_rte_char


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_rte_char','Purge dh_rte_char'
,'select distinct rte.rte_key    
from daas_tm_prepared.dh_rte rte
where rte.act_stus_ind=0'
 ,'rte_key'
 ,'DELETE FROM daas_tm_prepared.dh_rte_char del using filter r
WHERE del.rte_key = r.rte_key
','A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_rte','Purge dh_rte'
,'select distinct rte.rte_key    
from daas_tm_prepared.dh_rte rte
where rte.act_stus_ind=0'
 ,'rte_key'
 ,'DELETE FROM daas_tm_prepared.dh_rte del using filter r
WHERE del.rte_key = r.rte_key
','A');


---------------------------------------------------dh_tpln-----------------------------------------------------------

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_tpln','trip plan purge  dh_tpln'
,'select  distinct tpln_key FROM daas_tm_prepared.dh_tpln 
 WHERE act_stus_ind = 0'
,'tpln_key'
,'DELETE FROM daas_tm_prepared.dh_tpln del using filter r
WHERE del.tpln_key = r.tpln_key'
,'A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_tpln_asct'
,'Association purge dh_tpln_asct'
,'select distinct asct_key FROM daas_tm_prepared.dh_tpln_asct A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_tpln B where B.tpln_key  = A.tpln_key AND B.act_stus_ind = 1 )
or A.act_stus_ind <> 1'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_tpln_asct del using filter r
WHERE del.asct_key = r.asct_key','A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_tpln_char'
,'Association purge dh_tpln_char'
,'select tpln_key , char_type_key  FROM daas_tm_prepared.dh_tpln_char A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_tpln B where B.tpln_key  = A.tpln_key AND B.act_stus_ind = 1 )
or A.act_stus_ind <> 1
'
,'tpln_key , char_type_key'
,'DELETE FROM daas_tm_prepared.dh_tpln_char del using filter r
WHERE del.tpln_key = r.tpln_key and del.char_type_key = r.char_type_key','A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_tpln_seg','Association purge dh_tpln_seg'
,'select tpln_seg_key , tpln_seg_type_key FROM daas_tm_prepared.dh_tpln_seg A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_tpln B where B.tpln_key  = A.prim_obj_key AND B.act_stus_ind = 1 )
or A.act_stus_ind <> 1'
,'tpln_seg_key,tpln_seg_type_key'
,'DELETE FROM daas_tm_prepared.dh_tpln_seg del using filter r
WHERE del.tpln_seg_key = r.tpln_seg_key and del.tpln_seg_type_key = r.tpln_seg_type_key','A');

-- not used any more
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_tpln_seg_char','Association purge dh_tpln_seg_char'
,'select distinct tpln_seg_key  FROM daas_tm_prepared.dh_tpln_seg_char A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_tpln B where B.tpln_key  = A.prim_obj_key AND B.act_stus_ind = 1 )
--or A.act_stus_ind <> 1
'
,'tpln_seg_key '
,'DELETE FROM daas_tm_prepared.dh_tpln_seg_char del using filter r
WHERE del.tpln_seg_key = r.tpln_seg_key ','A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_tpln_seg_char_flatten','Association purge dh_tpln_seg_char_flatten'
,'select distinct tpln_seg_key  FROM daas_tm_prepared.dh_tpln_seg_char_flatten A
 WHERE NOT EXISTS (SELECT 1 FROM daas_tm_prepared.dh_tpln B where B.tpln_key  = A.prim_obj_key AND B.act_stus_ind = 1 )
or A.act_stus_ind <> 1'
,'tpln_seg_key '
,'DELETE FROM daas_tm_prepared.dh_tpln_seg_char_flatten del using filter r
WHERE del.tpln_seg_key = r.tpln_seg_key ','A');








------------------------dh_ship_cond_domn_evt---------------------Monday---------------------------------------------------------------------
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_cond_domn_evt',
'Purge dh_ship_cond_domn_evt every Monday based on dh_ship, initial purge needed',
'select distinct  a.ship_key FROM daas_tm_prepared.dh_ship_cond_domn_evt a
left join daas_tm_prepared.dh_ship b on a.ship_key = b.ship_key and b.act_stus_ind=1
where b.ship_key is null 
and extract(dow from current_date)::integer =1'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_ship_cond_domn_evt del using filter r
WHERE del.domn_evt_key = r.domn_evt_key','A');




------------------dh_ship_asct_char_domn_evt --------------- Monday --------------------------------------------------------------------------
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_ship_asct_char_domn_evt','purge dh_ship_asct_char_domn_evt each Monday based on dh_ship_asct , initial purge needed'
,'select distinct  a.asct_key FROM daas_tm_prepared.dh_ship_asct_char_domn_evt a
left join daas_tm_prepared.dh_ship_asct b on a.asct_key = b.asct_key and b.act_stus_ind=1
where b.asct_key is null 
and extract(dow from current_date)::integer =1
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_ship_asct_char_domn_evt del using filter r
WHERE del.asct_key = r.asct_key'
,'A');



---------------------------------------dh_trsp_evt_char_domn_evt--------- Tuesday ------------------------------------------------------------------
insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_trsp_evt_char_domn_evt','purge dh_trsp_evt_char_domn_evt every Tuesday based on dh_trsp_evt, initial purge may need'
,'select distinct  a.trsp_evt_key FROM daas_tm_prepared.dh_trsp_evt_char_domn_evt a
left join daas_tm_prepared.dh_trsp_evt b on a.trsp_evt_key = b.trsp_evt_key and b.act_stus_ind=1
where b.trsp_evt_key is null 
and extract(dow from current_date)::integer =2
'
,'trsp_evt_key'
,'DELETE FROM daas_tm_prepared.dh_trsp_evt_char_domn_evt del using filter r
WHERE del.trsp_evt_key = r.trsp_evt_key'
,'A');



-------------------- dh_trsp_evt_asct_char_domn_evt --------------------Wednesday------------------------------------

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_trsp_evt_asct_char_domn_evt','purge dh_trsp_evt_asct_char_domn_evt every Tuesday based on dh_trsp_evt_asct, Initial purge needed'
,'select distinct  a.asct_key FROM daas_tm_prepared.dh_trsp_evt_asct_char_domn_evt a
left join daas_tm_prepared.dh_trsp_evt_asct b on a.asct_key = b.asct_key and b.act_stus_ind=1
where b.asct_key is null 
and extract(dow from current_date)::integer =3
'
,'asct_key'
,'DELETE FROM daas_tm_prepared.dh_trsp_evt_asct_char_domn_evt del using filter r
WHERE del.asct_key = r.asct_key','A');




-----dh_cnvy_cond_domn_evt-----------------------------------------------Monday to Friday-------------------------------------


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_cond_domn_evt','Keep Last 2 Versions - dh_cnvy_cond_domn_evt_p1 every Monday'
,' select domn_evt_key from (select domn_evt_key, COND_CHAR_KEY,SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_cond_domn_evt_p1 
where extract(dow from current_date)::integer =1 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_cond_domn_evt_p1 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_cond_domn_evt','Keep Last 2 Versions - dh_cnvy_cond_domn_evt_p2 every Tuesday'
,' select domn_evt_key from (select domn_evt_key, COND_CHAR_KEY,SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_cond_domn_evt_p2 
where extract(dow from current_date)::integer =2 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_cond_domn_evt_p2 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_cond_domn_evt','Keep Last 2 Versions - dh_cnvy_cond_domn_evt_p3 every Wednesday'
,' select domn_evt_key from (select domn_evt_key, COND_CHAR_KEY,SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_cond_domn_evt_p3 
where extract(dow from current_date)::integer =3 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_cond_domn_evt_p3 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_cond_domn_evt','Keep Last 2 Versions - dh_cnvy_cond_domn_evt_p4 every Thursday'
,' select domn_evt_key from (select domn_evt_key, COND_CHAR_KEY,SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_cond_domn_evt_p4 
where extract(dow from current_date)::integer =4 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_cond_domn_evt_p4 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_cond_domn_evt','Keep Last 2 Versions - dh_cnvy_cond_domn_evt_p5 every Friday'
,' select domn_evt_key from (select domn_evt_key, COND_CHAR_KEY,SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_cond_domn_evt_p5 
where extract(dow from current_date)::integer =5 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_cond_domn_evt_p5 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');






--dh_cnvy_char_domn_evt------------------------------------------------ Monday to Friday-----------------------------------------------------------------------------------
-- train data do not exist in dh_cnvy_char_domn_evt

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_char_domn_evt','Keep Last 2 Versions - dh_cnvy_char_domn_evt_p1 every Monday'
,' select domn_evt_key from (select domn_evt_key, SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_char_domn_evt_p1 
where extract(dow from current_date)::integer =1 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_char_domn_evt_p1 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_char_domn_evt','Keep Last 2 Versions - dh_cnvy_char_domn_evt_p2 every Tuesday'
,' select domn_evt_key from (select domn_evt_key, SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_char_domn_evt_p2 
where extract(dow from current_date)::integer =2 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_char_domn_evt_p1 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');

insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_char_domn_evt','Keep Last 2 Versions - dh_cnvy_char_domn_evt_p3 every Wednesday'
,' select domn_evt_key from (select domn_evt_key, SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_char_domn_evt_p3 
where extract(dow from current_date)::integer =3 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_char_domn_evt_p3 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_char_domn_evt','Keep Last 2 Versions - dh_cnvy_char_domn_evt_p4 every Thursday'
,' select domn_evt_key from (select domn_evt_key, SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_char_domn_evt_p4 
where extract(dow from current_date)::integer =4 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_char_domn_evt_p4 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');


insert into daas_tm_prepared.DH_PURGE_QUERIES("table_name","description","temp_table","temp_table_column_list","purge_query","active_status")
values ('dh_cnvy_char_domn_evt','Keep Last 2 Versions - dh_cnvy_char_domn_evt_p5 every Friday'
,' select domn_evt_key from (select domn_evt_key, SOR_PROC_TS,ROW_NUMBER() OVER (PARTITION BY cnvy_key, char_type_key ORDER BY SOR_PROC_TS DESC) rk from daas_tm_prepared.dh_cnvy_char_domn_evt_p5 
where extract(dow from current_date)::integer =5 ) t where rk > 2'
,'domn_evt_key'
,'DELETE FROM daas_tm_prepared.dh_cnvy_char_domn_evt_p5 del using filter r
WHERE del.domn_evt_key = r.domn_evt_key'
,'A');





