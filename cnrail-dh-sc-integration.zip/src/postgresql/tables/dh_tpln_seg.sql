DROP TABLE IF EXISTS dh_tpln_seg CASCADE;

CREATE TABLE dh_tpln_seg
(
	tpln_seg_key         BYTEA NOT NULL,
	tpln_seg_type_key    BYTEA NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	tpln_seg_val         TEXT NOT NULL,
	sor_crlt_id          VARCHAR(256) NOT NULL,
	sys_key              BYTEA NOT NULL,
	rpt_clnt_id          VARCHAR(50) NULL,
	rpt_sor_proc_ts      TIMESTAMP NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	rmv_clnt_id          VARCHAR(50) NULL,
	rmv_sor_proc_ts      TIMESTAMP NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	domn_evt_crt_ts      TIMESTAMP NOT NULL,
	domn_evt_read_ts     TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
	domn_evt_meta        TEXT NULL,
	prim_obj_key         BYTEA NULL,
	sor_evt_ts_tz_dst_cd SMALLINT NULL,
	sor_proc_ts_tz_dst_cd SMALLINT NULL,
	PRIMARY KEY (tpln_seg_key)
) partition by hash (tpln_seg_key);

create table dh_tpln_seg_p1  partition of dh_tpln_seg for values with (modulus 3, remainder 0);
create table dh_tpln_seg_p2  partition of dh_tpln_seg for values with (modulus 3, remainder 1);
create table dh_tpln_seg_p3  partition of dh_tpln_seg for values with (modulus 3, remainder 2);

CREATE INDEX XIE1TRIPPLANSEGMENT ON dh_tpln_seg
(
	data_hub_crt_ts ASC, act_stus_ind,tpln_seg_key
);