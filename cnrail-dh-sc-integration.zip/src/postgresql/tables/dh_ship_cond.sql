DROP TABLE IF EXISTS dh_ship_cond CASCADE;

CREATE TABLE dh_ship_cond
(
	ship_key             BYTEA NOT NULL,
	char_type_key        BYTEA NOT NULL,
	char_val             TEXT NOT NULL,
	act_stus_ind         SMALLINT NOT NULL,
	sor_crlt_id          VARCHAR(256) NOT NULL,
	sys_key              BYTEA NOT NULL,
	rpt_clnt_id          VARCHAR(50) NULL,
	rpt_sor_proc_ts      TIMESTAMP NULL,
	sor_evt_ts           TIMESTAMP NOT NULL,
	rmv_clnt_id          VARCHAR(50) NULL,
	rmv_sor_proc_ts      TIMESTAMP NULL,
	sor_ingt_crt_ts      TIMESTAMP NOT NULL,
	sor_read_ts          TIMESTAMP NOT NULL,
	domn_evt_crt_ts      TIMESTAMP NOT NULL,
	domn_evt_read_ts     TIMESTAMP NOT NULL,
	data_hub_crt_ts      TIMESTAMP NOT NULL,
	sor_tpic_nm          VARCHAR(80) NOT NULL DEFAULT '',
	domn_evt_meta        TEXT NULL,
	sor_evt_ts_tz_dst_cd SMALLINT NULL,
	sor_proc_ts_tz_dst_cd SMALLINT NULL,
	PRIMARY KEY (ship_key,char_type_key)
);


CREATE INDEX CONCURRENTLY XIE1SHIPMENT_CONDITION ON dh_ship_cond
( 
	char_type_key,char_val
);


CREATE INDEX CONCURRENTLY XIE2SHIPMENT_CONDITION ON dh_ship_cond
( 
	data_hub_crt_ts ,act_stus_ind
);