DROP TABLE IF EXISTS offsethistory CASCADE;

CREATE TABLE offsethistory (
	id serial NOT NULL,
	"ms-name" varchar(255) NOT NULL,
	"ms-instance" varchar(255) NULL,
	env varchar(30) NULL,
	viewname varchar(255) NULL,
	lastfetch timestamp NOT NULL,
	status varchar(50) NULL,
	PRIMARY KEY (id)
);

CREATE UNIQUE INDEX xak1offsethistory ON offsethistory (viewname);
