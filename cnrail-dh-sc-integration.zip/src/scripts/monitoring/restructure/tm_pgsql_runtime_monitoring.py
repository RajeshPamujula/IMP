import psycopg2
import pandas as pd
from datetime import datetime,timedelta,date
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
import sqlalchemy
import os,sys
import argparse

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

#params
'''
pg_user_name = 'scdh-pgdb-azdb-uat'
pg_host = 'zcc1dhtmpgflex01u.postgres.database.azure.com'
pg_port = 5432
pg_db = 'datahub'
pg_passwd = '<pwd>'
pgsql_runtime_tbl_name  = 'dh_monitor_de_runtimes'
pgsql_schema = 'daas_tm_prepared'
'''
pg_user_name=sys.argv[1]
pgsql_schema=sys.argv[2]
pg_host=sys.argv[3]
pg_port=sys.argv[4]
pg_db=sys.argv[5]
pg_passwd=sys.argv[6]
pgsql_runtime_tbl_name=sys.argv[7]
pgsql_runDate=sys.argv[8] #'''YYYY-MM-DD Format

# if we not pass any date value default will take current date -1
if pgsql_runDate is None or len(pgsql_runDate) != 10:
    pgsql_runDate = str(date.today() + timedelta(days = -1))



pd.set_option('display.max_colwidth', 100)
pd.set_option('display.max_rows', 999)
pd.set_option('display.width', 1000)
'''
def convert_df_timedelta_to_str(df):
    for col in df.columns[3:]:
        df[col] = df[col].astype(str)
    return df
'''


if __name__ == '__main__':
    try:
        conn = psycopg2.connect(database=pg_db, user=pg_user_name, password=pg_passwd, host=pg_host, port=pg_port, sslmode='require')
        conn.autocommit = True
        print("starting conn")
        stmt = "select * from {}.f_run_dh_runtime_monitoring_current_state({});".format(pgsql_schema,"'" + pgsql_runDate + "'")
        df = pd.read_sql_query(stmt, conn)
        conn.close()
#        df = convert_df_timedelta_to_str(df)
#        print(len(df))
          
    except Exception as e:
        print ("Exception",e.with_traceback)
        if conn:
            conn.close()
        exit(RC_ERROR)