#!/bin/bash

# "**********************************************************************************************"
# Usage   : bash tm_monitoring_notification.sh -u PIN -e INT --jobs list,of,jobs [--email] [--db]
# Example : bash tm_monitoring_notification.sh -u 193459 -e SB --jobs error --db
# "**********************************************************************************************"

export currentDirectory=`dirname $0`

# Setting kinit
export KRB5_CONFIG=/etc/krb5.conf
unset KRB5CCNAME;
USER=${USER}

usage()
{
    echo "usage: bash tm_monitoring_notification.sh -u PIN -e INT --jobs list,of,jobs [--email] [--db]"
    echo "    valid job names: runtimes, jobstatus, volumes, error, integrity"
}

if [ $# -eq 0 ]; then
    echo "No arguments supplied"
    usage
    exit 1
fi

email=""
db=""
while [ "$1" != "" ]; do
    case $1 in
        -u | --username )       shift
                                USER=$1
                                ;;
        -e | --env)             shift
                                env=$1
                                ;;
        -j | --jobs )           shift
                                jobs=$1
                                ;;
        --email )               email="--email"
                                ;;
        --db )                  db="--db"
                                ;;
        -h | --help )           usage
                                exit
                                ;;
        * )                     usage
                                exit 1
    esac
    shift
done


# setup env
if [ "$env" != "" ]; then
    case $env in
        "SB"|"QA"|"INT"|"PROD"|"UAT" )
            kinit ${USER}@CN.CA -kt /home/${USER}/.${USER}.keytab > /dev/null 2>&1
            klist > /dev/null 2>&1
            source ${currentDirectory}/../../utilities/ENV_${env}.sh > /dev/null 2>&1
            ;;
        * )         
            echo "ERROR: Invalid ENV option: "$env
            usage
            exit -1
            ;;
    esac
else
    usage
    exit -1
fi

# Declaring Environment variables
export DH_ENV=${DH_ENV}
export HDP_VERSION=3.1
export PYSPARK_DRIVER_PYTHON=/opt/python3/bin/python
export PYSPARK_PYTHON=/opt/python3/bin/python
export SPARK_HOME=/usr/hdp/current/spark2-client
export SPARK_HISTORY_SERVER=${SPARK_HISTORY_SERVER}
export SPARK_HISTORY_PORT=${SPARK_HISTORY_PORT}
export SPARK_JOB_PREFIX=${SPARK_JOB_PREFIX}
export hostEnv=`hostname`
export EMAIL_TO=${TARGET_EMAILS_LIST}
export SPARK_CONF_FILE=${SPARK_CONF_DIR}/spark.conf

# add Python3 path
export PATH=/opt/python3/bin:$PATH

# Log file
LOG_PATH=$SPARK_LOG
if [[ ! -e $LOG_PATH ]]; then
    mkdir -p $LOG_PATH
fi
#rm -f $LOG_PATH/tm_monitoring_notification*.txt >/dev/null 2>&1
#LOGFILE=${LOG_PATH}/tm_monitoring_notification$$.txt

#rm -f $LOG_PATH/${USER}_tm_monitoring_notification*.txt >/dev/null 2>&1
#LOGFILE=${LOG_PATH}/${USER}_tm_monitoring_notification$$.txt


#touch ${LOGFILE}
#chmod 777 ${LOGFILE}

RC=0
for job in ${jobs//,/ }
do
    case $job in
		purge_data )
		rm -f $LOG_PATH/${USER}_tm_pgsql_purge_data*.txt >/dev/null 2>&1
		LOGFILE=${LOG_PATH}/${USER}_tm_pgsql_purge_data$$.txt
		touch ${LOGFILE}
		chmod 777 ${LOGFILE}
		spark-submit --name "${USER}_tm_pgsql_purge_data" --master yarn --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE ./tm_pgsql_purge_data.py -t $EMAIL_TO  >> ${LOGFILE} 2>&1
                    res=$?
                    ;;
		integrity )
		#rm -f $LOG_PATH/${USER}_tm_pgsql_integrity_controls*.txt >/dev/null 2>&1
		LOGFILE=${LOG_PATH}/${USER}_tm_pgsql_integrity_controls$$.txt
		touch ${LOGFILE}
		#chmod 777 ${LOG_FILE}
		spark-submit --name "${USER}_tm_pgsql_integrity_controls" --master yarn --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE ./tm_pgsql_integrity_controls.py -t $EMAIL_TO  >> ${LOGFILE} 2>&1
                    res=$?
                    ;;
        runtimes )
		rm -f $LOG_PATH/${USER}_tm_pgsql_runtime_monitoring*.txt >/dev/null 2>&1
		LOGFILE=${LOG_PATH}/${USER}_tm_pgsql_runtime_monitoring$$.txt
		touch ${LOGFILE}
		chmod 777 ${LOGFILE}
		spark-submit --name "${USER}_tm_pgsql_runtime_monitoring" tm_pgsql_runtime_monitoring.py -t $EMAIL_TO $email $db >> ${LOGFILE} 2>&1
                    res=$?
                    ;;
        jobstatus )
		rm -f $LOG_PATH/${USER}_tm_spark_monitoring*.txt >/dev/null 2>&1
		LOGFILE=${LOG_PATH}/${USER}_tm_spark_monitoring$$.txt
		touch ${LOGFILE}
		chmod 777 ${LOGFILE}
		spark-submit --name "${USER}_tm_spark_monitoring" tm_spark_monitoring.py -u "$USER" $db $email -t $EMAIL_TO >> ${LOGFILE} 2>&1
                    res=$?
                    ;;
        volumes )   
		rm -f $LOG_PATH/${USER}_tm_pgsql_volume_status*.txt >/dev/null 2>&1
		LOGFILE=${LOG_PATH}/${USER}_tm_pgsql_volume_status$$.txt
		touch ${LOGFILE}
		chmod 777 ${LOGFILE}
		spark-submit --name "${USER}_tm_pgsql_volume_status" --master yarn --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE ./tm_pgsql_volume_status.py -t $EMAIL_TO $email $db >> ${LOGFILE} 2>&1
                    res=$?
                    ;;
        error )     
		rm -f $LOG_PATH/${USER}_tm_failure_notification*.txt >/dev/null 2>&1
		LOGFILE=${LOG_PATH}/${USER}_tm_failure_notification$$.txt
		touch ${LOGFILE}
		chmod 777 ${LOGFILE}
		spark-submit --name "${USER}_tm_failure_notification" --master yarn --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE --jars $BUILD_PATH/jars/spark-sql-kafka-0-10_2.11-2.3.2.jar,$BUILD_PATH/jars/kafka-clients-0.10.2.2.jar ./tm_failure_notification.py -t $EMAIL_TO $email $db >> ${LOGFILE} 2>&1
                    res=$?
                    ;;
        purge )     
		rm -f $LOG_PATH/${USER}_tm_pgsql_purge_records*.txt >/dev/null 2>&1
		LOGFILE=${LOG_PATH}/${USER}_tm_pgsql_purge_records$$.txt
		touch ${LOGFILE}
		chmod 777 ${LOGFILE}
		spark-submit --name "${USER}_tm_pgsql_purge_records" tm_pgsql_purge_records.py -u "$USER" >> ${LOGFILE} 2>&1
                    res=$?
                    ;;
        * )         usage
                    exit 1
                    ;;
    esac
    RC=$(( res > RC ? res : RC))
done

exit $RC
