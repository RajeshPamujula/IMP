#!/usr/bin/env python
# coding: utf-8

'''
  Usage   :        Use the script to run monitoring queries to purge data in PostgreSQL tables
                   
  Changed : update existing function DDL to procedure DDL
  
pip3 install SQLAlchemy
pip3 install psycopg2-binary
pip3 install pandas

'''
import psycopg2
#import collections
import pandas as pd
#from datetime import datetime
#from email.mime.text import MIMEText
#from email.mime.multipart import MIMEMultipart
#from subprocess import Popen, PIPE
#import sqlalchemy
import argparse
import os,sys
#import logging

pd.set_option('display.max_colwidth', 100)
pd.set_option('display.max_rows', 999)
pd.set_option('display.width', 1000)

'''
pg_user_name = 'scdh-pgdb-azdb-uat'
pgsql_schema = 'daas_tm_prepared'
pg_host = 'zcc1dhtmpgflex01x.postgres.database.azure.com'
pg_port = 5432
pg_db = 'datahub'
pg_passwd='<pwd>'
'''
#Params

pg_user_name=sys.argv[1]
pgsql_schema=sys.argv[2]
pg_host=sys.argv[3]
pg_port=sys.argv[4]
pg_db=sys.argv[5]
pg_passwd=sys.argv[6]

if __name__ == '__main__':
    
    try:
        # connect to PostgreSQL DB
        conn = psycopg2.connect(database=pg_db, user=pg_user_name, password=pg_passwd, host=pg_host, port=pg_port, sslmode='require' )
        conn.autocommit = True
        #print("{0} INFO: Connected to: {1}/{2}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), pg_host,pg_db))
        #get all eligible queries
        df_queries = pd.read_sql_query(""" SELECT purge_id,table_name,description,purge_query
                                        FROM daas_tm_prepared.dh_purge_queries
                                        WHERE active_status = 'A'
                                        ORDER BY purge_id """, conn)
        #print(df_queries)
        df_list = []
        # execute f_run_dh_purge_queries procedure with purge_id params
        for purge_id in df_queries['purge_id']:
            conn.cursor().execute("""call {0}.f_run_dh_purge_queries({1})""".format(pgsql_schema, purge_id))
            print("""called procedure DDL with param : - call {0}.f_run_dh_purge_queries({1})""".format(pgsql_schema, purge_id))
            df_list.append(purge_id)
        
        print('\nTotal no of purge_ids passed in to f_run_dh_purge_queries procedure is:- '+str(df_list))
        
        # print the current records from dh_purge_results table limit 10
        df_purgeResults = pd.read_sql_query(""" SELECT * FROM daas_tm_prepared.dh_purge_results where purge_id in {0} order by purge_time desc limit 10 """.format(tuple(df_list)), conn)
        print('\n****** ---: dh_purge_results table records below :--- ******\n')
        #print(df_purgeResults.to_string(index=False))
        print(df_purgeResults)
    
    except Exception as e:
        print ("Exception",e.with_traceback)
        if conn:
            conn.close()

    # clean-up
    if(conn):
        conn.close()