#!/opt/python3/bin/python
# coding: utf-8

"""
  Usage   :        Use the script to record the size and row count of PostgreSQL tables
                   spark-submit --name "tm_pgsql_volume_status" --master yarn --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE \
                   ./tm_pgsql_volume_status.py [--db] [--email -t <email address>]
                   where either --db or --email are required, or both.
  Author  :        Jun Dai (189485) / Brendan McGarry (193459)
  Created :        2019-12-05
  Changed :        2019-12-18 Raphael MARY - Removed filter to show only 10 tables
  Updated :        2020-05-20 Parameterize schema list
"""

import psycopg2
import collections
import pandas as pd
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
import sqlalchemy
import argparse
import os,sys
import logging

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--to', action='store', dest='to_',
                        help="receiver's email address")
    parser.add_argument('-e', '--email', action='store_true', dest='send_email',
                        help="flag for whether to send an email")
    parser.add_argument('--db', action='store_true', dest='db_insert',
                        help="flag for whether to store in the database")
    parser.add_argument('-d', action='store', dest='opt_date', default='',
                        help="optional start date, format: yyyy-mm-dd")
    args = parser.parse_args()
    
    # must provide at least one arg of --email or --db
    if not (args.send_email or args.db_insert):
        parser.error("Must provide at least one of the arguments: --db or --email")
    
    # must provide a recipient with -t if --email is specified
    if args.send_email and not args.to_:
        parser.error("Must provide --to [email address] if --email is given.")
    
    return args

def send_email(subj,from_,to_,msg_body):
    """Send email to receiver
    
    Args:
        subj:      Email's subject
        from_:     Sender's email address
        to_:       Receiver's email address
        msg_body:  Email body in hmtl format
    Returns:
        
    """
    msg = MIMEMultipart('alternative')
    msg["From"] = from_
    msg["To"] = to_
    msg["Subject"] = subj
    HTML_BODY = MIMEText(msg_body, 'html')
    msg.attach(HTML_BODY)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    if (sys.version_info > (3, 0)):
        p.communicate(msg.as_bytes())
    else:
        p.communicate(msg.as_string())


# read vars from env file
try:
    user_name = os.environ["PG_USER"]
    pgsql_conn_str = os.environ["PG_CONN_URL"]
    jks_path = r'jceks://' + os.environ["PG_PWD_FILE"]
    alias_name = os.environ["PG_PWD_ALIAS"]
    schema_str = os.environ["PG_SCHEMA_LIST"]
    pgsql_schema = os.environ['PG_PREPARED_SCHEMA']
except KeyError as e:
    print("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
    sys.exit(-1)
    
        
# java keystore
# cmd to create jceks:    "hadoop credential create postgres.password.alias -provider jceks:/path/to/postgres.password.jceks"
# jks_path = "jceks://path/to/postgres.password.jceks"
# alias_name = "postgres.password.alias"
# source ..//utilities/ENV_*.sh

# PGSQL volume status report will be written back to postgreSQL
# - current row count
# - current table size
# schema_list = ['tm_raw','tm_prepared','tm_trusted']
schema_str = ','.join("'{0}'".format(w) for w in schema_str.split(','))

# postgreSQL
pgsql_volume_status_tbl_name = 'dh_monitor_data_volumes'

if '' in [user_name,pgsql_conn_str,jks_path,alias_name]:
    print('Error: PostgreSQL config is missing, check your ENV setting!')
    sys.exit(-1)

host = pgsql_conn_str.split(':')[2][2:]
port = pgsql_conn_str.split(':')[3].split('/')[0]
pg_db = pgsql_conn_str.split(':')[3].split('/')[1]

# to retrieve the passwd from jave keystore
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("yarn").appName(os.environ['USER'] + "_tm_pgsql_volume_status").getOrCreate()

x = spark.sparkContext._jsc.hadoopConfiguration()
x.set("hadoop.security.credential.provider.path", jks_path)
a = x.getPassword(alias_name)

passwd = ""
for i in range(a.__len__()):
    passwd = passwd + str(a.__getitem__(i))

# get the full table list for each schema
# return dict => {'schema name', [list of tables]}
def get_table_list(conn):
    cur = conn.cursor()
    stmt = "select table_schema, table_name from information_schema.tables where table_schema in ("+schema_str+") and table_type='BASE TABLE';"
    cur.execute(stmt)
    rows = cur.fetchall()
    conn.commit()
    cur.close()
    
    if(rows):
        c = collections.defaultdict(list)
        for a,b in rows:
            c[a].append(b)
        return dict(c.items())
    else:
        return None

# create Pandas data frame
def create_monitoring_df(conn, schema_tbl_dict):
    df = pd.DataFrame(columns=['exec_date', 'schema_name', 'tbl_name','tbl_size','row_count'])
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # iterate the schema_table_dict to get table size and row count
    cur = conn.cursor()
    for key,value in schema_tbl_dict.items():
        for tbl in value:
            tbl_name = key+'.'+tbl
            stmt = "SELECT  pg_relation_size ('"+tbl_name+"'), count(*) from "+tbl_name+";"
            cur.execute(stmt)
            rows = cur.fetchone()
            df = df.append({'exec_date':ts , 'schema_name':key , 'tbl_name':tbl ,'tbl_size':rows[0] ,'row_count':rows[1] }, ignore_index=True)
    df['exec_date']= pd.to_datetime(df['exec_date'])
    conn.commit()
    cur.close()
    return df

def sample_df(df):
    df_s = df.loc[df['tbl_name'] != pgsql_volume_status_tbl_name].sort_values(by =['exec_date', 'schema_name', 'tbl_name'])
    return df_s.sort_index()

def rename_cols_for_db(df):
    df_renamed = df.rename(columns={"tbl_name": "table_name", "tbl_size": "size"})
    return df_renamed

def write_df_to_pgsql(df):
    conn_str = "postgresql://{0}:{1}@{2}:{3}/{4}".format(user_name,passwd,host,port,pg_db)
    engine = sqlalchemy.create_engine(conn_str)
    df.to_sql(pgsql_volume_status_tbl_name, engine, schema=pgsql_schema.lower(),if_exists='append',index=False)

def generate_header(user):
    header  = ["PostgreSQL Volume Status Report"]
    header += ["<hr>"]
    header += [""]
    header += ["UTC Date and Time: " + datetime.strftime(datetime.now(), "%Y/%m/%d %H:%M:%S")]
    header += ["User: " + user]
    header += [""]
    return "<br>".join(header)

def generate_footer():
    footer  = [""]
    footer += ["<hr>"]
    footer += ["Ending " + os.path.basename(__file__) + " at " + datetime.strftime(datetime.now(), "%Y-%m-%d-%H.%M.%S")]
    footer += ["<hr>"]
    return "<br>".join(footer)


if __name__ == '__main__':
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=FORMAT)
    
    args = get_args()
    
    # connect to PostgreSQL DB
    conn = psycopg2.connect(database=pg_db, user=user_name, password=passwd, host=host, port=port)

    df = create_monitoring_df(conn, get_table_list(conn))
    
    if args.db_insert:
        # Persist the volume status result to postgreSQL
        write_df_to_pgsql(rename_cols_for_db(df))

    if args.send_email:
        # Email Report
        report  = generate_header(os.environ["USER"])
        report += "<br>"
        report += sample_df(df).to_html()
        report += "<br>"
        report += generate_footer()
        
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        subj = "PostgreSQL Volume Status Checks ({ts})".format(ts=ts)
        from_ = os.getenv("USER") + '@CN.CA'
        to_ = args.to_
        send_email(subj,from_,to_,report)
    
    # clean-up
    if conn:
        conn.close()
    exit(RC_SUCCESS)