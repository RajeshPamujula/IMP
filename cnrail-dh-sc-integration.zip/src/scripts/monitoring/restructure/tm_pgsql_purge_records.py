#!/usr/bin/env python
# coding: utf-8

'''
  Usage   :        Use the script to run delete purge records records in older than 30 days in PostgreSQL tables
                   spark-submit tm_pgsql_purge_records.py
  Author  :        Rajesh Pamujula (xt25766) / Uma
  Created :        2020-04-21
  Usage   :        spark-submit --name "tm_pgsql_purge_records" --master yarn --deploy-mode cluster --queue $YARN_QUEUE --keytab $USER_KEYTAB_BKUP --principal ${SPARK_USER_NAME}@CN.CA --files "/etc/krb5.conf#krb5.conf,$USER_KEYTAB#${USER}.keytab,$JAAS_CONFIG#jaas.conf" --conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf  -Djava.security.krb5.conf=krb5.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" --conf "spark.eventLog.enabled=true" --conf "spark.eventLog.dir=hdfs:///spark2-history/" --driver-java-options "-Djava.security.auth.login.config=jaas.conf" --properties-file $SPARK_CONF_FILE --jars $BUILD_PATH/jars/spark-sql-kafka-0-10_2.11-2.3.2.jar,$BUILD_PATH/jars/kafka-clients-0.10.2.2.jar \
                   ./tm_pgsql_purge_records.py
'''
import psycopg2
import pandas as pd
from datetime import datetime
from datetime import datetime, timedelta
from subprocess import Popen, PIPE
import sqlalchemy
import os,sys
import argparse
import logging
import time

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--to', action='store', dest='to_',
                        help="receiver's email address")
    parser.add_argument('-e', '--email', action='store_true', dest='send_email',
                        help="flag for whether to send an email")
    parser.add_argument('--db', action='store_true', dest='db_insert',
                        help="flag for whether to store in the database")
    parser.add_argument('-d', action='store', dest='opt_date', default='',
                        help="optional start date, format: yyyy-mm-dd")
    args = parser.parse_args()
    
    return args


user_name = os.environ["PG_USER"]
pgsql_conn_str = os.environ["PG_CONN_URL"]
jks_path = r'jceks://' + os.environ["PG_PWD_FILE"]
alias_name = os.environ["PG_PWD_ALIAS"]
pgsql_schema = os.environ['PG_PREPARED_SCHEMA']

# postgreSQL
#pgsql_audit_tbl_name = 'dh_monitor_de_runtimes'

if '' in [user_name, pgsql_conn_str, jks_path, alias_name]:
    print('Error: PostgreSQL config is missing, check your ENV setting!')
    sys.exit(-1)

host = pgsql_conn_str.split(':')[2][2:]
port = pgsql_conn_str.split(':')[3].split('/')[0]
pg_db = pgsql_conn_str.split(':')[3].split('/')[1]

# to retrieve the passwd from jave keystore
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("yarn").appName(user_name + "_" + "tm_pgsql_purge_records").getOrCreate()

x = spark.sparkContext._jsc.hadoopConfiguration()
x.set("hadoop.security.credential.provider.path", jks_path)
a = x.getPassword(alias_name)

passwd = ""
for i in range(a.__len__()):
    passwd = passwd + str(a.__getitem__(i))

pd.set_option('display.max_colwidth', 100)
pd.set_option('display.max_rows', 999)
pd.set_option('display.width', 1000)

def deletePurgeRecords(table,DeleteStmt):
    try:
        conn = psycopg2.connect(database=pg_db, user=user_name, password=passwd, host=host, port=port)
        logging.info("Successfully connected to PostGreSQL Database")
        conn.autocommit = True
        cursor = conn.cursor()
        cursor.execute(DeleteStmt)
        logging.info("Successfully Executed Delete Statement on table :- "+ table)
        time.sleep(3)
        cursor.execute(DeleteStmt)
        count = cursor.rowcount
        logging.info("Total no of deleted records count is : - "+ str(count))
        cursor.close()
        conn.close()
    except Exception as err:
        logging.error("ERROR has occured: - "+err)
        exit(RC_ERROR)
        if conn:
            conn.close()

if __name__ == '__main__':
    #args = get_args()
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=FORMAT)

    #args = get_args()
    
    purgeDays = 30 # purge the 30 days older records
    deletestmt_monitor_job = "delete from {}.dh_monitor_job_status WHERE "'"exec_date"'" < (now() - '{} days'::interval);".format(pgsql_schema,purgeDays)
    deletestmt_data_volumes = "delete from {}.dh_monitor_data_volumes WHERE "'"exec_date"'" < (now() - '{} days'::interval);".format(pgsql_schema,purgeDays)
    deletestmt_data_runtimes = "delete from {}.dh_monitor_de_runtimes WHERE "'"exec_date"'" < (now() - '{} days'::interval);".format(pgsql_schema,purgeDays)
    deletestmt_error_queue = "delete from {}.dh_monitor_error_queue WHERE "'"exec_date"'" < (now() - '{} days'::interval);".format(pgsql_schema,purgeDays)

    deletePurgeRecords("deletestmt_monitor_job",deletestmt_monitor_job)
    deletePurgeRecords("deletestmt_data_volumes",deletestmt_data_volumes)
    deletePurgeRecords("deletestmt_data_runtimes",deletestmt_data_runtimes)
    deletePurgeRecords("deletestmt_error_queue",deletestmt_error_queue)
    
    exit(RC_SUCCESS)
    
    
    
