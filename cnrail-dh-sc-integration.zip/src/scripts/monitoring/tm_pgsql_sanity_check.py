#!/opt/python3/bin/python
# coding: utf-8

'''
  Usage   :        spark-submit tm_pgsql_sanity_check.py -h
  Author  :        Jun Dai (189485)
  Created :        2020-05-24
  Desc    :
    -f the file path of input text file
    -t receiver's email address
  Example :
    spark-submit tm_pgsql_sanity_check.py -f path/tm_plsql_sanity_check.csv

'''

from datetime import datetime
import argparse
import os,sys,logging
import subprocess
import pandas as pd
import psycopg2
from psycopg2 import sql
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def send_email(subj,from_,to_,msg_body):
    msg = MIMEMultipart('alternative')
    msg["From"] = from_
    msg["To"] = to_
    msg["Subject"] = subj
    HTML_BODY = MIMEText(msg_body, 'html')
    msg.attach(HTML_BODY)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    if (sys.version_info > (3, 0)):
        p.communicate(msg.as_bytes())
    else:
        p.communicate(msg.as_string())
        
def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', action='store', dest='csv_file',
                        help="path to the csv file", required=True)
    parser.add_argument('-t', action='store', dest='to_',
                        help="email receiver", required=True)
    args = parser.parse_args()
    return args

def get_PgSQLConn(pg_user, pg_pwd, host, port, database):
    conn = psycopg2.connect(user=pg_user, password=pg_pwd, host=host, port=port, database=database)
    conn.set_client_encoding('UTF8')
    conn.autocommit = True
    return conn
    
def calc_record_count(row,cur,intvl='10 min'):
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    tbl_name = row['schema_name']+'.'+row['table_name']
    row['execution_ts_utc'] = ts
    stmt = "SELECT COUNT(*) FROM {} WHERE data_hub_crt_ts >= TIMESTAMP '{}' - INTERVAL '{}' AND SOR_TPIC_NM = '{}'".format(tbl_name,ts,intvl,row['sor_tpic_nm'])
    logging.debug(stmt)
    try:
        cur.execute(stmt)
        row['record_count'] = cur.fetchone()[0]
    except psycopg2.ProgrammingError as e:
        row['record_count'] = "{}.{} is not found".format(row['schema_name'],row['table_name'])
    return row
        
if __name__ == "__main__":
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=FORMAT)
    
    args = get_args()
    
    try:
        pgsql_schema = os.environ['PG_RAW_SCHEMA']
        user_name = os.environ["PG_USER"]
        pgsql_conn_str = os.environ["PG_CONN_URL"]
        jks_path = r'jceks://' + os.environ["PG_PWD_FILE"]
        alias_name = os.environ["PG_PWD_ALIAS"]
    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        exit(RC_ERROR)       
    
    # check env vars
    if '' in [user_name,pgsql_conn_str,jks_path,alias_name]:
        print('Error: PostgreSQL config is missing, check your ENV setting!')
        sys.exit(-1)
    
    # get pgsql passwd
    host = pgsql_conn_str.split(':')[2][2:]
    port = pgsql_conn_str.split(':')[3].split('/')[0]
    pg_db = pgsql_conn_str.split(':')[3].split('/')[1]
    
    # to retrieve the passwd from jave keystore
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.master("yarn").appName("tm_pgsql_sanity_check").getOrCreate()    
    x = spark.sparkContext._jsc.hadoopConfiguration()
    x.set("hadoop.security.credential.provider.path", jks_path)
    a = x.getPassword(alias_name)
    passwd = ""
    for i in range(a.__len__()):
        passwd = passwd + str(a.__getitem__(i))
    
    # create pgsql connection
    pg_conn = get_PgSQLConn(user_name, passwd, host, port, pg_db)
    cur = pg_conn.cursor()
    
    # read input file and send each line to Kafka queue as a message
    pdf = pd.read_csv(args.csv_file,skipinitialspace=True,header=0)
    pdf = pdf.apply(calc_record_count,args=(cur,),axis=1)
        
    # close pgsql connection
    if pg_conn:
        cur.close()
        pg_conn.close()
        
    # send email
    email_content = pdf.to_html(index=False)    
    user = os.getenv("USER") + '@CN.CA'
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    subj = "Sanity Checks " + ts + " <Report>"
    send_email(subj,user,args.to_,email_content)
    


    
