# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ### Import Required Python Libraries

# COMMAND ----------

import requests
import os
import json
import argparse
import time

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Databricks Credentials via Azure Key Vault Backed Secret Scope (URL, PAT)

# COMMAND ----------

# # url of databricks workspace
DBRK_URL = dbutils.secrets.get(scope="DATAHUBTM",key="scdh-azdb-url")
# # Used to store personnel access token for the service principal
DBRK_PAT = dbutils.secrets.get(scope="DATAHUBTM",key="scdh-azdb-pat")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Job Selection Limits(Constants set by User)

# COMMAND ----------

# The number of jobs the API should return. ref: https://docs.microsoft.com/en-us/azure/databricks/dev-tools/api/latest/jobs#--runs-list
NO_OF_JOBS_LIMIT = 1000
# time in seconds : for retrieving jobs history 
# 90000 seconds= 25 hours
SELECTION_INTERVAL = 90000

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Config with Permissions, used to override default permissions

# COMMAND ----------

conf = """{
        "dev":{"acl_to_add": [
          {
                "group_name": "DAAS_DATAHUB_ADMIN_NPD",
                "permission_level": "CAN_VIEW"
            },
            {
                "group_name": "DAAS_DATAHUBTM_DE_NPD",
                "permission_level": "CAN_VIEW"
            }
        ]
        },
        "uat":{"acl_to_add": [
          {
                "group_name": "DAAS_DATAHUB_ADMIN_NPD",
                "permission_level": "CAN_VIEW"
            },
            {
                "group_name": "DAAS_DATAHUBTM_DE_NPD",
                "permission_level": "CAN_VIEW"
            },
            {
                "group_name": "DAAS_DATAHUBTM_OPS",
                "permission_level": "CAN_VIEW"
            }
        ]
        },
        "stg":{"acl_to_add": [
          {
                "group_name": "DAAS_DATAHUB_ADMIN_NPD",
                "permission_level": "CAN_VIEW"
            },
            {
                "group_name": "DAAS_DATAHUBTM_DE_NPD",
                "permission_level": "CAN_VIEW"
            },
            {
                "group_name": "DAAS_DATAHUBTM_OPS",
                "permission_level": "CAN_VIEW"
            }
        ]
        },
        "prod":{"acl_to_add": [
          {
                "group_name": "DAAS_DATAHUB_ADMIN_NPD",
                "permission_level": "CAN_VIEW"
            },
            {
                "group_name": "DAAS_DATAHUBTM_DE_NPD",
                "permission_level": "CAN_VIEW"
            },
            {
                "group_name": "DAAS_DATAHUBTM_OPS",
                "permission_level": "CAN_VIEW"
            }
        ]
        }
}"""

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Functions

# COMMAND ----------

'''
    Build Authorization Bearer Token header for API Call Authorization.
'''
def get_header():
    header_json = {'Authorization': 'Bearer %s' % DBRK_PAT}
    return header_json

  
'''
    Parse config from conf variable.
'''
def parse_config(fl_config):
    config = json.loads(fl_config)
    return config
          

'''
    Select jobs for which the access needs to be provided.
    => selection_interval_seconds -> jobs run within the last x seconds from current time.
'''
def select_jobs(jobsList, selection_interval_seconds):
    print('Select jobs from list...')
    current_time = time.time()
    jobs_list = [[l1["job_id"],l1["creator_user_name"]] for l1 in jobsList["runs"]
                 if l1["run_type"] == "SUBMIT_RUN"
                 and (current_time - (l1["start_time"]/1000)) < selection_interval_seconds]
    print('jobs list {}'.format(jobs_list))
    return jobs_list
  
'''
    Build the new permissions to be applied to the job_cluster
'''  
def get_permission_for_update(env,job_access_details):

    try:
      new_perms = job_access_details[env]['acl_to_add']
    except:
      print("Unable to find the environment's permission within config")
            
    print("NEW_PERMS :", new_perms)
    return new_perms


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### API Calls

# COMMAND ----------

'''
    Get the List of latest 'n' jobs, where n is the limit
'''
def get_listof_jobs(limit):
    print('Fetching list of jobs ...')
    dbrk_rest_url = '%s/api/2.0/jobs/runs/list?run_type=SUBMIT_RUN&limit=%s' % (DBRK_URL, limit)
    response = requests.get(dbrk_rest_url, headers=get_header())
    return response.json()
  
'''
    Apply permission to the job/cluster
'''
# Ref:  https://docs.microsoft.com/en-us/azure/databricks/dev-tools/api/latest/permissions

def apply_permissions(job_id, updated_permissions):
    print('Applying permissions for job [{}]...'.format(job_id))
    permission_json = {
        "access_control_list": updated_permissions}
    print(permission_json)
    dbrk_rest_url = '%s/api/2.0/permissions/jobs/%s' % (
        DBRK_URL, job_id)
    print(dbrk_rest_url)
    response = requests.patch(dbrk_rest_url, headers=get_header(), json=permission_json)
    print(response.json())  

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Main Entry Point

# COMMAND ----------

import sys

if __name__ == "__main__":
    # total arguments
    n = len(sys.argv)
    print("Total arguments passed:", n)
 
    # Arguments passed
    print("\nName of Python script:", sys.argv[0])
 
    print("\nArguments passed:", end = " ")
    for i in range(1, n):
      print(sys.argv[i], end = " ")
      
    if n >= 1:
      env = sys.argv[1]
    else:
      env = 'dev'
  
    # Get the details from Conf file
    job_access_details = parse_config(conf)
    print("job_access_details :", job_access_details)

    # Get the List of jobs from which the required jobs are selected.
    jobsList = get_listof_jobs(NO_OF_JOBS_LIMIT)
    print("jobsList:",jobsList)
    
    if jobsList is not None:
      select_jobs_list = select_jobs(jobsList, SELECTION_INTERVAL)
    else:
      print("No Jobs Applicable to change permissions")
    
    # Get the new permissions to be applied. If Override flag is set, the permissions fro the conf is used, else it is derived from the pool.    
    new_permissions = get_permission_for_update(env,job_access_details)
    print("new_permissions:",new_permissions)

    # For all the jobs in the List apply the permissions.
    for jlst in select_jobs_list:
      jId = jlst[0]
      userId = jlst[1]
      print("JID:", jId , " USERID:", userId)
      apply_permissions(jId, new_permissions)
    

    print('Finished!!')

