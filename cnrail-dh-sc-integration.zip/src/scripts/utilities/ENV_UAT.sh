#!/bin/bash
# Environment Specific Variable Assignment
DH_USER=qa
DH_CONTAINER=scdh

SRC_STORAGE_ACC="zcc1dhtmsta01u"
ADLS_ROOT_DIR="abfss://${DH_CONTAINER}@${SRC_STORAGE_ACC}.dfs.core.windows.net/deploy"

# Environment Variable Export
sudo echo export DH_USER=qa >>/databricks/spark/conf/spark-env.sh

sudo echo export APPLICATION_ID="98bec299-5fec-4678-8145-9d5ce0abd153" >>/databricks/spark/conf/spark-env.sh
sudo echo export TENANT_ID="fd753b92-f3b7-49fa-95cf-aed075c0f21c" >>/databricks/spark/conf/spark-env.sh
sudo echo export DB_SECRET_SCOPE="DATAHUBTM" >>/databricks/spark/conf/spark-env.sh
sudo echo export DB_SECRET_KEY="scdh-az-appsp" >>/databricks/spark/conf/spark-env.sh
sudo echo export SRC_STORAGE_ACC="zcc1dhtmsta01u" >>/databricks/spark/conf/spark-env.sh
sudo echo export ADB_SCOPE="DATAHUBTM" >>/databricks/spark/conf/spark-env.sh
sudo echo export KAFKA_USER="scdh-ckafka-rwuname" >>/databricks/spark/conf/spark-env.sh
sudo echo export KAFKA_PWD="scdh-ckafka-rwpwd" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRUSTSTORE_FILE_LOCATION="/dbfs/scdh/deploy/scripts/conf/truststore.jks" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRUSTSTORE_PASSWORD="changeit" >>/databricks/spark/conf/spark-env.sh

# DATABRICKS & ADLS
sudo echo export ADLS_ROOT_DIR="abfss://${DH_CONTAINER}@${SRC_STORAGE_ACC}.dfs.core.windows.net/deploy" >>/databricks/spark/conf/spark-env.sh
sudo echo export SPARK_REFERENCE_DATA_DIR="${ADLS_ROOT_DIR}/reference_data" >>/databricks/spark/conf/spark-env.sh
sudo echo export SPARK_CHKPT_ROOT_DIR="${ADLS_ROOT_DIR}/checkpoint/" >>/databricks/spark/conf/spark-env.sh

# Kafka
sudo echo export KAFKA_BROKER_HOST="pkc-4k3y2.canadacentral.azure.confluent.cloud:9092" >>/databricks/spark/conf/spark-env.sh
############## Raw and domain queues for Act Train Schedule
sudo echo export TRANSPORTATION_ACT_TRN_SCH_RAW_SRSYIT="${DH_USER}.transportation.r-trnScheduleActive.raw.v2" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CNVY_CRT_PREPARED="${DH_USER}.transportation.cnvyCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CNVY_DSC_PREPARED="${DH_USER}.transportation.cnvyDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_RTE_PLAN_PREPARED="${DH_USER}.transportation.rtePlan.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CNVY_RMV_PREPARED="${DH_USER}.transportation.cnvyRmv.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_RTE_CANC_PREPARED="${DH_USER}.transportation.rteCanc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_RTE_DSC_PREPARED="${DH_USER}.transportation.rteDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############## Error queue for publish messages
sudo echo export TRANSPORTATION_RTE_ERR_PREPARED="${DH_USER}.transportation.rteErr.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############## Raw and domain queues for Train Reporting
sudo echo export TRANSPORTATION_TRN_RPTG_RAW_SRSYIT="${DH_USER}.transportation.r-trnReporting.raw.v3" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRAN_EVT_RPTD_PREPARED="${DH_USER}.transportation.trspEvtRpt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRAN_EVT_ASCT_PREPARED="${DH_USER}.transportation.trspEvtAsct.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CONV_ASCT_PREPARED="${DH_USER}.transportation.cnvyAsct.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CONV_ASCT_DESC_PREPARED="${DH_USER}.transportation.cnvyAsctDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_AST_ASCT_PREPARED="${DH_USER}.transportation.asetAsct.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_AST_ASCT_DESC_PREPARED="${DH_USER}.transportation.asetAsctDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_AST_CRT_PREPARED="${DH_USER}.transportation.asetCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_AST_DESC_PREPARED="${DH_USER}.transportation.asetDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############## Raw and domain queues for Car Inventory
sudo echo export TRANSPORTATION_CAR_INVE_RAW_SRSYIT="${DH_USER}.transportation.r-carInventory.raw.v2" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CNVY_COND_CRT_PREPARED="${DH_USER}.transportation.cnvyCondCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CNVY_COND_CHG_PREPARED="${DH_USER}.transportation.cnvyCondChg.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_EVT_ASSOC_DESC_PREPARED="${DH_USER}.transportation.trspEvtAsctDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_CRT_PREPARED="${DH_USER}.transportation.tripCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_DESC_PREPARED="${DH_USER}.transportation.tripDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_LOC_ASSOC_PREPARED="${DH_USER}.transportation.locAsct.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_LOC_ASSOC_DESC_PREPARED="${DH_USER}.transportation.locAsctDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_ASSOC_PREPARED="${DH_USER}.transportation.tripAsct.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_ASSOC_DESC_PREPARED="${DH_USER}.transportation.shipAsctDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CAR_INVENTORY_DELETE_PREPARED="${DH_USER}.transportation.car-inventory-deleted.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############## Error queue for implement messages
sudo echo export TRANSPORTATION_DH_PGLOGS_PREPARED="${DH_USER}.transportation.dhPGLogs.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############## Raw and domain queues for Train Consist
sudo echo export TRANSPORTATION_TRN_CONSIST_RAW_SRSYIT="${DH_USER}.transportation.r-trnConsist.raw.v2" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_PLAN_EVT_RPT_PREPARED="${DH_USER}.transportation.planEvtRpt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_PLAN_EVT_ASCT_PREPARED="${DH_USER}.transportation.planEvtAsct.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_EVT_DSC_PREPARED="${DH_USER}.transportation.trspEvtDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############## Raw Kafka queues for Terminal Event
sudo echo export TRANSPORTATION_TER_EVT_RAW_SRSIM="${DH_USER}.transportation.r-yardEvent.raw.v3" >>/databricks/spark/conf/spark-env.sh
############## Raw Kafka queues for Industrial Instruction/Reason
sudo echo export TRANSPORTATION_INDS_INSN_RAW_SRSYIT="${DH_USER}.transportation.r-indsInsn.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_PLAN_EVT_DSC_PREPARED="${DH_USER}.transportation.planEvtDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_PLAN_EVT_DSC_CHG_PREPARED="${DH_USER}.transportation.planEvtDscChg.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_PLAN_EVT_RMV_PREPARED="${DH_USER}.transportation.planEvtRmv.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CONV_DASCT_PREPARED="${DH_USER}.transportation.cnvyDasc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_GQL_SHP_UPDATE_PREPARED="${DH_USER}.transportation.shipment-updated.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_GQL_OFFSET_TRIGGER="${DH_USER}.transportation.shipment-updated-push.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and domain queues for Waybill
sudo echo export TRANSPORTATION_WAYBILL_RAW_SRSYIT="${DH_USER}.transportation.r-wayBill.raw.v3" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_DESC_PREPARED="${DH_USER}.transportation.shipDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_CRTD_PREPARED="${DH_USER}.transportation.shipCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_ASSOC_PREPARED="${DH_USER}.transportation.shipAsct.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_COND_CRT_PREPARED="${DH_USER}.transportation.shipCondCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Locomotive Inventory
sudo echo export TRANSPORTATION_LOCO_INV_RAW_SRSYIT="${DH_USER}.transportation.r-locomotive-inventory.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Waybill Reference
sudo echo export TRANSPORTATION_WAYBILLREFERENCE_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-reference.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and domain queues for GATE EVENT
sudo echo export TRANSPORTATION_GTE_EVT_RAW_SRSYIT="${DH_USER}.transportation.r-gateEvts.raw.v2" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRAN_EVT_RMV_PREPARED="${DH_USER}.transportation.trspEvtRmv.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and domain queues for ETAETD
sudo echo export TRANSPORTATION_ETA_ETD_UPDATE_RAW_SRSYIT="${DH_USER}.transportation.r-trnETAETD.raw.v2" >>/databricks/spark/conf/spark-env.sh
############ Raw and domain queues for IntermodalCarContainer
sudo echo export TRANSPORTATION_IMDL_CAR_CTNR_RAW_SRSYIT="${DH_USER}.transportation.r-carCtnr.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Car Inventory Intermodal
sudo echo export TRANSPORTATION_CAR_INV_IMDL_RAW_SRSIM="${DH_USER}.transportation.r-carInvImdl.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Voyage
sudo echo export TRANSPORTATION_VYG_RAW_SRSYIT="${DH_USER}.transportation.r-voyage.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and domain queue for Intermodal Bad Order
sudo echo export TRANSPORTATION_IBO_RAW_SRSYIT="${DH_USER}.transportation.r-imBadOrder.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CNVY_COND_CHG_PREPARED="${DH_USER}.transportation.cnvyCondChg.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and domain queue for Locomotive Position
sudo echo export TRANSPORTATION_LP_RAW_SRSYIT="${DH_USER}.transportation.r-locomotive-position.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_ASSET_COND_CRT_PREPARED="${DH_USER}.transportation.asset-condition-created.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Motor Carrier
sudo echo export TRANSPORTATION_MTR_CARR_RAW_SRSYIT="${DH_USER}.transportation.r-imMtrCarr.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_BUS_PRTR_CRT_PREPARED="${DH_USER}.transportation.busPrtrCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_BUS_PRTR_COND_CRT_PREPARED="${DH_USER}.transportation.busPrtrCondCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_BUS_PRTR_DSC_PREPARED="${DH_USER}.transportation.busPrtrDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_BUS_PRTR_RMV_PREPARED="${DH_USER}.transportation.busPrtrRmv.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Vessel
sudo echo export TRANSPORTATION_VSL_RAW_SRSYIT="${DH_USER}.transportation.r-vessel.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Port Station Info
sudo echo export TRANSPORTATION_PORT_STN_INFO_RAW_SRSYIT="${DH_USER}.transportation.r-portStnInfo.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Voyage Segment
sudo echo export TRANSPORTATION_VYG_SEG_RAW_SRSYIT="${DH_USER}.transportation.r-voyageSeg.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_PLAN_EVT_DASC_PREPARED="${DH_USER}.transportation.planEvtDasc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Rail Station Reference
sudo echo export TRANSPORTATION_RAILSTATION_REFERENCE="${DH_USER}.transportation.r-commonStn.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Car Reference
sudo echo export TRANSPORTATION_CAR_REFERENCE="${DH_USER}.transportation.r-commonUmler.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Track Reference
sudo echo export TRANSPORTATION_TRACK_REFERENCE="${DH_USER}.transportation.r-commonYrdTrk.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and domain queues for Waybill Seal
sudo echo export TRANSPORTATION_WAYBILL_SEAL_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-seal.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Intermodal Storage
sudo echo export TRANSPORTATION_IS_RAW_SRSYIT="${DH_USER}.supply.r-intermodal-storage.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Waybill Stopoff
sudo echo export TRANSPORTATION_WAYBILL_STOP_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-stop.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Waybill City Customer
sudo echo export TRANSPORTATION_WAYBILL_CITY_CUST_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-city-customer.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_CMP_CRT_PREPARED="${DH_USER}.transportation.shipCmpCrt.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_CMP_DSC_PREPARED="${DH_USER}.transportation.shipCmpDsc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_CMP_RMV_PREPARED="${DH_USER}.transportation.shipCmpRmv.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue and domain queue Carrier Foreign Station
sudo echo export TRANSPORTATION_CARR_FGN_STN_RAW_SRSYIT="${DH_USER}.transportation.r-carrFgnStn.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_LOC_CRT_PREPARED="${DH_USER}.transportation.location-created.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_LOC_DSC_PREPARED="${DH_USER}.transportation.location-described.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_LOC_RMV_PREPARED="${DH_USER}.transportation.location-removed.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Waybill Vessel
sudo echo export TRANSPORTATION_WAYBILL_VSL_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-vessel.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Umler
sudo echo export TRANSPORTATION_UMLER_RAW_SRSYIT="${DH_USER}.transportation.r-umler.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for System Equipment
sudo echo export TRANSPORTATION_SE_RAW_SRSYIT="${DH_USER}.transportation.r-system-equipment-extracted.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and Prepared queue for Customer
sudo echo export TRANSPORTATION_CUST_RAW_SRSYIT="${DH_USER}.transportation.r-cust.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_BUS_PRTR_ASSOC_PREPARED="${DH_USER}.transportation.business-partner-associated.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and Prepared queue for Commodity
sudo echo export TRANSPORTATION_COMM_RAW_SRSYIT="${DH_USER}.transportation.r-commodity.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_COMM_CRT_PREPARED="${DH_USER}.transportation.commodity-created.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_COMM_DSC_PREPARED="${DH_USER}.transportation.commodity-described.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_COMM_COND_CRT_PREPARED="${DH_USER}.transportation.commodity-condition-created.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_COMM_RMV_PREPARED="${DH_USER}.transportation.commodity-removed.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw Queue for Bad Order Code ReferenceLoad
sudo echo export TRANSPORTATION_BAD_ORDER_CODE_RAW_SRSYIT="${DH_USER}.transportation.r-bad-order-code-reference.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Current Inventory
sudo echo export TRANSPORTATION_CURR_INV_RAW_SRSYIT="${DH_USER}.transportation.r-currInvEvt.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CNVY_CMP_CRT_PREPARED="${DH_USER}.transportation.conveyor-composite-created.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_CNVY_CMP_DSC_PREPARED="${DH_USER}.transportation.conveyor-composite-described.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and Prepared queue for Station
sudo echo export TRANSPORTATION_STN_RAW_SRSYIT="${DH_USER}.transportation.r-station-master.raw.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_LOC_COND_CRT_PREPARED="${DH_USER}.transportation.location-condition-created.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and Prepared queue for Hazardous Commodity
sudo echo export TRANSPORTATION_HAZARD_COMM_RAW_SRSYIT="${DH_USER}.transportation.r-hazardous-commodity.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and Prepared queue for Waybill Lading
sudo echo export TRANSPORTATION_WAYBILL_LADING_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-lading.raw.v1 " >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_SHP_DASC_PREPARED="${DH_USER}.transportation.shipDasc.prepared.v1" >>/databricks/spark/conf/spark-env.sh
########### Raw queue for Storage Charge
sudo echo export TRANSPORTATION_STRG_CHRG_SRSYIT="${DH_USER}.transportation.storage-charge.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Non-System Equipment
sudo echo export TRANSPORTATION_NON_SE_RAW_SRSYIT="${DH_USER}.transportation.r-non-system-equipment-extracted.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Unit Location Update
sudo echo export TRANSPORTATION_ULU_RAW_SRSYIT="${DH_USER}.transportation.unit-location-updated.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Waybill Fumigation
sudo echo export TRANSPORTATION_WAYBILL_FUMIGATION_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-fumigation.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and Prepared queue for Waybill Special Condition Codes
sudo echo export TRANSPORTATION_WAYBILL_SP_COND_COD_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-special-condition-codes.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Ipro Unit Move Plan
sudo echo export TRANSPORTATION_IPRO_UNIT_MOVE_PLAN_RAW_SRSYIT="${DH_USER}.transportation.unit-move-plan.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Special Condition Code Reference
sudo echo export TRANSPORTATION_SPL_COND_CODE_REFERENCE="${DH_USER}.transportation.r-special-condition-code-reference.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Waybill Codes Reference
sudo echo export TRANSPORTATION_WAYBILL_CODES_REFERENCE="${DH_USER}.transportation.r-waybill-codes.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Customer Destionation Instruction
sudo echo export TRANSPORTATION_CUST_DEST_INSTR_RAW_SRSYIT="${DH_USER}.transportation.r-destination-instruction.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and Prepared queue for Waybill hazardous waste information
sudo echo export TRANSPORTATION_WAYBILL_HAZARDOUS_WASTE_INFO_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-hazardous-waste-information.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Waybill Hazardous Material Notes.
sudo echo export TRANSPORTATION_WAYBILL_HAZ_MAT_NOTE_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-hazardous-material-note.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Waybill Hazardous Material Description
sudo echo export TRANSPORTATION_WB_HAZ_MATRL_DESC_RAW_SRSYIT="${DH_USER}.transportation.r-waybill-hazardous-material-description.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw and Prepared queue for Trip Plan
sudo echo export TRANSPORTATION_TRIP_PLAN_RAW_SRSYIT="${DH_USER}.transportation.r-trpPlan.raw.v2" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_PLAN_ASSOC_PREPARED="${DH_USER}.transportation.trip-plan-associated.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_PLAN_CRT_PREPARED="${DH_USER}.transportation.trip-plan-created.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_PLAN_DSC_PREPARED="${DH_USER}.transportation.trip-plan-described.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_PLAN_RMV_PREPARED="${DH_USER}.transportation.trip-plan-removed.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_PLAN_SEG_CRT_PREPARED="${DH_USER}.transportation.trip-plan-segment-created.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_TRIP_PLAN_SEG_DSC_PREPARED="${DH_USER}.transportation.trip-plan-segment-described.prepared.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Stop Order
sudo echo export TRANSPORTATION_STOP_ORDER_RAW_SRSYIT="${DH_USER}.transportation.r-stop-order.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Equipment Owner
sudo echo export TRANSPORTATION_EQP_OWNER_RAW_SRSIM="${DH_USER}.transportation.r-equipment-owner.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Intermodal Note Events
sudo echo export TRANSPORTATION_IMDL_NTE_EVNT_RAW_SRSYIT="${DH_USER}.transportation.r-event-notation.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Hold Status Reference queue
sudo echo export TRANSPORTATION_HOLD_STATUS_CODE_RAW_SRSYIT="${DH_USER}.transportation.r-hold-status-code-reference.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for In Gate Request
sudo echo export TRANSPORTATION_IN_GATE_REQ_SRSYIT="${DH_USER}.transportation.in-gate-request.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Raw queue for Car Weight Specification
sudo echo export TRANSPORTATION_CAR_WGT_SPEC_RAW_SRSYIT="${DH_USER}.transportation.r-car-weight-specification.raw.v1" >>/databricks/spark/conf/spark-env.sh
############ Graphql queues
sudo echo export TRANSPORTATION_GQL_RCAR_EVT_RPT_PREPARED="${DH_USER}.transportation.railcar-event-reported.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_GQL_RCAR_OFFSET_TRIGGER="${DH_USER}.transportation.railcar-event-reported-push.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_GQL_TPLN_SEG_PREPARED="${DH_USER}.transportation.trip-plan-segment.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_GQL_TPLN_SEG_OFFSET_TRIGGER="${DH_USER}.transportation.trip-plan-segment-push.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_GQL_IM_UNIT_UPD_PREPARED="${DH_USER}.transportation.intermodal-unit-updated.prepared.v1" >>/databricks/spark/conf/spark-env.sh
sudo echo export TRANSPORTATION_GQL_IM_UNIT_UPD_OFFSET_TRIGGER="${DH_USER}.transportation.intermodal-unit-updated-push.prepared.v1" >>/databricks/spark/conf/spark-env.sh

# Postgres
sudo echo export PG_CONN_URL="jdbc:postgresql://zcc1dhtmpgflex01u.postgres.database.azure.com:6432/datahub?sslmode=require" >>/databricks/spark/conf/spark-env.sh
sudo echo export PG_USER="scdh-azpg-azdb-rwuname" >>/databricks/spark/conf/spark-env.sh
sudo echo export PG_PWD="scdh-azpg-azdb-rwpwd" >>/databricks/spark/conf/spark-env.sh
sudo echo export PG_PREPARED_SCHEMA="daas_tm_prepared" >>/databricks/spark/conf/spark-env.sh
sudo echo export PG_RAW_SCHEMA="daas_tm_raw" >>/databricks/spark/conf/spark-env.sh
sudo echo export PG_TRUSTED_SCHEMA="daas_tm_trusted" >>/databricks/spark/conf/spark-env.sh
sudo echo export PG_DRIVER="org.postgresql.Driver" >>/databricks/spark/conf/spark-env.sh

# Print to be sure that ENV file has been executed
echo "Executed env_uat.sh"
