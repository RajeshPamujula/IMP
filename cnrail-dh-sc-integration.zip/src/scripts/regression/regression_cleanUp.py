#!/opt/python3/bin/python
# coding: utf-8

'''
  Usage   :        spark-submit regression_cleanup.py -h
  Author  :        Jun Dai (189485)
  Created :        2020-03-30
  Desc    :
  - kill spark job
    The spark job launched by regression test has the naming convention as:
    regression_tm_jobClassName
    when kill the spark job, use cmd below:
    spark-submit regression_cleanup.py -c jobClassName1,jobClassName2,etc
    
  - delete Kafka topics
    spark-submit regression_cleanup.py -t topic1,topic2,etc
    
  - drop postgres tables
    spark-submit regression_cleanup.py -s table1,table2,etc
'''

import psycopg2
import argparse
import json
import os,sys,logging
import subprocess
from kafka.admin import KafkaAdminClient
from kafka import KafkaConsumer
from utilities import *

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', action='store', dest='spark_cls_name',
                        help="spark job class name", required=True)
    parser.add_argument('-t', action='store', dest='topics',
                        help="topic name", required=False)
    parser.add_argument('-s', action='store', dest='pg_tbls',
                        help="pgsql tables", required=False)
    args = parser.parse_args()
    return args    

args = get_args()

def exec_sql(user,passwd,host,port,db,sql_stmt):
    # establish connection
    conn = psycopg2.connect(database=db,user=user,password=passwd,host=host,port=port)
    conn.autocommit = True
    logging.info("Database is connected!")
    
    # define a cursor
    cur = conn.cursor()

    try:
        cur.execute(sql_stmt)
    except psycopg2.Error as e:
        logging.debug('Failed to execute Postgres Statement.\n{0}'.format(sql_stmt))
        logging.error(e)
        addTestResultRow(cleanUp=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
    finally:
        conn.close()

def del_topic(topic,bootstrap_srv):
    #KAFKA_BROKER_HOST="mtl-emp02d.cn.ca:6667,mtl-emp03d.cn.ca:6667,mtl-emp04d.cn.ca:6667"
    admin_client = KafkaAdminClient(bootstrap_servers=bootstrap_srv,sasl_mechanism='GSSAPI', sasl_kerberos_service_name='kafka',security_protocol='SASL_PLAINTEXT')
    topics = [topic]
    try:
        admin_client.delete_topics(topics, timeout_ms=None)
    except:
        logging.error("CleanUp: Failed to delete Kafka topic: '{}' with error '{}'".format(topic,sys.exc_info()[0]))
        addTestResultRow(cleanUp=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)

def clean_hdfs_dir(*argv):
    for hdfs_dir in argv:
        status = subprocess.call("hadoop fs -test -e {}".format(hdfs_dir), shell=True)
        if(status):
            logging.warn("HDFS directory {} does NOT exist.".format(hdfs_dir))        
        else:
            status = subprocess.call("hadoop fs -rm -r -f -skipTrash {}".format(hdfs_dir+'/*'), shell=True)
            if(status):
                logging.error("CleanUp: Failed to empty HDFS folder: '{}'".format(hdfs_dir))
                addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
                exit(RC_ERROR)
            else:
                logging.info("HDFS directory {} is clean now.".format(hdfs_dir))

def getTopics(bootstrap_srv,pattern=None):
    consumer = KafkaConsumer(bootstrap_servers=bootstrap_srv,enable_auto_commit=False, auto_offset_reset='earliest',consumer_timeout_ms=2000, security_protocol='SASL_PLAINTEXT', sasl_mechanism='GSSAPI', sasl_kerberos_service_name='kafka')
    topics = consumer.topics()
    consumer.close()
    ret = []
    if(pattern is not None):
        for topic in topics:
            if pattern in topic:
                ret.append(topic)
        return ret
    else:
        return topics
    
    
def main():
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(level=logging.INFO, format=FORMAT)

    # create test result table in sqlite3 DB (local: output/test_result.db)
    createTestResultTable()
    
    try:
        user_id            = os.environ["USER"]
        kafka_brokers      = os.environ["KAFKA_BROKER_HOST"]
        bootstrap_srv      = kafka_brokers.split(',')
        pg_uid             = os.environ["PG_USER"]
        pgsql_conn_str     = os.environ["PG_CONN_URL"]
        jks_path           = r'jceks://' + os.environ["PG_PWD_FILE"]
        alias_name         = os.environ["PG_PWD_ALIAS"]
        spark_chkpt_dir    = os.environ['REG_CHKPT_DIR']
        REG_PG_SCHEMA      = os.environ["REG_PG_SCHEMA"]
    except KeyError as e:
        logging.error("CleanUp: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        addTestResultRow(cleanUp=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
        
    # postgreSQL
    if '' in [pg_uid,pgsql_conn_str,jks_path,alias_name]:
        logging.error('CleanUp: PostgreSQL config is missing, check your ENV setting!')
        addTestResultRow(cleanUp=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
    
    host = pgsql_conn_str.split(':')[2][2:]
    port = pgsql_conn_str.split(':')[3].split('/')[0]
    pg_db = pgsql_conn_str.split(':')[3].split('/')[1]
    
    # Clean Spark
    if ":" not in args.spark_cls_name:
        logging.error('CleanUp: Invalid Spark class name!')
        addTestResultRow(cleanUp=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
        
    job_name = args.spark_cls_name  # tc_id:spark_class_name, eg. tc_id_1:Car
    tc_id = job_name.split(':')[0]
    cmd = "/opt/python3/bin/python regression_run.py -u {} -c {} -k".format(user_id,job_name)
    logging.info("kill the Spark job: "+cmd)
    subprocess.call(cmd,shell=True)
        
    # Clean Kafka
    # if -t is present, then only delete the listed topics
    # otherwise delete all topics the test case has created
    # test case topics must use the naming pattern "tc_id.PIN", eg. "tc_id_1.189485"
    if args.topics is not None:
        # delete topics
        topic_list = [ x.strip() for x in args.topics.split(',') if x]
        for topic in topic_list:
            del_topic(topic,kafka_brokers)
    else:
        pattern = tc_id + '.' + user_id
        for topic in getTopics(kafka_brokers,pattern):
            print(topic)
            del_topic(topic,kafka_brokers)
            
    # Clean PostgreSQL
    if args.pg_tbls is not None:
        # To retrieve the passwd from jave keystore
        # java keystore
        # cmd to create jceks:    "hadoop credential create postgres.password.alias -provider jceks:/path/to/postgres.password.jceks"
        # jks_path = "jceks://[hdfs|file]/path/to/postgres.password.jceks"
        # alias_name = "postgres.password.alias"
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.master("local").appName(user_id+"_tm_regression_cleanup").getOrCreate()
        x = spark.sparkContext._jsc.hadoopConfiguration()
        x.set("hadoop.security.credential.provider.path", jks_path)
        passwd_b = x.getPassword(alias_name)
        if not passwd_b:
            logging.error('CleanUp: Failed to retrieve pgsql password!')
            addTestResultRow(cleanUp=0,kw_id=args.spark_cls_name)
            exit(RC_ERROR)
        passwd = ""
        for i in range(passwd_b.__len__()):
            passwd = passwd + str(passwd_b.__getitem__(i))
            
        # create pgsql connection
        pg_tbl_list = [ x.strip() for x in args.pg_tbls.split(',')]
        for pg_tbl in pg_tbl_list:
            # drop tables
            pg_tbl = REG_PG_SCHEMA + '.' + pg_tbl
            sql_stmt = "DROP TABLE IF EXISTS " + pg_tbl
            logging.info("Exec sql statement: " + sql_stmt)
            exec_sql(pg_uid,passwd,host,port,pg_db,sql_stmt)
    
    # clean spark checkpoint directory
    clean_hdfs_dir(spark_chkpt_dir)
    
    # clean /tmp/tc_id_spark.conf
    spark_conf_fn = '/tmp/'+tc_id+'_spark.conf'
    subprocess.call("rm -f {}".format(spark_conf_fn), shell=True)
    
if __name__ == "__main__":
    main()
    udf_exit(RC_SUCCESS,cleanUp=1,kw_id=get_args().spark_cls_name)
    