#!/opt/python3/bin/python
# coding: utf-8

'''
  Usage   :        python regression_loadInput.py -h
  Author  :        Jun Dai (189485)
  Created :        2020-03-23
  Desc    :
  -t Kafka topic name
  -f the file path of input text file
  -r the file path of reference data file
  Example :
  python regression_loadInput.py -c SparkClassName -t topic_name -f input/input_file.json
  python regression_loadInput.py -c SparkClassName -t topic_name -f input/input_file.json -r /path/to/ref_data.csv
'''

from datetime import datetime
import argparse
import json
import os,sys,logging
from kafka import KafkaProducer
from kafka.errors import KafkaError
import subprocess
from utilities import *

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', action='store', dest='spark_cls_name',
                        help="spark job class name", required=True)
    parser.add_argument('-t', action='store', dest='topic',
                        help="topic name", required=True)
    parser.add_argument('-f', action='store', dest='json_file',
                        help="the json file to be sent", required=True)
    parser.add_argument('-r', action='store', dest='ref_data',
                        help="the reference data file", required=False)
    args = parser.parse_args()
    return args

args = get_args()
 
def put_hdfs(local_path,hdfs_path):
    status = subprocess.call("hadoop fs -put -f {} {}".format(local_path,hdfs_path), shell=True)
    if(status):
        logging.error("Failed to put reference data '{}' to HDFS folder: '{}'".format(local_path,hdfs_path))
        addTestResultRow(loadInput=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)        

def get_lines(fp):
    for l in fp:
        line = l.strip()
        if line:
            yield line
            
class KafkaWriter(object):
    def __init__(self, topic, bootstrap_servers):
        self.bootstrap_servers = bootstrap_servers
        self.topic = topic
        self.producer = KafkaProducer(bootstrap_servers=self.bootstrap_servers,sasl_mechanism='GSSAPI', sasl_kerberos_service_name='kafka',security_protocol='SASL_PLAINTEXT')
        #KafkaProducer(bootstrap_servers=bootstrap_srv,sasl_mechanism='GSSAPI', sasl_kerberos_service_name='kafka',security_protocol='SASL_PLAINTEXT',value_serializer=lambda m: json.dumps(m).encode('utf-8'))
    def publish(self,msg):        
        self.producer.send(topic=self.topic,value=msg)
        
    def close(self):
        if self.producer:
            self.producer.flush()
            self.producer.close()
        
def main():
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=FORMAT)
    
    try:
        REF_DATA_DIR = os.environ["SPARK_REFERENCE_DATA_DIR"]
    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        addTestResultRow(loadInput=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
        
    # create test result table in sqlite3 DB (local: output/test_result.db)
    createTestResultTable()
    
    # put reference data to HDFS
    if args.ref_data is not None:
        put_hdfs(args.ref_data,REF_DATA_DIR)
    
    try:
        kafka_brokers = os.environ["KAFKA_BROKER_HOST"]
    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        addTestResultRow(loadInput=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
    
    # read input file and send each line to Kafka queue as a message
    with open(args.json_file,mode='rb') as fp:
        kaf = KafkaWriter(args.topic,kafka_brokers)
        try:            
            for line in get_lines(fp):
                kaf.publish(line)
        except Exception as e:
            logging.error('Failed to send message to topic: {}'.format(kaf.topic), exc_info=e)
            addTestResultRow(loadInput=0,kw_id=args.spark_cls_name)
            exit(RC_ERROR)
        finally:
            kaf.close()

if __name__ == "__main__":
    main()
    addTestResultRow(loadInput=1,kw_id=get_args().spark_cls_name)
    exit(RC_SUCCESS)

    