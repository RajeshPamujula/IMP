'''
  Author:   jun.dai@cn.ca
  Date:     2020-03-24
  Usage:    python regression_run.py -h
  Example:  python regression_run.py -u 189485 -c TrainReportingDomainFeed -kt /path/.189485.keytab -pr 189485@CN.CA -kc /path/.189485.keytab.bak -j /path/jaas.conf -q default -sc /path/spark.conf -m cluster

'''

import argparse
import requests
from requests_kerberos import HTTPKerberosAuth, OPTIONAL
import os,sys,re
import logging
import json
from datetime import datetime
import time
from utilities import *

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2


def main():
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=FORMAT)
    
    args = get_args()
    
    ts = datetime.utcnow()
    
    # create test result table in sqlite3 DB (local: output/test_result.db)
    createTestResultTable()
    
    try:
        yarn_rm_http_url   = os.environ["YARN_RM_HOST_URL"]
        jaas_config        = os.environ["JAAS_CONFIG"]
        spark_jar_loc      = os.environ["SPARK_JAR_LOC"]
        ca_path            = os.environ["CA_PATH"]
        spark_timeout      = os.environ.get("REG_TIMEOUT")
        user               = args.user_id
        jobNames           = args.classNames.replace(':','_')
        tc_id,className    = args.classNames.split(':')

    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        addTestResultRow(sparkRun=0,kw_id=args.classNames)
        exit(RC_ERROR)
    
    default_ca_bundle = os.path.join(ca_path, 'CN.bundle.pem')
    kerberos_auth = HTTPKerberosAuth(mutual_authentication=OPTIONAL)

    running_jobs = get_spark_history(default_ca_bundle, kerberos_auth, yarn_rm_http_url)
    if(running_jobs):
        # search for the running job with name provided, if exists, kill them
        kill_spark_job(default_ca_bundle,kerberos_auth,yarn_rm_http_url, find_app_ids(running_jobs, [jobNames]))
 
    # deploy the spark job
    if not get_args().kill_only:
        deploy_spark_jobs([(tc_id,className)],spark_jar_loc)
    else:
        return 0    
        
    # wait and let spark job finish
    if spark_timeout is None:
        spark_timeout = 60
    time.sleep(int(spark_timeout))
    
    # check job status, startedTime > ts
    app_info = get_latest_job(default_ca_bundle, kerberos_auth, yarn_rm_http_url,[jobNames],ts)
    if app_info: #('id','name','startedTime','state','finalStatus')
        if app_info[3] not in ['RUNNING', 'FINISHED']:
            logging.error("The '{}' state of spark job '{}':'{}' is NOT valid.".format(app_info[3],app_info[0],app_info[1]))
            kill_spark_job(default_ca_bundle,kerberos_auth,yarn_rm_http_url,[app_info])
            udf_exit(RC_ERROR,sparkRun=0,kw_id=get_args().classNames)
        else:
            # finalStatus = ['UNDEFINED', 'SUCCEEDED', 'FAILED', 'KILLED']
            if app_info[3] == 'FINISHED' and app_info[4] != 'SUCCEEDED':
                logging.error("The '{}' finalStatus of spark job '{}':'{}' is NOT valid.".format(app_info[4],app_info[0],app_info[1]))
                kill_spark_job(default_ca_bundle,kerberos_auth,yarn_rm_http_url,[app_info])
                udf_exit(RC_ERROR,sparkRun=0,kw_id=get_args().classNames)
    else:
        logging.error("Cannot get the application information of spark class {}".format(jobNames))
        udf_exit(RC_ERROR,sparkRun=0,kw_id=get_args().classNames)
        
def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', action='store', dest='user_id',
                        help="The user ID to filter on for all Spark jobs", required=True)                   
    parser.add_argument('-c', action='store', dest='classNames',
                        help="Job names to be handled.", required=True)
    parser.add_argument('-kt', action='store', dest='keytab',
                        help="kerberos keytab abs path")
    parser.add_argument('-pr', action='store', dest='principal',
                        help="kerberos principal")
    parser.add_argument('-kc', action='store', dest='kt_copy',
                        help="keytab copy")                    
    parser.add_argument('-j', action='store', dest='jaas',
                        help="jaas conf")
    parser.add_argument('-b', action='store', dest='no_block',
                        help="1: non-blocking, 0: blocking mode", default=1, type=int)
    parser.add_argument('-m', action='store', dest='cluster_mode',
                        help="cluster|client", default='client', type=str)
    parser.add_argument('-q', action='store', dest='yarn_queue',
                        help="yarn queue", default='default', type=str)
    parser.add_argument('-k', dest='kill_only',
                        help="kill only", default=False, action='store_true')
    parser.add_argument('-o', dest='opts',
                        help="options", default="--num-executors 1 --driver-memory 2g --executor-memory 2g --executor-cores 1", type=str)
    parser.add_argument('-sc', dest='spark_conf',
                        help="spark conf file path", type=str)
    args = parser.parse_args()
    return args

def find_app_ids(jobs_dict, jobNames, keywd = 'regression'):
    # iterate the jobNames, if there is running job, return the app Id
    # spark job naming rule: regression_className, eg. regression_tm_prepared_Car
    # jobs_dict: {'application_id': 'regression_tm_load_Car'}
    # jobNames: ['Car','ActiveTrainScheduleFeed']
    # pattern:  ^regression.*Car$
    
    className_patterns = [ '^'+keywd+'.*'+jobName+'$' for jobName in jobNames]
    if jobs_dict:
        rt = []
        for app_id, app_name in jobs_dict.items():
            for pattern in className_patterns:
                if re.match(pattern, app_name):
                    rt.append((app_id,app_name))
        # In theory, app name should be unique
        return rt
    return None


def get_spark_history(bundle, kerberos_auth, yarn_rm_http_url, status='running'):
    r = requests.get('http://{}/ws/v1/cluster/apps?states={}'.format(yarn_rm_http_url,status), verify=bundle, auth=kerberos_auth)
    spark_history_dict = json.loads(r.text)
    running_jobs = {}
    for d in spark_history_dict["apps"]["app"]:
        running_jobs[d['id']]=d['name']
    if running_jobs:
        return running_jobs
    else:
        return None

def get_spark_full_history(bundle, kerberos_auth, yarn_rm_http_url):
    r = requests.get('http://{}/ws/v1/cluster/apps'.format(yarn_rm_http_url), verify=bundle, auth=kerberos_auth)
    spark_history_dict = json.loads(r.text)
    spark_jobs = {}
    for d in spark_history_dict["apps"]["app"]:
        spark_jobs[d['id']]=(d['name'],get_ts_from_epoch(d['startedTime']),d['state'],d['finalStatus'])
    if spark_jobs:
        return spark_jobs
    else:
        return None

def kill_spark_job(bundle,kerberos_auth,yarn_rm_http_url, app_ids):
    header = {
        "Content-Type" : "application/json"
    }
    payload = {
        "state" : "KILLED"
    }
    if app_ids:
        for app_id in app_ids:
            logging.warn("WARN: {}:'{}' is still running, it will be killed for the purpose of regression test clean-up.".format(app_id[0],app_id[1]))
            r = requests.put('http://{}/ws/v1/cluster/apps/{}/state'.format(yarn_rm_http_url,app_id[0]), headers=header, data=json.dumps(payload),verify=bundle, auth=kerberos_auth)
            assert r.status_code in (200, 202), "(PUT) HTTP Error: " + str(r.status_code)
            logging.warn("WARN: {} has been killed successfully.".format(app_id[0]))


def get_app_state(bundle,kerberos_auth,yarn_rm_http_url,appId):
    r = requests.get('http://{}/ws/v1/cluster/apps/{}/state'.format(yarn_rm_http_url,appId), verify=bundle, auth=kerberos_auth)
    spark_app_state_dict = json.loads(r.text)
    if spark_app_state_dict: # {'state': 'RUNNING'}
        return (spark_app_state_dict)
    else:
        return None 

# if ts is None, get the latest spark job of all spark jobs
# else get the latest one of whose startedTime > ts    
def get_latest_job(default_ca_bundle, kerberos_auth, yarn_rm_http_url,jobNames,ts=None,keywd='regression'):
    all_spark_jobs = get_spark_full_history(default_ca_bundle, kerberos_auth, yarn_rm_http_url)    
    className_patterns = [ '^'+keywd+'.*'+jobName+'$' for jobName in jobNames]
    if all_spark_jobs:
        app_list = []
        for app_id, app_info in all_spark_jobs.items():
            for pattern in className_patterns:
                if re.match(pattern, app_info[0]):
                    if ts is not None:
                        if app_info[1] > ts:
                            app_list.append((app_id,app_info[0],app_info[1],app_info[2],app_info[3]))
                    else:
                        app_list.append((app_id,app_info[0],app_info[1],app_info[2],app_info[3]))    
    #('id','name','startedTime','state','finalStatus')
    if app_list:
        if len(app_list) >= 1:
            app_list.sort(key=lambda tup: tup[2],reverse=True)  # sort by startedTime
            return app_list[0]
    else:
        return None

def deploy_spark_jobs(jobNames,jar_loc):
    for jobNameTuple in jobNames:  # (tc_id,className)
        spark_submit_proc(jobNameTuple,jar_loc)


def spark_submit_proc(className,jar_loc):
    # call spark-submit
    appName = 'regression_tm_'+className[0]+'_'+className[1]  # prefix = 'regression_tm_'
    kt_fname = os.path.basename(get_args().keytab)
    kt_fname = kt_fname if kt_fname[0] != '.' else kt_fname[1:]

    app_conf = jar_loc + '/'+ className[1] + '/classes/application.conf'
    class_name = '--class ' + className[1] 
    mode = '--master yarn --deploy-mode ' + get_args().cluster_mode.lower()
    yarn_queue = '--queue '+get_args().yarn_queue
    config = '--conf "spark.executor.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf" '
    config += '--conf "spark.driver.extraJavaOptions=-XX:+UseG1GC -Djava.security.auth.login.config=jaas.conf -Djava.security.krb5.conf=krb5.conf"'
    driver = '--driver-java-options "-Djava.security.auth.login.config=jaas.conf -Dconfig.file.name=application.conf"'
    jar_file = jar_loc + '/'+ className[1] + '/*.jar'
    opts = get_args().opts
    spark_conf = '--properties-file ' + get_args().spark_conf
    keytab = '--keytab=' + get_args().kt_copy + ' ' + '--principal='+ get_args().principal
    files = '--files "/etc/krb5.conf#krb5.conf,' + get_args().keytab+'#'+kt_fname+','+get_args().jaas+'#jaas.conf,'+app_conf+'#application.conf"'
    f_log = os.environ["SPARK_LOG"]+'/' + className[0] + '_' + className[1] + '.log'
    cmd = 'spark-submit ' + ' '.join(['--name '+appName,mode,class_name,opts,keytab,files,config,driver,yarn_queue,spark_conf,jar_file])
    logging.debug(cmd)
    #logging.debug(appName)
    #logging.debug(cmd)
    #logging.debug(f_log)
    import subprocess
    with open(f_log,"w") as out:
        # 1: non-blocking (default), 0: blocking mode 
        if get_args().no_block:
            subprocess.Popen(cmd,shell=True, stdin=None, stdout=out, stderr=out)
        else:
            subprocess.call(cmd,shell=True, stdin=None, stdout=out, stderr=out)

def get_ts_from_epoch(epoch_time):
    return datetime.fromtimestamp(int(epoch_time)/1000.0)
    
if __name__ == "__main__":
    main()
    if not get_args().kill_only:  # skip re-entry
        udf_exit(RC_SUCCESS,sparkRun=1,kw_id=get_args().classNames)
