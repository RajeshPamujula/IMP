#!/opt/python3/bin/python
# coding: utf-8

'''
  Usage   :        spark-submit regression_loadOutput.py -h
  Author  :        Jun Dai (189485)
  Created :        2020-03-25
  Desc    :
  -t Kafka topic name
  -f the output file to write
  -s pgsql table names
  -x pgsql column filter         - pg table columns which to be excluded 
  -y kafka message filter        - kafka key:value pair to be excluded
  Example :
  spark-submit regression_loadOutput.py -c SparkClassName -t topic_names -f output/SparkClassName_Actual.json  -y key1,key2
  spark-submit regression_loadOutput.py -c SparkClassName -s table_names -f output/SparkClassName_Actual.json -x col_1,col_2
'''

from datetime import datetime
import psycopg2
import argparse
import json
import os,sys,logging
from kafka import KafkaConsumer
from utilities import *

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', action='store', dest='spark_cls_name',
                        help="spark job class name", required=True)
    parser.add_argument('-t', action='store', dest='topics',
                        help="topic name", required=False)
    parser.add_argument('-f', action='store', dest='json_file',
                        help="the output file to write", required=True)
    parser.add_argument('-s', action='store', dest='pg_tbls',
                        help="pgsql tables", required=False)
    parser.add_argument('-x', action='store', dest='pg_filter',
                        help="pgsql table field filter", required=False)
    parser.add_argument('-y', action='store', dest='kaf_filter',
                        help="kafka msg filter", required=False)
    args = parser.parse_args()
    return args    

def obj2jsonConverter(obj):
    if isinstance(obj, datetime):
        return obj.__str__()
    else:
        #by default try to use __str__
        return obj.__str__()

def get_PgSQLConn(pg_user, pg_pwd, host, port, database):
    conn = psycopg2.connect(user=pg_user, password=pg_pwd, host=host, port=port, database=database)
    conn.set_client_encoding('UTF8')
    conn.autocommit = True
    return conn
    
class KafkaReader(object):
    def __init__(self, topic_name, bootstrap_servers):
        self.bootstrap_servers = bootstrap_servers
        self.topic_name = topic_name
        
    def fetch(self):
        consumer = KafkaConsumer(self.topic_name,bootstrap_servers=self.bootstrap_servers,enable_auto_commit=False, auto_offset_reset='earliest',consumer_timeout_ms=2000, security_protocol='SASL_PLAINTEXT', sasl_mechanism='GSSAPI', sasl_kerberos_service_name='kafka',value_deserializer=lambda m: json.loads(m.decode('utf-8')))
        for message in consumer:
            yield message.value
        consumer.close()

class PostgresReader(object):
    def __init__(self, pg_conn, sql_text):
        self.pg_conn = pg_conn
        self.sql_text = sql_text

    def fetch(self):
        with self.pg_conn.cursor() as cur:
            try:
                cur.execute(self.sql_text)
            except Exception as e:
                logging.error("Couldn't execute query: {}".format(self.sql_text))
                logging.error("Reason being:", e)
            logging.debug(cur.description)
            cols = [x[0] for x in cur.description]
            for row in cur:
                r = {}
                for k,v in zip(cols, row):
                    # add bytes handling
                    if isinstance(v,memoryview):
                        v = bytes(v).decode("utf-8")
                    r[k] = v
                yield r
    def run(self):
        with self.pg_conn.cursor() as cur:
            try:
                cur.execute(self.sql_text)
            except Exception as e:
                logging.error("Couldn't execute query: {}".format(self.sql_text))
                logging.error("Reason being:", e)
                
class FileWriter(object):
    def __init__(self, file_path):
        self.f = open(file_path, 'w+',encoding="utf-8")

    def __del__(self):
        if not self.f.close():
            self.f.close()
            self.f = None
    def write_str(self, str_t):
        self.f.write(str_t)
        
    def write_json(self, json_str):
        json.dump(json_str,self.f,indent=2,default = obj2jsonConverter)


def main():
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(level=logging.INFO, format=FORMAT)
    
    args = get_args()

    # create test result table in sqlite3 DB (local: output/test_result.db)
    createTestResultTable()
    
    try:
        kafka_brokers = os.environ["KAFKA_BROKER_HOST"]
        bootstrap_srv=kafka_brokers.split(',')
        pg_uid             = os.environ["PG_USER"]
        pgsql_conn_str     = os.environ["PG_CONN_URL"]
        jks_path           = r'jceks://' + os.environ["PG_PWD_FILE"]
        alias_name         = os.environ["PG_PWD_ALIAS"]
        REG_PG_SCHEMA      = os.environ["REG_PG_SCHEMA"]
    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        addTestResultRow(loadOutput=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
    
    # postgreSQL
    if '' in [pg_uid,pgsql_conn_str,jks_path,alias_name]:
        logging.error('Error: PostgreSQL config is missing, check your ENV setting!')
        addTestResultRow(loadOutput=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
    
    host = pgsql_conn_str.split(':')[2][2:]
    port = pgsql_conn_str.split(':')[3].split('/')[0]
    pg_db = pgsql_conn_str.split(':')[3].split('/')[1]
    
    
    # define output file for writing
    wrt = FileWriter(args.json_file)
    json_obj = {}
    # Kafka Output
    if args.topics is not None and args.topics.strip() != "":
        # create topics
        kaf_msg_list = []
        topic_list = [ x.strip() for x in args.topics.split(',') if x]        
        for topic in topic_list:
            topic_msg_list = []
            kaf = KafkaReader(topic, bootstrap_srv)
            for msg in kaf.fetch():
                # add kafka msg filter
                if args.kaf_filter is not None and args.kaf_filter.strip() != "":
                    kaf_filter = [ x.strip() for x in args.kaf_filter.split(',') if x]
                    rmDictKey(msg,kaf_filter)
                topic_msg_list.append(msg)
            # add schema {"name": "topic_name", "data":"data"}
            kaf_msg_list.append({"name":topic,"data":topic_msg_list})
            
        if kaf_msg_list:
            json_obj["Kafka_Output"] = kaf_msg_list
  
    # PostgreSQL Output
    if args.pg_tbls is not None and args.pg_tbls.strip() != "":
        # To retrieve the passwd from jave keystore
        # java keystore
        # cmd to create jceks:    "hadoop credential create postgres.password.alias -provider jceks:/path/to/postgres.password.jceks"
        # jks_path = "jceks://[hdfs|file]/path/to/postgres.password.jceks"
        # alias_name = "postgres.password.alias"
        uid = os.getenv("USER")
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.master("local").appName(uid+"_tm_regression_prepare").getOrCreate()
        x = spark.sparkContext._jsc.hadoopConfiguration()
        x.set("hadoop.security.credential.provider.path", jks_path)
        passwd_b = x.getPassword(alias_name)
        if not passwd_b:
            logging.error('Failed to retrieve pgsql password!')
            addTestResultRow(loadOutput=0,kw_id=args.spark_cls_name)
            exit(RC_ERROR)
        passwd = ""
        for i in range(passwd_b.__len__()):
            passwd = passwd + str(passwd_b.__getitem__(i))
            
        # create pgsql connection
        pg_conn = get_PgSQLConn(pg_uid, passwd, host, port, pg_db)
        pg_tbl_list = [ x.strip() for x in args.pg_tbls.split(',')]
        pg_msg_list = []
        for pg_tbl in pg_tbl_list:
            # apply column filter - exclude specific columns
            # PostgreSQL syntax "DROP COLUMN IF EXISTS"
            tbl_msg_list = []
            stmt_schema = "SET search_path TO {};".format(REG_PG_SCHEMA)
            if args.pg_filter is not None and args.pg_filter.strip() != "":
                pg_col_filter = [ "DROP COLUMN IF EXISTS "+x.strip() for x in args.pg_filter.split(',')]
                filter_stmt = ','.join(pg_col_filter)
                pg_stmt = """SELECT * INTO temp_{0} FROM {0};
                           ALTER TABLE temp_{0} {1};
                           SELECT * FROM temp_{0}""".format(pg_tbl,filter_stmt)
                pg_stmt = stmt_schema + pg_stmt
                logging.debug(pg_stmt)
                pg_reader = PostgresReader(pg_conn, pg_stmt)
                for record in pg_reader.fetch():
                    tbl_msg_list.append(record)
                    
                # clean-up    
                pg_stmt = "DROP TABLE IF EXISTS temp_{0};".format(pg_tbl)
                PostgresReader(pg_conn, pg_stmt).run()
            else:
                pg_stmt = "SELECT * FROM {}".format(pg_tbl)
                pg_stmt = stmt_schema + pg_stmt
                logging.debug(pg_stmt)
                pg_reader = PostgresReader(pg_conn, pg_stmt)            
                for record in pg_reader.fetch():
                    tbl_msg_list.append(record)
            # add schema {"name": "table_name", "data":"data"}    
            pg_msg_list.append({"name":pg_tbl.lower(),"data":tbl_msg_list})
            
        if pg_msg_list:
            json_obj["PostgreSQL_Output"] = pg_msg_list
    
    if(json_obj):
        wrt.write_json(json_obj)
    else:
        logging.error('Failed to get any output result!')
        addTestResultRow(loadOutput=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
        
if __name__ == "__main__":
    main()
    udf_exit(RC_SUCCESS,loadOutput=1,kw_id=get_args().spark_cls_name)
    