#!/opt/python3/bin/python
# coding: utf-8

'''
  Usage   :        python regression_compare.py -h 
  Author  :        Jun Dai (189485)
  Created :        2020-03-26
  Desc    :
  -s source json file to compare - expected output
  -t target json file to compare - actual output
  -x pgsql column filter         - pg table columns which to be excluded 
  -y kafka message filter        - kafka key:value pair to be excluded
  Example :
  python regression_compare.py -c SparkClassName -s SparkClassName_Expect.json -t SparkClassName_Actual.json
  python regression_compare.py -c SparkClassName -s SparkClassName_Expect.json -t SparkClassName_Actual.json -x col_1,col_2
  python regression_compare.py -c SparkClassName -s SparkClassName_Expect.json -t SparkClassName_Actual.json -y key1,key2
  
'''

import argparse
import json
import os,sys,logging
import pandas as pd
from pandas.io.json import json_normalize  
from utilities import *


RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR_COUNT = 2
RC_ERROR_SCHEMA = 3
RC_ERROR_VALUE =4
diff = None

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', action='store', dest='spark_cls_name',
                        help="spark job class name", required=True)
    parser.add_argument('-s', action='store', dest='file_exp',
                        help="source json file to compare", required=True)
    parser.add_argument('-t', action='store', dest='file_act',
                        help="target json file to compare", required=True)
    parser.add_argument('-x', action='store', dest='pg_filter',
                        help="pgsql table field filter", required=False)
    parser.add_argument('-y', action='store', dest='kaf_filter',
                        help="kafka msg filter", required=False)
    args = parser.parse_args()
    return args

def ordered(obj):
    if isinstance(obj, dict):
        return sorted((k, ordered(v)) for k, v in obj.items() if v is not None)
    if isinstance(obj, list):
        return sorted(ordered(x) for x in obj if x is not None)
    else:
        return obj
        
def compare_object(a,b):
    if type(a) != type (b):
        return False
    elif type(a) is dict:
        return compare_dict(a,b)
    elif type(a) is list:
        return compare_list(a,b)
    else:
        return a == b

def compare_dict(a,b):
    if len(a) != len(b):
        return False
    else:
        for k,v in a.items():
            if not k in b:
                return False
            else:
                if not compare_object(v, b[k]):
                    return False
    return True
    
def compare_list(a,b):
    global diff
    if len(a) != len(b):
        return False
    else:
        for i in range(len(a)):
            if not compare_object(a[i], b[i]):
                if(type(b[i]) is tuple):
                    diff = (a[i],b[i])
                return False
    return True

def read_json(file):
    with open(file) as fp:
        json_obj = json.load(fp)
        if isinstance(json_obj, dict) or isinstance(json_obj, list):
            return json_obj
        else:
            logging.error("Failed to read, unknow format.")
            addTestResultRow(test_count=0,kw_id=args.spark_cls_name)
            exit(RC_ERROR)
        
# Aux func to display file content
def print_json(file):
    with open(file) as fp:
        json_obj = json.load(fp)
    if isinstance(json_obj, dict) or isinstance(json_obj, list):
        logging.info("File Name: " + file)
        logging.info("\n"+json.dumps(json_obj, indent = 2, sort_keys=True))
    else:
        logging.error("Failed to print, unknow format.")


def diff_list(list1,list2):
    return (list(set(list1) - set(list2)))

           
def main():
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(level=logging.INFO, format=FORMAT)
    
    args = get_args()
    
    # create test result table in sqlite3 DB (local: output/test_result.db)
    createTestResultTable()

    # Print the content of files   
    #print_json(args.file_exp)
    #print_json(args.file_act)
    
    # load file
    json_exp = read_json(args.file_exp)
    json_act = read_json(args.file_act)
    
    # apply filter
    if args.pg_filter is not None and args.pg_filter.strip() != "":
        pg_filter = [ x.strip() for x in args.pg_filter.split(',') if x]
        rmDictKey(json_exp,pg_filter)
        
    if args.kaf_filter is not None and args.kaf_filter.strip() != "":
        kaf_filter = [ x.strip() for x in args.kaf_filter.split(',') if x]
        rmDictKey(json_exp,kaf_filter)

    cmp_keys = ['Kafka_Output','PostgreSQL_Output']
    for key in cmp_keys:
        if key in json_exp.keys():
            # convert json to pandas dataframe
            pdf_1 = json_normalize(json_exp[key])
            pdf_2 = json_normalize(json_act[key])
            if(pdf_1.shape != pdf_2.shape):
                if(pdf_1.shape[0] != pdf_2.shape[0]):
                    logging.error("Test is failed for "+ key +", expected result and actual result have different count.")
                    addTestResultRow(test_count=0,kw_id=args.spark_cls_name)
                    exit(RC_ERROR_COUNT)
                else:
                    logging.error("Test is failed, expected result and actual result have different schema.")
                    addTestResultRow(test_count=1,test_schema=0,kw_id=args.spark_cls_name)
                    exit(RC_ERROR_SCHEMA)
                    
            # validate the json values 
            if ordered(json_exp[key]) != ordered(json_act[key]):
                compare_object(ordered(json_exp[key]),ordered(json_act[key]))
                logging.debug(ordered(json_exp[key]))
                logging.debug(ordered(json_act[key]))
                logging.error("Test is failed, expected result and actual result have different values.")
                #print("\nExpected Result:"+"+"*100+"\n")
                #print(diff[0])
                #print("\nActual Result:"+"-"*100+"\n")
                #print(diff[1])
                if(diff):
                    addTestResultRow(test_count=1,test_schema=1,test_value=0,expect_value="\""+str(diff[0])+"\"",actual_value="\""+str(diff[1])+"\"",kw_id=args.spark_cls_name)
                else:
                    addTestResultRow(test_count=1,test_schema=1,test_value=0,kw_id=args.spark_cls_name)
                exit(RC_ERROR_VALUE)

        
if __name__ == "__main__":
    main()
    logging.info("Test is passed, expected result and actual result are identical.")
    addTestResultRow(test_count=1,test_schema=1,test_value=1,expect_value="''",actual_value="''",kw_id=get_args().spark_cls_name)
    exit(RC_SUCCESS)
