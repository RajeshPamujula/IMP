#!/opt/python3/bin/python
# coding: utf-8

'''
  Usage   :        spark-submit regression_prepare.py -h
  Author  :        Jun Dai (189485)
  Created :        2020-03-18
  Desc    :
  -tp Kafka topic name
  -pg the output file to write
  Example :
  spark-submit regression_prepare.py -c SparkClassName -tp topic_names
  spark-submit regression_prepare.py -c SparkClassName -tp topic_names -pg table_names
'''

import psycopg2
import collections
import pandas as pd
from datetime import datetime
import time
import argparse
import os,sys,logging
import subprocess
import kafka
from kafka.admin import KafkaAdminClient, NewTopic
from utilities import *

RC_SUCCESS = 0
RC_WARNING = 1
RC_ERROR = 2

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', action='store', dest='spark_cls_name',
                        help="spark job class name", required=True)
    parser.add_argument('-tp', action='store', dest='topics',
                        help="name of topics to be created", required=False)
    parser.add_argument('-pg', action='store', dest='pg_tbls',
                        help="the postgres tables to created", required=False)
    args = parser.parse_args()
    return args    

args = get_args() 
    
def main():
    FORMAT = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=FORMAT)
    
    # create test result table in sqlite3 DB (local: output/test_result.db)
    createTestResultTable()
   
    try:
        pg_uid             = os.environ["PG_USER"]
        pgsql_conn_str     = os.environ["PG_CONN_URL"]
        jks_path           = r'jceks://' + os.environ["PG_PWD_FILE"]
        alias_name         = os.environ["PG_PWD_ALIAS"]
        kafka_brokers      = os.environ["KAFKA_BROKER_HOST"]
        RL_PATH            = os.environ["RL_PATH"]
        REF_DATA_DIR       = os.environ["REG_REFERENCE_DATA_DIR"]
        REG_SCRATCH_DIR    = os.environ["REG_SCRATCH_DIR"]
        REG_CHKPT_DIR      = os.environ["REG_CHKPT_DIR"]
        REG_PG_SCHEMA      = os.environ["REG_PG_SCHEMA"]
        PG_DDL_PATH        = "../../postgresql/tables/"
    except KeyError as e:
        logging.error("ERROR: Variable '{}' from the ENV_.sh cannot be resolved".format(e.args[0]))
        addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
    
    # validate HDFS dir
    validate_hdfs_dir(REF_DATA_DIR,REG_CHKPT_DIR)
    
    # validate Local dir
    validate_local_dir(REG_SCRATCH_DIR)
    
    # postgreSQL
    if '' in [pg_uid,pgsql_conn_str,jks_path,alias_name]:
        logging.error('Error: PostgreSQL config is missing, check your ENV setting!')
        addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
    
    host = pgsql_conn_str.split(':')[2][2:]
    port = pgsql_conn_str.split(':')[3].split('/')[0]
    pg_db = pgsql_conn_str.split(':')[3].split('/')[1]
    
   
    # prepare kafka env
    if args.topics is not None:
        # create topics
        topic_list = [ x.strip() for x in args.topics.split(',')]
        ret = [create_topic(x,kafka_brokers) for x in topic_list if x]
        if sum(ret) > 0:
            err_ret = zip(topic_list,ret)
            logging.error("Topic(s) below is not created properly: {}".format(str([x[0] for x in err_ret if x[1] == 1])))
            addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
            exit(RC_ERROR)
    
    # prepare postgres env
    if args.pg_tbls is not None:
        # To retrieve the passwd from jave keystore
        # java keystore
        # cmd to create jceks: "hadoop credential create postgres.password.alias -provider jceks:/path/to/postgres.password.jceks"
        # jks_path = "jceks://[hdfs|file]/path/to/postgres.password.jceks"
        # alias_name = "postgres.password.alias"
        uid = os.getenv("USER")
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.master("local").appName(uid+"_tm_regression_prepare").getOrCreate()
        x = spark.sparkContext._jsc.hadoopConfiguration()
        x.set("hadoop.security.credential.provider.path", jks_path)
        passwd_b = x.getPassword(alias_name)
        if not passwd_b:
            logging.error(os.path.basename(__file__) + ' Failed to retrieve pgsql password!')
            addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
            exit(RC_ERROR)        
        passwd = ""
        for i in range(passwd_b.__len__()):
            passwd = passwd + str(passwd_b.__getitem__(i))        
            
        # read the DDL file then run
        pg_tbl_list = [ x.strip() for x in args.pg_tbls.split(',')]
        try:
            for pg_tbl in pg_tbl_list:
                # naming convention table_Name.sql
                sql_fp = PG_DDL_PATH + pg_tbl + '.sql'
                logging.debug("Creating table: {}".format(sql_fp))
                with open(sql_fp) as fp:
                    ddl = fp.read()
                    stmt_schema = "SET search_path TO {};".format(REG_PG_SCHEMA)
                    # note: the Linux user name maybe different from the schema name.
                    if os.getenv("USER").lower() in ['ihl_dev_rm', 'ihl_prd_rm']:
                        stmt_schema += "SET ROLE {}_admin;".format(REG_PG_SCHEMA.lower())
                    ddl = stmt_schema + ddl
                    logging.debug(ddl)
                    create_table(pg_uid,passwd,host,port,pg_db,ddl)
        except FileNotFoundError as e:
            logging.error(os.path.basename(__file__) + " " + str(e))
            addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
            exit(RC_ERROR)
    
    
def create_topic(topic_name,bootstrap_srv):
    #KAFKA_BROKER_HOST="mtl-emp02d.cn.ca:6667,mtl-emp03d.cn.ca:6667,mtl-emp04d.cn.ca:6667"
    admin_client = KafkaAdminClient(bootstrap_servers=bootstrap_srv,sasl_mechanism='GSSAPI', sasl_kerberos_service_name='kafka',security_protocol='SASL_PLAINTEXT')
    topic_list = []
    topic_list.append(NewTopic(name=topic_name, num_partitions=3, replication_factor=3))
    try:
        admin_client.create_topics(new_topics=topic_list, validate_only=False)
        return 0
    # delete the topic if exists
    except kafka.errors.TopicAlreadyExistsError as e:
        logging.warning("Prepare: Topic {} exists, delete it first.".format(topic_name))
        try:
            admin_client.delete_topics([topic_name], timeout_ms=None)
            time.sleep(10)  # wait 5s to let topic deletion finish
            admin_client.create_topics(new_topics=topic_list, validate_only=False)
            return 0
        except:
            logging.error("Failed to create topic: {}".format(topic_name))
            return 1
    except:
        logging.error("Unexpected error: {}".format(sys.exc_info()[0]))
        return 1
        

def create_table(user,passwd,host,port,db,ddl):
    # establish connection
    conn = psycopg2.connect(database=db,user=user,password=passwd,host=host,port=port)
    conn.autocommit = True
    logging.info("Database is connected!")
    
    # define a cursor
    cur = conn.cursor()
    try:
        cur.execute(ddl)
    except psycopg2.Error as e:
        logging.debug('Failed to execute Postgres DDL.\n{0}'.format(ddl))
        logging.error(os.path.basename(__file__) + " " + str(e))
        addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)
    finally:
        conn.close()

def create_spark_conf(RL_PATH,ENV):
    script=os.path.join(RL_PATH,r'scripts/deployment/deploy_spark_env.sh')
    cmd = "bash " + script + " " + os.getenv("USER") + " " + ENV
    ret = subprocess.call(cmd,shell=True)
    if ret:
        logging.error(os.path.basename(__file__) + " Failed to create spark.conf.")
        addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
        exit(RC_ERROR)

def validate_topic(topics,bootstrap_srv):
    consumer = kafka.KafkaConsumer(group_id='reg-test', bootstrap_servers=bootstrap_srv,sasl_mechanism='GSSAPI', sasl_kerberos_service_name='kafka',security_protocol='SASL_PLAINTEXT')
    # fetch all topics that user is authorised to view
    all_topics = consumer.topics()
    for topic in topics:
        if topic in all_topics:
            logging.info("Topic: "+topic+" is found in Kafka cluster.")
        else:
            logging.error("Topic: "+topic+" is NOT found in Kafka cluster.")
            addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
            exit(RC_ERROR)

def validate_hdfs_dir(*argv):
    for hdfs_dir in argv:
        status = subprocess.call("hadoop fs -test -e {}".format(hdfs_dir), shell=True)
        if(status):
            logging.warn("HDFS directory {} does NOT exist.".format(hdfs_dir))
            status = subprocess.call("hadoop fs -mkdir -p {}".format(hdfs_dir), shell=True)
            if(status):
                logging.error("Failed to create HDFS folder: '{}'".format(hdfs_dir))
                addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
                exit(RC_ERROR)
        else:
            logging.info("HDFS directory {} does exist.".format(hdfs_dir))
            
def validate_local_dir(*argv):
    for local_dir in argv:
        if not os.path.isdir(local_dir):
            logging.warn("Local directory {} does NOT exist.".format(local_dir))
            try:
                os.makedirs(local_dir)
            except:
                logging.error("Failed to create local folder: '{}'".format(local_dir))
                addTestResultRow(prepare=0,kw_id=args.spark_cls_name)
                exit(RC_ERROR)
        else:
            logging.info("Local directory {} does exist.".format(local_dir))

if __name__ == "__main__":
    main()
    udf_exit(RC_SUCCESS,prepare=1,kw_id=get_args().spark_cls_name)

    